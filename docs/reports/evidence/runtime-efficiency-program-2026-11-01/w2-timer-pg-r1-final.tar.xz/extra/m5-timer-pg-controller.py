import json,os,pathlib,pwd,subprocess,sys,time,datetime,hashlib
b=pathlib.Path('/home/elsarunner/elsa-runtime-efficiency-20261101-i67');series=sys.argv[1];cases=json.loads(sys.argv[2])
d=b/series;d.mkdir();u=pwd.getpwnam('elsarunner');os.chown(d,u.pw_uid,u.pw_gid)
conn=(b/'native-fixture-connection').read_text().strip()
env={'PATH':'/usr/bin:/bin','HOME':'/home/elsarunner','DOTNET_ROOT':str(b/'dotnet'),'DOTNET_CLI_TELEMETRY_OPTOUT':'1','ELSA_EFFICIENCY_POSTGRES_CONNECTION':conn}
probe=b/'timer-profile/Probe';ledger=[];ok=True
hashes={n:hashlib.sha256((b/'timer-profile'/n).read_bytes()).hexdigest() for n in ['Probe.dll','Elsa.Workflows.Runtime.dll','Elsa.Workflows.Runtime.Core.dll','Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.dll','Elsa.Workflows.Runtime.Scheduling.dll'] if (b/'timer-profile'/n).exists()}
for c in cases:
 assert 'NTPSynchronized=yes' in subprocess.run(['timedatectl','show','-p','NTPSynchronized'],capture_output=True,text=True).stdout
 others=subprocess.run(['pgrep','-f','native-6d77c4402|workbench/|boundary/'],capture_output=True,text=True).stdout.strip()
 assert not others,'Overlapping owned workload'
 label=c['label'];cfg=d/(label+'.config.json');cfg.write_text(json.dumps({'Output':str(d/label),'Provider':c.get('provider','PostgreSql'),'Mode':c['mode'],'Count':c['count'],'Degree':c['degree']}));cfg.chmod(0o644)
 load=os.getloadavg();t0=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with open(d/(label+'.log'),'w') as log:
  p=subprocess.run([str(probe),str(cfg)],cwd=str(d),env=env,stdout=log,stderr=subprocess.STDOUT,user=u.pw_uid,group=u.pw_gid,timeout=600)
 res=d/label/'result.json';r=json.loads(res.read_text()) if res.exists() else None
 row={'label':label,'case':c,'exit':p.returncode,'launchedAt':t0,'loadBefore':load,'correct':bool(r and r['Correct'] and p.returncode==0),'resumesPerSecond':r and r['ResumesPerSecond'],'seconds':r and r['Seconds'],'cpuSeconds':r and r['CpuSeconds'],'allocatedBytesPerResume':r and r['AllocatedBytesPerResume'],'peakWorkingSet':r and r['PeakWorkingSet'],'startedAt':r and r['startedAt'],'endedAt':r and r['endedAt'],'resultSha256':hashlib.sha256(res.read_bytes()).hexdigest() if res.exists() else None,'binaryHashes':hashes}
 ledger.append(row);ok=ok and row['correct'];(d/'ledger.json').write_text(json.dumps(ledger,indent=1))
 if not row['correct']:break
 time.sleep(c.get('pauseAfter',5))
(d/'finished').write_text('passed' if ok and len(ledger)==len(cases) else 'failed')
