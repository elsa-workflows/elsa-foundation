import pathlib,os,json,subprocess,time,secrets,pwd,socket,hashlib,urllib.request,shutil,traceback,sys
base=pathlib.Path('/home/elsarunner/elsa-runtime-efficiency-20261101-i67');root=base/'final-qualification-63e4c1fc4-r2';src=base/'m4-pumps-63e4c1fc4/source';art=root/'artifacts-functional-r2';case=json.loads(pathlib.Path(sys.argv[1]).read_text());run=root/case['label'];run.mkdir();user=pwd.getpwnam('elsarunner');uid=user.pw_uid;gid=user.pw_gid;pw=json.loads((root/'qualification-connection.json').read_text())['password'];host=None;iostat=None
state={'status':'running','phase':'preflight','libraryHead':'63e4c1fc48be2b99505f0c26eb2aae46ff2c5d26','driverCommit':'6d77c4402','timingEligible':False,'protocol':'Single traced Http4 request with five-second before/request-tail/after EF observation phases; no timing claim','configuration':case}
env=os.environ.copy();env.update(DOTNET_ROOT=str(base/'dotnet'),PATH=str(root/'tools/privacy')+':'+str(base/'dotnet')+':'+env['PATH'],DOTNET_CLI_HOME=str(base/'cli-home'),NUGET_PACKAGES=str(base/'packages'),HOME='/home/elsarunner')
def save(): (run/'status.json').write_text(json.dumps(state,indent=2))
def command(label,args,asuser=False,timeout=1800):
 state['phase']=label;save()
 with (run/(label+'.log')).open('w') as log:
  p=subprocess.run(args,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,**({'user':uid,'group':gid,'extra_groups':os.getgrouplist('elsarunner',gid)} if asuser else {}))
 if p.returncode: raise RuntimeError(label+' failed: '+str(p.returncode))
try:
 assert json.loads((root/'privacy-preflight-status.json').read_text())['status']=='passed'
 assert json.loads((root/'diagnostics-preflight-4/status.json').read_text())['status']=='passed'
 # Two quiet-host observations; host builds and other timing series must not overlap.
 observations=[]
 for quiet in range(2):
  load=[float(x) for x in pathlib.Path('/proc/loadavg').read_text().split()[:2]];observations.append({'time':time.time(),'load':load});assert max(load)<os.cpu_count(),'Host load exceeds the eight-core qualification guard'
  if quiet==0:time.sleep(30)
 state['quietPreflight']=observations;save()
 name='elsa-efficiency-i67-final-pg';state['container']=name;save()
 command('create-owned-database',['docker','exec',name,'psql','-U','postgres','-X','-c','CREATE DATABASE '+case['database']])
 conn='Host=127.0.0.1;Port=15432;Database='+case['database']+';Username=postgres;Password='+pw
 service=run/'pg_service.conf';service.write_text('[eff_i67]\nhost=127.0.0.1\nport=15432\ndbname='+case['database']+'\nuser=postgres\n');service.chmod(0o600)
 pgpass=run/'pgpass';pgpass.write_text('127.0.0.1:15432:*:postgres:'+pw+'\n');pgpass.chmod(0o600)
 counters=run/'counter-secret.env';counters.write_text('PROTECTED_PASSWORD='+pw+'\nPROTECTED_CONNECTION='+conn+'\n');counters.chmod(0o600)
 env.update(PGSERVICEFILE=str(service),PGPASSFILE=str(pgpass),DOTNET_COUNTERS_REAL=str(root/'tools/counters/dotnet-counters'),COUNTER_PRIVACY_SECRET_FILE=str(counters),COUNTER_PRIVACY_FIFO_ROOT='/run/elsa-efficiency-i67-counters/fifos',COUNTER_PRIVACY_FIFO_HELPER='/run/elsa-efficiency-i67-counters/fifo-helper.py')
 command('postgres-select-one',['psql','service=eff_i67','-X','-At','-c','select 1; show track_wal_io_timing'])
 content=run/'content';content.mkdir();diag=(content/'diagnostics') if case['placement']=='same-device' else pathlib.Path('/mnt/elsa-runtime-efficiency-20261101-i67')/case['label'];diag.mkdir(parents=True)
 if case['placement']=='separate-device':
  parent=pathlib.Path('/mnt/elsa-runtime-efficiency-20261101-i67');assert parent.resolve()==parent and parent.is_dir();parent.chmod(0o755)
 settings=json.loads((src/'Essentials/apps/Elsa.Workbench/appsettings.json').read_text());settings['Elsa']['Persistence']['Resources']={'primary':{'Provider':'PostgreSql','ConnectionName':'EfficiencyRuntime'},'diagnostics':{'Provider':'Sqlite','ConnectionName':'EfficiencyDiagnostics'}};settings['ConnectionStrings']['Elsa']='Data Source='+str(content/'legacy.db');settings['ConnectionStrings']['EfficiencyDiagnostics']='Data Source='+str(diag/'diagnostics.db');settings['Nuplane']['Setup']['AutomaticReconciliation']=False
 (content/'appsettings.json').write_text(json.dumps(settings,indent=2));shells=json.loads((src/'Essentials/apps/Elsa.Workbench/shells.json').read_text());shell=shells['CShells']['Shells']['default'];shell['Configuration']['Elsa']={'Persistence':{'DefaultResource':'primary','Bindings':{'DiagnosticsOpenTelemetryEntityFrameworkCore':'diagnostics','DiagnosticsStructuredLogsEntityFrameworkCore':'diagnostics'}}}
 for feature in ['DiagnosticsOpenTelemetryEntityFrameworkCore','DiagnosticsStructuredLogsEntityFrameworkCore']:shell['Features'][feature]={}
 shell['Features']['GitHubCopilotAgent']['Enabled']=False
 if case['diagnostics']=='Off':
  for feature in ['DiagnosticsOpenTelemetryEntityFrameworkCore','DiagnosticsStructuredLogsEntityFrameworkCore']:shell['Features'].pop(feature)
 (content/'shells.json').write_text(json.dumps(shells,indent=2));(content/'appsettings.Development.json').write_text('{}')
 data=root/'postgres-data'
 command('storage-device-placement',['findmnt','-T',str(data),'-o','SOURCE,TARGET,FSTYPE,OPTIONS','-J']);command('diagnostic-device-placement',['findmnt','-T',str(diag),'-o','SOURCE,TARGET,FSTYPE,OPTIONS','-J'])
 subprocess.run(['chown','-R','--no-dereference','elsarunner:elsarunner',str(run),str(root/'native'),str(diag)],check=True)
 subprocess.run(['runuser','-u','elsarunner','--','python3','-c','import pathlib,sys; p=pathlib.Path(sys.argv[1]); p.open("x").close(); p.unlink()',str(diag/'owned-write-preflight')],check=True)
 port_check=socket.socket();port_check.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);port_check.bind(("127.0.0.1",18183));port_check.close()
 hostenv=env.copy();hostenv.update(ASPNETCORE_ENVIRONMENT='Development',ASPNETCORE_URLS='http://127.0.0.1:18183',ConnectionStrings__EfficiencyRuntime=conn,DOTNET_STARTUP_HOOKS=str(root/'artifacts-8251453ef/diagnostics-attribution/ElsaEfficiencySqlHook.dll'),ELSA_SQL_CAPTURE_OUTPUT=str(run/'sql.jsonl'),ELSA_SQL_CAPTURE_CONTROL=str(run/'capture-control'))
 log=(run/'host.log').open('w');os.chown(run/'host.log',uid,gid);host=subprocess.Popen([str(root/'workbench/Elsa.Workbench'),'--contentRoot',str(content)],cwd=content,env=hostenv,stdout=log,stderr=subprocess.STDOUT,user=uid,group=gid,extra_groups=os.getgrouplist('elsarunner',gid),start_new_session=True);state['hostPid']=host.pid;state['phase']='host-readiness';save();end=time.monotonic()+180
 while True:
  if host.poll() is not None:raise RuntimeError('Owned Workbench exited during startup')
  try:
   with urllib.request.urlopen('http://127.0.0.1:18183/health/ready',timeout=3) as response:
    if response.status==200:state['readiness']=json.load(response);break
  except Exception:pass
  if time.monotonic()>end:raise RuntimeError('Owned Workbench readiness expired')
  time.sleep(2)
 command('capture-attribution',[str(root/'tools/pwsh/pwsh'),'-NoProfile','-File',str(root/'artifacts-8251453ef/diagnostics-attribution/Capture.ps1'),'-BaseUrl','http://127.0.0.1:18183','-CandidateSha',state['libraryHead'],'-ReferenceScript',str(art/'e2e-tests/http/Capture-RuntimeDbPaging2392Reference.ps1'),'-ControlPath',str(run/'capture-control'),'-OutputPath',str(run/'request-receipt.json'),'-PersistenceMode',case['mode']],asuser=True,timeout=600)
 host.terminate();host.wait(timeout=30);state['hostStopped']=True
 receipt=json.loads((run/'sql.jsonl.receipt.json').read_text());records=[json.loads(x) for x in (run/'sql.jsonl').read_text().splitlines()];assert receipt['complete'] and receipt['dropped']==0 and receipt['errorType'] is None and receipt['rows']==len(records) and not any(x['sqlTruncated'] for x in records)
 request=json.loads((run/'request-receipt.json').read_text());marked=[x for x in records if x['traceId']==request['traceId']];assert any(x['kind']=='CommandExecuted' for x in marked),'The marked HTTP trace did not correlate with physical EF commands'
 from collections import defaultdict
 groups=defaultdict(lambda:{'events':0,'durationMilliseconds':0})
 for row in records:
  key=(row['phase'],row['contextType'],row['kind'],row['traceId']==request['traceId']);groups[key]['events']+=1;groups[key]['durationMilliseconds']+=row['durationMilliseconds'] or 0
 summary=[dict(phase=k[0],contextType=k[1],kind=k[2],markedTrace=k[3],**v) for k,v in groups.items()]
 assert not any(x['kind']=='CommandError' for x in records),'Observed SQL errors invalidate attribution'
 (run/'attribution-summary.json').write_text(json.dumps({'request':request,'receipt':receipt,'groups':summary,'timingEligible':False,'hookCommit':'e3e8702da','captureCommit':'8251453ef'},indent=2));state.update(status='passed',phase='complete',recordedEvents=len(records),markedTraceEvents=len(marked),completedInstances=request['completedInstances'])
except Exception as e:state.update(status='failed',errorType=type(e).__name__,error=str(e).replace(pw,'<fixture-password>'));(run/'driver-error.log').write_text(traceback.format_exc().replace(pw,'<fixture-password>'))
finally:
 if iostat is not None:
  iostat.terminate();iostat.wait(timeout=10)
 if host is not None:
  host.terminate()
  try:host.wait(timeout=30)
  except subprocess.TimeoutExpired:host.kill();host.wait()
  state['hostStopped']=True
 for pattern in ['*.log','*.json']:
  for path in run.rglob(pattern):
   text=path.read_text(errors='replace')
   if pw in text:path.write_text(text.replace(pw,'<fixture-password>'))
 save();(run/'finished').write_text(state['status'])
