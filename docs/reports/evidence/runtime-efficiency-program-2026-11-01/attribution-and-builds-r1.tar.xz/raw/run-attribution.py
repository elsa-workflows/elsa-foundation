import pathlib,json,subprocess,time
r=pathlib.Path('/home/elsarunner/elsa-runtime-efficiency-20261101-i67/final-qualification-63e4c1fc4-r2');end=time.monotonic()+180
while not (r/'capacity-schema-r1/finished').exists():
 if time.monotonic()>end:raise TimeoutError('Schema primer did not finish')
 time.sleep(2)
assert (r/'capacity-schema-r1/finished').read_text()=='passed'
ledger=[]
for diag in ['On','Off']:
 label='attribution-'+diag.lower()+'-r1';case={'label':label,'database':'eff_i67_'+label.replace('-','_'),'mode':'Balanced','diagnostics':diag,'placement':'same-device'};path=r/(label+'.json');path.write_text(json.dumps(case))
 with (r/(label+'-driver.log')).open('w') as log:p=subprocess.run(['python3',str(r/'attribution-case.py'),str(path)],stdout=log,stderr=subprocess.STDOUT,timeout=900)
 state=json.loads((r/label/'status.json').read_text());ledger.append({'case':label,'exit':p.returncode,'state':state});(r/'attribution-status.json').write_text(json.dumps(ledger,indent=2))
 if p.returncode or state['status']!='passed':break
(r/'attribution-finished').write_text('passed' if len(ledger)==2 and all(x['state']['status']=='passed' for x in ledger) else 'failed')
