import pathlib,json,subprocess,os,time,hashlib,tarfile,traceback
b=pathlib.Path('/home/elsarunner/elsa-runtime-efficiency-20261101-i67');r=b/'final-qualification-63e4c1fc4-r2';out=r/'baseline-validation-build-r5';out.mkdir();state={'status':'running','phase':'waiting-for-attribution','scope':'Only post-measurement physical outbox validation in baseline native start-only qualification driver; baseline execution code unchanged'}
def save():(out/'status.json').write_text(json.dumps(state,indent=2))
try:
 end=time.monotonic()+1800
 while not (r/'attribution-r2-finished').exists():
  if time.monotonic()>end:raise TimeoutError('Attribution did not finish before build')
  time.sleep(2)
 baseline=r/'paired-baseline-ab46bc22a';driver=baseline/'specs/1183-runtime-efficiency-program/evidence/native-qualification/Program.cs';old=driver.read_text();needle='var sourceItem = await stores.GetRequiredService<IPostCommitOutboxLookupStore>().FindDurableAsync(sourceId);';assert needle in old;driver.with_name('Program.before-physical-lookup.cs.txt').write_text(old);patched=old.replace(needle,'var sourceItem = await stores.GetRequiredService<InMemoryRuntimeCheckpointCommitStore>().FindAsync(sourceId);');driver.write_text(patched);state.update(phase='publish-baseline-validation',beforeSha256=hashlib.sha256(old.encode()).hexdigest(),afterSha256=hashlib.sha256(patched.encode()).hexdigest());save()
 env=os.environ.copy();env.update(DOTNET_ROOT=str(b/'dotnet'),PATH=str(b/'dotnet')+':'+env['PATH'],DOTNET_CLI_HOME=str(b/'cli-home'),NUGET_PACKAGES=str(b/'packages'))
 with (out/'publish.log').open('w') as log:p=subprocess.run([str(b/'dotnet/dotnet'),'publish',str(driver.with_name('Probe.csproj')),'-c','Release','-r','linux-x64','--self-contained','true','-o',str(r/'baseline-native-validation-r5')],env=env,cwd=baseline,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
 assert p.returncode==0
 hashes={name:hashlib.sha256((r/'baseline-native-validation-r5'/name).read_bytes()).hexdigest() for name in ['Elsa.Workflows.Runtime.dll','Elsa.Workflows.Runtime.Core.dll','Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.dll']};assert all(value==hashlib.sha256((r/'baseline-native-compat-r3'/name).read_bytes()).hexdigest() for name,value in hashes.items());state['productionLibraryHashes']=hashes
 owner=json.loads((b/'final-share/owner.json').read_text());archive=b/'final-share'/owner['slug']/'baseline-native-validation-r5-linux-x64.tar.gz';assert not archive.exists()
 with tarfile.open(archive,'w:gz',compresslevel=1) as t:t.add(r/'baseline-native-validation-r5',arcname='baseline-native-validation-r5')
 state.update(status='passed',phase='ready',package={'blob':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()})
except Exception as e:state.update(status='failed',errorType=type(e).__name__,error=str(e));(out/'error.log').write_text(traceback.format_exc())
finally:save();(out/'finished').write_text(state['status'])
