$ErrorActionPreference = 'Stop'
$params = Get-Content -LiteralPath '/home/elsarunner/elsa-runtime-efficiency-20261101-i67/final-qualification-63e4c1fc4-r2/diag-durable-on-separate-r2/capture-parameters.json' -Raw | ConvertFrom-Json -AsHashtable
& '/home/elsarunner/elsa-runtime-efficiency-20261101-i67/final-qualification-63e4c1fc4-r2/artifacts-functional-r2/e2e-tests/http/Capture-RuntimeThroughputRamp.ps1' @params
