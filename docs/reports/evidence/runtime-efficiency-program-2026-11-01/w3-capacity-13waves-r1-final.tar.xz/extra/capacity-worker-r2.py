"""Finite independent-host qualification controller; input plan and binary hashes are retained by the operator."""
import pathlib,json,os,subprocess,time,datetime,pwd,hashlib,traceback,signal,re,sys
plan_path=pathlib.Path(sys.argv[1]);plan=json.loads(plan_path.read_text());name=plan['worker'];base=pathlib.Path('/home/elsarunner/elsa-runtime-efficiency-20261101-i67');root=base/plan['label'];root.mkdir();root.chmod(0o755);user=pwd.getpwnam('elsarunner');uid=user.pw_uid;gid=user.pw_gid;ledger=[];active=None
assert re.fullmatch(r'[a-z0-9-]{1,100}',plan['label']) and 1<=len(plan['cases'])<=24
secret=(base/'native-fixture-connection').read_text();env=os.environ.copy();env.update(HOME='/home/elsarunner');deadline=time.monotonic()+7200
def utc(value):return datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
def wait_until(value):
 while (remaining:=(value-datetime.datetime.now(datetime.timezone.utc)).total_seconds())>0:
  if time.monotonic()>deadline:raise TimeoutError('Finite qualification plan elapsed')
  time.sleep(min(1,remaining))
def save(): (root/'ledger.json').write_text(json.dumps(ledger,indent=2))
try:
 prerequisite={'w1':'memory-durable-r2','w3':'etl-series-r1','w4':'bpmn-series-r3'}.get(name)
 if prerequisite:
  while not (base/prerequisite/'finished').exists():
   if time.monotonic()>deadline:raise TimeoutError('Prior owned workload has not stopped')
   time.sleep(2)
  assert (base/prerequisite/'finished').read_text()=='passed','Prior owned workload failed; do not overlap capacity'
 for index,case in enumerate(plan['cases']):
  start=utc(case['startAtUtc']);release=utc(case['validateAtUtc']);assert release>start and case['seconds']<=60
  if name not in case['workers']:wait_until(release+datetime.timedelta(seconds=10));continue
  wait_until(start-datetime.timedelta(seconds=45))
  assert 'NTPSynchronized=yes' in subprocess.check_output(['timedatectl','show','-p','NTPSynchronized'],text=True),'Guest clock is unsynchronized'
  load=[float(x) for x in pathlib.Path('/proc/loadavg').read_text().split()[:2]]
  if max(load)>os.cpu_count():raise RuntimeError('CPU load exceeds this worker core count before a sample')
  label=case['label']+'-'+name;assert re.fullmatch(r'[a-zA-Z0-9_-]{1,128}',label)
  out=root/label;out.mkdir();os.chown(out,uid,gid)
  config={'Label':label,'Provider':case['provider'],'Mode':case['mode'],'Activities':case['activities'],'Concurrency':case['concurrency'],'Seconds':case['seconds'],'Minimum':0,'WarmupSeconds':15,'WarmupMinimum':1,'Output':str(out),'ContextPooling':case.get('pooling',False),'StartAtUtc':start.isoformat(),'ValidationGate':str(out/'validate')}
  if case['provider']=='PostgreSql':config.update(Database=case['database'],SkipInitialize=True)
  path=out/'config.json';path.write_text(json.dumps(config));path.chmod(0o644)
  binary=base/(('native-6d77c4402/native/Probe') if case.get('binary','candidate')=='candidate' else 'baseline-native/Probe')
  assert binary.exists();binary_hashes={p:hashlib.sha256((binary.parent/p).read_bytes()).hexdigest() for p in ['Probe.dll','Elsa.Workflows.Runtime.dll','Elsa.Workflows.Runtime.Core.dll','Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.dll']};env['ELSA_EFFICIENCY_POSTGRES_CONNECTION']=secret
  with (out/'run.log').open('w') as log:
   active=subprocess.Popen([str(binary),str(path)],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,user=uid,group=gid,extra_groups=os.getgrouplist('elsarunner',gid),start_new_session=True)
   marker=out/('validate.'+label+'.measured')
   while not marker.exists():
    if active.poll() is not None:raise RuntimeError('Native driver exited before measurement receipt: '+str(active.returncode))
    if datetime.datetime.now(datetime.timezone.utc)>release:raise TimeoutError('Measurement missed the fixed validation boundary; sample invalid')
    time.sleep(.1)
   receipt=json.loads(marker.read_text());assert utc(receipt['measuredEndedAt'])<release and receipt['Errors']==0
   wait_until(release);(out/'validate').write_text('fixed validation release after all measured windows must have ended')
   code=active.wait(timeout=120);active=None
  result=json.loads((out/(label+'.json')).read_text());record={'case':case,'worker':name,'exit':code,'correct':result['Correct'],'sampleStart':result['measuredStartedAt'],'sampleEnd':result['measuredEndedAt'],'validationReleaseAtUtc':release.isoformat(),'count':result['Count'],'workflowsPerSecond':result['WorkflowsPerSecond'],'p95Ms':result['P95Ms'],'allocatedBytesPerWorkflow':result['AllocatedBytesPerWorkflow'],'cpuCoreEquivalent':result['CpuCoreEquivalent'],'peakWorkingSet':result['PeakWorkingSet'],'totalRuns':result['TotalRuns'],'distinctRunIds':result['DistinctRunIds'],'binaryHashes':binary_hashes,'resultSha256':hashlib.sha256((out/(label+'.json')).read_bytes()).hexdigest(),'loadBefore':load};ledger.append(record);save();assert code==0 and result['Correct'],'Native result failed accounting'
 (root/'finished').write_text('passed')
except Exception as e:
 ledger.append({'status':'failed','errorType':type(e).__name__,'error':str(e).replace(secret,'<fixture-connection>')});save();(root/'finished').write_text('failed');(root/'driver-error.log').write_text(traceback.format_exc().replace(secret,'<fixture-connection>'));raise
finally:
 if active is not None and active.poll() is None:
  os.killpg(active.pid,signal.SIGTERM)
  try:active.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(active.pid,signal.SIGKILL);active.wait()
 # Only task-only connection material is ever sanitized; workload results remain exact numeric data.
 password=secret.rsplit('Password=',1)[-1].split(';',1)[0]
 for file in root.rglob('*.log'):
  text=file.read_text(errors='replace');file.write_text(text.replace(secret,'<fixture-connection>').replace(password,'<fixture-password>'))
