S-2 local composed proof at 4f3416436711e97fe1ca6b70f078c4c241efd1d2
Download BOTH balanced parts for all six appearances. Each contains43 named PNG/aria pairs and a proof/trace per included project.
Named captures, proofs and reports are unchanged. Shared trace COPIES redact credentials and omit continuous screencast events/resources; full original traces and filmstrips are NOT shared. manifest.json records source, hashes, layout, redactions and frame omissions.
Open PNG/aria directly or use pnpm exec playwright show-trace results/<project>/trace.zip for actions, DOM and network evidence. This is local source proof, not CI evidence.
