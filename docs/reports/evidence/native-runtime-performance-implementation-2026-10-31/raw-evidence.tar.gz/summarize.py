import pathlib,json,statistics,collections,re
p=pathlib.Path(__file__).resolve().parent
groups=collections.defaultdict(list)
for f in (p/'results').glob('*.json'):
 d=json.loads(f.read_text());assert d['Correct'],f
 c=d['Config'];variant='candidate' if '-candidate-' in c['Label'] else 'baseline'
 groups[(c['Mode'],c['Activities'],c['Concurrency'],variant)].append(d)
rows=[]
for key,rs in sorted(groups.items()):
 row=dict(zip(['mode','leaves','concurrency','variant'],key));row['runs']=len(rs);row['completions']=sum(r['Count'] for r in rs)
 for field in ['WorkflowsPerSecond','P50Ms','P95Ms','P99Ms','AllocatedBytesPerWorkflow']:
  row[field]=statistics.median(r[field] for r in rs)
 row['range']=[min(r['WorkflowsPerSecond'] for r in rs),max(r['WorkflowsPerSecond'] for r in rs)]
 row['commands']=sorted({r['Accounting']['Count'] for r in rs})
 row['transactions']=sorted({r['Accounting']['Commits'] for r in rs})
 row['checkpointCommits']=sorted({sum(q['Value']*len(re.findall(r'INSERT INTO [\"\[]?elsa_runtime_checkpoint_commit',q['Key'])) for q in r['Accounting']['Sql']) for r in rs})
 row['labels']=[r['Config']['Label'] for r in rs]
 rows.append(row)
(p/'summary.json').write_text(json.dumps(rows,indent=2))
for r in rows:print(json.dumps(r))
