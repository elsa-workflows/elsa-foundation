import pathlib,subprocess,json,time,os,datetime,re,shutil,hashlib
out=pathlib.Path('/private/tmp/elsa-perf-implementation'); base=pathlib.Path('/private/tmp/elsa-native-perf-20261031/baseline-bin')
matched=out/'matched-bin'; shutil.copytree(base,matched,dirs_exist_ok=True)
changed=['Elsa.Workflows.Runtime.dll','Elsa.Persistence.EntityFramework.dll','Elsa.Activities.Runtime.Core.dll']
for name in changed: shutil.copy2(out/'candidate-bin'/name,matched/name)
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p.name:{'baseline':hashfile(p),'candidate':hashfile(matched/p.name)} for p in base.glob('*.dll')}
assert [n for n,h in manifest.items() if h['baseline']!=h['candidate']] == sorted(changed,key=lambda n:list(manifest).index(n))
(out/'binary-comparison.json').write_text(json.dumps(manifest,indent=2))
results=out/'results';results.mkdir(exist_ok=True)
def environment(owned=None):
 cpu=0
 for row in subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True).splitlines()[1:]:
  f=row.strip().split(None,2)
  if len(f)==3 and int(f[0]) not in [os.getpid(),owned] and 'OrbStack' not in f[2]: cpu+=float(f[1])
 return dict(at=time.time(),load=os.getloadavg(),externalCpu=round(cpu,1))
def instant(v):
 v=re.sub(r'\.(\d+)(?=[+-]\d{2}:\d{2}$)',lambda m:'.'+(m.group(1)+'000000')[:6],v)
 return datetime.datetime.fromisoformat(v).timestamp()
cases=[('Balanced',1,1),('Balanced',10,1),('Balanced',100,1),('Balanced',10,16),('Durable',10,1)]
with (out/'comparison.jsonl').open('a',buffering=1) as progress:
 for repeat in [1,2]:
  for mode,activities,concurrency in cases:
   for variant in (['baseline','candidate'] if repeat==1 else ['candidate','baseline']):
    label=f'{mode}-a{activities}-c{concurrency}-{variant}-r{repeat}'
    result=results/(label+'.json')
    if result.exists() and json.loads(result.read_text()).get('Correct'):continue
    cfg=dict(Label=label,Provider='PostgreSql',Mode=mode,Activities=activities,Concurrency=concurrency,Seconds=20,Minimum=100,WarmupSeconds=5,WarmupMinimum=10,Output=str(results))
    config=out/(label+'.config.json');config.write_text(json.dumps(cfg,indent=2))
    attempt=0
    while True:
     quiet=0
     while quiet<5:
      env=environment();quiet=quiet+1 if env['externalCpu']<=400 else 0
      if not quiet:print('WAIT '+label+' '+json.dumps(env),flush=True)
      time.sleep(2 if quiet else 10)
     attempt+=1;start=time.time();print('START '+label+' attempt '+str(attempt),flush=True)
     dll=(base if variant=='baseline' else matched)/'Perf.dll'
     with (out/(label+f'-attempt{attempt}.log')).open('w') as log:
      run=subprocess.Popen(['dotnet',str(dll),str(config)],stdout=log,stderr=subprocess.STDOUT);samples=[]
      while run.poll() is None:
       samples.append(environment(run.pid));time.sleep(2)
       if time.time()-start>900:run.terminate();run.wait();break
     if not result.exists():raise RuntimeError('No result: '+label)
     d=json.loads(result.read_text());window=[s for s in samples if instant(d['measuredStartedAt'])-2<=s['at']<=instant(d['measuredEndedAt'])+2]
     streak=0;noisy=False
     for sample in window:
      streak=streak+1 if sample['externalCpu']>500 else 0
      noisy=noisy or streak>=2
     row=dict(label=label,attempt=attempt,exit=run.returncode,seconds=time.time()-start,contaminated=noisy,measuredLoadSamples=window,loadSamples=samples)
     progress.write(json.dumps(row)+'\n')
     if run.returncode or not d['Correct']:raise RuntimeError('Correctness failed: '+label)
     if noisy:
      rejected=out/'rejected';rejected.mkdir(exist_ok=True);shutil.move(result,rejected/(label+f'-attempt{attempt}.json'));print('REJECT '+label,flush=True);continue
     print(json.dumps({k:d[k] for k in ['Count','Correct','WorkflowsPerSecond','P95Ms','AllocatedBytesPerWorkflow']}),flush=True)
     break
