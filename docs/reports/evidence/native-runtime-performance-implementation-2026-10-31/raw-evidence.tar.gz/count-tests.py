import pathlib,subprocess,json,xml.etree.ElementTree as ET
out=pathlib.Path('/private/tmp/elsa-perf-implementation')
rows={}
for directory in ['final','review']:
 for line in (out/directory/'validation.jsonl').read_text().splitlines():
  row=json.loads(line)
  if row['name'].endswith('negative') or row['exit'] or not (out/directory/(row['name']+'.trx')).exists():continue
  rows[row['name']]=(row,directory)
result=[]
for name,(row,directory) in rows.items():
 cmd=['dotnet','test',row['command'][2],'--no-build','--no-restore','--list-tests']
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/'review'/(name+'-list.log')).write_text(p.stdout)
 assert p.returncode==0,p.stdout
 tests=[l.strip() for l in p.stdout.splitlines() if l.startswith('    ') and l.strip()]
 counters=ET.parse(out/directory/(name+'.trx')).find('.//{*}Counters').attrib
 executed=[r.attrib['testName'] for r in ET.parse(out/directory/(name+'.trx')).findall('.//{*}UnitTestResult')]
 missing=[t for t in tests if t not in executed and not any(r.startswith(t+'(') for r in executed)]
 unexpected=[r for r in executed if r not in tests and r.split('(',1)[0] not in tests]
 expanded={t:sum(r.startswith(t+'(') for r in executed) for t in tests if t not in executed}
 record=dict(name=name,project=row['command'][2],listed=len(tests),counts=counters,directory=directory,expandedTheories=expanded,missing=missing,unexpected=unexpected)
 result.append(record);print(json.dumps(record),flush=True)
 assert not missing and not unexpected,record
 assert len(tests)+sum(n-1 for n in expanded.values())==int(counters['total']),record
(out/'test-accounting.json').write_text(json.dumps(result,indent=2))
