import subprocess,pathlib,json,time
out=pathlib.Path('/private/tmp/elsa-perf-implementation/final');out.mkdir(exist_ok=True)
projects=[
('runtime','Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj'),
('provider-drift','Essentials/tests/Persistence/EntityFramework/BindingDriftTests/Elsa.Persistence.EntityFramework.BindingDriftTests.csproj'),
('activities-runtime','Essentials/tests/Activities/Runtime/Tests/Elsa.Activities.Runtime.Tests.csproj'),
('sequence','Essentials/tests/Activities/Sequence/Tests/Elsa.Activities.Sequence.Tests.csproj'),
('control-flow','Essentials/tests/Activities/ControlFlow/Tests/Elsa.Activities.ControlFlow.Tests.csproj'),
('flowchart','Essentials/tests/Activities/Flowchart/Tests/Elsa.Activities.Flowchart.Tests.csproj'),
('persistence-ef','Essentials/tests/Persistence/EntityFramework/Tests/Elsa.Persistence.EntityFramework.Tests.csproj'),
('runtime-ef','Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.Tests.csproj')]
commands=[(n,['dotnet','test',p,'--logger','trx;LogFileName='+n+'.trx','--results-directory',str(out)]) for n,p in projects]
commands += [('workbench-build',['dotnet','build','Essentials/apps/Elsa.Workbench/Elsa.Workbench.csproj']),
('probe-build',['dotnet','build','/private/tmp/elsa-native-perf-20261031/Perf.csproj','-c','Release','-o','/private/tmp/elsa-perf-implementation/candidate-bin']),
('maps',['dotnet','run','--project','tools/maps/Elsa.Maps.Generator','--','check']),('architecture-restore',['bash','tools/architecture/restore-ci-project-graph.sh']),('architecture',['dotnet','test','Essentials/tests/Architecture/Tests/Elsa.Architecture.Tests.csproj','--logger','trx;LogFileName=architecture.trx','--results-directory',str(out)])]
with (out/'validation.jsonl').open('a',buffering=1) as progress:
 for name,cmd in commands:
    print('START '+name,flush=True)
    start=time.time()
    with (out/(name+'.log')).open('w') as log: result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
    row={'name':name,'command':cmd,'exit':result.returncode,'seconds':time.time()-start}
    progress.write(json.dumps(row)+'\n');print(json.dumps(row),flush=True)
    if result.returncode: break
