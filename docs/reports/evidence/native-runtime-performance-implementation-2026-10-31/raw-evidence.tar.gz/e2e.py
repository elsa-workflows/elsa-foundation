import pathlib,subprocess,json,time
out=pathlib.Path('/private/tmp/elsa-perf-implementation')
pwsh='/private/tmp/codex-http-delivery-pwsh/pwsh'
for name,script in [('json-bindings','e2e-tests/http/Test-JsonActivityBindings.ps1'),('variable-loop','e2e-tests/variables/Test-SetVariableLoop.ps1'),('restart','e2e-tests/durability/Test-RestartRecovery.ps1')]:
 start=time.time();print('START '+name,flush=True)
 with (out/('e2e-'+name+'.log')).open('w') as log: r=subprocess.run([pwsh,'-NoProfile','-File',script],stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,exit=r.returncode,seconds=time.time()-start)
 with (out/'e2e.jsonl').open('a') as p:p.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
