import pathlib,subprocess,json
r=pathlib.Path.cwd()
out=pathlib.Path('/private/tmp/elsa-perf-implementation')
groups=[('runtime-negative',[
'Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Values/RuntimeActivityInputSnapshotMaterializer.cs',
'Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Values/RuntimeActivityInputMaterializer.cs',
'Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Coalescing/CoalescingRuntimeStateStores.cs'],
'Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj',
'FullyQualifiedName~Empty_default_snapshot|FullyQualifiedName~Preparation_reuses|FullyQualifiedName~Large_overlay_page'),
('provider-negative',['Essentials/src/Persistence/EntityFramework/EfRelationalProviderBinding.cs'],
'Essentials/tests/Persistence/EntityFramework/BindingDriftTests/Elsa.Persistence.EntityFramework.BindingDriftTests.csproj',
'FullyQualifiedName~Warm_provider_binding')]
for name,files,project,filter in groups:
    backups={p:(r/p).read_bytes() for p in files}
    try:
        for p in files: (r/p).write_bytes(subprocess.check_output(['git','show','HEAD:'+p]))
        with (out/(name+'.log')).open('w') as log:
            result=subprocess.run(['dotnet','test',project,'--no-restore','--filter',filter,'--logger','trx;LogFileName='+name+'.trx','--results-directory',str(out)],stdout=log,stderr=subprocess.STDOUT)
        print(json.dumps({'name':name,'exit':result.returncode}),flush=True)
    finally:
        for p,data in backups.items(): (r/p).write_bytes(data)
