import pathlib,subprocess,json,time,xml.etree.ElementTree as ET
root=pathlib.Path.cwd(); out=pathlib.Path('/private/tmp/elsa-perf-implementation/review')
runtime='Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj'
provider='Essentials/tests/Persistence/EntityFramework/BindingDriftTests/Elsa.Persistence.EntityFramework.BindingDriftTests.csproj'
snapshot=root/'Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Values/RuntimeActivityInputSnapshotMaterializer.cs'
ef=root/'Essentials/src/Persistence/EntityFramework/EfRelationalProviderBinding.cs'
def run(name,cmd,negative=False):
 print('START '+name,flush=True);start=time.time()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,exit=r.returncode,seconds=time.time()-start,command=cmd)
 trx=out/(name+'.trx')
 if trx.exists():row['counts']=ET.parse(trx).find('.//{*}Counters').attrib
 with (out/'validation.jsonl').open('a') as p:p.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
 if negative:
  assert r.returncode and int(row.get('counts',{}).get('failed',0))>0,row
 else:assert r.returncode==0,row

def test(name,project,filter=None,negative=False):
 cmd=['dotnet','test',project,'--no-restore','--logger','trx;LogFileName='+name+'.trx','--results-directory',str(out)]
 if filter:cmd+=['--filter',filter]
 run(name,cmd,negative)
mutations=[('workflow-read-negative',snapshot,'        cancellationToken.ThrowIfCancellationRequested();','        cancellationToken.ThrowIfCancellationRequested();\n        await workflowExecutionStateStore!.FindAsync(state.Execution.WorkflowExecutionId, cancellationToken);',runtime,'FullyQualifiedName~Empty_default_snapshot'),
 ('custom-values-negative',snapshot,'workflowInputEnvelopes: workflowInputEnvelopes,','workflowInputEnvelopes: null,',runtime,'FullyQualifiedName~Custom_materializer_receives'),
 ('provider-retention-negative',ef,'    private static readonly ConditionalWeakTable<Type, MethodInfo> ExtensionMethods = new();','    private static readonly ConditionalWeakTable<Type, MethodInfo> ExtensionMethods = new();\n    private static readonly List<Type> RetainedTypes = new();',provider,'FullyQualifiedName~Provider_types_in_separate')]
for name,path,before,after,project,filter in mutations:
 saved=path.read_text()
 try:
  assert before in saved
  changed=saved.replace(before,after)
  if name=='provider-retention-negative':changed=changed.replace('        var actionType = method.GetParameters()[2].ParameterType;','        var actionType = method.GetParameters()[2].ParameterType;\n        RetainedTypes.Add(actionType);')
  path.write_text(changed);test(name,project,filter,True)
 finally:path.write_text(saved)
for name,project in [('runtime',runtime),('provider-drift',provider),('publishing','Essentials/tests/Workflows/Publishing/Tests/Elsa.Workflows.Publishing.Tests.csproj'),('architecture','Essentials/tests/Architecture/Tests/Elsa.Architecture.Tests.csproj')]:test(name,project)
run('e2e',['python3','/private/tmp/elsa-perf-implementation/e2e.py'])
