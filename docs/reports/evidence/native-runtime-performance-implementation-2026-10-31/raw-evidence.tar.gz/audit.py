import pathlib,json,hashlib,re
p=pathlib.Path('/private/tmp/elsa-perf-implementation')
results={f.stem:json.loads(f.read_text()) for f in (p/'results').glob('*.json')}
ledger=[json.loads(l) for l in (p/'comparison.jsonl').read_text().splitlines()]
accepted={r['label']:r for r in ledger if not r['contaminated']}
assert len(results)==20 and set(results)==set(accepted)
for label,r in results.items():
 assert r['Correct'] and not r['Errors'] and not r['Queued'] and not r['Incidents'] and not r['PendingOutbox']
 assert r['Count']>=100 and r['Seconds']>=20 and accepted[label]['exit']==0
 assert r['measuredLeaves']==r['Count']*r['Config']['Activities']
 assert r['States']==r['Completed']==r['TotalRuns']
 expected=(1,2) if r['Config']['Activities']<100 and r['Config']['Mode']=='Balanced' else ((3,7) if r['Config']['Mode']=='Balanced' else (12,25))
 actual=(sum(q['Value']*len(re.findall(r'INSERT INTO [\"\[]?elsa_runtime_checkpoint_commit',q['Key'])) for q in r['Accounting']['Sql']),r['Accounting']['Commits'])
 assert actual==expected,(label,actual,expected)
manifest=json.loads((p/'binary-comparison.json').read_text())
assert sum(v['baseline']!=v['candidate'] for v in manifest.values())==3
result=dict(acceptedProcesses=len(results),rejectedProcesses=len(ledger)-len(accepted),measuredCompletions=sum(r['Count'] for r in results.values()),allCorrect=True,expectedCheckpointAndTransactionCounts=True,binaryDllCount=len(manifest),changedDllCount=3)
(p/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
