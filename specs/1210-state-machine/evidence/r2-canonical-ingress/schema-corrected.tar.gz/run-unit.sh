#!/usr/bin/env bash
# Run only after actual worker/codex/source admission under the standing allocation.
set -u
job_root=/srv/elsa-qualification/statemachine/r2-schema-fixture-01
/usr/bin/python3 "$job_root/inputs/packet/run.py" \
  --source-tree "/srv/elsa-qualification/statemachine/r2-controls73-02/source" \
  --evidence "$job_root/evidence" \
  >"$job_root/controller.stdout.log" 2>"$job_root/controller.stderr.log"
job_exit_status=$?
/usr/bin/python3 - "$job_root" "$job_exit_status" <<'PY'
import json, os, sys, tempfile
from datetime import datetime, timezone
from pathlib import Path
root=Path(sys.argv[1]);result={'status':'EXITED','exitCode':int(sys.argv[2]),'endedAt':datetime.now(timezone.utc).isoformat(),'scope':'Corrected finalization testfixture regressions; actual TRX, per-phase result and cleanup evidence still require inspection'}
fd,tmp=tempfile.mkstemp(prefix='.terminal-',dir=root)
with os.fdopen(fd,'w') as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
os.replace(tmp,root/'unit-command-terminal.json')
PY
receipt_exit_status=$?
if [[ "$receipt_exit_status" != 0 ]]; then exit "$receipt_exit_status"; fi
exit "$job_exit_status"
