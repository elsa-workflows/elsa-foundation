#!/usr/bin/env python3
"""Supervisor-allocated remote compile/tests for frozen R2 sources. No host or migration phase."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

PACKET = Path(__file__).resolve().parent
WORKTREE = None
OUTPUT = None
TERMINATION_SIGNAL = None
os.environ['MSBUILDDISABLENODEREUSE'] = '1'
os.environ['DOTNET_CLI_USE_MSBUILD_SERVER'] = '0'

def check_termination():
    if TERMINATION_SIGNAL is not None:
        raise SystemExit(128 + TERMINATION_SIGNAL)


def capture(command):
    return subprocess.check_output(command, cwd=WORKTREE, text=True, timeout=5).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + '\n')


def group_members(group):
    rows = capture(['ps', '-axo', 'pid=,ppid=,pgid=,lstart=,args=']).splitlines()
    return [row.strip() for row in rows if len(row.split()) >= 3 and row.split()[2] == str(group)]


def close_group(process):
    # Only the new session/group created by this launcher is ever signalled.
    group = process.pid
    def exists():
        process.poll()  # Reap the launcher-owned root when it has exited.
        try:
            os.killpg(group, 0)
            return True
        except ProcessLookupError:
            return False
    for sig, seconds in [(signal.SIGTERM, 10), (signal.SIGKILL, 5)]:
        if not exists():
            return []
        try:
            os.killpg(group, sig)
        except ProcessLookupError:
            return []
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if not exists():
                return []
            time.sleep(0.25)
    return ['Owned process group still exists after bounded closeout'] if exists() else []


def phase(name, command, seconds):
    check_termination()
    start = time.monotonic()
    timed_out = False
    process = None
    observed = set()
    exception = None
    try:
        with (OUTPUT / (name + '.stdout.log')).open('x') as out, (OUTPUT / (name + '.stderr.log')).open('x') as err:
            process = subprocess.Popen(command, cwd=WORKTREE, stdout=out, stderr=err, start_new_session=True)
            save(name + '.started.json', {'pid': process.pid, 'group': process.pid, 'command': command, 'deadlineSeconds': seconds})
            while process.poll() is None:
                check_termination()
                observed.update(group_members(process.pid))
                if time.monotonic() - start >= seconds:
                    timed_out = True
                    break
                time.sleep(0.5)
            check_termination()
    except BaseException as failure:
        exception = repr(failure)
        raise
    finally:
        # The non-raising handler keeps recording TERM/INT during bounded closeout.
        try:
            leftovers_before_cleanup = group_members(process.pid) if process is not None else []
        except (subprocess.SubprocessError, OSError) as failure:
            leftovers_before_cleanup = ['Owned process observation failed: ' + repr(failure)]
        remaining = close_group(process) if process is not None else []
        if process is not None:
            process.wait(timeout=5)
        result = {'command': command, 'pid': process.pid if process else None, 'exception': exception,
                  'exitCode': process.returncode if process else None, 'timedOut': timed_out,
                  'elapsedSeconds': time.monotonic() - start, 'observedProcessRows': sorted(observed),
                  'ownedGroupRowsBeforeCleanup': leftovers_before_cleanup,
                  'remainingOwnedGroupRows': remaining}
        save(name + '.result.json', result)
    check_termination()
    return result['exitCode'] == 0 and not timed_out and not leftovers_before_cleanup and not remaining


def validate_sources(manifest):
    if capture(['git', 'rev-parse', 'HEAD']) != manifest['base']:
        raise RuntimeError('Wrong isolated checkout base; refusing producer.')
    for name, expected in manifest['files'].items():
        if sha(WORKTREE / name) != expected:
            raise RuntimeError('Frozen source changed: ' + name)
    # Only the reviewed overlay may alter source. Build output stays ignored as in normal CI.
    changed = set(capture(['git', 'diff', 'HEAD', '--name-only']).splitlines())
    changed.update(capture(['git', 'ls-files', '--others', '--exclude-standard']).splitlines())
    if changed != set(manifest['files']):
        raise RuntimeError('Unexpected or missing source changes in isolated checkout.')


def assert_trx(name, expected):
    files = list((OUTPUT / name).glob('*.trx'))
    if len(files) != 1:
        raise RuntimeError('Expected exactly one TRX for ' + name)
    root = ET.parse(files[0]).getroot()
    ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    counters = root.find('t:ResultSummary/t:Counters', ns)
    rows = root.findall('t:Results/t:UnitTestResult', ns)
    valid = counters is not None and int(counters.attrib['total']) == expected and int(counters.attrib['passed']) == expected and len(rows) == expected and all(row.attrib['outcome'] == 'Passed' for row in rows)
    save(name + '.trx-summary.json', {'expected': expected, 'counters': counters.attrib if counters is not None else None,
        'path': str(files[0]), 'sha256': sha(files[0]), 'valid': valid})
    if not valid:
        raise RuntimeError('Missing, failed or non-passing expected cases in ' + name)


def discovered_names(text):
    marker = 'The following Tests are available:'
    if marker not in text:
        raise RuntimeError('Actual discovery list is missing.')
    names = [line.strip() for line in text.split(marker, 1)[1].splitlines() if line.startswith('    ') and line.strip().startswith('Elsa.')]
    # xUnit truncates argument displays; distinct rows can have equal display names.
    # Keep every discovery row: method counters still require all discovered cases.
    if not names:
        raise RuntimeError('Expected nonempty discovery names.')
    return names


def inventory_counts(names):
    from collections import Counter
    return Counter(name.split('(', 1)[0] for name in names)


def compare_inventory(discovered, executed):
    required = inventory_counts(discovered)
    actual = inventory_counts(executed)
    missing = {name: {'discovered': count, 'executed': actual.get(name, 0)} for name, count in required.items() if actual.get(name, 0) < count}
    extras = sorted(set(actual) - set(required))
    return {'missingOrUnderexecuted': missing, 'unexpectedMethods': extras,
        'runtimeTheoryExpansions': {name: count - required[name] for name, count in actual.items() if name in required and count > required[name]},
        'valid': not missing and not extras}


def prior_run_succeeded(phase_receipt, launcher_receipt, terminal_receipt):
    return phase_receipt.get('exitCode') == 0 and phase_receipt.get('exception') is None and not phase_receipt.get('timedOut') and phase_receipt.get('ownedGroupRowsBeforeCleanup') == [] and phase_receipt.get('remainingOwnedGroupRows') == [] and launcher_receipt.get('passed') is True and terminal_receipt.get('status') == 'EXITED' and terminal_receipt.get('exitCode') == 0


def main():
    global WORKTREE, OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-tree', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    if sys.platform != 'linux' or not args.source_tree.is_absolute() or not args.evidence.is_absolute():
        raise RuntimeError('Assigned Linux worker and absolute owned paths required.')
    WORKTREE = args.source_tree.resolve(strict=True)
    OUTPUT = args.evidence.resolve()
    if OUTPUT == WORKTREE or WORKTREE in OUTPUT.parents:
        raise RuntimeError('Evidence must be outside source.')
    packet = json.loads((PACKET / 'packet.json').read_text())
    for name, expected in packet['files'].items():
        if sha(PACKET / name) != expected:
            raise RuntimeError('Frozen packet differs: ' + name)
    manifest = json.loads((PACKET / 'source-manifest.json').read_text())
    validate_sources(manifest)
    previous = Path('/srv/elsa-qualification/statemachine/r2-schema-fixture-01/evidence')
    preflight = json.loads((previous / 'preflight.json').read_text())
    if preflight['sourceManifestSha256'] != sha(PACKET / 'source-manifest.json'):
        raise RuntimeError('The prior normal build used a different source.')
    ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    prior_files = list((previous / 'ef-regression').glob('*.trx'))
    if len(prior_files) != 1:
        raise RuntimeError('Require the actual prior four-case normal-build receipt.')
    prior_rows = ET.parse(prior_files[0]).getroot().findall('t:Results/t:UnitTestResult', ns)
    if len(prior_rows) != 4 or any(row.attrib['outcome'] != 'Passed' for row in prior_rows):
        raise RuntimeError('All prior schema/legacy cases must pass before the whole suite.')
    prior_phase = json.loads((previous / 'ef-regression.result.json').read_text())
    prior_launcher = json.loads((previous / 'launcher-result.json').read_text())
    prior_terminal = json.loads((previous.parent / 'unit-command-terminal.json').read_text())
    if not prior_run_succeeded(prior_phase, prior_launcher, prior_terminal):
        raise RuntimeError('Prior normal build/test, cancellation disposition or cleanup did not succeed.')
    OUTPUT.mkdir(parents=True, exist_ok=False)
    project = 'Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.Tests.csproj'
    binary_root = WORKTREE / Path(project).parent / 'bin/Release/net10.0'
    binaries = {str(file.relative_to(binary_root)): sha(file) for file in binary_root.rglob('*') if file.is_file()}
    if not binaries:
        raise RuntimeError('Prior compiled output is absent.')
    save('preflight.json', {'base': manifest['base'], 'sourceManifestSha256': sha(PACKET / 'source-manifest.json'), 'load': capture(['uptime']), 'priorSchema4TrxSha256': sha(prior_files[0]), 'scope': 'Whole affected EF project; no native/StateMachine/provider-container acceptance inferred'})
    save('binary-inputs.json', binaries)
    common = ['dotnet', 'test', project, '-c', 'Release', '--no-build', '--no-restore', '-m:1', '-nr:false', '-p:UseSharedCompilation=false', '-p:RestoreLockedMode=true', '--nologo', '--settings', str(PACKET / 'runtime.runsettings')]
    current = 'discovery'
    try:
        if not phase(current, common + ['--list-tests'], 900):
            raise RuntimeError('Actual whole-project discovery failed.')
        discovered = discovered_names((OUTPUT / 'discovery.stdout.log').read_text())
        save('discovery-inventory.json', {'names': discovered, 'discoveredNames': len(discovered), 'methodDefinitions': len(inventory_counts(discovered))})
        validate_sources(manifest)
        for name, expected in binaries.items():
            if sha(binary_root / name) != expected:
                raise RuntimeError('Compiled inputs changed after discovery: ' + name)
        current = 'whole-ef'
        command = common + ['--logger', 'trx;LogFileName=whole-ef.trx', '--results-directory', str(OUTPUT / 'whole-ef')]
        succeeded = phase(current, command, 3600)
        validate_sources(manifest)
        files = list((OUTPUT / 'whole-ef').glob('*.trx'))
        if len(files) != 1:
            raise RuntimeError('Require exactly one actual whole-project TRX.')
        tree = ET.parse(files[0]).getroot()
        counters = tree.find('t:ResultSummary/t:Counters', ns)
        rows = tree.findall('t:Results/t:UnitTestResult', ns)
        comparison = compare_inventory(discovered, [row.attrib['testName'] for row in rows])
        valid = succeeded and counters is not None and len(rows) > 0 and int(counters.attrib['total']) == len(rows) and int(counters.attrib['passed']) == len(rows) and all(row.attrib['outcome'] == 'Passed' for row in rows) and comparison['valid']
        save('whole-ef.trx-summary.json', {'valid': bool(valid), 'counters': counters.attrib if counters is not None else None, 'executedRows': len(rows), 'discoveredNames': len(discovered), 'inventoryComparison': comparison, 'trxSha256': sha(files[0])})
        if not valid:
            raise RuntimeError('Whole project failed/skipped or actual discovery/execution inventory differs.')
        save('launcher-result.json', {'passed': True, 'executedCases': len(rows), 'discoveredNames': len(discovered), 'scope': 'Whole affected EF project only; separate real providers/native restart/StateMachine/Studio remain required'})
        return 0
    except BaseException as exception:
        save('launcher-result.json', {'passed': False, 'stoppedAt': current, 'exception': repr(exception)})
        raise


if __name__ == '__main__':
    def terminate(signum, _frame):
        global TERMINATION_SIGNAL
        TERMINATION_SIGNAL = signum
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    raise SystemExit(main())
