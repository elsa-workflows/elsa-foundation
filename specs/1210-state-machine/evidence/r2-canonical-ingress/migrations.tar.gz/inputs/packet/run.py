#!/usr/bin/env python3
"""Supervisor-allocated remote compile/tests for frozen R2 sources. No host or migration phase."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

PACKET = Path(__file__).resolve().parent
WORKTREE = None
OUTPUT = None
TERMINATION_SIGNAL = None
os.environ['MSBUILDDISABLENODEREUSE'] = '1'
os.environ['DOTNET_CLI_USE_MSBUILD_SERVER'] = '0'

def check_termination():
    if TERMINATION_SIGNAL is not None:
        raise SystemExit(128 + TERMINATION_SIGNAL)


def capture(command):
    return subprocess.check_output(command, cwd=WORKTREE, text=True, timeout=5).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + '\n')


def group_members(group):
    rows = capture(['ps', '-axo', 'pid=,ppid=,pgid=,lstart=,args=']).splitlines()
    return [row.strip() for row in rows if len(row.split()) >= 3 and row.split()[2] == str(group)]


def close_group(process):
    # Only the new session/group created by this launcher is ever signalled.
    group = process.pid
    def exists():
        process.poll()  # Reap the launcher-owned root when it has exited.
        try:
            os.killpg(group, 0)
            return True
        except ProcessLookupError:
            return False
    for sig, seconds in [(signal.SIGTERM, 10), (signal.SIGKILL, 5)]:
        if not exists():
            return []
        try:
            os.killpg(group, sig)
        except ProcessLookupError:
            return []
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if not exists():
                return []
            time.sleep(0.25)
    return ['Owned process group still exists after bounded closeout'] if exists() else []


def phase(name, command, seconds):
    check_termination()
    start = time.monotonic()
    timed_out = False
    process = None
    observed = set()
    exception = None
    try:
        with (OUTPUT / (name + '.stdout.log')).open('x') as out, (OUTPUT / (name + '.stderr.log')).open('x') as err:
            process = subprocess.Popen(command, cwd=WORKTREE, stdout=out, stderr=err, start_new_session=True)
            save(name + '.started.json', {'pid': process.pid, 'group': process.pid, 'command': command, 'deadlineSeconds': seconds})
            while process.poll() is None:
                check_termination()
                observed.update(group_members(process.pid))
                if time.monotonic() - start >= seconds:
                    timed_out = True
                    break
                time.sleep(0.5)
            check_termination()
    except BaseException as failure:
        exception = repr(failure)
        raise
    finally:
        # The non-raising handler keeps recording TERM/INT during bounded closeout.
        try:
            leftovers_before_cleanup = group_members(process.pid) if process is not None else []
        except (subprocess.SubprocessError, OSError) as failure:
            leftovers_before_cleanup = ['Owned process observation failed: ' + repr(failure)]
        remaining = close_group(process) if process is not None else []
        if process is not None:
            process.wait(timeout=5)
        result = {'command': command, 'pid': process.pid if process else None, 'exception': exception,
                  'exitCode': process.returncode if process else None, 'timedOut': timed_out,
                  'elapsedSeconds': time.monotonic() - start, 'observedProcessRows': sorted(observed),
                  'ownedGroupRowsBeforeCleanup': leftovers_before_cleanup,
                  'remainingOwnedGroupRows': remaining}
        save(name + '.result.json', result)
    check_termination()
    return result['exitCode'] == 0 and not timed_out and not leftovers_before_cleanup and not remaining


def validate_sources(manifest):
    if capture(['git', 'rev-parse', 'HEAD']) != manifest['base']:
        raise RuntimeError('Wrong isolated checkout base; refusing producer.')
    for name, expected in manifest['files'].items():
        if sha(WORKTREE / name) != expected:
            raise RuntimeError('Frozen source changed: ' + name)
    # Only the reviewed overlay may alter source. Build output stays ignored as in normal CI.
    changed = set(capture(['git', 'diff', 'HEAD', '--name-only']).splitlines())
    changed.update(capture(['git', 'ls-files', '--others', '--exclude-standard']).splitlines())
    if changed != set(manifest['files']):
        raise RuntimeError('Unexpected or missing source changes in isolated checkout.')


def assert_trx(name, expected):
    files = list((OUTPUT / name).glob('*.trx'))
    if len(files) != 1:
        raise RuntimeError('Expected exactly one TRX for ' + name)
    root = ET.parse(files[0]).getroot()
    ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    counters = root.find('t:ResultSummary/t:Counters', ns)
    rows = root.findall('t:Results/t:UnitTestResult', ns)
    valid = counters is not None and int(counters.attrib['total']) == expected and int(counters.attrib['passed']) == expected and len(rows) == expected and all(row.attrib['outcome'] == 'Passed' for row in rows)
    save(name + '.trx-summary.json', {'expected': expected, 'counters': counters.attrib if counters is not None else None,
        'path': str(files[0]), 'sha256': sha(files[0]), 'valid': valid})
    if not valid:
        raise RuntimeError('Missing, failed or non-passing expected cases in ' + name)


def post_budget(deadline):
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError('Post-generation evidence capture deadline exhausted.')
    return min(10, remaining)


def post_command(args, deadline):
    return subprocess.run(args, cwd=WORKTREE, capture_output=True, timeout=post_budget(deadline))


def post_capture(args, deadline):
    result = post_command(args, deadline)
    result.check_returncode()
    return result.stdout.decode().strip()


def capture_partial_generation(manifest, deadline):
    # Diagnostic capture only. Incomplete, unexpected or deleted output never satisfies success.
    prefixes = ['Essentials/src/Workflows/Runtime/Persistence/EntityFrameworkCore/Migrations/Runtime/' + name + '/' for name in ['Sqlite', 'SqlServer', 'PostgreSql', 'MySql']]
    changed = set(post_capture(['git', 'diff', 'HEAD', '--name-only'], deadline).splitlines())
    untracked = set(post_capture(['git', 'ls-files', '--others', '--exclude-standard'], deadline).splitlines())
    generated = (changed | untracked) - set(manifest['files'])
    allowed = sorted(name for name in generated if any(name.startswith(prefix) for prefix in prefixes))
    patch = post_command(['git', 'diff', '--binary', 'HEAD', '--', *prefixes], deadline)
    patch.check_returncode()
    patch = patch.stdout
    ordinary = []
    for name in allowed:
        post_budget(deadline)
        path = WORKTREE / name
        if path.is_symlink() or not path.is_file():
            continue
        ordinary.append(name)
        if name in untracked:
            result = post_command(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], deadline)
            if result.returncode != 1:
                raise RuntimeError('Could not capture a partial new migration diff.')
            patch += result.stdout
    (OUTPUT / 'generated-partial.patch').write_bytes(patch)
    import tarfile
    with tarfile.open(OUTPUT / 'generated-partial.tar.gz', 'x:gz') as archive:
        for name in ordinary:
            post_budget(deadline)
            archive.add(WORKTREE / name, arcname=name, recursive=False)
    post_budget(deadline)
    save('generated-partial-manifest.json', {'diagnosticOnly': True, 'allNewChangedPaths': sorted(generated), 'outsideAllowedPaths': sorted(set(generated) - set(allowed)), 'deletedOrNonordinaryPaths': sorted(set(allowed) - set(ordinary)), 'files': {name: sha(WORKTREE / name) for name in ordinary}, 'originalSource': {name: {'actualSha256': sha(WORKTREE / name) if (WORKTREE / name).is_file() else None, 'expectedSha256': expected} for name, expected in manifest['files'].items()}, 'patchSha256': sha(OUTPUT / 'generated-partial.patch'), 'archiveSha256': sha(OUTPUT / 'generated-partial.tar.gz')})


def main():
    global WORKTREE, OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-tree', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    if sys.platform != 'linux' or not args.source_tree.is_absolute() or not args.evidence.is_absolute():
        raise RuntimeError('Assigned isolated Linux worker and absolute owned paths required.')
    WORKTREE = args.source_tree.resolve(strict=True)
    OUTPUT = args.evidence.resolve()
    if OUTPUT == WORKTREE or WORKTREE in OUTPUT.parents:
        raise RuntimeError('Evidence must remain outside the source checkout.')
    packet_manifest = json.loads((PACKET / 'packet.json').read_text())
    for name, expected in packet_manifest['files'].items():
        if sha(PACKET / name) != expected:
            raise RuntimeError('Frozen packet changed: ' + name)
    manifest = json.loads((PACKET / 'source-manifest.json').read_text())
    validate_sources(manifest)
    OUTPUT.mkdir(parents=True, exist_ok=False)
    save('preflight.json', {'base': manifest['base'], 'sourceManifestSha256': sha(PACKET / 'source-manifest.json'), 'load': capture(['uptime']), 'scope': 'Approved incremental four-provider generation only; no database application/host/ABI acceptance'})
    command = ['bash', 'tools/ef/generate-module-migrations.sh', '--runtime-incremental', 'StimulusIngressSources']
    current = 'generate-migrations'
    post_phase_deadline = None
    try:
        generated_ok = phase(current, command, 1800)
        post_phase_deadline = time.monotonic() + 45
        if not generated_ok:
            raise RuntimeError('Generator failed; preserve the first cause, do not retry.')
        for name, expected in manifest['files'].items():
            post_budget(post_phase_deadline)
            if sha(WORKTREE / name) != expected:
                raise RuntimeError('Generator changed original frozen source: ' + name)
        changed = set(post_capture(['git', 'diff', 'HEAD', '--name-only'], post_phase_deadline).splitlines())
        untracked = set(post_capture(['git', 'ls-files', '--others', '--exclude-standard'], post_phase_deadline).splitlines())
        generated = (changed | untracked) - set(manifest['files'])
        providers = ['Sqlite', 'SqlServer', 'PostgreSql', 'MySql']
        prefixes = ['Essentials/src/Workflows/Runtime/Persistence/EntityFrameworkCore/Migrations/Runtime/' + name + '/' for name in providers]
        if len(generated) != 12 or any(not any(name.startswith(prefix) for prefix in prefixes) for name in generated):
            raise RuntimeError('Expected only three generated files in each of four Runtime provider paths.')
        for provider, prefix in zip(providers, prefixes):
            names = [name for name in generated if name.startswith(prefix)]
            expected_snapshot = prefix + 'Runtime' + provider + 'DbContextModelSnapshot.cs'
            if len(names) != 3 or expected_snapshot not in names or sum(name.endswith('_StimulusIngressSources.cs') for name in names) != 1 or sum(name.endswith('_StimulusIngressSources.Designer.cs') for name in names) != 1:
                raise RuntimeError('Unexpected generated migration/snapshot set for ' + provider)
        if post_capture(['git', 'diff', 'HEAD', '--name-only', '--diff-filter=D'], post_phase_deadline):
            raise RuntimeError('Generator deleted existing source/history.')
        post_command(['git', 'diff', '--check'], post_phase_deadline).check_returncode()
        patch = post_command(['git', 'diff', '--binary', 'HEAD', '--', *prefixes], post_phase_deadline)
        patch.check_returncode()
        patch = patch.stdout
        for name in sorted(generated & untracked):
            result = post_command(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], post_phase_deadline)
            if result.returncode != 1:
                raise RuntimeError('Expected one full new migration diff.')
            patch += result.stdout
        (OUTPUT / 'generated-migrations.patch').write_bytes(patch)
        import tarfile
        with tarfile.open(OUTPUT / 'generated-migrations.tar.gz', 'x:gz') as archive:
            for name in sorted(generated):
                post_budget(post_phase_deadline)
                if not (WORKTREE / name).is_file() or (WORKTREE / name).is_symlink():
                    raise RuntimeError('Generated output is not an ordinary owned source file.')
                archive.add(WORKTREE / name, arcname=name, recursive=False)
        post_budget(post_phase_deadline)
        save('generated-manifest.json', {'sourceManifestSha256': sha(PACKET / 'source-manifest.json'), 'files': {name: sha(WORKTREE / name) for name in sorted(generated)}, 'patchSha256': sha(OUTPUT / 'generated-migrations.patch'), 'archiveSha256': sha(OUTPUT / 'generated-migrations.tar.gz')})
        save('launcher-result.json', {'passed': True, 'generatedProviderSets': 4, 'generatedFiles': 12, 'scope': 'Generation and source inventory only; independent review and actual schema/provider tests still required'})
        return 0
    except BaseException as exception:
        # Persist primary outcome before bounded diagnostics; an outer stop cannot erase it.
        save('launcher-result.json', {'passed': False, 'stoppedAt': current, 'exception': repr(exception), 'partialCapture': 'PENDING'})
        capture_failure = None
        try:
            capture_partial_generation(manifest, post_phase_deadline if post_phase_deadline is not None else time.monotonic() + 45)
        except BaseException as snapshot_error:
            capture_failure = repr(snapshot_error)
        save('launcher-result.json', {'passed': False, 'stoppedAt': current, 'exception': repr(exception), 'partialCaptureError': capture_failure})
        raise


if __name__ == '__main__':
    def terminate(signum, _frame):
        global TERMINATION_SIGNAL
        TERMINATION_SIGNAL = signum
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    raise SystemExit(main())
