#!/usr/bin/env python3
"""Supervisor-allocated remote compile/tests for frozen R2 sources. No host or migration phase."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

PACKET = Path(__file__).resolve().parent
WORKTREE = None
OUTPUT = None
TERMINATION_SIGNAL = None
os.environ['MSBUILDDISABLENODEREUSE'] = '1'
os.environ['DOTNET_CLI_USE_MSBUILD_SERVER'] = '0'

def check_termination():
    if TERMINATION_SIGNAL is not None:
        raise SystemExit(128 + TERMINATION_SIGNAL)


def capture(command):
    return subprocess.check_output(command, cwd=WORKTREE, text=True, timeout=5).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + '\n')


def group_members(group):
    rows = capture(['ps', '-axo', 'pid=,ppid=,pgid=,lstart=,args=']).splitlines()
    return [row.strip() for row in rows if len(row.split()) >= 3 and row.split()[2] == str(group)]


def close_group(process):
    # Only the new session/group created by this launcher is ever signalled.
    group = process.pid
    def exists():
        process.poll()  # Reap the launcher-owned root when it has exited.
        try:
            os.killpg(group, 0)
            return True
        except ProcessLookupError:
            return False
    for sig, seconds in [(signal.SIGTERM, 10), (signal.SIGKILL, 5)]:
        if not exists():
            return []
        try:
            os.killpg(group, sig)
        except ProcessLookupError:
            return []
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if not exists():
                return []
            time.sleep(0.25)
    return ['Owned process group still exists after bounded closeout'] if exists() else []


def phase(name, command, seconds):
    check_termination()
    start = time.monotonic()
    timed_out = False
    process = None
    observed = set()
    exception = None
    try:
        with (OUTPUT / (name + '.stdout.log')).open('x') as out, (OUTPUT / (name + '.stderr.log')).open('x') as err:
            process = subprocess.Popen(command, cwd=WORKTREE, stdout=out, stderr=err, start_new_session=True)
            save(name + '.started.json', {'pid': process.pid, 'group': process.pid, 'command': command, 'deadlineSeconds': seconds})
            while process.poll() is None:
                check_termination()
                observed.update(group_members(process.pid))
                if time.monotonic() - start >= seconds:
                    timed_out = True
                    break
                time.sleep(0.5)
            check_termination()
    except BaseException as failure:
        exception = repr(failure)
        raise
    finally:
        # The non-raising handler keeps recording TERM/INT during bounded closeout.
        try:
            leftovers_before_cleanup = group_members(process.pid) if process is not None else []
        except (subprocess.SubprocessError, OSError) as failure:
            leftovers_before_cleanup = ['Owned process observation failed: ' + repr(failure)]
        remaining = close_group(process) if process is not None else []
        if process is not None:
            process.wait(timeout=5)
        result = {'command': command, 'pid': process.pid if process else None, 'exception': exception,
                  'exitCode': process.returncode if process else None, 'timedOut': timed_out,
                  'elapsedSeconds': time.monotonic() - start, 'observedProcessRows': sorted(observed),
                  'ownedGroupRowsBeforeCleanup': leftovers_before_cleanup,
                  'remainingOwnedGroupRows': remaining}
        save(name + '.result.json', result)
    check_termination()
    return result['exitCode'] == 0 and not timed_out and not leftovers_before_cleanup and not remaining


def validate_sources(manifest):
    if capture(['git', 'rev-parse', 'HEAD']) != manifest['base']:
        raise RuntimeError('Wrong isolated checkout base; refusing producer.')
    for name, expected in manifest['files'].items():
        if sha(WORKTREE / name) != expected:
            raise RuntimeError('Frozen source changed: ' + name)
    # Only the reviewed overlay may alter source. Build output stays ignored as in normal CI.
    changed = set(capture(['git', 'diff', 'HEAD', '--name-only']).splitlines())
    changed.update(capture(['git', 'ls-files', '--others', '--exclude-standard']).splitlines())
    if changed != set(manifest['files']):
        raise RuntimeError('Unexpected or missing source changes in isolated checkout.')


def assert_trx(name, expected):
    files = list((OUTPUT / name).glob('*.trx'))
    if len(files) != 1:
        raise RuntimeError('Expected exactly one TRX for ' + name)
    root = ET.parse(files[0]).getroot()
    ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    counters = root.find('t:ResultSummary/t:Counters', ns)
    rows = root.findall('t:Results/t:UnitTestResult', ns)
    valid = counters is not None and int(counters.attrib['total']) == expected and int(counters.attrib['passed']) == expected and len(rows) == expected and all(row.attrib['outcome'] == 'Passed' for row in rows)
    save(name + '.trx-summary.json', {'expected': expected, 'counters': counters.attrib if counters is not None else None,
        'path': str(files[0]), 'sha256': sha(files[0]), 'valid': valid})
    if not valid:
        raise RuntimeError('Missing, failed or non-passing expected cases in ' + name)


def assert_binding_red():
    files = list((OUTPUT / 'binding-red').glob('*.trx'))
    if len(files) != 1:
        raise RuntimeError('The mutation requires exactly one actual TRX; compilation/discovery failure is not the intended red.')
    root = ET.parse(files[0]).getroot()
    ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    counters = root.find('t:ResultSummary/t:Counters', ns)
    rows = root.findall('t:Results/t:UnitTestResult', ns)
    failed = [row for row in rows if row.attrib.get('outcome') == 'Failed']
    passed = [row for row in rows if row.attrib.get('outcome') == 'Passed']
    import re
    message = failed[0].find('t:Output/t:ErrorInfo/t:Message', ns) if len(failed) == 1 else None
    valid = counters is not None and counters.attrib['total'] == '2' and counters.attrib['failed'] == '1' and counters.attrib['passed'] == '1' and len(rows) == 2 and len(failed) == 1 and len(passed) == 1 and re.search(r'keyed:\s*false', failed[0].attrib['testName'], re.I) and re.search(r'keyed:\s*true', passed[0].attrib['testName'], re.I) and message is not None and 'Assert.NotEqual() Failure' in message.text
    save('binding-red.trx-summary.json', {'expected': 'Only keyed=False loses its distinct binding identity; keyed=True remains passing', 'valid': bool(valid), 'counters': counters.attrib if counters is not None else None, 'rows': [row.attrib for row in rows], 'failure': message.text if message is not None else None, 'sha256': sha(files[0])})
    if not valid:
        raise RuntimeError('The mutation did not fail for the intended binding-collapse assertion.')


def main():
    global WORKTREE, OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-tree', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    if sys.platform != 'linux' or not args.source_tree.is_absolute() or not args.evidence.is_absolute():
        raise RuntimeError('Dedicated Linux worker with absolute owned paths required.')
    WORKTREE = args.source_tree.resolve(strict=True)
    OUTPUT = args.evidence.resolve()
    if OUTPUT == WORKTREE or WORKTREE in OUTPUT.parents:
        raise RuntimeError('Evidence must remain outside the source checkout.')
    packet_manifest = json.loads((PACKET / 'packet.json').read_text())
    for name, expected in packet_manifest['files'].items():
        if sha(PACKET / name) != expected:
            raise RuntimeError('Frozen packet changed: ' + name)
    manifest = json.loads((PACKET / 'source-manifest.json').read_text())
    validate_sources(manifest)
    OUTPUT.mkdir(parents=True, exist_ok=False)
    target_name = 'Essentials/src/Workflows/Runtime/Core/Models/RuntimeCheckpointCommitFingerprint.cs'
    target = WORKTREE / target_name
    original = target.read_bytes()
    needle = b'TriggerBindingId = triggerBindingId, '
    if original.count(needle) != 1:
        raise RuntimeError('Expected the one reviewed binding component; refusing mutation.')
    mutant = original.replace(needle, b'')
    mutated_manifest = dict(manifest, files=dict(manifest['files']))
    mutated_manifest['files'][target_name] = hashlib.sha256(mutant).hexdigest()
    save('preflight.json', {'base': manifest['base'], 'sourceManifestSha256': sha(PACKET / 'source-manifest.json'), 'load': capture(['uptime']), 'scope': 'One per-binding identity negative control; no provider/native/StateMachine acceptance', 'beforeSha256': hashlib.sha256(original).hexdigest(), 'mutantSha256': hashlib.sha256(mutant).hexdigest()})
    project = 'Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj'
    common = ['dotnet', 'test', project, '-c', 'Release', '-m:1', '-nr:false', '-p:UseSharedCompilation=false', '-p:RestoreLockedMode=true', '--nologo', '--settings', str(PACKET / 'runtime.runsettings'), '--filter', 'FullyQualifiedName~StimulusIngressFingerprintTests.Unkeyed_sources_start_each_binding_while_published_caller_keys_keep_per_artifact_identity']
    def command(name, restored=False):
        return common + (['--no-restore'] if restored else []) + ['--logger', 'trx;LogFileName=' + name + '.trx', '--results-directory', str(OUTPUT / name)]
    current = 'binding-baseline-green'
    try:
        if not phase(current, command(current), 900):
            raise RuntimeError('Baseline compile/test failed; mutation not started.')
        validate_sources(manifest)
        assert_trx(current, 2)
        current = 'binding-red'
        try:
            target.write_bytes(mutant)
            validate_sources(mutated_manifest)
            unexpected_success = phase(current, command(current, True), 900)
            validate_sources(mutated_manifest)
            result = json.loads((OUTPUT / (current + '.result.json')).read_text())
            if unexpected_success or result['exitCode'] != 1 or result['timedOut'] or result['exception'] is not None or result['ownedGroupRowsBeforeCleanup'] or result['remainingOwnedGroupRows']:
                raise RuntimeError('Mutation requires the intended ordinary test failure, not timeout/cleanup/compile failure.')
            assert_binding_red()
        finally:
            if target.read_bytes() not in (original, mutant):
                raise RuntimeError('Unexpected third-party target edit; refusing overwrite.')
            target.write_bytes(original)
        validate_sources(manifest)
        current = 'binding-restored-green'
        if not phase(current, command(current, True), 900):
            raise RuntimeError('Restored source did not re-establish green.')
        validate_sources(manifest)
        assert_trx(current, 2)
        save('launcher-result.json', {'passed': True, 'negativeControlValidated': True, 'sequence': '2green -> 1intendedfailure/1pass -> 2green', 'sourceRestored': True, 'scope': 'Per-binding generated start identity only; no native/provider/full-feature proof'})
        return 0
    except BaseException as exception:
        save('launcher-result.json', {'passed': False, 'stoppedAt': current, 'exception': repr(exception), 'sourceRestored': target.read_bytes() == original})
        raise


if __name__ == '__main__':
    def terminate(signum, _frame):
        global TERMINATION_SIGNAL
        TERMINATION_SIGNAL = signum
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    raise SystemExit(main())
