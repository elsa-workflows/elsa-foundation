#!/usr/bin/env python3
"""Frozen dormant R3 input components on the assigned Azure worker; no producer or host."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

PACKET = Path(__file__).resolve().parent
WORKTREE = None
OUTPUT = None
TERMINATION_SIGNAL = None
os.environ['MSBUILDDISABLENODEREUSE'] = '1'
os.environ['DOTNET_CLI_USE_MSBUILD_SERVER'] = '0'

def check_termination():
    if TERMINATION_SIGNAL is not None:
        raise SystemExit(128 + TERMINATION_SIGNAL)


def capture(command):
    return subprocess.check_output(command, cwd=WORKTREE, text=True, timeout=5).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + '\n')


def group_members(group):
    rows = capture(['ps', '-axo', 'pid=,ppid=,pgid=,lstart=,args=']).splitlines()
    return [row.strip() for row in rows if len(row.split()) >= 3 and row.split()[2] == str(group)]


def close_group(process):
    # Only the new session/group created by this launcher is ever signalled.
    group = process.pid
    def exists():
        process.poll()  # Reap the launcher-owned root when it has exited.
        try:
            os.killpg(group, 0)
            return True
        except ProcessLookupError:
            return False
    for sig, seconds in [(signal.SIGTERM, 10), (signal.SIGKILL, 5)]:
        if not exists():
            return []
        try:
            os.killpg(group, sig)
        except ProcessLookupError:
            return []
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if not exists():
                return []
            time.sleep(0.25)
    return ['Owned process group still exists after bounded closeout'] if exists() else []


def phase(name, command, seconds):
    check_termination()
    start = time.monotonic()
    timed_out = False
    process = None
    observed = set()
    exception = None
    try:
        with (OUTPUT / (name + '.stdout.log')).open('x') as out, (OUTPUT / (name + '.stderr.log')).open('x') as err:
            process = subprocess.Popen(command, cwd=WORKTREE, stdout=out, stderr=err, start_new_session=True)
            save(name + '.started.json', {'pid': process.pid, 'group': process.pid, 'command': command, 'deadlineSeconds': seconds})
            while process.poll() is None:
                check_termination()
                observed.update(group_members(process.pid))
                if time.monotonic() - start >= seconds:
                    timed_out = True
                    break
                time.sleep(0.5)
            check_termination()
    except BaseException as failure:
        exception = repr(failure)
        raise
    finally:
        # The non-raising handler keeps recording TERM/INT during bounded closeout.
        try:
            leftovers_before_cleanup = group_members(process.pid) if process is not None else []
        except (subprocess.SubprocessError, OSError) as failure:
            leftovers_before_cleanup = ['Owned process observation failed: ' + repr(failure)]
        remaining = close_group(process) if process is not None else []
        if process is not None:
            process.wait(timeout=5)
        result = {'command': command, 'pid': process.pid if process else None, 'exception': exception,
                  'exitCode': process.returncode if process else None, 'timedOut': timed_out,
                  'elapsedSeconds': time.monotonic() - start, 'observedProcessRows': sorted(observed),
                  'ownedGroupRowsBeforeCleanup': leftovers_before_cleanup,
                  'remainingOwnedGroupRows': remaining}
        save(name + '.result.json', result)
    check_termination()
    return result['exitCode'] == 0 and not timed_out and not leftovers_before_cleanup and not remaining


def validate_sources(manifest):
    if capture(['git', 'rev-parse', 'HEAD']) != manifest['base']:
        raise RuntimeError('Wrong isolated checkout base; refusing producer.')
    if capture(['git', 'rev-parse', 'HEAD^{tree}']) != manifest['tree']:
        raise RuntimeError('Wrong original source tree.')
    for name, expected in manifest['reviewedFiles'].items():
        if sha(WORKTREE / name) != expected:
            raise RuntimeError('Frozen source changed: ' + name)
    # Only the reviewed overlay may alter source. Build output stays ignored as in normal CI.
    changed = set(capture(['git', 'diff', 'HEAD', '--name-only']).splitlines())
    changed.update(capture(['git', 'ls-files', '--others', '--exclude-standard']).splitlines())
    if changed != set(manifest['files']):
        raise RuntimeError('Unexpected or missing source changes in isolated checkout.')


def assert_trx(name, expected):
    files = list((OUTPUT / name).glob('*.trx'))
    if len(files) != 1: raise RuntimeError('Require exactly one original TRX for ' + name)
    root = ET.parse(files[0]).getroot()
    ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    counters = root.find('t:ResultSummary/t:Counters', ns)
    rows = root.findall('t:Results/t:UnitTestResult', ns)
    valid = counters is not None and int(counters.attrib['total']) == expected and int(counters.attrib['executed']) == expected and int(counters.attrib['passed']) == expected and len(rows) == expected and all(row.attrib['outcome'] == 'Passed' for row in rows)
    save(name + '.trx-summary.json', {'expected': expected, 'counters': counters.attrib if counters is not None else None, 'trxSha256': sha(files[0]), 'valid': bool(valid)})
    if not valid: raise RuntimeError('Missing, failed or skipped component cases: ' + name)


def main():
    global WORKTREE, OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-tree', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    if sys.platform != 'linux' or not args.source_tree.is_absolute() or not args.evidence.is_absolute():
        raise RuntimeError('Assigned Linux worker and absolute owned paths required.')
    WORKTREE = args.source_tree.resolve(strict=True); OUTPUT = args.evidence.resolve()
    if OUTPUT == WORKTREE or WORKTREE in OUTPUT.parents: raise RuntimeError('Evidence must be outside source.')
    packet = json.loads((PACKET / 'packet.json').read_text())
    for name, expected in packet['files'].items():
        if sha(PACKET / name) != expected: raise RuntimeError('Frozen packet differs: ' + name)
    manifest = json.loads((PACKET / 'source-manifest.json').read_text())
    validate_sources(manifest)
    OUTPUT.mkdir(parents=True, exist_ok=False)
    save('preflight.json', {'source': manifest['base'], 'tree': manifest['tree'], 'sourceManifestSha256': sha(PACKET / 'source-manifest.json'), 'load': capture(['uptime']), 'scope': '32 dormant input pin/fingerprint cases; no native/physical/producer or full-feature acceptance.'})
    common = ['dotnet', 'test', '-c', 'Release', '-m:1', '-nr:false', '-p:UseSharedCompilation=false', '-p:RestoreLockedMode=true', '--nologo', '--settings', str(PACKET / 'runtime.runsettings')]
    current = 'preflight'
    try:
        for step in packet['phases']:
            current = step['name']
            command = common + [step['project'], '--filter', step['filter'], '--logger', 'trx;LogFileName=' + current + '.trx', '--results-directory', str(OUTPUT / current)]
            if not phase(current, command, step['seconds']): raise RuntimeError('Component phase failed: ' + current)
            assert_trx(current, step['expectedCases'])
            validate_sources(manifest)
        check_termination()
        save('launcher-result.json', {'passed': True, 'executedCases': 32, 'source': manifest['base'], 'scope': 'Dormant input pin/semantic fingerprint components only. Whole project/provider/native/Studio and producer qualifications remain open.'})
        return 0
    except BaseException as exception:
        save('launcher-result.json', {'passed': False, 'stoppedAt': current, 'exception': repr(exception)})
        raise


if __name__ == '__main__':
    def terminate(signum, _frame):
        global TERMINATION_SIGNAL
        TERMINATION_SIGNAL = signum
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    raise SystemExit(main())
