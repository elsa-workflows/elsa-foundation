dotnet --info 
