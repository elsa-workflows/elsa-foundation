/usr/bin/python3 /opt/elsa-durable-messaging/source-5ed3-r3/resume-proof.py /opt/elsa-durable-messaging/source-5ed3-r3 /srv/elsa-qualification/durable-messaging/source-5ed3-r3 
