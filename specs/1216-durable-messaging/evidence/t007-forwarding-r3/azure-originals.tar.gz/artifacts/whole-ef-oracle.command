/usr/bin/python3 /opt/elsa-durable-messaging/source-5ed3-r3/check.py trx /srv/elsa-qualification/durable-messaging/source-5ed3-r3/artifacts/whole-ef.trx whole-ef 
