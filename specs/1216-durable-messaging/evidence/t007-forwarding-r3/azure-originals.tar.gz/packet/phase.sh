#!/bin/bash
# Continue only the unfinished EF suite. No source compile/generator/completed product runs are repeated.
set -Eeuo pipefail
umask 077
job_root=$1
packet_root=$2
admission=$3
[[ "$job_root" == /srv/elsa-qualification/durable-messaging/source-5ed3-r3 ]]
[[ ! -e "$job_root" && ! -L "$job_root" ]]
[[ "$(id -un)" == codex ]]
mkdir -m 0700 "$job_root"
mkdir -m 0700 "$job_root/artifacts"
artifacts=$job_root/artifacts
stage=admission
started=$(date -u +%FT%TZ)
finish() {
    phase_exit=$?
    trap - EXIT TERM INT
    /usr/bin/python3 "$packet_root/check.py" finish "$job_root" "$packet_root/phase.json" "$stage" "$phase_exit" "$started" || phase_exit=1
    exit "$phase_exit"
}
trap finish EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
/usr/bin/python3 "$packet_root/check.py" admission "$admission" "$packet_root/phase.json" "$packet_root/allocation.json" "$artifacts/admission.json"
dotnet_path=$(/usr/bin/python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["toolPaths"]["dotnet402"])' "$admission")
export PATH="$(dirname "$dotnet_path"):$PATH"
export DOTNET_ROOT="$(dirname "$dotnet_path")"
export DOTNET_CLI_HOME=/srv/elsa-qualification/durable-messaging/source-5ed3-r1/dotnet-home
export NUGET_PACKAGES=/srv/elsa-qualification/durable-messaging/source-5ed3-r1/nuget
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_PROCESSOR_COUNT=2
run_stage() {
    stage=$1
    local ceiling=$2
    shift 2
    printf '%s\n' "$stage" >"$artifacts/current-stage"
    printf '%q ' "$@" >"$artifacts/$stage.command"
    printf '\n' >>"$artifacts/$stage.command"
    local command_exit=0
    timeout --signal=TERM --kill-after=20s "${ceiling}s" "$@" >"$artifacts/$stage.log" 2>&1 || command_exit=$?
    printf '%s\n' "$command_exit" >"$artifacts/$stage.exit"
    return "$command_exit"
}
unset ELSA_EF_SCHEMA ELSA_EF_CONNECTION
[[ "$(dotnet --version)" == 10.0.402 ]]
run_stage resume-proof 15 /usr/bin/python3 "$packet_root/resume-proof.py" "$packet_root" "$job_root"
cd /srv/elsa-qualification/durable-messaging/source-5ed3-r1/source
run_stage source-before 10 /usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/base-source.json" generated
run_stage toolchain 10 dotnet --info
run_stage assembly-before 10 /usr/bin/python3 "$packet_root/check.py" assemblies "$packet_root/phase.json" "$artifacts/assembly-before.json" before
ef=Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.Tests.csproj
run_stage whole-ef 1100 dotnet test "$ef" --no-build --no-restore --configuration Debug --verbosity quiet -m:1 --logger 'console;verbosity=normal' --logger 'trx;LogFileName=whole-ef.trx' --results-directory "$artifacts" --blame-hang --blame-hang-timeout 300s --blame-hang-dump-type none
run_stage whole-ef-oracle 10 /usr/bin/python3 "$packet_root/check.py" trx "$artifacts/whole-ef.trx" whole-ef
run_stage assembly-after 10 /usr/bin/python3 "$packet_root/check.py" assemblies "$packet_root/phase.json" "$artifacts/assembly-after.json" after
run_stage source-after 10 /usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/final-source.json" generated
stage=complete
