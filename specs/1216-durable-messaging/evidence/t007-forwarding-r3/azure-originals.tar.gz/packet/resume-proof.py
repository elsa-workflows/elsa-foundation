#!/usr/bin/python3
"""Validate retained R2 failure/source proofs; seed the immutable generated-manifest comparison. No product execution."""
import hashlib,json,math,os
from pathlib import Path
from datetime import datetime
import sys
packet_root=Path(sys.argv[1]);job=Path(sys.argv[2]);packet=json.loads((packet_root/'phase.json').read_text())
prior=Path(packet['priorJobRoot']);source=Path(packet['sourceRoot'])
assert str(prior)=='/srv/elsa-qualification/durable-messaging/source-5ed3-r2'
assert str(source)=='/srv/elsa-qualification/durable-messaging/source-5ed3-r1/source'
assert source.resolve()==source and source.stat().st_uid==os.getuid()
for suffix in ('r1','r2'):
    assert not Path('/sys/fs/cgroup/system.slice/elsa-durable-source-5ed3-'+suffix+'.service').exists()
for name in ('nuget','dotnet-home'):
    path=Path(packet['sourceJobRoot'])/name
    assert path.resolve()==path and path.is_dir() and path.stat().st_uid==os.getuid()
retained=job/'artifacts'/'prior-r2';retained.mkdir(mode=0o700)
for item in packet['priorFiles']:
    path=prior/item['path'];data=path.read_bytes()
    assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],str(path)
    target=retained/Path(item['path']).name
    with target.open('xb') as stream:stream.write(data)
collection=json.loads((packet_root/'r2-collection-result.json').read_text())
cleanup=json.loads((packet_root/'r2-cleanup-result.json').read_text())
checked=json.loads((packet_root/'r2-source-after-stop.json').read_text())
primary=json.loads((packet_root/'r2-primary-observation.json').read_text())
assert collection['primaryStatus']=='FAILED' and collection['cleanupStatus']==collection['sourceStatus']=='VERIFIED'
assert collection['errors']==[] and collection['jobRetained']==str(prior)
assert collection['sourceRootRetained']==str(source) and collection['sourceJobRetained']==packet['sourceJobRoot']
assert cleanup['status']=='VERIFIED' and cleanup['unit']=='elsa-durable-source-5ed3-r2.service'
assert cleanup['noOtherUnitOrPidStopped'] is True and cleanup['cgroupExistsAfter'] is False
assert cleanup['survivingOwnedIdentities']==cleanup['membersAfter']==[]
assert checked['status']=='VERIFIED' and checked['head']==packet['head'] and checked['baseTree']==packet['tree']
assert checked['issues']==checked['untracked']==[] and len(checked['generatedFiles'])==12
assert checked['generatedTree']==checked['retainedGeneratedTree']==packet['generatedTree']
result=json.loads((retained/'phase-result.json').read_text())
assert result==primary['originalPhaseResult'] and result['stage']=='whole-ef' and result['exitCode']==124
assert result['status']=='FAILED_OR_INCOMPLETE' and result['expectedGeneratedSourcePolicyPassed'] is False
assert result['baseHead']==packet['head'] and result['baseTree']==packet['tree']
assert (retained/'whole-ef.exit').read_text().strip()=='124'
assert 'Test run for ' in (retained/'whole-ef.log').read_text() and not (prior/'artifacts/whole-ef.trx').exists()
properties=dict(line.split('=',1) for line in (packet_root/'r2-original-systemd.properties').read_text().splitlines() if '=' in line)
assert properties['Result']=='exit-code' and properties['ExecMainStatus']=='124' and properties['MainPID']=='0'
actual=(int(properties['ExecMainExitTimestampMonotonic'])-int(properties['ExecMainStartTimestampMonotonic']))/1000000
reported=(datetime.fromisoformat(result['endedAt'])-datetime.fromisoformat(result['startedAt'].replace('Z','+00:00'))).total_seconds()
assert reported==result['resumeActiveSeconds'] and result['priorActiveCeilingSeconds']==206
conservative=206+max(actual,reported)
assert conservative==primary['executionBudgetProof']['conservativeCumulativeSeconds']==packet['priorActiveSeconds']
assert math.ceil(conservative)==packet['priorActiveCeilingSeconds']==1162
assert packet['remainingActiveSeconds']==2438 and packet['remainingActiveSeconds']+1162==3600
r1proof=json.loads((retained/'resume-proof.json').read_text())
assert r1proof['originalR1Status']=='FAILED_OR_INCOMPLETE' and r1proof['priorActiveCeilingSeconds']==206
manifest=json.loads((retained/'generated-manifest.json').read_text())
assert manifest==packet['retainedGeneratedManifest'] and manifest['generatedTree']==packet['generatedTree']
assert manifest['files']==[{k:item[k] for k in ('path','bytes','sha256')} for item in checked['generatedFiles']]
assert manifest['patchSha256']==checked['patchSha256']==hashlib.sha256((retained/'generated-migrations.patch').read_bytes()).hexdigest()
for name in ('generated-manifest.json','generated-migrations.patch'):
    with (job/'artifacts'/name).open('xb') as stream:stream.write((retained/name).read_bytes())
(job/'artifacts/resume-proof.json').write_text(json.dumps({'baseHead':packet['head'],'baseTree':packet['tree'],'generatedTree':packet['generatedTree'],'sourceRoot':str(source),'priorJobRoot':str(prior),'originalR1Status':'FAILED_OR_INCOMPLETE','originalR2Status':'FAILED_OR_INCOMPLETE','originalR2FailureStage':'whole-ef','originalR2Exit':124,'priorActualR2InvocationSeconds':actual,'priorReportedR2Seconds':reported,'priorConservativeCumulativeSeconds':conservative,'priorActiveCeilingSeconds':1162,'remainingActiveSeconds':2438,'newProductRuns':0,'originalArtifactsWritten':False},indent=2)+'\n')
