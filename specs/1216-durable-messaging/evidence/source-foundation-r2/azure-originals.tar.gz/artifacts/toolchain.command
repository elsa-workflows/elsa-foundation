/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r2/check.py toolchain 
