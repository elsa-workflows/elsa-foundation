/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r2/handoff.py prior /opt/elsa-durable-messaging/message-foundation-r2 /srv/elsa-qualification/durable-messaging/message-foundation-r2 
