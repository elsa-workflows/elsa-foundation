#!/usr/bin/python3
"""A215 failure custody and exact one-using source continuation; guest execution only by root's launcher."""
from pathlib import Path
import hashlib,json,math,os,subprocess,sys
p=Path(sys.argv[2]);job=Path(sys.argv[3]);phase=json.loads((p/'phase.json').read_text());prior=Path(phase['priorJobRoot']);artifacts=job/'artifacts'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(path):
 assert path.is_file() and not path.is_symlink() and path.resolve()==path and path.stat().st_uid==os.getuid(),str(path)
 return path.read_bytes()
def git(*args):return subprocess.check_output(['git',*args])
def write(name,value):(artifacts/name).write_text(json.dumps(value,indent=2)+'\n')
if sys.argv[1]=='prior':
 assert str(prior)=='/srv/elsa-qualification/durable-messaging/message-foundation-r1'
 assert not Path('/sys/fs/cgroup/system.slice/elsa-durable-message-foundation-r1.service').exists()
 primary=json.loads((p/'prior-a-primary.json').read_text());cleanup=json.loads((p/'prior-a-cleanup.json').read_text());checked=json.loads((p/'prior-a-source.json').read_text());collection=json.loads((p/'prior-a-collection.json').read_text())
 assert primary['status']=='FAILED' and primary['originalSystemdResult']=='exit-code' and primary['originalExecMainStatus']=='1'
 assert primary['originalPhaseResult']['stage']=='ef-focused' and primary['originalPhaseResult']['exitCode']==1
 proof=primary['executionBudgetProof'];assert proof['status']=='VERIFIED' and math.ceil(proof['conservativeCumulativeSeconds'])==phase['priorActiveCeilingSeconds']==313 and proof['limitSeconds']==1800
 assert 313+690+780<=1800 and cleanup['status']=='VERIFIED' and not cleanup['cgroupExistsAfter'] and cleanup['membersAfter']==cleanup['survivingOwnedIdentities']==[]
 assert checked['status']=='VERIFIED' and checked['issues']==[] and checked['rawStatusEmpty'] is True and checked['head']==phase['priorHead'] and checked['tree']==phase['priorTree']
 assert collection['primaryStatus']=='FAILED' and collection['cleanupStatus']==collection['sourceStatus']=='VERIFIED' and collection['errors']==[]
 retained=artifacts/'prior-a';retained.mkdir(mode=0o700)
 for item in phase['priorFiles']:
  data=read(prior/item['path']);assert len(data)==item['bytes'] and sha(data)==item['sha256']
  with (retained/Path(item['path']).name).open('xb') as stream:stream.write(data)
 assert json.loads((retained/'phase-result.json').read_text())==primary['originalPhaseResult']
 # The unchanged Runtime cohort is retained, never rerun as a new result.
 check=p/'check.py';subprocess.check_call(['/usr/bin/python3',str(check),'trx',str(retained/'runtime-focused.trx'),'runtime-focused'])
 log=(retained/'ef-focused.log').read_text();errors=[s for s in log.splitlines() if 'error CS' in s]
 assert len(errors)==1 and 'error CS1061' in errors[0] and 'GetEnlistedTransaction' in errors[0] and 'EfRuntimeDeliverySourceStore.cs(259,' in errors[0]
 old=json.loads((retained/'old-cohort-closure.json').read_text());assert old['status']=='VERIFIED' and old['oldCohortSeconds']==1652.889368 and old['oldCohortLimit']==3600 and old['noOldOutcomeReset'] is True
 write('prior-a-proof.json',{'status':'VERIFIED','priorAFailedPreserved':True,'priorArchive':phase['priorArchive'],'priorActiveCeilingSeconds':313,'runtimeFocused86Retained':True,'noRuntimeFocusedRepeat':True,'oldCohortSeconds':1652.889368,'oldOutcomeReset':False,'oldArtifactsWritten':False})
elif sys.argv[1]=='source':
 root=Path(phase['sourceRoot']);assert root==prior/'source' and root.resolve()==root and root.stat().st_uid==os.getuid() and Path.cwd()==root
 assert git('rev-parse','HEAD').decode().strip()==phase['priorHead'] and git('rev-parse','HEAD^{tree}').decode().strip()==phase['priorTree']
 assert not git('status','--porcelain=v1','--untracked-files=all')
 def assets():
  items=[]
  for path in sorted(root.rglob('project.assets.json')):
   data=read(path);value=json.loads(data);project=Path(value['project']['restore']['projectPath']);assert project.is_file() and project.resolve()==project and project.is_relative_to(root)
   items.append({'path':str(path.relative_to(root)),'projectPath':str(project),'bytes':len(data),'sha256':sha(data)})
  assert 2<=len(items)<=512
  needed=['Essentials/tests/Workflows/Runtime/Tests/obj/project.assets.json','Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/obj/project.assets.json']
  assert all(any(i['path']==n for i in items) for n in needed)
  return items
 before=assets();write('assets-before.json',before)
 bundle=p/'source.bundle';data=bundle.read_bytes();assert len(data)==phase['bundle']['bytes'] and sha(data)==phase['bundle']['sha256']
 assert git('bundle','list-heads',str(bundle)).decode().splitlines()==[phase['head']+' HEAD']
 subprocess.check_call(['git','bundle','verify',str(bundle)]);subprocess.check_call(['git','fetch','--no-tags',str(bundle),'HEAD'])
 changed=git('diff','--name-only',phase['priorHead'],phase['head']).decode().splitlines();assert changed==phase['sourceDeltaPaths']
 store='Essentials/src/Workflows/Runtime/Persistence/EntityFrameworkCore/Stores/EfRuntimeDeliverySourceStore.cs'
 code=[x for x in changed if not x.startswith('specs/') and not x.startswith('docs/')];assert code==[store]
 old=git('show',phase['priorHead']+':'+store);new=git('show',phase['head']+':'+store)
 assert b'using System.Transactions;\n' not in old and new.count(b'using System.Transactions;\n')==1 and new.replace(b'using System.Transactions;\n',b'',1)==old
 assert [x for x in changed if x.endswith(('.cs','.csx','.csproj','.fsproj','.props','.targets','.sln','.slnx','.slnf')) or Path(x).name in ('packages.lock.json','global.json','NuGet.config','nuget.config')]==[store]
 subprocess.check_call(['git','checkout','--detach','--quiet',phase['head']])
 assert assets()==before,'An assets file or absolute project binding changed during source handoff'
 subprocess.check_call(['/usr/bin/python3',str(p/'check.py'),'source',str(p/'phase.json'),str(artifacts/'base-source.json')])
 write('source-handoff.json',{'status':'VERIFIED','priorHead':phase['priorHead'],'head':phase['head'],'tree':phase['tree'],'changedPaths':changed,'onlyCodeChange':'using System.Transactions;','assetsFiles':before,'sameAbsoluteSourceRoot':str(root),'restorePerformed':False,'oldArtifactOrPacketWrites':False})
else:raise ValueError('Unsupported handoff operation')
