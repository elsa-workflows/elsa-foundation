dotnet build Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false -p:BuildProjectReferences=false 
