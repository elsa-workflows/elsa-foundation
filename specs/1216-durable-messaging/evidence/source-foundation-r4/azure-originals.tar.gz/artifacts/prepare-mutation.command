/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r4/check.py mutate /srv/elsa-qualification/durable-messaging/message-foundation-r4/artifacts 
