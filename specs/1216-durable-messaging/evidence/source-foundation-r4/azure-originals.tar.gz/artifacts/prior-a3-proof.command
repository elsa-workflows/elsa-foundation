/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r4/handoff.py prior /opt/elsa-durable-messaging/message-foundation-r4 /srv/elsa-qualification/durable-messaging/message-foundation-r4 
