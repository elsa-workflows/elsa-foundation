dotnet build Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Elsa.Workflows.Runtime.csproj --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false -p:BuildProjectReferences=false 
