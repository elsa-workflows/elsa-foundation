#!/bin/bash
set -Eeuo pipefail
umask 077
job_root=$1
packet_root=$2
admission=$3
[[ "$job_root" == /srv/elsa-qualification/durable-messaging/message-foundation-r4 ]]
[[ ! -e "$job_root" && ! -L "$job_root" && "$(id -un)" == codex ]]
mkdir -m 0700 "$job_root"
mkdir -m 0700 "$job_root/artifacts"
artifacts=$job_root/artifacts
source_root=/srv/elsa-qualification/durable-messaging/message-foundation-r1/source
stage=admission
mutant_active=0
switch=Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Executables/InMemoryWorkflowActivationSwitch.cs
started=$(date -u +%FT%TZ)
finish() {
    phase_exit=$?
    trap - EXIT TERM INT
    if [[ "$mutant_active" == 1 && -f "$artifacts/repair-original.cs" ]]; then
        cp "$artifacts/repair-original.cs" "$source_root/$switch" || phase_exit=1
    fi
    /usr/bin/timeout --signal=TERM --kill-after=1s 8s /usr/bin/python3 "$packet_root/check.py" finish "$job_root" "$packet_root/phase.json" "$stage" "$phase_exit" "$started" || phase_exit=1
    exit "$phase_exit"
}
trap finish EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
run_stage() {
    stage=$1
    local ceiling=$2
    shift 2
    printf '%s\n' "$stage" >"$artifacts/current-stage"
    printf '%q ' "$@" >"$artifacts/$stage.command"
    printf '\n' >>"$artifacts/$stage.command"
    local command_exit=0
    timeout --signal=TERM --kill-after=5s "${ceiling}s" "$@" >"$artifacts/$stage.log" 2>&1 || command_exit=$?
    printf '%s\n' "$command_exit" >"$artifacts/$stage.exit"
    return "$command_exit"
}
run_stage admission 10 /usr/bin/python3 "$packet_root/check.py" admission "$admission" "$packet_root/phase.json" "$packet_root/allocation.json" "$artifacts/admission.json"
run_stage prior-a3-proof 6 /usr/bin/python3 "$packet_root/handoff.py" prior "$packet_root" "$job_root"
dotnet_path=$(/usr/bin/python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["toolPaths"]["dotnet402"])' "$admission")
export PATH="$(dirname "$dotnet_path"):$PATH" DOTNET_ROOT="$(dirname "$dotnet_path")"
export DOTNET_CLI_HOME=/srv/elsa-qualification/durable-messaging/message-foundation-r2/dotnet-home
export NUGET_PACKAGES=/srv/elsa-qualification/durable-messaging/source-5ed3-r1/nuget
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_PROCESSOR_COUNT=2 GIT_TERMINAL_PROMPT=0
unset ELSA_EF_SCHEMA ELSA_EF_CONNECTION
cd "$source_root"
run_stage source-handoff 12 /usr/bin/python3 "$packet_root/handoff.py" source "$packet_root" "$job_root"
run_stage toolchain 3 /usr/bin/python3 "$packet_root/check.py" toolchain
runtime_library=Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Elsa.Workflows.Runtime.csproj
runtime=Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj
ef=Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.Tests.csproj
ef_focused='FullyQualifiedName~RuntimeDeliverySourceReadClaimTests|FullyQualifiedName~BusinessMessageCanonicalCodecTests'
critical='FullyQualifiedName=Elsa.Workflows.Runtime.Tests.MessagePublicationInterestIntegrationTests.Legacy_repair_revalidates_prepared_material_before_any_projection_switches'
run_stage ef-focused 90 dotnet test "$ef" --no-restore -p:BuildProjectReferences=false --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter "$ef_focused" --logger 'trx;LogFileName=ef-focused.trx' --results-directory "$artifacts"
run_stage ef-focused-oracle 3 /usr/bin/python3 "$packet_root/check.py" trx "$artifacts/ef-focused.trx" ef-focused
mutant_active=1
run_stage prepare-mutation 2 /usr/bin/python3 "$packet_root/check.py" mutate "$artifacts"
run_stage runtime-library-mutant-build 32 dotnet build "$runtime_library" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false -p:BuildProjectReferences=false
run_stage runtime-tests-mutant-build 32 dotnet build "$runtime" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false -p:BuildProjectReferences=false
run_stage mutant-product-binding 3 /usr/bin/python3 "$packet_root/check.py" runtime-product "$packet_root/phase.json" "$artifacts" mutant
set +e
run_stage repair-mutation 15 dotnet test "$runtime" --no-build --no-restore --verbosity quiet -m:1 --filter "$critical" --logger 'trx;LogFileName=repair-mutation.trx' --results-directory "$artifacts"
mutation_exit=$?
set -e
run_stage mutation-restoration 2 /usr/bin/python3 "$packet_root/check.py" restore "$packet_root/phase.json" "$artifacts"
mutant_active=0
stage=mutation-exit-oracle
[[ "$mutation_exit" == 1 ]]
run_stage repair-mutation-oracle 3 /usr/bin/python3 "$packet_root/check.py" trx "$artifacts/repair-mutation.trx" repair-mutation
run_stage runtime-library-restored-build 32 dotnet build "$runtime_library" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false -p:BuildProjectReferences=false
run_stage runtime-tests-restored-build 32 dotnet build "$runtime" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false -p:BuildProjectReferences=false
run_stage restored-product-binding 3 /usr/bin/python3 "$packet_root/check.py" runtime-product "$packet_root/phase.json" "$artifacts" restored
run_stage repair-restored 15 dotnet test "$runtime" --no-build --no-restore --verbosity quiet -m:1 --filter "$critical" --logger 'trx;LogFileName=repair-restored.trx' --results-directory "$artifacts"
run_stage repair-restored-oracle 3 /usr/bin/python3 "$packet_root/check.py" trx "$artifacts/repair-restored.trx" repair-restored
run_stage whole-runtime 33 dotnet test "$runtime" --no-build --no-restore --verbosity quiet -m:1 --logger 'trx;LogFileName=whole-runtime.trx' --results-directory "$artifacts"
run_stage whole-runtime-oracle 3 /usr/bin/python3 "$packet_root/check.py" trx "$artifacts/whole-runtime.trx" whole-runtime
run_stage ef-output-refresh 25 dotnet build "$ef" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false -p:BuildProjectReferences=false
run_stage assemblies-ready 3 /usr/bin/python3 "$packet_root/check.py" assemblies "$packet_root/phase.json" "$artifacts/assemblies-ready.json"
run_stage source-final 3 /usr/bin/python3 "$packet_root/handoff.py" final "$packet_root" "$job_root"
stage=complete
