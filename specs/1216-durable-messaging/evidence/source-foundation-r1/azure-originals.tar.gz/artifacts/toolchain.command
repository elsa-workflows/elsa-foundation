/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r1/check.py toolchain 
