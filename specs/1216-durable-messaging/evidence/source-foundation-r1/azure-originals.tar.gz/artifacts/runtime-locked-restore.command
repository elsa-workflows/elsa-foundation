dotnet restore Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj --locked-mode -m:1 -p:WarningsNotAsErrors=NU1603 
