/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r1/check.py trx /srv/elsa-qualification/durable-messaging/message-foundation-r1/artifacts/runtime-focused.trx runtime-focused 
