git -c credential.helper= -c core.askPass= fetch --depth=64 https://github.com/elsa-workflows/elsa-foundation.git 7cf4e425143a2320141ea81c980506d75d515610 
