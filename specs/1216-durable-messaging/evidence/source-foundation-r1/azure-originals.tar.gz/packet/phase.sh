#!/bin/bash
set -Eeuo pipefail
umask 077
job_root=$1
packet_root=$2
admission=$3
[[ "$job_root" == /srv/elsa-qualification/durable-messaging/message-foundation-r1 ]]
[[ ! -e "$job_root" && ! -L "$job_root" && "$(id -un)" == codex ]]
mkdir -m 0700 "$job_root"
mkdir -m 0700 "$job_root/artifacts" "$job_root/source" "$job_root/dotnet-home"
artifacts=$job_root/artifacts
stage=admission
mutant_active=0
switch=Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Executables/InMemoryWorkflowActivationSwitch.cs
started=$(date -u +%FT%TZ)
finish() {
    phase_exit=$?
    trap - EXIT TERM INT
    if [[ "$mutant_active" == 1 && -f "$artifacts/repair-original.cs" ]]; then
        cp "$artifacts/repair-original.cs" "$job_root/source/$switch" || phase_exit=1
    fi
    /usr/bin/timeout --signal=TERM --kill-after=2s 10s /usr/bin/python3 "$packet_root/check.py" finish "$job_root" "$packet_root/phase.json" "$stage" "$phase_exit" "$started" || phase_exit=1
    exit "$phase_exit"
}
trap finish EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
run_stage() {
    stage=$1
    local ceiling=$2
    shift 2
    printf '%s\n' "$stage" >"$artifacts/current-stage"
    printf '%q ' "$@" >"$artifacts/$stage.command"
    printf '\n' >>"$artifacts/$stage.command"
    local command_exit=0
    timeout --signal=TERM --kill-after=20s "${ceiling}s" "$@" >"$artifacts/$stage.log" 2>&1 || command_exit=$?
    printf '%s\n' "$command_exit" >"$artifacts/$stage.exit"
    return "$command_exit"
}
run_stage admission 10 /usr/bin/python3 "$packet_root/check.py" admission "$admission" "$packet_root/phase.json" "$packet_root/allocation.json" "$artifacts/admission.json"
run_stage old-closure 10 /usr/bin/python3 "$packet_root/check.py" old-closure "$packet_root" "$job_root"
dotnet_path=$(/usr/bin/python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["toolPaths"]["dotnet402"])' "$admission")
export PATH="$(dirname "$dotnet_path"):$PATH" DOTNET_ROOT="$(dirname "$dotnet_path")"
export DOTNET_CLI_HOME="$job_root/dotnet-home"
export NUGET_PACKAGES=/srv/elsa-qualification/durable-messaging/source-5ed3-r1/nuget
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_PROCESSOR_COUNT=2 GIT_TERMINAL_PROMPT=0
unset ELSA_EF_SCHEMA ELSA_EF_CONNECTION
cd "$job_root/source"
git init --quiet
# Two actual bundle prerequisites are required; depth64 admits their public ancestry, followed by explicit checks.
run_stage source-fetch 45 git -c credential.helper= -c core.askPass= fetch --depth=64 https://github.com/elsa-workflows/elsa-foundation.git 7cf4e425143a2320141ea81c980506d75d515610
git checkout --detach --quiet FETCH_HEAD
run_stage private-bundle 10 /usr/bin/python3 "$packet_root/check.py" bundle "$packet_root/phase.json" "$packet_root/source.bundle" "$artifacts/bundle.json"
run_stage original-fixture 5 /usr/bin/python3 "$packet_root/check.py" fixture "$packet_root/phase.json" "$artifacts/fixture.json"
run_stage source-before 5 /usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/base-source.json"
run_stage toolchain 5 /usr/bin/python3 "$packet_root/check.py" toolchain
runtime=Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj
ef=Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.Tests.csproj
focused='FullyQualifiedName~BusinessMessageAcceptedHeaderTests|FullyQualifiedName~MessagePublicationInterestIntegrationTests|FullyQualifiedName~BusinessMessageSourceCodecTests'
ef_focused='FullyQualifiedName~RuntimeDeliverySourceReadClaimTests|FullyQualifiedName~BusinessMessageCanonicalCodecTests'
critical='FullyQualifiedName=Elsa.Workflows.Runtime.Tests.MessagePublicationInterestIntegrationTests.Legacy_repair_revalidates_prepared_material_before_any_projection_switches'
run_stage runtime-locked-restore 30 dotnet restore "$runtime" --locked-mode -m:1 -p:WarningsNotAsErrors=NU1603
run_stage ef-locked-restore 30 dotnet restore "$ef" --locked-mode -m:1 -p:WarningsNotAsErrors=NU1603
run_stage runtime-focused 240 dotnet test "$runtime" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter "$focused" --logger 'trx;LogFileName=runtime-focused.trx' --results-directory "$artifacts"
run_stage runtime-focused-oracle 4 /usr/bin/python3 "$packet_root/check.py" trx "$artifacts/runtime-focused.trx" runtime-focused
run_stage ef-focused 240 dotnet test "$ef" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter "$ef_focused" --logger 'trx;LogFileName=ef-focused.trx' --results-directory "$artifacts"
run_stage ef-focused-oracle 4 /usr/bin/python3 "$packet_root/check.py" trx "$artifacts/ef-focused.trx" ef-focused
mutant_active=1
run_stage prepare-mutation 4 /usr/bin/python3 "$packet_root/check.py" mutate "$artifacts"
set +e
run_stage repair-mutation 90 dotnet test "$runtime" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter "$critical" --logger 'trx;LogFileName=repair-mutation.trx' --results-directory "$artifacts"
mutation_exit=$?
set -e
run_stage mutation-restoration 4 /usr/bin/python3 "$packet_root/check.py" restore "$packet_root/phase.json" "$artifacts"
mutant_active=0
stage=mutation-exit-oracle
[[ "$mutation_exit" == 1 ]]
run_stage repair-mutation-oracle 4 /usr/bin/python3 "$packet_root/check.py" trx "$artifacts/repair-mutation.trx" repair-mutation
run_stage repair-restored 90 dotnet test "$runtime" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter "$critical" --logger 'trx;LogFileName=repair-restored.trx' --results-directory "$artifacts"
run_stage repair-restored-oracle 4 /usr/bin/python3 "$packet_root/check.py" trx "$artifacts/repair-restored.trx" repair-restored
run_stage whole-runtime 120 dotnet test "$runtime" --no-build --no-restore --verbosity quiet -m:1 --logger 'trx;LogFileName=whole-runtime.trx' --results-directory "$artifacts"
run_stage whole-runtime-oracle 4 /usr/bin/python3 "$packet_root/check.py" trx "$artifacts/whole-runtime.trx" whole-runtime
run_stage assemblies-ready 5 /usr/bin/python3 "$packet_root/check.py" assemblies "$packet_root/phase.json" "$artifacts/assemblies-ready.json"
run_stage source-final 5 /usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/final-source.json"
stage=complete
