#!/usr/bin/python3
"""Read/copy only hash-bound original A proofs. No product test, compile, source or old-artifact write."""
from pathlib import Path
import json,hashlib,math,os,sys,subprocess
packetRoot=Path(sys.argv[1]);job=Path(sys.argv[2]);packet=json.loads((packetRoot/'phase.json').read_text());prior=Path(packet['priorJobRoot'])
assert str(prior)=='/srv/elsa-qualification/durable-messaging/message-foundation-r6'
receiptData=(packetRoot/'accepted-a6-custody.json').read_bytes();receipt=json.loads(receiptData)
assert hashlib.sha256(receiptData).hexdigest()==packet['acceptedA6CustodyReceiptSha256'] and receipt['status']=='PASSED_A6_ORIGINALS_ACCEPTED'
assert receipt['head']==packet['head'] and receipt['tree']==packet['tree'] and receipt['archive']['sha256']==packet['priorArchive']['sha256']
assert not Path('/sys/fs/cgroup/system.slice/elsa-durable-message-foundation-r6.service').exists()
primary=json.loads((packetRoot/'phase-a-primary.json').read_text());cleanup=json.loads((packetRoot/'phase-a-cleanup.json').read_text())
checked=json.loads((packetRoot/'phase-a-source.json').read_text());collection=json.loads((packetRoot/'phase-a-collection.json').read_text())
assert primary['status']=='PASSED' and primary['originalSystemdResult']=='success' and primary['originalExecMainStatus']=='0'
assert primary['originalPhaseResult']['status']=='PASSED' and primary['originalPhaseResult']['stage']=='complete'
assert primary['executionBudgetProof']['status']=='VERIFIED' and primary['executionBudgetProof']['limitSeconds']==1800
assert primary['executionBudgetProof']['priorActiveCeilingSeconds']==872 and max(primary['executionBudgetProof']['actualInvocationSeconds'],primary['executionBudgetProof']['reportedActiveSeconds'])<=180
assert primary['executionBudgetProof']['conservativeCumulativeSeconds']==872+max(primary['executionBudgetProof']['actualInvocationSeconds'],primary['executionBudgetProof']['reportedActiveSeconds'])
priorCeil=math.ceil(primary['executionBudgetProof']['conservativeCumulativeSeconds'])
assert priorCeil==packet['priorActiveCeilingSeconds'] and priorCeil+690<=1800 and priorCeil+packet['remainingActiveSeconds']==1800
assert cleanup['status']=='VERIFIED' and cleanup['cgroupExistsAfter'] is False and cleanup['membersAfter']==cleanup['survivingOwnedIdentities']==[]
assert checked['status']=='VERIFIED' and checked['issues']==[] and checked['head']==packet['head'] and checked['tree']==packet['tree'] and checked['rawStatusEmpty'] is True
assert collection['primaryStatus']=='PASSED' and collection['cleanupStatus']==collection['sourceStatus']=='VERIFIED' and collection['errors']==[]
artifacts=job/'artifacts';retained=artifacts/'prior-a';retained.mkdir(mode=0o700)
for item in packet['priorFiles']:
    source=prior/item['path'];assert source.is_file() and not source.is_symlink() and source.resolve()==source and source.stat().st_uid==os.getuid()
    data=source.read_bytes();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
    with (retained/Path(item['path']).name).open('xb') as stream:stream.write(data)
phase=json.loads((retained/'phase-result.json').read_text());assert phase==primary['originalPhaseResult'] and phase['baseHead']==packet['head'] and phase['baseTree']==packet['tree']
ready=json.loads((retained/'assemblies-ready.json').read_text());assert len(ready['files'])==6 and ready['files']==checked['assemblyBinding']['files']
with (artifacts/'assemblies-ready.json').open('xb') as stream:stream.write((retained/'assemblies-ready.json').read_bytes())
mutant=json.loads((retained/'runtime-product-mutant.json').read_text());restored=json.loads((retained/'runtime-product-restored.json').read_text())
assert mutant['actualBuiltProductMatchesTestDirectory'] is True and restored['actualBuiltProductMatchesTestDirectory'] is True
assert mutant['runtimeSha256']==mutant['testRuntimeSha256'] and restored['runtimeSha256']==restored['testRuntimeSha256'] and mutant['runtimeSha256']!=restored['runtimeSha256']
assert next(item['sha256'] for item in ready['files'] if item['path'].endswith('/Elsa.Workflows.Runtime.dll'))==restored['runtimeSha256']=='45b1530d235bf1edb9ba21544823970b8993f7a4942bcc3b07ba9106acc11f8b'
current=json.loads((retained/'current-restored-product.json').read_text());assert current['status']=='VERIFIED' and current['runtimeSha256']==restored['runtimeSha256'] and current['actualLibraryAndRuntimeTestDirectoryMatchRetainedRestoredProduct'] is True
failedA=json.loads((retained/'prior-a5-proof.json').read_text());assert failedA['status']=='VERIFIED' and failedA['priorAAndA2AndA3AndA4AndA5FailedPreserved'] is True and failedA['priorActiveCeilingSeconds']==872 and failedA['runtimeFocused86Retained'] is True and failedA['oldOutcomeReset'] is False
warm=json.loads((retained/'warm-final.json').read_text());assert warm['status']=='VERIFIED' and warm['assetsUnchanged'] is True
assert warm['head']==packet['head'] and warm['tree']==packet['tree']
assert failedA['efFocused37Retained'] is True and failedA['noProductTestsRepeated'] is True
for mode in ['ef-focused','repair-mutation','repair-restored','whole-runtime']:
    subprocess.check_call(['/usr/bin/python3',str(packetRoot/'check.py'),'trx',str(retained/(mode+'.trx')),mode])
old=json.loads((retained/'old-cohort-closure.json').read_text());assert old['status']=='VERIFIED' and old['oldCohortSeconds']==1652.889368 and old['oldCohortLimit']==3600 and old['noOldOutcomeReset'] is True
(artifacts/'phase-a-proof.json').write_text(json.dumps({'status':'VERIFIED','continuationA6Passed':True,'originalAAndA2AndA3FailedPreserved':True,'actualPriorCeiling':priorCeil,'newGrantCumulativeLimit':1800,'oldCohortSeconds':1652.889368,'oldCohortLimit':3600,'noOldOutcomeReset':True,'newProductRuns':0,'oldArtifactsWritten':False},indent=2)+'\n')
