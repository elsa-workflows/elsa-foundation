/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-ef-r1/check.py toolchain 
