git -c credential.helper= -c core.askPass= fetch --depth=1 https://github.com/elsa-workflows/elsa-foundation.git 0246b4ecf4ea1df62db2c26437e7cc3cf7e6f40e 
