dotnet restore tools/ef/Elsa.EntityFrameworkCore.Tooling/Elsa.EntityFrameworkCore.Tooling.csproj --locked-mode -m:1 -p:WarningsNotAsErrors=NU1603 
