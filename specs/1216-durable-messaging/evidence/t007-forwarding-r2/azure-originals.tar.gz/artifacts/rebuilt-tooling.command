dotnet build tools/ef/Elsa.EntityFrameworkCore.Tooling/Elsa.EntityFrameworkCore.Tooling.csproj -c Release --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false 
