bash tools/ef/generate-module-migrations.sh --runtime-incremental RuntimeDeliverySources 
