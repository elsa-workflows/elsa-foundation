using System.Runtime.ExceptionServices;
using Elsa.Workflows.Runtime.Contracts;
using Elsa.Workflows.Runtime.Core.Constants;
using Elsa.Workflows.Runtime.Core.Contracts;
using Elsa.Workflows.Runtime.Core.Exceptions;
using Elsa.Workflows.Runtime.Core.Models;
using Elsa.Workflows.Runtime.Services.Claims;
using Elsa.Workflows.Runtime.Services.Incidents;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace Elsa.Workflows.Runtime.Services.Checkpoints;

public sealed class RuntimePostCommitOutboxProcessor : IRuntimePostCommitOutboxProcessor
{
    private const string GenericFailureCode = "runtime-post-commit-delivery-failed";
    private const string RetryUntilAcknowledgedFailureMessage =
        "Runtime post-commit intent delivery deferred pending acknowledgement.";

    private readonly IRuntimePostCommitOutboxStore _outboxStore;
    private readonly IPersistenceAccessContextAccessor? _persistenceAccessContextAccessor;
    private readonly HashSet<string> _requiredSourceKinds = new(StringComparer.Ordinal);
    private readonly HashSet<string> _requiredFinalizationKinds = new(StringComparer.Ordinal);
    private readonly IServiceProvider? _sourceServices;
    private readonly IRuntimePostCommitIntentDispatcher _intentDispatcher;
    private readonly TimeProvider _timeProvider;
    private readonly IRuntimeFaultCapturePolicy _faultCapturePolicy;
    private readonly IRuntimePostCommitOutboxClaimStore? _claimStore;
    private readonly IRuntimePostCommitOutboxClaimCompletionStore? _claimCompletionStore;
    private readonly IWorkflowDispatchStore? _workflowDispatchStore;
    private readonly IPostCommitFailureProjector? _deliveryFailureProjector;
    private readonly IRuntimeLiveDrainDeliveryAccessor? _liveDrainDeliveryAccessor;
    private readonly IRuntimeCoalescingSessionAccessor? _coalescingSessionAccessor;
    private readonly ILogger<RuntimePostCommitOutboxProcessor> _logger;
    private readonly IRuntimeAdmissionLoadSignal? _loadSignal;
    private readonly FencedClaimLease<RuntimePostCommitOutboxClaim>? _claimLease;
    private readonly string _claimOwnerId = $"runtime-outbox-{Guid.NewGuid():N}";
    private static readonly TimeSpan ClaimVisibilityTimeout = RuntimePostCommitOutboxProcessing.ClaimVisibilityTimeout;

    internal RuntimePostCommitOutboxProcessor(IServiceProvider services)
        : this(services.GetRequiredService<IRuntimePostCommitOutboxStore>(),
            services.GetRequiredService<IRuntimePostCommitIntentDispatcher>(), services.GetRequiredService<TimeProvider>(),
            services.GetRequiredService<IRuntimeFaultCapturePolicy>(), services.GetService<IWorkflowDispatchStore>(),
            services.GetServices<IPostCommitFailureProjector>(), services.GetService<ILogger<RuntimePostCommitOutboxProcessor>>(),
            services.GetService<IRuntimeLiveDrainDeliveryAccessor>(), services.GetService<IRuntimeCoalescingSessionAccessor>(),
            services.GetService<IPersistenceAccessContextAccessor>(), services.GetServices<RuntimePostCommitIntentHandlerContribution>(),
            services.GetService<IRuntimeAdmissionLoadSignal>()) => _sourceServices = services;

    public RuntimePostCommitOutboxProcessor(
        IRuntimePostCommitOutboxStore outboxStore,
        IRuntimePostCommitIntentDispatcher intentDispatcher)
        : this(outboxStore, intentDispatcher, TimeProvider.System)
    {
    }

    public RuntimePostCommitOutboxProcessor(
        IRuntimePostCommitOutboxStore outboxStore,
        IRuntimePostCommitIntentDispatcher intentDispatcher,
        TimeProvider timeProvider)
        : this(outboxStore, intentDispatcher, timeProvider, DefaultRuntimeFaultCapturePolicy.CreateDefault())
    {
    }

    public RuntimePostCommitOutboxProcessor(
        IRuntimePostCommitOutboxStore outboxStore,
        IRuntimePostCommitIntentDispatcher intentDispatcher,
        TimeProvider timeProvider,
        IRuntimeFaultCapturePolicy faultCapturePolicy)
        : this(outboxStore, intentDispatcher, timeProvider, faultCapturePolicy, workflowDispatchStore: null)
    {
    }

    public RuntimePostCommitOutboxProcessor(
        IRuntimePostCommitOutboxStore outboxStore,
        IRuntimePostCommitIntentDispatcher intentDispatcher,
        TimeProvider timeProvider,
        IRuntimeFaultCapturePolicy faultCapturePolicy,
        IWorkflowDispatchStore? workflowDispatchStore)
        : this(outboxStore, intentDispatcher, timeProvider, faultCapturePolicy, workflowDispatchStore, logger: null)
    {
    }

    public RuntimePostCommitOutboxProcessor(
        IRuntimePostCommitOutboxStore outboxStore,
        IRuntimePostCommitIntentDispatcher intentDispatcher,
        TimeProvider timeProvider,
        IRuntimeFaultCapturePolicy faultCapturePolicy,
        IWorkflowDispatchStore? workflowDispatchStore,
        ILogger<RuntimePostCommitOutboxProcessor>? logger,
        IRuntimeLiveDrainDeliveryAccessor? liveDrainDeliveryAccessor = null,
        IRuntimeCoalescingSessionAccessor? coalescingSessionAccessor = null)
    {
        ArgumentNullException.ThrowIfNull(outboxStore);
        ArgumentNullException.ThrowIfNull(intentDispatcher);
        ArgumentNullException.ThrowIfNull(timeProvider);
        ArgumentNullException.ThrowIfNull(faultCapturePolicy);

        _outboxStore = outboxStore;
        _intentDispatcher = intentDispatcher;
        _timeProvider = timeProvider;
        _faultCapturePolicy = faultCapturePolicy;
        _claimStore = outboxStore as IRuntimePostCommitOutboxClaimStore;
        _claimCompletionStore = outboxStore as IRuntimePostCommitOutboxClaimCompletionStore;
        _workflowDispatchStore = workflowDispatchStore;
        _liveDrainDeliveryAccessor = liveDrainDeliveryAccessor;
        _coalescingSessionAccessor = coalescingSessionAccessor;
        _logger = logger ?? NullLogger<RuntimePostCommitOutboxProcessor>.Instance;
        // Renewed before each dispatch, never during it (#2195). An intent handler works on the same scoped persistence
        // context as this store, so a renewal running beside the dispatch would collide with the handler's own queries. A
        // dispatch that alone outlives the visibility timeout can therefore still be repeated by a peer. Each intent kind
        // converges under that repeat by its own mechanism, PublishStimulus included since its starts are keyed; the
        // per-kind table under `IRuntimePostCommitOutboxStore` in Runtime EXTENSION_POINTS.md records each one and its limit.
        _claimLease = _claimStore is null
            ? null
            : new FencedClaimLease<RuntimePostCommitOutboxClaim>(
                _claimStore.RenewClaimAsync,
                ClaimVisibilityTimeout,
                _timeProvider);
    }

    public RuntimePostCommitOutboxProcessor(
        IRuntimePostCommitOutboxStore outboxStore,
        IRuntimePostCommitIntentDispatcher intentDispatcher,
        TimeProvider timeProvider,
        IRuntimeFaultCapturePolicy faultCapturePolicy,
        IWorkflowDispatchStore? workflowDispatchStore,
        IEnumerable<IPostCommitFailureProjector> deliveryFailureProjectors,
        ILogger<RuntimePostCommitOutboxProcessor>? logger,
        IRuntimeLiveDrainDeliveryAccessor? liveDrainDeliveryAccessor = null,
        IRuntimeCoalescingSessionAccessor? coalescingSessionAccessor = null)
        : this(outboxStore, intentDispatcher, timeProvider, faultCapturePolicy, workflowDispatchStore, logger, liveDrainDeliveryAccessor, coalescingSessionAccessor)
    {
        ArgumentNullException.ThrowIfNull(deliveryFailureProjectors);
        var projectors = deliveryFailureProjectors.ToArray();
        if (projectors.Length > 1)
        {
            throw new InvalidOperationException(
                "Exactly one owning feature may register the post-commit failure projector replacement contract.");
        }

        _deliveryFailureProjector = projectors.SingleOrDefault();
    }

    public RuntimePostCommitOutboxProcessor(IRuntimePostCommitOutboxStore outboxStore,
        IRuntimePostCommitIntentDispatcher intentDispatcher, TimeProvider timeProvider, IRuntimeFaultCapturePolicy faultCapturePolicy,
        IWorkflowDispatchStore? workflowDispatchStore, IEnumerable<IPostCommitFailureProjector> deliveryFailureProjectors,
        ILogger<RuntimePostCommitOutboxProcessor>? logger, IRuntimeLiveDrainDeliveryAccessor? liveDrainDeliveryAccessor,
        IRuntimeCoalescingSessionAccessor? coalescingSessionAccessor, IPersistenceAccessContextAccessor? persistenceAccessContextAccessor,
        IEnumerable<RuntimePostCommitIntentHandlerContribution> contributions, IRuntimeAdmissionLoadSignal? loadSignal = null)
        : this(outboxStore, intentDispatcher, timeProvider, faultCapturePolicy, workflowDispatchStore, deliveryFailureProjectors,
            logger, liveDrainDeliveryAccessor, coalescingSessionAccessor)
    {
        ArgumentNullException.ThrowIfNull(contributions);
        _loadSignal = loadSignal;
        _persistenceAccessContextAccessor = persistenceAccessContextAccessor;
        var registrations = contributions.ToArray();
        _requiredSourceKinds = RuntimePostCommitOutboxItems.RequiredSourceKinds(registrations);
        _requiredFinalizationKinds = registrations.Where(item => item.RequiresSuccessfulFinalization)
            .Select(item => item.IntentKind).ToHashSet(StringComparer.Ordinal);
    }

    private bool RequiresDurableSource(RuntimePostCommitOutboxItem item) =>
        item.StimulusDeliverySourceScope is not null || item.StimulusDeliveryProtocolVersion is not null ||
        _requiredSourceKinds.Contains(item.Intent.Kind) || _intentDispatcher.RequiresDurableSource(item.Intent.Kind);

    public async ValueTask<RuntimePostCommitOutboxProcessResult> ProcessAsync(
        RuntimePostCommitOutboxProcessRequest request,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        cancellationToken.ThrowIfCancellationRequested();

        var processedItems = new List<RuntimePostCommitOutboxProcessedItem>();

        if (_claimStore is not null && !DeliversInMemory(request))
        {
            var claims = await _claimStore.ClaimAsync(new RuntimePostCommitOutboxClaimRequest(
                ownerId: _claimOwnerId,
                now: _timeProvider.GetUtcNow(),
                visibilityTimeout: ClaimVisibilityTimeout,
                limit: request.Limit,
                workflowExecutionId: request.WorkflowExecutionId,
                intentKind: request.IntentKind), cancellationToken);
            // The whole batch shares one visibility timeout but is dispatched one item at a time, so a long batch can
            // outlive the claims at its end. Each item is renewed immediately before its dispatch, and an item whose
            // claim was lost is skipped rather than dispatched again or allowed to end the batch (#2195).
            foreach (var claim in ContinuationsFirst(claims))
                processedItems.Add(await ProcessClaimedItemAsync(claim, cancellationToken));
        }
        else
        {
            // In-memory live-drain delivery and the compatibility path for third-party v1 stores share the same
            // claim-free mechanics: read the deliverable items, enqueue the continuation through the queue's idempotent
            // EnqueueAsync, and mark the durable outbox item Delivered directly (Pending -> Delivered) via the existing
            // recording contract. DeliversInMemory forces this branch even when the store advertises the claim capability
            // so a live drain skips the durable claim round-trip while the durable outbox item stays a crash backstop.
            var items = await _outboxStore.GetDeliverableAsync(new RuntimePostCommitOutboxQuery(
                now: _timeProvider.GetUtcNow(),
                limit: request.Limit,
                workflowExecutionId: request.WorkflowExecutionId,
                intentKind: request.IntentKind),
                cancellationToken);
            // Deliver only the unfenced items. The fencing token never resets, so a claim that expired or failed
            // retryably leaves the item deliverable again while still carrying its token — and a claim-less recording
            // has no fence to present, so it could only ever come back superseded. Delivering it here would re-run the
            // dispatch for nothing and hand the work to a deliverer that cannot complete it.
            //
            // This filter lives here, not in the store's deliverable query, because that query is shared: it is also
            // the retry-visibility query (a retryable item must reappear once its delay elapses) and the query the
            // migration quiescence probe uses to decide whether outbox work is still outstanding. Hiding fenced items
            // from it would break retries and would let a migration proceed while delivery is still in flight.
            foreach (var item in items.Where(item => item.DeliveryFencingToken == 0))
                processedItems.Add(await ProcessUnclaimedItemAsync(item, cancellationToken));
        }

        return new RuntimePostCommitOutboxProcessResult(processedItems);
    }

    // Dispatches the batch's EnqueueSchedulerWork continuations before every other kind, each part in its claim order
    // (#2225). A continuation only enqueues work. Another kind can need an execution's mailbox: a PublishStimulus start or
    // resume, a DispatchWorkflow parent resume (BookmarkResumeDispatcher -> agent.EnqueueAsync). A live drain holds its
    // execution's mailbox while it waits for a continuation another deliverer claimed, so that continuation must never
    // queue behind a dispatch waiting for the same mailbox. Reordering does not touch the claims: each item is still
    // renewed immediately before its own dispatch.
    private static IEnumerable<RuntimePostCommitOutboxClaim> ContinuationsFirst(IReadOnlyCollection<RuntimePostCommitOutboxClaim> claims) =>
        claims.Where(IsContinuation).Concat(claims.Where(claim => !IsContinuation(claim)));

    private static bool IsContinuation(RuntimePostCommitOutboxClaim claim) =>
        StringComparer.Ordinal.Equals(claim.Item.Intent.Kind, RuntimePostCommitIntentKinds.EnqueueSchedulerWork);

    // The live-drain fast path engages only when a live drain owns this exact execution's delivery, the request targets
    // EnqueueSchedulerWork intents (every other kind stays on the durable claim path), and the drain's session has
    // stopped folding. Every drain pushes a live-drain scope beside its session. While the session folds, its overlay is
    // authoritative and delivers the continuations itself; once it stops (at a boundary that ends it, or from the start
    // on a queue that cannot delete by identity), the rest of the drain commits checkpoint by checkpoint and this path
    // delivers those continuations.
    private bool DeliversInMemory(RuntimePostCommitOutboxProcessRequest request) =>
        _liveDrainDeliveryAccessor?.Current is { } scope &&
        scope.AppliesTo(request.WorkflowExecutionId) &&
        StringComparer.Ordinal.Equals(request.IntentKind, RuntimePostCommitIntentKinds.EnqueueSchedulerWork) &&
        _coalescingSessionAccessor?.Current is not { IsActive: true };

    private async ValueTask<RuntimePostCommitOutboxProcessedItem> ProcessUnclaimedItemAsync(
        RuntimePostCommitOutboxItem item,
        CancellationToken cancellationToken)
    {
        if (RequiresDurableSource(item))
            throw new RuntimePostCommitSourceBoundaryException(item.OutboxItemId, item.Intent.Kind,
                new NotSupportedException("Required-source delivery needs the provider's fenced claim path."), false);
        try
        {
            using var charge = _loadSignal is { HasAmbientCharge: false } ? _loadSignal.OpenCharge() : null;
            await _intentDispatcher.DispatchAsync(item.Intent, cancellationToken);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (WorkflowDispatchAdmissionProjectionException)
        {
            // See the claimed path below.
            throw;
        }
        catch (Exception exception)
        {
            return await RecordFailureAsync(item, claim: null, exception, cancellationToken);
        }

        return await RecordSuccessAsync(item, claim: null, cancellationToken);
    }

    private async ValueTask<RuntimePostCommitOutboxProcessedItem> ProcessClaimedItemAsync(
        RuntimePostCommitOutboxClaim claim,
        CancellationToken cancellationToken)
    {
        var item = claim.Item;
        var run = await _claimLease!.RunAsync(
            claim,
            async dispatchCancellationToken =>
            {
                using var charge = _loadSignal is { HasAmbientCharge: false } ? _loadSignal.OpenCharge() : null;
                if (RequiresDurableSource(item))
                {
                    var source = await OpenDurableSourceAsync(claim, dispatchCancellationToken);
                    if (_intentDispatcher is IRuntimePostCommitCompletionAwareDispatcher completionAware)
                    {
                        var preparation = await completionAware.PrepareDispatchAsync(source, dispatchCancellationToken);
                        if (preparation is null || _requiredFinalizationKinds.Contains(item.Intent.Kind) && preparation.Finalization is null)
                            throw SourceFinalizationUnavailable(item);
                        if (preparation.Finalization is { } finalization)
                        {
                            if (!_requiredFinalizationKinds.Contains(item.Intent.Kind))
                                throw SourceFinalizationUnavailable(item);
                            RequireSourceFinalizationBoundary(source, finalization);
                        }
                        return preparation;
                    }
                    if (_requiredFinalizationKinds.Contains(item.Intent.Kind))
                        throw SourceFinalizationUnavailable(item);
                    await _intentDispatcher.DispatchAsync(source, dispatchCancellationToken);
                }
                else
                    await _intentDispatcher.DispatchAsync(item.Intent, dispatchCancellationToken);
                return RuntimePostCommitDispatchPreparation.LegacyHandled;
            },
            cancellationToken);

        if (run.Exception is RuntimePostCommitSourceBoundaryException boundary)
            ExceptionDispatchInfo.Capture(boundary).Throw();

        if (run.ClaimLost || run.Exception is RuntimePostCommitOutboxStaleClaimException sourceStale &&
            sourceStale.OutboxItemId == claim.OutboxItemId && sourceStale.PresentedOwnerId == claim.OwnerId &&
            sourceStale.PresentedFencingToken == claim.FencingToken)
        {
            // Nothing was dispatched: the claimant that holds the item now delivers it. Delivering is reported as the
            // requested status because nothing was requested at all, and the superseded outcome keeps the item out of
            // the delivered and failed counts.
            LogClaimLost(item, dispatched: false, run.Exception);
            return new RuntimePostCommitOutboxProcessedItem(
                item.OutboxItemId,
                item.Intent.IntentId,
                RuntimePostCommitOutboxStatus.Delivering,
                FailureMessage: null,
                RuntimePostCommitOutboxClaimCompletionOutcome.SupersededByOtherOwner);
        }

        // The child already exists. Leaving the fenced item Delivering lets claim expiry redeliver the exact
        // deterministic start and repair Started without misclassifying a live child as DispatchFailed.
        if (run.Exception is WorkflowDispatchAdmissionProjectionException admissionProjection)
            ExceptionDispatchInfo.Capture(admissionProjection).Throw();

        try
        {
            return run.Exception is { } failure
                ? await RecordFailureAsync(item, run.Claim, failure, cancellationToken)
                : await RecordSuccessAsync(item, run.Claim, cancellationToken, run.Result?.Finalization);
        }
        catch (RuntimePostCommitOutboxStaleClaimException stale)
        {
            // The dispatch outran the claim and a peer re-claimed the item, so this completion is refused and writes
            // nothing (#1812). That is one item's broken lease, not a reason to abandon the rest of the batch: the peer
            // records the item's real outcome, and the intent it dispatched again is idempotent.
            LogClaimLost(item, dispatched: true, stale);
            return new RuntimePostCommitOutboxProcessedItem(
                item.OutboxItemId,
                item.Intent.IntentId,
                run.Exception is { } failure ? EffectiveFailureStatus(item, failure) : RuntimePostCommitOutboxStatus.Delivered,
                FailureMessage: null,
                RuntimePostCommitOutboxClaimCompletionOutcome.SupersededByOtherOwner);
        }
    }

    private void RequireSourceFinalizationBoundary(PostCommitDeliveryContext source, RuntimePostCommitSourceFinalization finalization)
    {
        try
        {
            if (_sourceServices is null || _claimCompletionStore is null)
                throw new NotSupportedException("Source finalization requires the selected scoped completion boundary.");
            var sources = _sourceServices.GetService<IRuntimeDeliverySourceStore>() ??
                throw new NotSupportedException("The selected Runtime backend has no source capability.");
            var boundary = new RuntimeDeliveryBoundary(source.Scope, sources,
                _sourceServices.GetRequiredService<IRuntimeCheckpointCommitStore>(), _outboxStore,
                _sourceServices.GetRequiredService<IWorkflowExecutableStore>(),
                _sourceServices.GetRequiredService<IWorkflowExecutableSourceReferenceStore>(),
                _sourceServices.GetRequiredService<IDurableValueStateStore>(),
                _sourceServices.GetRequiredService<IWorkflowSchedulerWorkQueue>(),
                _sourceServices.GetRequiredService<IWorkflowExecutionStateStore>(),
                _sourceServices.GetRequiredService<IActivityExecutionStateStore>(),
                _sourceServices.GetRequiredService<IBookmarkStateStore>(),
                _sourceServices.GetService<IRuntimeModelExecutionReader>());
            if (!sources.CanParticipate(boundary) || !_claimCompletionStore.CanFinalizeSource(boundary, finalization))
                throw new NotSupportedException("The actual Runtime stores do not support this source participant.");
        }
        catch (Exception exception) when (exception is not RuntimePostCommitSourceBoundaryException)
        {
            throw new RuntimePostCommitSourceBoundaryException(source.SourceOutboxItemId, source.Intent.Kind, exception, false);
        }
    }

    private static RuntimePostCommitSourceBoundaryException SourceFinalizationUnavailable(RuntimePostCommitOutboxItem item) =>
        new(item.OutboxItemId, item.Intent.Kind,
            new NotSupportedException("Required source work needs typed preparation and atomic finalization."), false);

    private async ValueTask<PostCommitDeliveryContext> OpenDurableSourceAsync(RuntimePostCommitOutboxClaim claim,
        CancellationToken cancellationToken)
    {
        try
        {
            var access = _persistenceAccessContextAccessor?.Current ??
                throw new InvalidOperationException("Required-source delivery needs explicit persistence access.");
            var scope = access.RequireScope();
            var lookup = _outboxStore as IPostCommitOutboxLookupStore ??
                throw new NotSupportedException("Required-source delivery needs the provider's durable lookup capability.");
            var current = await lookup.FindDurableAsync(claim.OutboxItemId, cancellationToken) ??
                throw new InvalidDataException("The physically committed source does not exist.");
            if (current.OutboxItemId != claim.OutboxItemId ||
                RuntimeCheckpointCommitFingerprint.ComputeIntent(current.Intent) != RuntimeCheckpointCommitFingerprint.ComputeIntent(claim.Item.Intent) ||
                current.StimulusDeliverySourceScope is { } committedScope && committedScope != scope)
                throw new InvalidDataException("The durable source identity, intent or committed scope differs from the claim.");
            if (current.Status != RuntimePostCommitOutboxStatus.Delivering || current.DeliveringOwnerId != claim.OwnerId ||
                current.DeliveryFencingToken != claim.FencingToken || current.DeliveryVisibleAfter is null ||
                current.DeliveryVisibleAfter <= _timeProvider.GetUtcNow())
                throw new RuntimePostCommitOutboxStaleClaimException(claim.OutboxItemId, claim.OwnerId, claim.FencingToken,
                    current.DeliveringOwnerId, current.DeliveryFencingToken, current.Status);
            var authoritativeClaim = new RuntimePostCommitOutboxClaim(current, claim.OwnerId, claim.FencingToken,
                current.DeliveryStartedAt!.Value, current.DeliveryVisibleAfter.Value);
            return new(authoritativeClaim, scope);
        }
        catch (RuntimePostCommitOutboxStaleClaimException) { throw; }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception exception)
        {
            throw new RuntimePostCommitSourceBoundaryException(claim.OutboxItemId, claim.Item.Intent.Kind, exception,
                exception is not (InvalidDataException or InvalidOperationException or ArgumentException or NotSupportedException));
        }
    }

    private async ValueTask<RuntimePostCommitOutboxProcessedItem> RecordFailureAsync(
        RuntimePostCommitOutboxItem item,
        RuntimePostCommitOutboxClaim? claim,
        Exception exception,
        CancellationToken cancellationToken)
    {
        var classification = exception as RuntimePostCommitDeliveryException;
        var effectiveStatus = EffectiveFailureStatus(item, exception);
        var failureMessage = classification?.SafeSummary ?? (item.RetryPolicy.RetryUntilAcknowledged
            ? RetryUntilAcknowledgedFailureMessage
            : _faultCapturePolicy.Capture(exception).ToSummaryString());
        var recordedAt = _timeProvider.GetUtcNow();
        var (outcome, recordingException) = await TryRecordDeliveryResultAsync(
            item,
            claim,
            effectiveStatus,
            failureMessage,
            recordedAt,
            exception,
            cancellationToken);

        if (recordingException is not null)
            throw new OutboxProcessingException(item.OutboxItemId, item.Intent.IntentId, exception, recordingException);

        // H2: this enum has no exhaustive switch anywhere and the build is warnings-only, so a new value reaches here
        // silently. Superseded is handled FIRST and explicitly — falling through would log this item with the failure
        // status even though the store persisted nothing, misreporting an item this processor does not own.
        if (outcome == RuntimePostCommitOutboxClaimCompletionOutcome.SupersededByOtherOwner)
        {
            LogDeliverySuperseded(item);
            return new RuntimePostCommitOutboxProcessedItem(
                item.OutboxItemId,
                item.Intent.IntentId,
                effectiveStatus,
                failureMessage,
                RuntimePostCommitOutboxClaimCompletionOutcome.SupersededByOtherOwner);
        }

        var persistedStatus = outcome == RuntimePostCommitOutboxClaimCompletionOutcome.DeliveredOnChildEvidence
            ? RuntimePostCommitOutboxStatus.Delivered
            : effectiveStatus;
        LogDeliveryFailure(item, exception, classification, persistedStatus, recordedAt);

        return new RuntimePostCommitOutboxProcessedItem(
            item.OutboxItemId,
            item.Intent.IntentId,
            effectiveStatus,
            failureMessage);
    }

    private async ValueTask<RuntimePostCommitOutboxProcessedItem> RecordSuccessAsync(
        RuntimePostCommitOutboxItem item,
        RuntimePostCommitOutboxClaim? claim,
        CancellationToken cancellationToken,
        RuntimePostCommitSourceFinalization? finalization = null)
    {
        var successOutcome = await RecordDeliveryResultAsync(item, claim, RuntimePostCommitOutboxStatus.Delivered, null, recordedAt: null, deliveryFailure: null, cancellationToken, finalization);
        if (successOutcome == RuntimePostCommitOutboxClaimCompletionOutcome.SupersededByOtherOwner)
        {
            // The dispatch above still happened, and the continuation queue's enqueue is idempotent, so the work is done
            // exactly once. What this processor must NOT do is claim the delivery: the owning deliverer records the item's
            // terminal state, and counting it as delivered here would keep the drain cycling on work it does not own.
            LogDeliverySuperseded(item);
            return new RuntimePostCommitOutboxProcessedItem(
                item.OutboxItemId,
                item.Intent.IntentId,
                RuntimePostCommitOutboxStatus.Delivered,
                FailureMessage: null,
                RuntimePostCommitOutboxClaimCompletionOutcome.SupersededByOtherOwner);
        }

        LogDelivered(item);

        return new RuntimePostCommitOutboxProcessedItem(
            item.OutboxItemId,
            item.Intent.IntentId,
            RuntimePostCommitOutboxStatus.Delivered,
            FailureMessage: null);
    }

    private async ValueTask<(RuntimePostCommitOutboxClaimCompletionOutcome Outcome, Exception? Failure)> TryRecordDeliveryResultAsync(
        RuntimePostCommitOutboxItem item,
        RuntimePostCommitOutboxClaim? claim,
        RuntimePostCommitOutboxStatus status,
        string? failureMessage,
        DateTimeOffset recordedAt,
        Exception deliveryFailure,
        CancellationToken cancellationToken)
    {
        try
        {
            return (await RecordDeliveryResultAsync(item, claim, status, failureMessage, recordedAt, deliveryFailure, cancellationToken), null);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (RuntimePostCommitOutboxStaleClaimException)
        {
            // A lost claim is not a recording failure: the caller skips the item instead of ending the batch.
            throw;
        }
        catch (Exception exception)
        {
            return (RuntimePostCommitOutboxClaimCompletionOutcome.Persisted, exception);
        }
    }

    private async ValueTask<RuntimePostCommitOutboxClaimCompletionOutcome> RecordDeliveryResultAsync(
        RuntimePostCommitOutboxItem item,
        RuntimePostCommitOutboxClaim? claim,
        RuntimePostCommitOutboxStatus status,
        string? failureMessage,
        DateTimeOffset? recordedAt,
        Exception? deliveryFailure,
        CancellationToken cancellationToken,
        RuntimePostCommitSourceFinalization? finalization = null)
    {
        var result = new RuntimePostCommitOutboxDeliveryResult(
            outboxItemId: item.OutboxItemId,
            status: status,
            recordedAt: recordedAt ?? _timeProvider.GetUtcNow(),
            failureMessage: failureMessage);
        if (finalization is not null)
        {
            if (claim is null || _claimCompletionStore is null || status != RuntimePostCommitOutboxStatus.Delivered || deliveryFailure is not null)
                throw SourceFinalizationUnavailable(item);
            return await _claimCompletionStore.CompleteClaimAsync(
                RuntimePostCommitOutboxClaimCompletion.PrepareSourceFinalization(claim, result, finalization), cancellationToken);
        }
        if (claim is not null)
        {
            var dispatchFailure = await CreateDeliveryFailureProjectionAsync(item, result, cancellationToken);
            if (_claimCompletionStore is not null)
            {
                var outcome = await _claimCompletionStore.CompleteClaimAsync(
                    new RuntimePostCommitOutboxClaimCompletion(
                        claim,
                        result,
                        dispatchFailure?.WorkflowDispatch,
                        dispatchFailure?.FollowUpOutboxItem),
                    cancellationToken);
                // A store that found the child already started persisted the start as delivered and discarded the
                // projection, so there is no delivery incident or failure resume to report.
                if (dispatchFailure is not null && outcome == RuntimePostCommitOutboxClaimCompletionOutcome.Persisted)
                    LogDeliveryFailureProjection(item, dispatchFailure, result.RecordedAt, deliveryFailure);
                return outcome;
            }
            else if (dispatchFailure is not null)
            {
                throw new InvalidOperationException(
                    "A final workflow-dispatch start failure requires atomic outbox/dispatch claim completion support.");
            }
            else
                await _claimStore!.RecordDeliveryResultAsync(claim, result, cancellationToken);
        }
        else
            return await _outboxStore.RecordDeliveryResultAsync(result, cancellationToken);

        return RuntimePostCommitOutboxClaimCompletionOutcome.Persisted;
    }

    private async ValueTask<PostCommitFailureProjection?> CreateDeliveryFailureProjectionAsync(
        RuntimePostCommitOutboxItem item,
        RuntimePostCommitOutboxDeliveryResult result,
        CancellationToken cancellationToken)
    {
        if (!WillBecomeFinalFailure(item, result))
            return null;
        if (_deliveryFailureProjector is not null)
            return await _deliveryFailureProjector.ProjectAsync(item, result, cancellationToken);
        if (!StringComparer.Ordinal.Equals(item.Intent.Kind, WorkflowDispatchLifecycle.StartChildIntentKind) ||
            !item.Intent.Metadata.TryGetValue(RuntimeMetadataKeys.DispatchId, out var dispatchId))
            return null;
        if (_workflowDispatchStore is null)
            throw new InvalidOperationException("A workflow dispatch store is required to project final child-start delivery failure.");

        var record = await _workflowDispatchStore.FindAsync(dispatchId, cancellationToken)
            ?? throw new InvalidOperationException($"Workflow dispatch '{dispatchId}' was not found for final child-start delivery failure.");
        var identity = new WorkflowDispatchIdentity(
            record.ParentWorkflowExecutionId,
            record.ParentActivityExecutionId);
        if (!StringComparer.Ordinal.Equals(record.DispatchId, identity.DispatchId) ||
            !StringComparer.Ordinal.Equals(item.Intent.IntentId, identity.StartIntentId) ||
            !StringComparer.Ordinal.Equals(item.Intent.IdempotencyKey, identity.StartIdempotencyKey) ||
            !StringComparer.Ordinal.Equals(item.Intent.WorkflowExecutionId, record.ParentWorkflowExecutionId) ||
            !StringComparer.Ordinal.Equals(item.Intent.ActivityExecutionId, record.ParentActivityExecutionId))
        {
            throw new InvalidOperationException(
                $"Child-start intent '{item.Intent.IntentId}' conflicts with workflow dispatch '{record.DispatchId}'.");
        }
        if (record.Status == WorkflowDispatchStatus.DispatchFailed)
            return new PostCommitFailureProjection(record);
        var generation = WorkflowDispatchLifecycle.ReadDeliveryGeneration(record);
        var attemptCount = RuntimePostCommitRetryPolicy.SaturatingIncrement(item.DeliveryAttemptCount);
        var firstAttemptAt = RuntimePostCommitOutboxClaimTransitions.ReadFirstDeliveryAttemptedAt(item) ??
            item.DeliveryStartedAt ??
            result.RecordedAt;
        var failed = WorkflowDispatchLifecycle.TransitionToDispatchFailed(
            record,
            item.OutboxItemId,
            generation,
            attemptCount,
            firstAttemptAt,
            result.RecordedAt);
        return new PostCommitFailureProjection(failed);
    }

    private static bool WillBecomeFinalFailure(
        RuntimePostCommitOutboxItem item,
        RuntimePostCommitOutboxDeliveryResult result) =>
        result.Status == RuntimePostCommitOutboxStatus.FailedFinal ||
        result.Status == RuntimePostCommitOutboxStatus.FailedRetryable &&
        item.RetryPolicy.IsExhaustedAfterAttempt(
            RuntimePostCommitRetryPolicy.SaturatingIncrement(item.DeliveryAttemptCount));

    private static RuntimePostCommitOutboxStatus EffectiveFailureStatus(
        RuntimePostCommitOutboxItem item,
        Exception deliveryFailure)
    {
        if (deliveryFailure is RuntimePostCommitDeliveryException { Kind: PostCommitFailureKind.Permanent })
            return RuntimePostCommitOutboxStatus.FailedFinal;

        var attemptCount = RuntimePostCommitRetryPolicy.SaturatingIncrement(item.DeliveryAttemptCount);
        return item.RetryPolicy.IsExhaustedAfterAttempt(attemptCount)
            ? RuntimePostCommitOutboxStatus.FailedFinal
            : RuntimePostCommitOutboxStatus.FailedRetryable;
    }

    /// <remarks>
    /// Every failure event carries the delivery exception, so the cause and its stack trace reach the log; the structured
    /// fields stay identifiers and classifications. An expected deferral (<see cref="IRuntimePostCommitDeferral"/>) is a
    /// routine wait rather than a failure and is logged without its exception. The persisted <c>LastFailureMessage</c> and every durable dispatch
    /// and incident projection stay free of exception text. <paramref name="effectiveStatus"/> is the status the store
    /// persisted, which is <see cref="RuntimePostCommitOutboxStatus.Delivered"/> when it found the child of a failed start
    /// already started: the attempt still failed, but nothing became final and no retry was scheduled.
    /// </remarks>
    private void LogDeliveryFailure(
        RuntimePostCommitOutboxItem item,
        Exception exception,
        RuntimePostCommitDeliveryException? classification,
        RuntimePostCommitOutboxStatus effectiveStatus,
        DateTimeOffset recordedAt)
    {
        // Under retry-until-acknowledged a retryable failure is deferred, not scheduled. A permanent failure still ends
        // delivery, so it is logged as final like any other.
        if (item.RetryPolicy.RetryUntilAcknowledged && effectiveStatus == RuntimePostCommitOutboxStatus.FailedRetryable)
        {
            LogRetryUntilAcknowledged(item, exception, recordedAt);
            return;
        }

        item.Intent.Metadata.TryGetValue(RuntimeMetadataKeys.DispatchId, out var dispatchId);
        var attemptCount = RuntimePostCommitRetryPolicy.SaturatingIncrement(item.DeliveryAttemptCount);
        var failureCode = classification?.Code ?? GenericFailureCode;
        var failureKind = classification?.Kind.ToString() ?? PostCommitFailureKind.Transient.ToString();
        _logger.LogWarning(
            new EventId(68101, "RuntimePostCommitDeliveryAttemptFailed"),
            exception,
            "Runtime post-commit delivery attempt failed. OutboxItemId={OutboxItemId} IntentId={IntentId} IntentKind={IntentKind} DispatchId={DispatchId} DeliveryAttemptCount={DeliveryAttemptCount} FailureCode={FailureCode} FailureKind={FailureKind} EffectiveStatus={EffectiveStatus} RecordedAt={RecordedAt}",
            item.OutboxItemId,
            item.Intent.IntentId,
            item.Intent.Kind,
            dispatchId,
            attemptCount,
            failureCode,
            failureKind,
            effectiveStatus,
            recordedAt);

        if (effectiveStatus == RuntimePostCommitOutboxStatus.FailedFinal)
        {
            _logger.LogWarning(
                new EventId(68103, "RuntimePostCommitDeliveryFailedFinal"),
                exception,
                "Runtime post-commit delivery became final. OutboxItemId={OutboxItemId} IntentId={IntentId} IntentKind={IntentKind} DispatchId={DispatchId} DeliveryAttemptCount={DeliveryAttemptCount} FailureCode={FailureCode} FailureKind={FailureKind} EffectiveStatus={EffectiveStatus} RecordedAt={RecordedAt}",
                item.OutboxItemId,
                item.Intent.IntentId,
                item.Intent.Kind,
                dispatchId,
                attemptCount,
                failureCode,
                failureKind,
                effectiveStatus,
                recordedAt);
            return;
        }

        if (effectiveStatus != RuntimePostCommitOutboxStatus.FailedRetryable)
            return;

        var nextAvailableAt = recordedAt.Add(item.RetryPolicy.Delay!.Value);
        _logger.LogWarning(
            new EventId(68102, "RuntimePostCommitRetryScheduled"),
            exception,
            "Runtime post-commit delivery retry scheduled. OutboxItemId={OutboxItemId} IntentId={IntentId} IntentKind={IntentKind} DispatchId={DispatchId} DeliveryAttemptCount={DeliveryAttemptCount} FailureCode={FailureCode} FailureKind={FailureKind} EffectiveStatus={EffectiveStatus} NextAvailableAt={NextAvailableAt}",
            item.OutboxItemId,
            item.Intent.IntentId,
            item.Intent.Kind,
            dispatchId,
            attemptCount,
            failureCode,
            failureKind,
            effectiveStatus,
            nextAvailableAt);
    }

    private void LogDelivered(RuntimePostCommitOutboxItem item)
    {
        item.Intent.Metadata.TryGetValue(RuntimeMetadataKeys.DispatchId, out var dispatchId);
        // Debug, not Information (#2613): a delivery succeeding is the expected path of every checkpoint, and at
        // Information it was ~99% of all persisted structured-log volume, each line a commit on the diagnostics store.
        // Failures, retries and supersessions keep their levels.
        _logger.LogDebug(
            new EventId(68104, "RuntimePostCommitDeliverySucceeded"),
            "Runtime post-commit delivery succeeded. OutboxItemId={OutboxItemId} IntentId={IntentId} IntentKind={IntentKind} DispatchId={DispatchId} DeliveryAttemptCount={DeliveryAttemptCount} EffectiveStatus={EffectiveStatus}",
            item.OutboxItemId,
            item.Intent.IntentId,
            item.Intent.Kind,
            dispatchId,
            RuntimePostCommitRetryPolicy.SaturatingIncrement(item.DeliveryAttemptCount),
            RuntimePostCommitOutboxStatus.Delivered);
    }

    private void LogDeliverySuperseded(RuntimePostCommitOutboxItem item)
    {
        item.Intent.Metadata.TryGetValue(RuntimeMetadataKeys.DispatchId, out var dispatchId);
        // Information, not Warning: losing this race is the designed behaviour of a claim-less live drain running
        // alongside the resumption sweep, not a fault. The owning deliverer records the item's real terminal state.
        _logger.LogInformation(
            new EventId(68110, "RuntimePostCommitDeliverySuperseded"),
            "Runtime post-commit delivery was superseded by another owner; nothing was persisted by this deliverer. OutboxItemId={OutboxItemId} IntentId={IntentId} IntentKind={IntentKind} DispatchId={DispatchId}",
            item.OutboxItemId,
            item.Intent.IntentId,
            item.Intent.Kind,
            dispatchId);
    }

    /// <remarks>
    /// Warning, not Information like <see cref="LogDeliverySuperseded"/>: a claim-less live drain losing to the sweep is
    /// designed contention, but a claimant losing its own lease means a batch or a dispatch outran the visibility timeout.
    /// The exception is the renewal's failure or the store's stale-claim refusal, when there is one.
    /// </remarks>
    private void LogClaimLost(RuntimePostCommitOutboxItem item, bool dispatched, Exception? exception)
    {
        item.Intent.Metadata.TryGetValue(RuntimeMetadataKeys.DispatchId, out var dispatchId);
        _logger.LogWarning(
            new EventId(68113, "RuntimePostCommitClaimLost"),
            exception,
            "Runtime post-commit delivery lost its claim on an outbox item and left the item to the claimant that holds it; nothing was recorded by this deliverer. Dispatched={Dispatched} OutboxItemId={OutboxItemId} IntentId={IntentId} IntentKind={IntentKind} DispatchId={DispatchId}",
            dispatched,
            item.OutboxItemId,
            item.Intent.IntentId,
            item.Intent.Kind,
            dispatchId);
    }

    private void LogDeliveryFailureProjection(
        RuntimePostCommitOutboxItem item,
        PostCommitFailureProjection projection,
        DateTimeOffset recordedAt,
        Exception? deliveryFailure)
    {
        var dispatch = projection.WorkflowDispatch;
        _logger.LogWarning(
            new EventId(68105, "WorkflowDispatchDeliveryIncidentRecorded"),
            deliveryFailure,
            "Workflow dispatch delivery incident recorded. OutboxItemId={OutboxItemId} IntentId={IntentId} IntentKind={IntentKind} DispatchId={DispatchId} DeliveryGeneration={DeliveryGeneration} DeliveryAttemptCount={DeliveryAttemptCount} DeliveryIncidentId={DeliveryIncidentId} DeliveryDeadLetterId={DeliveryDeadLetterId} EffectiveStatus={EffectiveStatus} RecordedAt={RecordedAt}",
            item.OutboxItemId,
            item.Intent.IntentId,
            item.Intent.Kind,
            dispatch.DispatchId,
            WorkflowDispatchLifecycle.ReadDeliveryGeneration(dispatch),
            WorkflowDispatchLifecycle.ReadDeliveryAttemptCount(dispatch),
            WorkflowDispatchLifecycle.ReadDeliveryIncidentId(dispatch),
            WorkflowDispatchLifecycle.ReadDeliveryDeadLetterId(dispatch),
            RuntimePostCommitOutboxStatus.FailedFinal,
            recordedAt);

        if (projection.FollowUpOutboxItem is { } followUp)
        {
            _logger.LogInformation(
                new EventId(68106, "WorkflowDispatchFailureResumeQueued"),
                "Workflow dispatch failure resume queued. OutboxItemId={OutboxItemId} IntentId={IntentId} IntentKind={IntentKind} DispatchId={DispatchId} DeliveryGeneration={DeliveryGeneration} DeliveryIncidentId={DeliveryIncidentId} EffectiveStatus={EffectiveStatus} RecordedAt={RecordedAt}",
                followUp.OutboxItemId,
                followUp.Intent.IntentId,
                followUp.Intent.Kind,
                dispatch.DispatchId,
                WorkflowDispatchLifecycle.ReadDeliveryGeneration(dispatch),
                WorkflowDispatchLifecycle.ReadDeliveryIncidentId(dispatch),
                followUp.Status,
                recordedAt);
        }
    }

    private void LogRetryUntilAcknowledged(RuntimePostCommitOutboxItem item, Exception exception, DateTimeOffset recordedAt)
    {
        if (!item.RetryPolicy.RetryUntilAcknowledged)
            return;

        item.Intent.Metadata.TryGetValue(RuntimeMetadataKeys.DispatchId, out var dispatchId);
        var attemptCount = RuntimePostCommitRetryPolicy.SaturatingIncrement(item.DeliveryAttemptCount);
        var nextAvailableAt = recordedAt.Add(item.RetryPolicy.Delay!.Value);
        _logger.LogWarning(
            new EventId(67901, "RuntimePostCommitRetryDeferred"),
            exception is IRuntimePostCommitDeferral ? null : exception,
            "Runtime post-commit intent retry deferred. OutboxItemId={OutboxItemId} IntentId={IntentId} IntentKind={IntentKind} DispatchId={DispatchId} DeliveryAttemptCount={DeliveryAttemptCount} NextAvailableAt={NextAvailableAt}",
            item.OutboxItemId,
            item.Intent.IntentId,
            item.Intent.Kind,
            dispatchId,
            attemptCount,
            nextAvailableAt);
    }
}
