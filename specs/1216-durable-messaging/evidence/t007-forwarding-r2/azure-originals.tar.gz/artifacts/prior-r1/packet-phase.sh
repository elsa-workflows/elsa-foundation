#!/bin/bash
# Draft only. Start solely through the separately reviewed owned systemd launcher.
set -Eeuo pipefail
umask 077
job_root=$1
packet_root=$2
admission=$3
[[ "$job_root" == /srv/elsa-qualification/durable-messaging/source-5ed3-* ]]
[[ ! -e "$job_root" && ! -L "$job_root" ]]
[[ "$(id -un)" == codex ]]
mkdir -m 0700 "$job_root"
mkdir -m 0700 "$job_root/artifacts" "$job_root/source"
artifacts=$job_root/artifacts
stage=admission
mutant_active=0
processor=Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Checkpoints/RuntimePostCommitOutboxProcessor.cs
started=$(date -u +%FT%TZ)
finish() {
    phase_exit=$?
    trap - EXIT TERM INT
    if [[ "$mutant_active" == 1 ]]; then
        cp "$artifacts/processor-original.cs" "$job_root/source/$processor" || phase_exit=1
    fi
    /usr/bin/python3 "$packet_root/check.py" finish "$job_root" "$packet_root/phase.json" "$stage" "$phase_exit" "$started" || phase_exit=1
    exit "$phase_exit"
}
trap finish EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
/usr/bin/python3 "$packet_root/check.py" admission "$admission" "$packet_root/phase.json" "$packet_root/allocation.json" "$artifacts/admission.json"
dotnet_path=$(/usr/bin/python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["toolPaths"]["dotnet402"])' "$admission")
export PATH="$(dirname "$dotnet_path"):$PATH"
export DOTNET_ROOT="$(dirname "$dotnet_path")"
export DOTNET_CLI_HOME="$job_root/dotnet-home"
export NUGET_PACKAGES="$job_root/nuget"
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_PROCESSOR_COUNT=2
export ELSA_EF_CONFIGURATION=Release
unset ELSA_EF_SCHEMA ELSA_EF_CONNECTION
run_stage() {
    stage=$1
    local ceiling=$2
    shift 2
    printf '%s\n' "$stage" >"$artifacts/current-stage"
    printf '%q ' "$@" >"$artifacts/$stage.command"
    printf '\n' >>"$artifacts/$stage.command"
    local command_exit=0
    timeout --signal=TERM --kill-after=20s "${ceiling}s" "$@" >"$artifacts/$stage.log" 2>&1 || command_exit=$?
    printf '%s\n' "$command_exit" >"$artifacts/$stage.exit"
    return "$command_exit"
}
cd "$job_root/source"
git init --quiet
run_stage source-fetch 120 git -c credential.helper= -c core.askPass= fetch --depth=1 https://github.com/elsa-workflows/elsa-foundation.git 0246b4ecf4ea1df62db2c26437e7cc3cf7e6f40e
git checkout --detach --quiet FETCH_HEAD
stage=private-bundle-validation
/usr/bin/python3 "$packet_root/check.py" bundle "$packet_root/phase.json" "$packet_root/source-5ed3.bundle" "$artifacts/bundle.json"
git bundle verify "$packet_root/source-5ed3.bundle" >"$artifacts/bundle-verify.log" 2>&1
git fetch --no-tags "$packet_root/source-5ed3.bundle" HEAD
git checkout --detach --quiet FETCH_HEAD
stage=private-fixture-validation
/usr/bin/python3 "$packet_root/check.py" fixture "$packet_root/phase.json" "$packet_root/runtime.sqlite.gz" "$artifacts/fixture.json"
stage=source-validation
/usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/base-source.json" baseline
stage=toolchain
[[ "$(dotnet --version)" == 10.0.402 ]]
dotnet --info >"$artifacts/dotnet-info.log" 2>&1
runtime=Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj
ef=Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.Tests.csproj
tooling=tools/ef/Elsa.EntityFrameworkCore.Tooling/Elsa.EntityFrameworkCore.Tooling.csproj
efmodule=Essentials/src/Workflows/Runtime/Persistence/EntityFrameworkCore/Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.csproj
focused='FullyQualifiedName~RuntimePostCommitFinalizationProcessorTests|FullyQualifiedName~RuntimeDeliveryDiscoveryPartitionTests|FullyQualifiedName~RuntimeDeliveryDiscoveryPartitionJsonTests'
mechanism='FullyQualifiedName~RuntimePostCommitFinalizationProcessorTests'
run_stage runtime-locked-restore 180 dotnet restore "$runtime" --locked-mode -m:1 -p:WarningsNotAsErrors=NU1603
run_stage ef-locked-restore 180 dotnet restore "$ef" --locked-mode -m:1 -p:WarningsNotAsErrors=NU1603
run_stage tooling-locked-restore 180 dotnet restore "$tooling" --locked-mode -m:1 -p:WarningsNotAsErrors=NU1603
run_stage tool-restore 60 dotnet tool restore
run_stage runtime-focused 600 dotnet test "$runtime" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter "$focused" --logger 'trx;LogFileName=runtime-focused.trx' --results-directory "$artifacts"
stage=runtime-focused-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/runtime-focused.trx" runtime-focused
stage=prepare-mutation
cp "$processor" "$artifacts/processor-original.cs"
mutant_active=1
/usr/bin/python3 "$packet_root/check.py" mutate "$artifacts"
set +e
run_stage processor-mutation 180 dotnet test "$runtime" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter "$mechanism" --logger 'trx;LogFileName=processor-mutation.trx' --results-directory "$artifacts"
mutation_exit=$?
set -e
stage=mutation-restore
cp "$artifacts/processor-original.cs" "$processor"
cmp "$artifacts/processor-original.cs" "$processor"
mutant_active=0
/usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/restored-source.json" baseline
stage=mutation-oracle
[[ "$mutation_exit" == 1 ]]
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/processor-mutation.trx" processor-mutation
run_stage processor-restored 180 dotnet test "$runtime" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter "$mechanism" --logger 'trx;LogFileName=processor-restored.trx' --results-directory "$artifacts"
stage=processor-restored-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/processor-restored.trx" processor-restored
run_stage ef-projection 240 dotnet test "$ef" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter 'FullyQualifiedName~RuntimeDeliveryDiscoveryProjectionTests' --logger 'trx;LogFileName=ef-projection.trx' --results-directory "$artifacts"
stage=ef-projection-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/ef-projection.trx" ef-projection
run_stage whole-runtime 240 dotnet test "$runtime" --no-build --no-restore --verbosity quiet -m:1 --logger 'trx;LogFileName=whole-runtime.trx' --results-directory "$artifacts"
stage=whole-runtime-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/whole-runtime.trx" whole-runtime
run_stage generate-runtime-source-migrations 480 bash tools/ef/generate-module-migrations.sh --runtime-incremental RuntimeDeliverySources
stage=generated-source-validation
/usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/generated-source.json" generated
run_stage rebuilt-tooling 240 dotnet build "$tooling" -c Release --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false
for provider in Sqlite SqlServer PostgreSql MySql; do
    run_stage "pending-model-$provider" 30 dotnet ef migrations has-pending-model-changes --context "Runtime${provider}DbContext" --project "$efmodule" --startup-project "$tooling" --configuration Release --no-build
done
stage=pending-model-oracle
/usr/bin/python3 "$packet_root/check.py" parity "$artifacts"
# Rebuild this owning project after generation; --no-build would inspect the pre-generation assembly.
run_stage whole-ef 480 dotnet test "$ef" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --logger 'trx;LogFileName=whole-ef.trx' --results-directory "$artifacts"
stage=whole-ef-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/whole-ef.trx" whole-ef
stage=final-source-validation
/usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/final-source.json" generated
stage=complete
