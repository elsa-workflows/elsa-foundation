#!/usr/bin/python3
"""Reclassify retained R1 evidence, never rerun a product test or modify the original artifacts."""
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime

packet_root = Path(sys.argv[1]); job = Path(sys.argv[2])
packet = json.loads((packet_root / 'phase.json').read_text())
prior = Path(packet['priorJobRoot']); source = Path(packet['sourceRoot'])
assert str(prior) == '/srv/elsa-qualification/durable-messaging/source-5ed3-r1'
assert source == prior / 'source' and source.resolve() == source and source.stat().st_uid == os.getuid()
assert not Path('/sys/fs/cgroup/system.slice/elsa-durable-source-5ed3-r1.service').exists()
for directory in ('nuget', 'dotnet-home'):
    path = prior / directory
    assert path.is_dir() and path.resolve() == path and path.stat().st_uid == os.getuid()
retained = job / 'artifacts' / 'prior-r1'; retained.mkdir(mode=0o700)
for item in packet['priorFiles']:
    path = Path(packet['priorPacketRoot']) / item['packetPath'] if 'packetPath' in item else prior / item['path']
    data = path.read_bytes()
    assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], str(path)
    name = 'packet-' + item['packetPath'] if 'packetPath' in item else Path(item['path']).name
    (retained / name).write_bytes(data)
collection = json.loads((packet_root / 'r1-collection-result.json').read_text())
cleanup = json.loads((packet_root / 'r1-cleanup-result.json').read_text())
checked = json.loads((packet_root / 'r1-source-after-stop.json').read_text())
assert collection['primaryStatus'] == 'FAILED' and collection['cleanupStatus'] == collection['sourceStatus'] == 'VERIFIED'
assert collection['errors'] == [] and collection['jobRetained'] == str(prior)
assert cleanup['status'] == 'VERIFIED' and cleanup['unit'] == 'elsa-durable-source-5ed3-r1.service'
assert cleanup['noOtherUnitOrPidStopped'] is True and cleanup['cgroupExistsAfter'] is False
assert cleanup['survivingOwnedIdentities'] == [] and cleanup['membersAfter'] == []
assert checked['status'] == 'VERIFIED' and checked['head'] == packet['head'] and checked['baseTree'] == packet['tree']
assert checked['rawStatusEmpty'] is True and checked['issues'] == checked['changes'] == checked['untracked'] == checked['generatedFiles'] == []
result = json.loads((retained / 'phase-result.json').read_text())
assert result['stage'] == 'mutation-oracle' and result['status'] == 'FAILED_OR_INCOMPLETE' and result['exitCode'] == 1
assert result['baseHead'] == packet['head'] and result['baseTree'] == packet['tree']
elapsed = (datetime.fromisoformat(result['endedAt']) - datetime.fromisoformat(result['startedAt'].replace('Z', '+00:00'))).total_seconds()
assert elapsed == packet['priorActiveSeconds'] and math.ceil(elapsed) == packet['priorActiveCeilingSeconds'] == 206
assert (retained / 'runtime-focused.exit').read_text().strip() == '0'
assert (retained / 'processor-mutation.exit').read_text().strip() == '1'
assert json.loads((retained / 'restored-source.json').read_text())['sourcePolicyPassed'] is True
assert json.loads((retained / 'exit-mutation-restoration.json').read_text())['byteIdentical'] is True
original = (retained / 'processor-original.cs').read_bytes(); mutated = (retained / 'processor-mutated.cs').read_bytes()
before = b'RuntimePostCommitOutboxClaimCompletion.PrepareSourceFinalization(claim, result, finalization)'
after = b'new RuntimePostCommitOutboxClaimCompletion(claim, result)'
assert original.count(before) == 1 and original.replace(before, after) == mutated
assert (source / 'Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Checkpoints/RuntimePostCommitOutboxProcessor.cs').read_bytes() == original
mutation = json.loads((retained / 'processor-mutation.json').read_text())
assert mutation['originalSha256'] == hashlib.sha256(original).hexdigest()
assert mutation['mutatedSha256'] == hashlib.sha256(mutated).hexdigest()
# These are parser-only reads of copied original TRX. No dotnet or product test is launched here.
for name, mode in (('runtime-focused.trx', 'runtime-focused'), ('processor-mutation.trx', 'processor-mutation')):
    subprocess.check_call(['/usr/bin/python3', str(packet_root / 'check.py'), 'trx', str(retained / name), mode])
(job / 'artifacts' / 'resume-proof.json').write_text(json.dumps({
    'baseHead': packet['head'], 'baseTree': packet['tree'], 'sourceRoot': str(source), 'priorJobRoot': str(prior),
    'originalR1Status': 'FAILED_OR_INCOMPLETE', 'retainedFocusedCases': 55, 'retainedMutationPassed': 7,
    'retainedMutationFailed': 1, 'expectedAssertionReclassified': True, 'priorActiveSeconds': elapsed,
    'priorActiveCeilingSeconds': math.ceil(elapsed), 'remainingActiveSeconds': packet['remainingActiveSeconds'],
    'newProductRuns': 0, 'originalArtifactsWritten': False}, indent=2) + '\n')
