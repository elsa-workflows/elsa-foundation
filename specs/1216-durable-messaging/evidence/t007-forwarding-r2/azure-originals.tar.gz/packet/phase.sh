#!/bin/bash
# Continue the owned, restored R1 checkout. Never repeat focused55 or the real mutant8.
set -Eeuo pipefail
umask 077
job_root=$1
packet_root=$2
admission=$3
[[ "$job_root" == /srv/elsa-qualification/durable-messaging/source-5ed3-r2 ]]
[[ ! -e "$job_root" && ! -L "$job_root" ]]
[[ "$(id -un)" == codex ]]
mkdir -m 0700 "$job_root"
mkdir -m 0700 "$job_root/artifacts"
artifacts=$job_root/artifacts
stage=admission
started=$(date -u +%FT%TZ)
finish() {
    phase_exit=$?
    trap - EXIT TERM INT
    /usr/bin/python3 "$packet_root/check.py" finish "$job_root" "$packet_root/phase.json" "$stage" "$phase_exit" "$started" || phase_exit=1
    exit "$phase_exit"
}
trap finish EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
/usr/bin/python3 "$packet_root/check.py" admission "$admission" "$packet_root/phase.json" "$packet_root/allocation.json" "$artifacts/admission.json"
dotnet_path=$(/usr/bin/python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["toolPaths"]["dotnet402"])' "$admission")
export PATH="$(dirname "$dotnet_path"):$PATH"
export DOTNET_ROOT="$(dirname "$dotnet_path")"
export DOTNET_CLI_HOME=/srv/elsa-qualification/durable-messaging/source-5ed3-r1/dotnet-home
export NUGET_PACKAGES=/srv/elsa-qualification/durable-messaging/source-5ed3-r1/nuget
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_PROCESSOR_COUNT=2
export ELSA_EF_CONFIGURATION=Release
unset ELSA_EF_SCHEMA ELSA_EF_CONNECTION
run_stage() {
    stage=$1
    local ceiling=$2
    shift 2
    printf '%s\n' "$stage" >"$artifacts/current-stage"
    printf '%q ' "$@" >"$artifacts/$stage.command"
    printf '\n' >>"$artifacts/$stage.command"
    local command_exit=0
    timeout --signal=TERM --kill-after=20s "${ceiling}s" "$@" >"$artifacts/$stage.log" 2>&1 || command_exit=$?
    printf '%s\n' "$command_exit" >"$artifacts/$stage.exit"
    return "$command_exit"
}
run_stage resume-proof 60 /usr/bin/python3 "$packet_root/resume-proof.py" "$packet_root" "$job_root"
cd /srv/elsa-qualification/durable-messaging/source-5ed3-r1/source
stage=source-validation
/usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/base-source.json" baseline
stage=toolchain
[[ "$(dotnet --version)" == 10.0.402 ]]
dotnet --info >"$artifacts/dotnet-info.log" 2>&1
runtime=Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj
ef=Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.Tests.csproj
tooling=tools/ef/Elsa.EntityFrameworkCore.Tooling/Elsa.EntityFrameworkCore.Tooling.csproj
efmodule=Essentials/src/Workflows/Runtime/Persistence/EntityFrameworkCore/Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.csproj
# R1's final test assembly was mutated; rebuild from the verified byte-identical restored source.
run_stage processor-restored 180 dotnet test "$runtime" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter 'FullyQualifiedName~RuntimePostCommitFinalizationProcessorTests' --logger 'trx;LogFileName=processor-restored.trx' --results-directory "$artifacts"
stage=processor-restored-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/processor-restored.trx" processor-restored
run_stage ef-projection 240 dotnet test "$ef" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter 'FullyQualifiedName~RuntimeDeliveryDiscoveryProjectionTests' --logger 'trx;LogFileName=ef-projection.trx' --results-directory "$artifacts"
stage=ef-projection-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/ef-projection.trx" ef-projection
run_stage whole-runtime 240 dotnet test "$runtime" --no-build --no-restore --verbosity quiet -m:1 --logger 'trx;LogFileName=whole-runtime.trx' --results-directory "$artifacts"
stage=whole-runtime-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/whole-runtime.trx" whole-runtime
run_stage generate-runtime-source-migrations 480 bash tools/ef/generate-module-migrations.sh --runtime-incremental RuntimeDeliverySources
stage=generated-source-validation
/usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/generated-source.json" generated
run_stage rebuilt-tooling 240 dotnet build "$tooling" -c Release --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false
for provider in Sqlite SqlServer PostgreSql MySql; do
    run_stage "pending-model-$provider" 30 dotnet ef migrations has-pending-model-changes --context "Runtime${provider}DbContext" --project "$efmodule" --startup-project "$tooling" --configuration Release --no-build
done
stage=pending-model-oracle
/usr/bin/python3 "$packet_root/check.py" parity "$artifacts"
run_stage whole-ef 480 dotnet test "$ef" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --logger 'trx;LogFileName=whole-ef.trx' --results-directory "$artifacts"
stage=whole-ef-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/whole-ef.trx" whole-ef
stage=final-source-validation
/usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/final-source.json" generated
stage=complete
