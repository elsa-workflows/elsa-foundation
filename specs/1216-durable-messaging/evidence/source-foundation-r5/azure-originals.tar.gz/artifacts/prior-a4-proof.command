/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r5/handoff.py prior /opt/elsa-durable-messaging/message-foundation-r5 /srv/elsa-qualification/durable-messaging/message-foundation-r5 
