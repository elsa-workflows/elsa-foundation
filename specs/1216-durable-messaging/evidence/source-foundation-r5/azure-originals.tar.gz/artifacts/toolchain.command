/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r5/check.py toolchain 
