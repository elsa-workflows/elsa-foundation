/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r5/check.py mutate /srv/elsa-qualification/durable-messaging/message-foundation-r5/artifacts 
