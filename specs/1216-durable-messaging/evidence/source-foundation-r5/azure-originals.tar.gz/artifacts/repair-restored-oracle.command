/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r5/check.py trx /srv/elsa-qualification/durable-messaging/message-foundation-r5/artifacts/repair-restored.trx repair-restored 
