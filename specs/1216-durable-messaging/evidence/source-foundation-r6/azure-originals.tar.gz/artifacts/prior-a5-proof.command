/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r6/handoff.py prior /opt/elsa-durable-messaging/message-foundation-r6 /srv/elsa-qualification/durable-messaging/message-foundation-r6 
