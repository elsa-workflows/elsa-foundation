/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r6/check.py toolchain 
