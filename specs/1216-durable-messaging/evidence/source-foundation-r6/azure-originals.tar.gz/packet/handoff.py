#!/usr/bin/python3
"""Retain actual failed A5 originals; refresh only unfinished EF outputs on the same warm source."""
from pathlib import Path
import hashlib,json,math,os,subprocess,sys
p=Path(sys.argv[2]);job=Path(sys.argv[3]);phase=json.loads((p/'phase.json').read_text());prior=Path(phase['priorJobRoot']);artifacts=job/'artifacts'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):
    assert path.is_file() and not path.is_symlink() and path.resolve()==path and path.stat().st_uid==os.getuid(),str(path)
    return path.read_bytes()
def git(*args):return subprocess.check_output(['git',*args])
def write(name,value):(artifacts/name).write_text(json.dumps(value,indent=2)+'\n')
def assets(root):
    items=[]
    for path in sorted(root.rglob('project.assets.json')):
        data=read(path);value=json.loads(data);project=Path(value['project']['restore']['projectPath'])
        assert project.is_file() and project.resolve()==project and project.is_relative_to(root)
        items.append({'path':str(path.relative_to(root)),'projectPath':str(project),'bytes':len(data),'sha256':sha(data)})
    assert 2<=len(items)<=512
    for needed in ['Essentials/tests/Workflows/Runtime/Tests/obj/project.assets.json','Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/obj/project.assets.json']:
        assert any(item['path']==needed for item in items)
    return items
if sys.argv[1]=='prior':
    assert str(prior)=='/srv/elsa-qualification/durable-messaging/message-foundation-r5'
    assert not Path('/sys/fs/cgroup/system.slice/elsa-durable-message-foundation-r5.service').exists()
    primary=json.loads((p/'prior-a5-primary.json').read_text());cleanup=json.loads((p/'prior-a5-cleanup.json').read_text())
    checked=json.loads((p/'prior-a5-source.json').read_text());collection=json.loads((p/'prior-a5-collection.json').read_text())
    assert primary['status']=='FAILED' and primary['originalSystemdResult']=='exit-code' and primary['originalExecMainStatus']=='124'
    result=primary['originalPhaseResult'];assert result['stage']=='ef-output-refresh' and result['exitCode']==124 and result['status']=='FAILED_OR_INCOMPLETE'
    proof=primary['executionBudgetProof'];assert proof['status']=='VERIFIED' and proof['priorActiveCeilingSeconds']==730
    assert proof['conservativeCumulativeSeconds']==871.032886 and math.ceil(proof['conservativeCumulativeSeconds'])==phase['priorActiveCeilingSeconds']==872
    assert proof['limitSeconds']==1800 and 872+180+690==1742<=1800
    assert cleanup['status']=='VERIFIED' and not cleanup['cgroupExistsAfter'] and cleanup['membersAfter']==cleanup['survivingOwnedIdentities']==[]
    assert checked['status']=='VERIFIED' and checked['issues']==[] and checked['rawStatusEmpty'] is True and checked['head']==phase['head'] and checked['tree']==phase['tree']
    assert collection['primaryStatus']=='FAILED' and collection['cleanupStatus']==collection['sourceStatus']=='VERIFIED' and collection['errors']==[]
    retained=artifacts/'prior-a5';retained.mkdir(mode=0o700)
    for item in phase['priorFiles']:
        data=read(prior/item['path']);assert len(data)==item['bytes'] and sha(data)==item['sha256']
        with (retained/item['retainedName']).open('xb') as stream:stream.write(data)
    assert json.loads((retained/'phase-result.json').read_text())==result
    for stage,code in [('repair-mutation',1),('repair-restored',0),('whole-runtime',0),('ef-focused',0),('ef-output-refresh',124)]:
        assert (retained/(stage+'.exit')).read_text().strip()==str(code)
    for mode in ['repair-mutation','repair-restored','whole-runtime','ef-focused','runtime-focused']:
        subprocess.check_call(['/usr/bin/python3',str(p/'check.py'),'trx',str(retained/(mode+'.trx')),mode])
    for name in ['repair-restoration.json','exit-restoration.json']:assert json.loads((retained/name).read_text())['byteIdentical'] is True
    for mode in ['mutant','restored']:
        value=json.loads((retained/('runtime-product-'+mode+'.json')).read_text())
        assert value['head']==phase['head'] and value['tree']==phase['tree'] and value['actualBuiltProductMatchesTestDirectory'] is True
        assert value['runtimeSha256']==value['testRuntimeSha256']==phase['retainedRuntimeProducts'][mode]
        (artifacts/('runtime-product-'+mode+'.json')).write_bytes((retained/('runtime-product-'+mode+'.json')).read_bytes())
    assert phase['retainedRuntimeProducts']['mutant']!=phase['retainedRuntimeProducts']['restored']
    old=json.loads((retained/'old-cohort-closure.json').read_text());assert old['status']=='VERIFIED' and old['oldCohortSeconds']==1652.889368 and old['noOldOutcomeReset'] is True
    failed=json.loads((retained/'prior-a4-proof.json').read_text());assert failed['status']=='VERIFIED' and failed['priorAAndA2AndA3AndA4FailedPreserved'] is True
    write('prior-a5-proof.json',{'status':'VERIFIED','priorAAndA2AndA3AndA4AndA5FailedPreserved':True,'priorArchive':phase['priorArchive'],
        'priorExactCumulativeSeconds':871.032886,'priorActiveCeilingSeconds':872,'runtimeFocused86Retained':True,'efFocused37Retained':True,
        'mutationExpectedFailureRetained':True,'restoredRegressionRetained':True,'wholeRuntime3685Retained':True,
        'noProductTestsRepeated':True,'oldCohortSeconds':1652.889368,'oldOutcomeReset':False,'oldArtifactsWritten':False})
elif sys.argv[1]=='library':
    assert Path.cwd()==Path(phase['sourceRoot'])
    for name in ['runtimeLibraryPath','runtimeTestProductPath']:
        assert sha(read(Path.cwd()/phase[name]))==phase['retainedRuntimeProducts']['restored'],'Actual Runtime product no longer matches retained A5 restored build'
    write('current-restored-product.json',{'status':'VERIFIED','head':phase['head'],'tree':phase['tree'],'runtimeSha256':phase['retainedRuntimeProducts']['restored'],
        'actualLibraryAndRuntimeTestDirectoryMatchRetainedRestoredProduct':True})
elif sys.argv[1] in ('source','final'):
    root=Path(phase['sourceRoot']);assert str(root)=='/srv/elsa-qualification/durable-messaging/message-foundation-r1/source' and root.resolve()==root and root.stat().st_uid==os.getuid() and Path.cwd()==root
    assert not git('status','--porcelain=v1','--untracked-files=all')
    assert git('rev-parse','HEAD').decode().strip()==phase['head'] and git('rev-parse','HEAD^{tree}').decode().strip()==phase['tree']
    for name in ['dotnetHome','nugetCache']:
        directory=Path(phase[name]);assert directory.is_dir() and directory.resolve()==directory and directory.stat().st_uid==os.getuid()
    assert os.environ.get('DOTNET_CLI_HOME')==phase['dotnetHome'] and os.environ.get('NUGET_PACKAGES')==phase['nugetCache']
    current=assets(root)
    if sys.argv[1]=='source':
        assert current==json.loads((artifacts/'prior-a5/assets-before.json').read_text())
        write('assets-before.json',current)
        subprocess.check_call(['/usr/bin/python3',str(p/'check.py'),'source',str(p/'phase.json'),str(artifacts/'base-source.json')])
        write('warm-source.json',{'status':'VERIFIED','head':phase['head'],'tree':phase['tree'],'sameAbsoluteSourceRoot':str(root),
            'assetsFiles':current,'dotnetHome':phase['dotnetHome'],'nugetCache':phase['nugetCache'],'sourceVersionChanged':False,
            'productionOrProjectSourcesChanged':False,'restorePerformed':False,'oldArtifactsOrPacketWrites':False})
    else:
        assert current==json.loads((artifacts/'assets-before.json').read_text()),'Warm assets changed without authorized restore'
        subprocess.check_call(['/usr/bin/python3',str(p/'check.py'),'source',str(p/'phase.json'),str(artifacts/'final-source.json')])
        write('warm-final.json',{'status':'VERIFIED','head':phase['head'],'tree':phase['tree'],'assetsUnchanged':True,'assetsFiles':current,'restorePerformed':False})
else:raise ValueError('Unsupported handoff operation')
