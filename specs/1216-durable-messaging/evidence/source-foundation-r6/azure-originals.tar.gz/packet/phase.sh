#!/bin/bash
set -Eeuo pipefail
umask 077
job_root=$1
packet_root=$2
admission=$3
[[ "$job_root" == /srv/elsa-qualification/durable-messaging/message-foundation-r6 ]]
[[ ! -e "$job_root" && ! -L "$job_root" && "$(id -un)" == codex ]]
mkdir -m 0700 "$job_root"
mkdir -m 0700 "$job_root/artifacts"
artifacts=$job_root/artifacts
source_root=/srv/elsa-qualification/durable-messaging/message-foundation-r1/source
stage=admission
switch=Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Executables/InMemoryWorkflowActivationSwitch.cs
started=$(date -u +%FT%TZ)
finish() {
    phase_exit=$?
    trap - EXIT TERM INT
    /usr/bin/timeout --signal=TERM --kill-after=1s 8s /usr/bin/python3 "$packet_root/check.py" finish "$job_root" "$packet_root/phase.json" "$stage" "$phase_exit" "$started" || phase_exit=1
    exit "$phase_exit"
}
trap finish EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
run_stage() {
    stage=$1
    local ceiling=$2
    shift 2
    printf '%s\n' "$stage" >"$artifacts/current-stage"
    printf '%q ' "$@" >"$artifacts/$stage.command"
    printf '\n' >>"$artifacts/$stage.command"
    local command_exit=0
    timeout --signal=TERM --kill-after=5s "${ceiling}s" "$@" >"$artifacts/$stage.log" 2>&1 || command_exit=$?
    printf '%s\n' "$command_exit" >"$artifacts/$stage.exit"
    return "$command_exit"
}
run_stage admission 10 /usr/bin/python3 "$packet_root/check.py" admission "$admission" "$packet_root/phase.json" "$packet_root/allocation.json" "$artifacts/admission.json"
run_stage prior-a5-proof 10 /usr/bin/python3 "$packet_root/handoff.py" prior "$packet_root" "$job_root"
dotnet_path=$(/usr/bin/python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["toolPaths"]["dotnet402"])' "$admission")
export PATH="$(dirname "$dotnet_path"):$PATH" DOTNET_ROOT="$(dirname "$dotnet_path")"
export DOTNET_CLI_HOME=/srv/elsa-qualification/durable-messaging/message-foundation-r2/dotnet-home
export NUGET_PACKAGES=/srv/elsa-qualification/durable-messaging/source-5ed3-r1/nuget
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_PROCESSOR_COUNT=2 GIT_TERMINAL_PROMPT=0
unset ELSA_EF_SCHEMA ELSA_EF_CONNECTION
cd "$source_root"
run_stage source-warm-proof 5 /usr/bin/python3 "$packet_root/handoff.py" source "$packet_root" "$job_root"
run_stage toolchain 5 /usr/bin/python3 "$packet_root/check.py" toolchain
runtime_library=Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Elsa.Workflows.Runtime.csproj
runtime=Essentials/tests/Workflows/Runtime/Tests/Elsa.Workflows.Runtime.Tests.csproj
ef=Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.Tests.csproj
ef_focused='FullyQualifiedName~RuntimeDeliverySourceReadClaimTests|FullyQualifiedName~BusinessMessageCanonicalCodecTests'
critical='FullyQualifiedName=Elsa.Workflows.Runtime.Tests.MessagePublicationInterestIntegrationTests.Legacy_repair_revalidates_prepared_material_before_any_projection_switches'
run_stage restored-product-before 3 /usr/bin/python3 "$packet_root/handoff.py" library "$packet_root" "$job_root"
run_stage ef-output-refresh 120 dotnet build "$ef" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false -p:BuildProjectReferences=false
run_stage assemblies-ready 5 /usr/bin/python3 "$packet_root/check.py" assemblies "$packet_root/phase.json" "$artifacts/assemblies-ready.json"
run_stage source-final 5 /usr/bin/python3 "$packet_root/handoff.py" final "$packet_root" "$job_root"
stage=complete
