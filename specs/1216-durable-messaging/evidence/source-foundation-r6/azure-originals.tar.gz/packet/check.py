#!/usr/bin/python3
"""Task-specific frozen Message foundation checks; imports perform no product/network work."""
import hashlib,json,math,os,re,subprocess,sys,urllib.request,xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime,timezone,timedelta

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):
    path=Path(path);temporary=path.with_suffix(path.suffix+'.tmp');temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(path)
def git(*args):return subprocess.check_output(['git',*args])
def source(packet,destination):
    assert git('rev-parse','HEAD').decode().strip()==packet['head']
    assert git('rev-parse','HEAD^{tree}').decode().strip()==packet['tree']
    assert not git('status','--porcelain=v1','--untracked-files=all')
    assert 1<=len(packet['sourceFiles'])<=128
    for item in packet['sourceFiles']:assert digest(item['path'])==item['sha256'],item['path']
    fixture=packet['fixture'];assert Path(fixture['path']).stat().st_size==fixture['bytes'] and digest(fixture['path'])==fixture['sha256']
    write(destination,{'head':packet['head'],'tree':packet['tree'],'cleanSourcePolicyPassed':True,'sourceFileCount':len(packet['sourceFiles']),'fixtureSha256':fixture['sha256']})
def trx(path,mode):
    path=Path(path);root=ET.parse(path).getroot();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    counters={k:int(v) for k,v in root.find('.//t:Counters',ns).attrib.items()};results=root.findall('.//t:UnitTestResult',ns)
    methods={d.get('id'):d.find('t:TestMethod',ns).attrib for d in root.findall('.//t:UnitTest',ns)}
    expected={'runtime-focused':86,'ef-focused':37,'repair-mutation':1,'repair-restored':1,'whole-runtime':3685,'whole-ef':1946}[mode]
    assert counters['total']==counters['executed']==len(results)==len({r.get('executionId') for r in results})==expected
    for key,value in counters.items():
        if key not in ('total','executed','passed','failed'):assert value==0,(key,counters)
    critical='Elsa.Workflows.Runtime.Tests.MessagePublicationInterestIntegrationTests.Legacy_repair_revalidates_prepared_material_before_any_projection_switches'
    if mode=='repair-mutation':
        assert counters['failed']==1 and counters['passed']==0 and root.find('.//t:ResultSummary',ns).get('outcome')=='Failed'
        assert results[0].get('outcome')=='Failed'
        method=methods[results[0].get('testId')];assert method['className']+'.'+method['name']==critical
        message=results[0].find('.//t:Message',ns).text or ''
        assert message.startswith('Assert.Throws() Failure: No exception was thrown'),message
        errors=root.findall('.//t:RunInfo[@outcome="Error"]',ns);assert len(errors)==1 and len(errors[0])==1
        text=errors[0].find('t:Text',ns);assert text is not None and re.fullmatch(r'\[xUnit\.net [0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]+)?\]\s+'+re.escape(critical)+r' \[FAIL\]',text.text or '')
    else:
        assert counters['failed']==0 and counters['passed']==expected and all(r.get('outcome')=='Passed' for r in results)
        assert not root.findall('.//t:RunInfo[@outcome="Error"]',ns)
    classes={};qualified=[]
    for result in results:
        method=methods[result.get('testId')];name=method['className'].rsplit('.',1)[-1];classes[name]=classes.get(name,0)+1
        qualified.append(method['className']+'.'+method['name'])
    if mode=='runtime-focused':assert classes=={'BusinessMessageAcceptedHeaderTests':29,'MessagePublicationInterestIntegrationTests':17,'BusinessMessageSourceCodecTests':40},classes
    if mode=='ef-focused':assert classes=={'RuntimeDeliverySourceReadClaimTests':32,'BusinessMessageCanonicalCodecTests':5},classes
    if mode in ('repair-mutation','repair-restored'):assert qualified==[critical]
    if mode=='whole-runtime':
        assert all(name in classes for name in ['BusinessMessageAcceptedHeaderTests','MessagePublicationInterestIntegrationTests','BusinessMessageSourceCodecTests'])
    if mode=='whole-ef':
        assert classes.get('RuntimeDeliverySourceReadClaimTests')==32 and classes.get('BusinessMessageCanonicalCodecTests')==5
        assert any(name.endswith('.Additive_model_tables_upgrade_an_actual_legacy_store_without_changing_any_legacy_rows') for name in qualified)
    write(path.with_suffix('.counters.json'),{'mode':mode,'counters':counters,'classes':classes,'rawSha256':digest(path)})

op=sys.argv[1]
if op=='admission':
    expected=json.loads(Path(sys.argv[2]).read_text());packet=json.loads(Path(sys.argv[3]).read_text());grant=json.loads(Path(sys.argv[4]).read_text())
    assert digest(sys.argv[4])==packet['allocationSha256']=='2bdedc2fd9061d21d6d4cac3901abdd0b67c2755582d0ab21823f73f035ba7ec'
    assert grant['ownerChatId']==packet['ownerChatId'] and grant['workerName']==expected['name']=='elsa-dev-18'
    assert grant['resourceId'].casefold()==expected['resourceId'].casefold() and grant['limits']['operationalSeconds']==1800 and grant['limits']['cleanupSeconds']==120
    assert packet['reviewBlockers']==[] and re.fullmatch('[0-9a-f]{40}',packet['head']) and re.fullmatch('[0-9a-f]{40}',packet['tree'])
    request=urllib.request.Request('http://169.254.169.254/metadata/instance?api-version=2021-02-01',headers={'Metadata':'true'})
    with urllib.request.urlopen(request,timeout=8) as response:compute=json.load(response)['compute']
    facts={'name':compute['name'],'vmId':compute['vmId'],'resourceId':compute['resourceId'],'subscriptionId':compute['subscriptionId'],
        'machineId':Path('/etc/machine-id').read_text().strip(),'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'uid':os.getuid(),'at':datetime.now(timezone.utc).isoformat(),'toolPaths':expected['toolPaths'],'cgroup':Path('/proc/self/cgroup').read_text()}
    for key in ('name','vmId','machineId','bootId','uid'):assert facts[key]==expected[key],key
    assert expected['admitted'] is True and facts['resourceId'].casefold()==expected['resourceId'].casefold()
    assert facts['subscriptionId']=='8e23037a-420f-4ad0-9594-9d194de29e84'
    expiry=min(datetime.fromisoformat(v.replace('Z','+00:00')) for v in [expected['effectiveExpiresAt'],grant['expiresAt'],packet['hardExpiresAt']])
    assert packet['priorActiveCeilingSeconds']==872 and packet['priorActiveCeilingSeconds']+packet['remainingActiveSeconds']==1800
    assert 872+packet['budgetsSeconds']['outerSystemd']+packet['budgetsSeconds']['followingWholeEf']==1742<=1800
    assert datetime.now(timezone.utc)+timedelta(seconds=packet['budgetsSeconds']['outerSystemd']+30+120)<expiry
    facts['dotnetHostSha256']=digest(Path(expected['toolPaths']['dotnet402']).resolve());assert facts['dotnetHostSha256']==expected['dotnetHostSha256']
    cgroup=Path('/sys/fs/cgroup')/facts['cgroup'].strip().split('::',1)[1].lstrip('/')
    quota,period=(cgroup/'cpu.max').read_text().split();memory=(cgroup/'memory.max').read_text().strip();swap=(cgroup/'memory.swap.max').read_text().strip()
    assert quota!='max' and int(quota)<=2*int(period) and memory!='max' and int(memory)<=6500*1024*1024 and swap=='0'
    facts['limits']={'cpuMax':[quota,period],'memoryMax':memory,'memorySwapMax':swap};write(sys.argv[5],facts)
elif op=='toolchain':
    assert subprocess.check_output(['dotnet','--version']).decode().strip()=='10.0.402'
    subprocess.check_call(['uptime']);subprocess.check_call(['nproc']);subprocess.check_call(['dotnet','--info'])
elif op=='source':source(json.loads(Path(sys.argv[2]).read_text()),sys.argv[3])
elif op=='trx':trx(sys.argv[2],sys.argv[3])
elif op=='mutate':
    artifacts=Path(sys.argv[2]);path=Path('Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Executables/InMemoryWorkflowActivationSwitch.cs');original=path.read_bytes()
    before=b'                    projection.CheckSwitch(plan.ActivationId, null);'
    after=b'                    if (projection is not InMemoryMessagePublicationInterestStore)\n                        projection.CheckSwitch(plan.ActivationId, null);'
    assert original.count(before)==1
    (artifacts/'repair-original.cs').write_bytes(original);path.write_bytes(original.replace(before,after));(artifacts/'repair-mutated.cs').write_bytes(path.read_bytes())
    (artifacts/'repair-mutation.patch').write_bytes(git('diff','--binary','--full-index','--',str(path)))
    write(artifacts/'repair-mutation.json',{'singleChange':'Skip only Message CheckSwitch during repair before any projection switch','originalSha256':hashlib.sha256(original).hexdigest(),'mutatedSha256':digest(path)})
elif op=='restore':
    packet=json.loads(Path(sys.argv[2]).read_text());artifacts=Path(sys.argv[3]);path=Path('Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Executables/InMemoryWorkflowActivationSwitch.cs')
    original=(artifacts/'repair-original.cs').read_bytes();path.write_bytes(original);assert path.read_bytes()==original
    source(packet,artifacts/'restored-source.json');write(artifacts/'repair-restoration.json',{'byteIdentical':True,'sha256':digest(path)})
elif op=='runtime-product':
    packet=json.loads(Path(sys.argv[2]).read_text());artifacts=Path(sys.argv[3]);mode=sys.argv[4]
    assert mode in ('mutant','restored')
    library=Path(packet['runtimeLibraryPath']);consumer=Path(packet['runtimeTestProductPath'])
    assert library.is_file() and consumer.is_file() and not library.is_symlink() and not consumer.is_symlink()
    built=digest(library);actual=digest(consumer);assert built==actual,'Test-directory Runtime product differs from the actual built Runtime library'
    if mode=='restored':assert built!=json.loads((artifacts/'runtime-product-mutant.json').read_text())['runtimeSha256'],'Restored Runtime product equals mutant'
    write(artifacts/('runtime-product-'+mode+'.json'),{'mode':mode,'head':packet['head'],'tree':packet['tree'],'runtimeSha256':built,'testRuntimeSha256':actual,'actualBuiltProductMatchesTestDirectory':True,'runtimeLibraryPath':str(library),'runtimeTestProductPath':str(consumer)})
elif op=='assemblies':
    packet=json.loads(Path(sys.argv[2]).read_text());items=[]
    for relative in packet['assemblyPaths']:
        path=Path(relative);assert path.is_file() and not path.is_symlink();items.append({'path':relative,'bytes':path.stat().st_size,'sha256':digest(path)})
    runtime=next(item for item in items if item['path'].endswith('/Elsa.Workflows.Runtime.dll'))
    assert runtime['sha256']==digest(packet['runtimeLibraryPath'])==json.loads((Path(sys.argv[3]).parent/'runtime-product-restored.json').read_text())['runtimeSha256']
    write(sys.argv[3],{'head':packet['head'],'tree':packet['tree'],'files':items,'scope':'Current aea Debug EF outputs, actual restored Runtime product bound; exact six files for separate wholeEF phase'})
elif op=='finish':
    job=Path(sys.argv[2]);packet=json.loads(Path(sys.argv[3]).read_text());stage=sys.argv[4];code=int(sys.argv[5]);good=False
    try:
        os.chdir(packet['sourceRoot']);(job/'artifacts/exit-source.status').write_bytes(git('status','--porcelain=v1','--untracked-files=all'))
        (job/'artifacts/exit-source.patch').write_bytes(git('diff','--binary','--full-index','HEAD'))
        if stage=='complete' and code==0:source(packet,job/'artifacts/exit-source.json');good=True
        original=job/'artifacts/prior-a5/repair-original.cs';path=Path('Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/Services/Executables/InMemoryWorkflowActivationSwitch.cs')
        if original.exists():write(job/'artifacts/exit-restoration.json',{'byteIdentical':path.read_bytes()==original.read_bytes()})
    except Exception as error:write(job/'artifacts/exit-capture-error.json',{'type':type(error).__name__})
    ended=datetime.now(timezone.utc);seconds=(ended-datetime.fromisoformat(sys.argv[6].replace('Z','+00:00'))).total_seconds();cumulative=packet['priorActiveCeilingSeconds']+seconds
    good=good and seconds<=packet['budgetsSeconds']['outerSystemd'] and cumulative<=1800
    if good:
        try:
            final=json.loads((job/'artifacts/warm-final.json').read_text());assemblies=json.loads((job/'artifacts/assemblies-ready.json').read_text())
            mutant=json.loads((job/'artifacts/runtime-product-mutant.json').read_text());restored=json.loads((job/'artifacts/runtime-product-restored.json').read_text())
            current=json.loads((job/'artifacts/current-restored-product.json').read_text());prior=json.loads((job/'artifacts/prior-a5-proof.json').read_text())
            good=mutant['runtimeSha256']!=restored['runtimeSha256']==packet['retainedRuntimeProducts']['restored']==current['runtimeSha256'] and current['status']=='VERIFIED' and prior['status']=='VERIFIED' and mutant['actualBuiltProductMatchesTestDirectory'] is True and restored['actualBuiltProductMatchesTestDirectory'] is True and final.get('status')=='VERIFIED' and final.get('assetsUnchanged') is True and assemblies.get('head')==packet['head'] and assemblies.get('tree')==packet['tree'] and len(assemblies.get('files',[]))==6
        except (OSError,ValueError,TypeError):good=False
    write(job/'artifacts/phase-result.json',{'stage':stage,'exitCode':code,'startedAt':sys.argv[6],'endedAt':ended.isoformat(),'baseHead':packet['head'],'baseTree':packet['tree'],
        'priorActiveCeilingSeconds':packet['priorActiveCeilingSeconds'],'resumeActiveSeconds':seconds,'cumulativeActiveCeilingSeconds':cumulative,'cumulativeActiveLimitSeconds':1800,
        'oldCohortConservativeSeconds':packet['oldCohortConservativeSeconds'],'expectedCleanSourcePolicyPassed':good,'status':'PASSED' if good and stage=='complete' and code==0 else 'FAILED_OR_INCOMPLETE'})
    if stage=='complete' and code==0 and not good:sys.exit(1)
else:raise ValueError('Unknown frozen phase operation')
