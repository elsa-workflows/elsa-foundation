#!/usr/bin/python3
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta


def write(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def git(*arguments):
    return subprocess.check_output(['git', *arguments], text=True).strip()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


operation = sys.argv[1]
if operation == 'admission':
    expected = json.loads(Path(sys.argv[2]).read_text())
    request = urllib.request.Request('http://169.254.169.254/metadata/instance?api-version=2021-02-01', headers={'Metadata': 'true'})
    with urllib.request.urlopen(request, timeout=10) as response:
        instance = json.load(response)
    compute = instance['compute']
    facts = {'vmId': compute['vmId'], 'name': compute['name'], 'resourceId': compute['resourceId'],
             'subscriptionId': compute['subscriptionId'], 'machineId': Path('/etc/machine-id').read_text().strip(),
             'bootId': Path('/proc/sys/kernel/random/boot_id').read_text().strip(), 'uid': os.getuid(),
             'at': datetime.now(timezone.utc).isoformat(), 'toolPaths': expected['toolPaths'],
             'cgroup': Path('/proc/self/cgroup').read_text()}
    assert facts['name'] == 'elsa-dev-18'
    for key in ('vmId', 'name', 'machineId', 'bootId', 'uid'):
        assert facts[key] == expected[key], key
    assert facts['resourceId'].casefold() == expected['resourceId'].casefold()
    assert facts['subscriptionId'] == '8e23037a-420f-4ad0-9594-9d194de29e84'
    assert expected['admitted'] is True
    assert datetime.now(timezone.utc) + timedelta(seconds=2880) < datetime.fromisoformat(expected['effectiveExpiresAt'].replace('Z', '+00:00'))
    facts['dotnetHostSha256'] = digest(Path(expected['toolPaths']['dotnet402']).resolve())
    assert facts['dotnetHostSha256'] == expected['dotnetHostSha256']
    cgroup_path = facts['cgroup'].strip().split('::', 1)[1]
    cgroup = Path('/sys/fs/cgroup') / cgroup_path.lstrip('/')
    quota, period = (cgroup / 'cpu.max').read_text().split()
    memory = (cgroup / 'memory.max').read_text().strip()
    swap = (cgroup / 'memory.swap.max').read_text().strip()
    assert quota != 'max' and int(quota) <= 2 * int(period)
    assert memory != 'max' and int(memory) <= 6500 * 1024 * 1024
    assert swap == '0'
    facts['limits'] = {'cpuMax': [quota, period], 'memoryMax': memory, 'memorySwapMax': swap}
    write(sys.argv[3], facts)
elif operation == 'source':
    packet = json.loads(Path(sys.argv[2]).read_text())
    assert git('rev-parse', 'HEAD') == packet['head']
    assert git('rev-parse', 'HEAD^{tree}') == packet['tree']
    assert not git('status', '--porcelain')
    for item in packet['sourceFiles']:
        assert digest(item['path']) == item['sha256'], item['path']
    write(sys.argv[3], {'head': packet['head'], 'tree': packet['tree'], 'clean': True,
                        'sourceFiles': packet['sourceFiles'], 'agentsSha256': digest('AGENTS.md')})
elif operation == 'trx':
    path = Path(sys.argv[2]); expected = int(sys.argv[3]); mode = sys.argv[4]
    root = ET.parse(path).getroot()
    namespace = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    counters = root.find('.//t:Counters', namespace).attrib
    methods = {item.get('id'): item.find('t:TestMethod', namespace).attrib for item in root.findall('.//t:UnitTest', namespace)}
    results = root.findall('.//t:UnitTestResult', namespace)
    numbers = {key: int(value) for key, value in counters.items()}
    assert numbers['total'] >= expected if mode == 'whole' else numbers['total'] == expected
    assert numbers['executed'] == numbers['total']
    assert numbers['notExecuted'] == numbers['error'] == numbers['timeout'] == numbers['aborted'] == 0
    if mode == 'red':
        assert numbers['failed'] == 23 and numbers['passed'] == 1
        failures = [item for item in results if item.get('outcome') == 'Failed']
        assert len(failures) == 23
        for item in failures:
            method = methods[item.get('testId')]
            assert method['className'] == 'Elsa.Activities.Runtime.Tests.NativeMessageMaterialInterestProviderTests'
            message = item.find('.//t:Message', namespace).text
            assert message.startswith('Assert.'), message
        passed = [methods[item.get('testId')]['name'] for item in results if item.get('outcome') == 'Passed']
        assert passed == ['Event_and_model_material_are_not_reclassified_and_the_existing_feature_registers_no_Message_provider']
    else:
        assert numbers['failed'] == 0 and numbers['passed'] == numbers['total']
        if mode == 'whole':
            classes = {methods[item.get('testId')]['className'] for item in results}
            for suffix in ('PublishEventTests', 'WorkflowInvokeActivitySchedulerWorkHandlerTests', 'WorkflowResumeBookmarkSchedulerWorkHandlerTests'):
                assert 'Elsa.Activities.Runtime.Tests.' + suffix in classes, suffix
    write(path.with_suffix('.counters.json'), {'mode': mode, 'counters': counters, 'rawSha256': digest(path)})
elif operation == 'mutate':
    path = Path('Essentials/src/Activities/Primitives/Services/NativeMessageMaterialInterestProvider.cs')
    original = path.read_text()
    before = 'if (node.ActivityType != ReceiveMessage.ActivityType && node.ActivityType != typeof(ReceiveMessage).FullName) continue;'
    after = 'if (node.ActivityType != "Test.IntentionallyAbsentReceiver") continue;'
    assert original.count(before) == 1
    path.write_text(original.replace(before, after))
    artifacts = Path(sys.argv[2]); (artifacts / 'provider-mutated.cs').write_bytes(path.read_bytes())
    (artifacts / 'provider-mutation.patch').write_text(git('diff', '--', str(path)))
    write(artifacts / 'provider-mutation.json', {'mutation': 'Skip actual ReceiveMessage nodes',
          'originalSha256': digest(artifacts / 'provider-original.cs'), 'mutatedSha256': digest(path)})
elif operation == 'finish':
    root = Path(sys.argv[2]); stage = sys.argv[3]; code = int(sys.argv[4])
    source = root / 'source'
    clean = None
    if (source / '.git').exists():
        clean = not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True).strip()
    write(root / 'artifacts' / 'phase-result.json', {'stage': stage, 'exitCode': code,
          'startedAt': sys.argv[5], 'endedAt': datetime.now(timezone.utc).isoformat(),
          'sourceCleanAtExit': clean, 'status': 'PASSED' if code == 0 and stage == 'complete' and clean is True else 'FAILED_OR_INCOMPLETE'})
else:
    raise ValueError('Unknown phase operation')
