#!/bin/bash
set -Eeuo pipefail
umask 077
job_root=$1
packet_root=$2
admission=$3
[[ "$job_root" == /srv/elsa-qualification/durable-messaging/native-0246-* ]]
[[ ! -e "$job_root" && ! -L "$job_root" ]]
[[ "$(id -un)" == codex ]]
mkdir -m 0700 "$job_root"
mkdir -m 0700 "$job_root/artifacts" "$job_root/source"
artifacts=$job_root/artifacts
stage=admission
mutant_active=0
started=$(date -u +%FT%TZ)
finish() {
    phase_exit=$?
    trap - EXIT TERM INT
    if [[ "$mutant_active" == 1 ]]; then
        cp "$artifacts/provider-original.cs" "$job_root/source/Essentials/src/Activities/Primitives/Services/NativeMessageMaterialInterestProvider.cs"
    fi
    /usr/bin/python3 "$packet_root/check.py" finish "$job_root" "$stage" "$phase_exit" "$started" || true
    exit "$phase_exit"
}
trap finish EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
/usr/bin/python3 "$packet_root/check.py" admission "$admission" "$artifacts/admission.json"
dotnet_path=$(/usr/bin/python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["toolPaths"]["dotnet402"])' "$admission")
export PATH="$(dirname "$dotnet_path"):$PATH"
export DOTNET_ROOT="$(dirname "$dotnet_path")"
export DOTNET_CLI_HOME="$job_root/dotnet-home"
export NUGET_PACKAGES="$job_root/nuget"
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 DOTNET_PROCESSOR_COUNT=2
run_stage() {
    stage=$1
    local ceiling=$2
    shift 2
    printf '%s\n' "$stage" >"$artifacts/current-stage"
    local command_exit=0
    timeout --signal=TERM --kill-after=20s "${ceiling}s" "$@" >"$artifacts/$stage.log" 2>&1 || command_exit=$?
    printf '%s\n' "$command_exit" >"$artifacts/$stage.exit"
    return "$command_exit"
}
cd "$job_root/source"
git init --quiet
run_stage source-fetch 180 git -c credential.helper= -c core.askPass= fetch --depth=1 https://github.com/elsa-workflows/elsa-foundation.git 0246b4ecf4ea1df62db2c26437e7cc3cf7e6f40e
git checkout --detach --quiet FETCH_HEAD
stage=source-validation
/usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/source.json"
stage=toolchain
[[ "$(dotnet --version)" == 10.0.402 ]]
dotnet --info >"$artifacts/dotnet-info.log" 2>&1
project=Essentials/tests/Activities/Runtime/Tests/Elsa.Activities.Runtime.Tests.csproj
focused='FullyQualifiedName~ReceiveMessageContractTests|FullyQualifiedName~NativeMessageMaterialInterestProviderTests'
run_stage locked-restore 300 dotnet restore "$project" --locked-mode -m:1 -p:WarningsNotAsErrors=NU1603
run_stage focused-first 900 dotnet test "$project" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter "$focused" --logger 'trx;LogFileName=focused-first.trx' --results-directory "$artifacts"
stage=focused-first-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/focused-first.trx" 31 green
stage=prepare-mutation
cp Essentials/src/Activities/Primitives/Services/NativeMessageMaterialInterestProvider.cs "$artifacts/provider-original.cs"
mutant_active=1
/usr/bin/python3 "$packet_root/check.py" mutate "$artifacts"
set +e
run_stage provider-mutation 300 dotnet test "$project" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter 'FullyQualifiedName~NativeMessageMaterialInterestProviderTests' --logger 'trx;LogFileName=provider-mutation.trx' --results-directory "$artifacts"
mutation_exit=$?
set -e
printf '%s\n' "$mutation_exit" >"$artifacts/provider-mutation.exit"
stage=mutation-restore
cp "$artifacts/provider-original.cs" Essentials/src/Activities/Primitives/Services/NativeMessageMaterialInterestProvider.cs
mutant_active=0
/usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/restored-source.json"
stage=mutation-oracle
[[ "$mutation_exit" != 0 && "$mutation_exit" != 124 && "$mutation_exit" != 137 && "$mutation_exit" != 143 ]]
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/provider-mutation.trx" 24 red
run_stage focused-restored 300 dotnet test "$project" --no-restore --verbosity quiet -m:1 -p:UseSharedCompilation=false --filter "$focused" --logger 'trx;LogFileName=focused-restored.trx' --results-directory "$artifacts"
stage=focused-restored-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/focused-restored.trx" 31 green
run_stage whole-activities-runtime 600 dotnet test "$project" --no-build --no-restore --verbosity quiet -m:1 --logger 'trx;LogFileName=whole-activities-runtime.trx' --results-directory "$artifacts"
stage=whole-activities-runtime-oracle
/usr/bin/python3 "$packet_root/check.py" trx "$artifacts/whole-activities-runtime.trx" 31 whole
stage=final-source-validation
/usr/bin/python3 "$packet_root/check.py" source "$packet_root/phase.json" "$artifacts/final-source.json"
stage=complete
