/usr/bin/python3 /opt/elsa-durable-messaging/message-foundation-r3/handoff.py prior /opt/elsa-durable-messaging/message-foundation-r3 /srv/elsa-qualification/durable-messaging/message-foundation-r3 
