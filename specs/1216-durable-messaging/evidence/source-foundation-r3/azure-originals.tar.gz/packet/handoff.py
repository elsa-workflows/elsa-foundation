#!/usr/bin/python3
"""Exact unchanged warm-source A3 continuation; preserves both failed prior invocations and all original artifacts."""
from pathlib import Path
import hashlib,json,math,os,re,subprocess,sys
p=Path(sys.argv[2]);job=Path(sys.argv[3]);phase=json.loads((p/'phase.json').read_text());prior=Path(phase['priorJobRoot']);artifacts=job/'artifacts'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):
    assert path.is_file() and not path.is_symlink() and path.resolve()==path and path.stat().st_uid==os.getuid(),str(path)
    return path.read_bytes()
def git(*args):return subprocess.check_output(['git',*args])
def write(name,value):(artifacts/name).write_text(json.dumps(value,indent=2)+'\n')
def assets(root):
    items=[]
    for path in sorted(root.rglob('project.assets.json')):
        data=read(path);value=json.loads(data);project=Path(value['project']['restore']['projectPath'])
        assert project.is_file() and project.resolve()==project and project.is_relative_to(root)
        items.append({'path':str(path.relative_to(root)),'projectPath':str(project),'bytes':len(data),'sha256':sha(data)})
    assert 2<=len(items)<=512
    for needed in ['Essentials/tests/Workflows/Runtime/Tests/obj/project.assets.json','Essentials/tests/Workflows/Runtime/Persistence/EntityFrameworkCore/Tests/obj/project.assets.json']:
        assert any(item['path']==needed for item in items)
    return items
if sys.argv[1]=='prior':
    assert str(prior)=='/srv/elsa-qualification/durable-messaging/message-foundation-r2'
    for unit in ['message-foundation-r1','message-foundation-r2']:
        assert not Path('/sys/fs/cgroup/system.slice/elsa-durable-'+unit+'.service').exists()
    primary=json.loads((p/'prior-a2-primary.json').read_text());cleanup=json.loads((p/'prior-a2-cleanup.json').read_text())
    checked=json.loads((p/'prior-a2-source.json').read_text());collection=json.loads((p/'prior-a2-collection.json').read_text())
    assert primary['status']=='FAILED' and primary['originalSystemdResult']=='exit-code' and primary['originalExecMainStatus']=='124'
    result=primary['originalPhaseResult'];assert result['stage']=='ef-focused' and result['exitCode']==124 and result['status']=='FAILED_OR_INCOMPLETE'
    proof=primary['executionBudgetProof'];assert proof['status']=='VERIFIED' and proof['priorActiveCeilingSeconds']==313
    assert proof['conservativeCumulativeSeconds']==555.172188 and math.ceil(proof['conservativeCumulativeSeconds'])==phase['priorActiveCeilingSeconds']==556
    assert proof['limitSeconds']==1800 and 556+450+780==1786<=1800
    assert cleanup['status']=='VERIFIED' and not cleanup['cgroupExistsAfter'] and cleanup['membersAfter']==cleanup['survivingOwnedIdentities']==[]
    assert checked['status']=='VERIFIED' and checked['issues']==[] and checked['rawStatusEmpty'] is True and checked['head']==phase['head'] and checked['tree']==phase['tree']
    assert collection['primaryStatus']=='FAILED' and collection['cleanupStatus']==collection['sourceStatus']=='VERIFIED' and collection['errors']==[]
    retained=artifacts/'prior-a2';retained.mkdir(mode=0o700)
    for item in phase['priorFiles']:
        data=read(prior/item['path']);assert len(data)==item['bytes'] and sha(data)==item['sha256']
        destination=retained/item['retainedName']
        with destination.open('xb') as stream:stream.write(data)
    assert json.loads((retained/'phase-result.json').read_text())==result
    assert (retained/'ef-focused.exit').read_text().strip()=='124' and not (prior/'artifacts/ef-focused.trx').exists()
    log=(retained/'ef-focused.log').read_text()
    assert not re.search(r'(?mi)^\s*(?:Test run for\b|Starting test execution\b|(?:Passed|Failed)!\s)',log)
    assert not re.search(r'\berror\s+(?:CS|MSB|NU)\d+\b',log) and 'warning ' in log
    assert all(marker in log for marker in ['/src/Cli/','/src/Activities/Bpmn/','/src/Workflows/Design/','/src/Http/'])
    earlier=json.loads((retained/'earlier-a-phase-result.json').read_text());earlierProof=json.loads((retained/'earlier-a-proof.json').read_text())
    assert earlier['status']=='FAILED_OR_INCOMPLETE' and earlier['stage']=='ef-focused' and earlier['exitCode']==1
    assert earlierProof['status']=='VERIFIED' and earlierProof['priorAFailedPreserved'] is True and earlierProof['priorActiveCeilingSeconds']==313
    assert earlierProof['priorArchive']==phase['earlierAArchive']
    earlierLog=(retained/'earlier-a-ef-focused.log').read_text();errors=[line for line in earlierLog.splitlines() if 'error CS' in line]
    assert len(errors)==1 and 'error CS1061' in errors[0] and 'GetEnlistedTransaction' in errors[0]
    subprocess.check_call(['/usr/bin/python3',str(p/'check.py'),'trx',str(retained/'runtime-focused.trx'),'runtime-focused'])
    old=json.loads((retained/'old-cohort-closure.json').read_text())
    assert old['status']=='VERIFIED' and old['oldCohortSeconds']==1652.889368 and old['oldCohortLimit']==3600 and old['noOldOutcomeReset'] is True
    write('prior-a2-proof.json',{'status':'VERIFIED','priorAAndA2FailedPreserved':True,'priorArchive':phase['priorArchive'],
        'priorExactCumulativeSeconds':555.172188,'priorActiveCeilingSeconds':556,'runtimeFocused86Retained':True,
        'noRuntimeFocusedRepeat':True,'efTimedOutDuringBuild':True,'noEfTrxOrTestRunBanner':True,'noCompilerError':True,
        'oldCohortSeconds':1652.889368,'oldOutcomeReset':False,'oldArtifactsWritten':False})
elif sys.argv[1] in ('source','final'):
    root=Path(phase['sourceRoot']);assert str(root)=='/srv/elsa-qualification/durable-messaging/message-foundation-r1/source'
    assert root.resolve()==root and root.stat().st_uid==os.getuid() and Path.cwd()==root
    assert git('rev-parse','HEAD').decode().strip()==phase['head'] and git('rev-parse','HEAD^{tree}').decode().strip()==phase['tree']
    assert not git('status','--porcelain=v1','--untracked-files=all')
    for name in ['dotnetHome','nugetCache']:
        directory=Path(phase[name]);assert directory.is_dir() and directory.resolve()==directory and directory.stat().st_uid==os.getuid()
    assert os.environ.get('DOTNET_CLI_HOME')==phase['dotnetHome'] and os.environ.get('NUGET_PACKAGES')==phase['nugetCache']
    current=assets(root)
    if sys.argv[1]=='source':
        expected=json.loads((artifacts/'prior-a2/assets-before.json').read_text())
        handoff=json.loads((artifacts/'prior-a2/source-handoff.json').read_text())
        assert handoff['status']=='VERIFIED' and handoff['head']==phase['head'] and handoff['tree']==phase['tree'] and handoff['restorePerformed'] is False
        assert expected==handoff['assetsFiles']==current
        write('assets-before.json',current)
        subprocess.check_call(['/usr/bin/python3',str(p/'check.py'),'source',str(p/'phase.json'),str(artifacts/'base-source.json')])
        write('warm-source.json',{'status':'VERIFIED','head':phase['head'],'tree':phase['tree'],'sameAbsoluteSourceRoot':str(root),
            'assetsFiles':current,'dotnetHome':phase['dotnetHome'],'nugetCache':phase['nugetCache'],
            'sourceVersionChanged':False,'gitCheckoutOrFetch':False,'restorePerformed':False,'oldArtifactsOrPacketWrites':False})
    else:
        assert current==json.loads((artifacts/'assets-before.json').read_text()),'Warm assets changed without authorized restore'
        subprocess.check_call(['/usr/bin/python3',str(p/'check.py'),'source',str(p/'phase.json'),str(artifacts/'final-source.json')])
        write('warm-final.json',{'status':'VERIFIED','head':phase['head'],'tree':phase['tree'],'assetsUnchanged':True,
            'assetsFiles':current,'sourceVersionChanged':False,'restorePerformed':False})
else:raise ValueError('Unsupported handoff operation')
