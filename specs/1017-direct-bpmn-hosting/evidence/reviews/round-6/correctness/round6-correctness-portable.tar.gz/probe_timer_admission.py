import json,pathlib,os,subprocess,signal,time,threading,re,urllib.request,urllib.error,http.cookiejar,hashlib,sqlite3,gzip,shutil,datetime
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/sipke/.codex/worktrees/f236/elsa-foundation')
BIN=REPO/'Essentials/apps/Elsa.Workbench/bin/Release/net10.0/Elsa.Workbench.dll'
HOST=ROOT/'timer-host';HOST.mkdir(exist_ok=False)
for name in ('appsettings.json','appsettings.Development.json','shells.json'):shutil.copy(REPO/'Essentials/apps/Elsa.Workbench'/name,HOST/name)
(HOST/'packages').mkdir()
shells=json.loads((HOST/'shells.json').read_text());features=shells['CShells']['Shells']['default']['Features']
features['ActivitiesBpmnHosting']={'AdmitNewExecutions':True};features['ActivitiesBpmnHostingApi']={};features['WorkflowsRuntimeResumption']={'SweepIntervalSeconds':0.2}
allowed={'ActivitiesBpmnHosting','ActivitiesBpmnHostingApi','ActivitiesRuntime','Events','Expressions','FileSystemDistributedLocking','Primitives','Serialization','Tasks','WorkflowsRuntimeEntityFrameworkCore','WorkflowsRuntimeResumption','FoundationIdentityAbstractions','FoundationIdentityApi','FoundationIdentityAspNetCoreIdentity','FoundationIdentityAspNetCoreIdentityEntityFrameworkCore','IdentityIamEntityFrameworkCore','IdentityProviderConfigurationEntityFrameworkCore'}
for key in list(features):
 if key not in allowed:del features[key]
features['WorkflowsRuntimeEntityFrameworkCore']['ConnectionString']='Data Source=runtime.db'
(HOST/'shells.json').write_text(json.dumps(shells,indent=2))
meta={'reviewedHead':'d1449c0bff679212f8a64766a95b1c29cfadbcea','base':'d481d6a5e624e35bba9fbf32033ed02aff64cbef','executingSource':'9c7681c56c529c8a1a4ab4d9fc91934ec07d0448','backendSourceDiffFromReviewedHead':subprocess.check_output(['git','diff','--name-only','9c7681c56c529c8a1a4ab4d9fc91934ec07d0448','d1449c0bff679212f8a64766a95b1c29cfadbcea','--','Essentials/src','Essentials/apps/Elsa.Workbench'],cwd=REPO,text=True).splitlines(),'products':{},'processes':[],'requests':[]}
for name in ('Elsa.Workbench.dll','Elsa.Activities.Bpmn.dll','Elsa.Workflows.Runtime.dll','Elsa.Workflows.Runtime.Persistence.EntityFrameworkCore.dll','Bpmn.Semantics.dll'):
 path=BIN.parent/name;meta['products'][name]=hashlib.sha256(path.read_bytes()).hexdigest()
proc=None;opener=None;base=None

def req(method,path,body=None):
 data=json.dumps(body).encode() if body is not None else None
 r=urllib.request.Request(base+path,data=data,method=method,headers={'Content-Type':'application/json'})
 try:
  with opener.open(r,timeout=30) as response:status=response.status;raw=response.read().decode()
 except urllib.error.HTTPError as e:status=e.code;raw=e.read().decode()
 try:result=json.loads(raw)
 except:result=raw
 if path!='/_elsa/identity/login':meta['requests'].append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':method,'path':path,'body':body,'status':status,'result':result})
 return status,result

def launch(stage):
 global proc,opener,base
 env=os.environ.copy();env['ASPNETCORE_ENVIRONMENT']='Development'
 log=open(ROOT/(stage+'-host.log'),'w')
 proc=subprocess.Popen(['dotnet',str(BIN),'--contentRoot',str(HOST),'--urls','http://127.0.0.1:0'],cwd=HOST,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
 meta['processes'].append({'stage':stage,'pid':proc.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'assembly':str(BIN)})
 lines=[]
 def read():
  for line in proc.stdout:lines.append(line);log.write(line);log.flush()
  log.close()
 threading.Thread(target=read,daemon=True).start()
 deadline=time.monotonic()+150
 while time.monotonic()<deadline:
  if proc.poll() is not None:raise RuntimeError('Owned child exited '+str(proc.returncode))
  for line in list(lines):
   m=re.search(r'Now listening on: (http://127.0.0.1:\d+)',line)
   if m:base=m.group(1)
  if base:
   opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
   try:
    with opener.open(base+'/health/ready',timeout=3) as r:
     if r.status==200:break
   except (urllib.error.HTTPError,urllib.error.URLError):pass
  time.sleep(0.2)
 else:raise RuntimeError('Owned child readiness timeout')
 assert req('POST','/_elsa/identity/login',{'username':'admin','password':'Password123!'})[0]==200

def stop(stage):
 global proc,base
 if proc and proc.poll() is None:proc.terminate();proc.wait(timeout=30)
 if proc:meta['processes'][-1]['exitCode']=proc.returncode
 proc=None;base=None
 db=HOST/'runtime.db'
 if db.exists():
  with sqlite3.connect('file:'+str(db)+'?mode=ro&immutable=1',uri=True) as c:
   tables=c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
   meta.setdefault('closedStores',{})[stage]={'integrity':c.execute('pragma integrity_check').fetchall(),'tables':[x[0] for x in tables]}
   for t in ('RuntimeSchedulerWorkItems','RuntimeModelExecutions','RuntimeModelInputs'):
    if (t,) in tables:meta['closedStores'][stage][t]=[dict(zip([d[0] for d in cur.description],row)) for cur in [c.execute('SELECT * FROM "'+t+'"')] for row in cur]
  with open(db,'rb') as f,gzip.open(ROOT/(stage+'-runtime.sqlite.gz'),'wb') as z:shutil.copyfileobj(f,z)

def definition(interval):
 return {'formatVersion':4,'humanBindings':['review-work'],'timerBindings':['timeout-work'],'process':{'processId':'r6-duration-admission','elements':[{'elementId':'start','elementType':'startEvent'},{'elementId':'review','elementType':'userTask','bindingRef':'review-work'},{'elementId':'timeout','elementType':'boundaryEvent','bindingRef':'timeout-work','attachedToRef':'review','cancelActivity':True,'eventDefinitions':[{'type':'timer','properties':{'interval':interval}}]},{'elementId':'done','elementType':'endEvent'},{'elementId':'timed-out','elementType':'endEvent'}],'sequenceFlows':[{'flowId':'start-review','sourceRef':'start','targetRef':'review'},{'flowId':'review-done','sourceRef':'review','targetRef':'done'},{'flowId':'timeout-end','sourceRef':'timeout','targetRef':'timed-out'}]}}
try:
 launch('first')
 started={}
 for name,interval in [('control','PT1H'),('beyond-date-range','P3000000D')]:
  pub=req('POST','/bpmn/artifacts',{'requestId':'r6-publish-'+name,'definition':definition(interval)})
  assert pub[0] in (200,201),pub
  start=req('POST','/bpmn/executions',{'requestId':'r6-start-'+name,'sourceReferenceId':pub[1]['sourceReferenceId']})
  assert start[0] in (200,201,202),start
  started[name]=start[1]
  req('GET','/bpmn/executions/'+start[1]['executionId'])
  req('GET','/bpmn/executions/'+start[1]['executionId']+'/commands/r6-start-'+name)
 time.sleep(1)
 stop('before-restart')
 launch('restarted')
 time.sleep(2)
 for name,start in started.items():
  req('GET','/bpmn/executions/'+start['executionId'])
  req('GET','/bpmn/executions/'+start['executionId']+'/commands/r6-start-'+name)
  if name=='beyond-date-range':req('POST','/bpmn/executions/'+start['executionId']+'/cancel',{'requestId':'r6-cancel-unstarted'})
 meta['started']=started
finally:
 stop('final');(ROOT/'timer-admission-result.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'processes':meta['processes'],'requests':[{'method':x['method'],'path':x['path'],'status':x['status'],'result':x['result']} for x in meta['requests']]},indent=2))
