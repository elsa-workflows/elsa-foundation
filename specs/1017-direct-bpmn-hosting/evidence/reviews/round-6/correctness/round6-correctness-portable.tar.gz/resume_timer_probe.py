import json,pathlib,os,subprocess,signal,time,threading,re,urllib.request,urllib.error,http.cookiejar,hashlib,sqlite3,gzip,shutil,datetime
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/sipke/.codex/worktrees/f236/elsa-foundation')
BIN=REPO/'Essentials/apps/Elsa.Workbench/bin/Release/net10.0/Elsa.Workbench.dll'
HOST=ROOT/'timer-host'
meta=json.loads((ROOT/'timer-admission-result.json').read_text());proc=None;opener=None;base=None
def req(method,path,body=None):
 data=json.dumps(body).encode() if body is not None else None
 r=urllib.request.Request(base+path,data=data,method=method,headers={'Content-Type':'application/json'})
 try:
  with opener.open(r,timeout=30) as response:status=response.status;raw=response.read().decode()
 except urllib.error.HTTPError as e:status=e.code;raw=e.read().decode()
 try:result=json.loads(raw)
 except:result=raw
 if path!='/_elsa/identity/login':meta['requests'].append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':method,'path':path,'body':body,'status':status,'result':result})
 return status,result

def launch(stage):
 global proc,opener,base
 env=os.environ.copy();env['ASPNETCORE_ENVIRONMENT']='Development'
 log=open(ROOT/(stage+'-host.log'),'w')
 proc=subprocess.Popen(['dotnet',str(BIN),'--contentRoot',str(HOST),'--urls','http://127.0.0.1:0'],cwd=HOST,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
 meta['processes'].append({'stage':stage,'pid':proc.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'assembly':str(BIN)})
 lines=[]
 def read():
  for line in proc.stdout:lines.append(line);log.write(line);log.flush()
  log.close()
 threading.Thread(target=read,daemon=True).start()
 deadline=time.monotonic()+150
 while time.monotonic()<deadline:
  if proc.poll() is not None:raise RuntimeError('Owned child exited '+str(proc.returncode))
  for line in list(lines):
   m=re.search(r'Now listening on: (http://127.0.0.1:\d+)',line)
   if m:base=m.group(1)
  if base:
   opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
   try:
    with opener.open(base+'/health/ready',timeout=3) as r:
     if r.status==200:break
   except (urllib.error.HTTPError,urllib.error.URLError):pass
  time.sleep(0.2)
 else:raise RuntimeError('Owned child readiness timeout')
 assert req('POST','/_elsa/identity/login',{'username':'admin','password':'Password123!'})[0]==200

def stop(stage):
 global proc,base
 if proc and proc.poll() is None:proc.terminate();proc.wait(timeout=30)
 if proc:meta['processes'][-1]['exitCode']=proc.returncode
 proc=None;base=None
 db=HOST/'runtime.db'
 if db.exists():
  with sqlite3.connect('file:'+str(db)+'?mode=ro&immutable=1',uri=True) as c:
   tables=c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
   meta.setdefault('closedStores',{})[stage]={'integrity':c.execute('pragma integrity_check').fetchall(),'tables':[x[0] for x in tables]}
   for t in ('RuntimeSchedulerWorkItems','RuntimeModelExecutions','RuntimeModelInputs'):
    if (t,) in tables:meta['closedStores'][stage][t]=[dict(zip([d[0] for d in cur.description],row)) for cur in [c.execute('SELECT * FROM "'+t+'"')] for row in cur]
  with open(db,'rb') as f,gzip.open(ROOT/(stage+'-runtime.sqlite.gz'),'wb') as z:shutil.copyfileobj(f,z)

try:
 launch('post-expiry')
 time.sleep(25)
 for name,start in meta['started'].items():
  req('GET','/bpmn/executions/'+start['executionId'])
  req('GET','/bpmn/executions/'+start['executionId']+'/commands/r6-start-'+name)
  if name=='beyond-date-range':req('POST','/bpmn/executions/'+start['executionId']+'/cancel',{'requestId':'r6-cancel-after-expiry'})
finally:
 stop('after-expiry');(ROOT/'timer-after-expiry-result.json').write_text(json.dumps(meta,indent=2)+'\n')
print('Original input remained pending after normal claim-expiry resumption. See timer-after-expiry-result.json.')
