#!/usr/bin/env python3
"""Portable ADAPTER for the existing round-6 C1 evidence; does not build or edit product/state.
Original controller scripts are retained separately, byte-for-byte. This adapter is not a new review.
"""
import argparse
import base64
import datetime
import gzip
import hashlib
import http.cookiejar
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

REVIEWED_HEAD = 'd1449c0bff679212f8a64766a95b1c29cfadbcea'
BASE = 'd481d6a5e624e35bba9fbf32033ed02aff64cbef'
TABLES = ('elsa_runtime_scheduler_work_item', 'elsa_runtime_model_execution', 'elsa_runtime_model_input')
ALLOWED = {
    'ActivitiesBpmnHosting', 'ActivitiesBpmnHostingApi', 'ActivitiesRuntime', 'Events',
    'Expressions', 'FileSystemDistributedLocking', 'Primitives', 'Serialization', 'Tasks',
    'WorkflowsRuntimeEntityFrameworkCore', 'WorkflowsRuntimeResumption',
    'FoundationIdentityAbstractions', 'FoundationIdentityApi', 'FoundationIdentityAspNetCoreIdentity',
    'FoundationIdentityAspNetCoreIdentityEntityFrameworkCore', 'IdentityIamEntityFrameworkCore',
    'IdentityProviderConfigurationEntityFrameworkCore',
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository', required=True, type=Path, help='Fresh Elsa Foundation checkout containing the pinned commits/configuration')
    parser.add_argument('--workbench', required=True, type=Path, help='Fresh built Elsa.Workbench.dll; no build is performed')
    parser.add_argument('--reader', required=True, type=Path, help='Fresh built DeliveryRecoveryRead.dll with backup/inspection ports')
    parser.add_argument('--output', required=True, type=Path, help='New output directory; must not already exist')
    parser.add_argument('--dotnet', default='dotnet', help='dotnet executable, optionally an explicit full path')
    parser.add_argument('--case-inputs', type=Path, default=Path(__file__).with_name('case-inputs.json'))
    parser.add_argument('--expiry-limit-seconds', type=float, default=180, help='Maximum real wait for claim expiry; never changes a clock or row')
    args = parser.parse_args()
    repository = args.repository.resolve(strict=True)
    workbench = args.workbench.resolve(strict=True)
    reader = args.reader.resolve(strict=True)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    private = output / 'private-host'
    private.mkdir()
    state = {'kind': 'portable-explicit-products-adapter', 'reviewRound': 6,
             'newReviewRound': False, 'reviewedHead': REVIEWED_HEAD, 'base': BASE,
             'requests': [], 'processes': [], 'observations': [], 'diagnostics': [],
             'noSqlStateEdits': True, 'qualification': 'not run yet'}
    process = None
    base_url = None
    opener = None
    log_thread = None
    products_before = {str(path): digest(path) for path in (workbench, reader)}

    def reader_call(stage, *arguments):
        result = subprocess.run([args.dotnet, str(reader), *map(str, arguments)],
                                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=60, check=False)
        (output / (stage + '-reader.stdout')).write_text(result.stdout)
        (output / (stage + '-reader.stderr')).write_text(result.stderr)
        value = {'stage': stage, 'arguments': list(map(str, arguments)), 'exitCode': result.returncode}
        if result.returncode == 0:
            value['result'] = json.loads(result.stdout)
        state['observations'].append(value)
        if result.returncode != 0:
            raise RuntimeError('Read-only product observer failed at ' + stage + '; original stdout/stderr retained')
        return value['result']

    def request(method, path, body=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(base_url + path, data=data, method=method,
                                     headers={'Content-Type': 'application/json'})
        try:
            with opener.open(req, timeout=30) as response:
                status, raw = response.status, response.read().decode()
        except urllib.error.HTTPError as error:
            status, raw = error.code, error.read().decode()
        try:
            value = json.loads(raw)
        except json.JSONDecodeError:
            value = raw
        # Demo login secrets and auth cookies stay in memory, outside portable evidence.
        if path != '/_elsa/identity/login':
            entry = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                     'method': method, 'path': path, 'body': body, 'status': status, 'result': value}
            state['requests'].append(entry)
            with (output / 'requests.jsonl').open('a') as log:
                log.write(json.dumps(entry) + '\n')
        return status, value

    def launch(stage):
        nonlocal process, base_url, opener, log_thread
        base_url = None
        env = os.environ.copy()
        env['ASPNETCORE_ENVIRONMENT'] = 'Development'
        process = subprocess.Popen([args.dotnet, str(workbench), '--contentRoot', str(private),
                                    '--urls', 'http://127.0.0.1:0'], cwd=private, env=env,
                                   text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=1)
        record = {'stage': stage, 'pid': process.pid,
                  'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'assemblySha256': digest(workbench)}
        state['processes'].append(record)
        owned_process = process
        lines = []
        def consume():
            with (output / (stage + '-host.log')).open('w') as log:
                for line in owned_process.stdout:
                    lines.append(line)
                    log.write(line)
                    log.flush()
        log_thread = threading.Thread(target=consume, daemon=True)
        log_thread.start()
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        deadline = time.monotonic() + 150
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError('Owned Workbench exited before readiness')
            for line in list(lines):
                match = re.search(r'Now listening on: (http://127\.0\.0\.1:\d+)', line)
                if match:
                    base_url = match.group(1)
            if base_url:
                try:
                    with opener.open(base_url + '/health/ready', timeout=3) as response:
                        if response.status == 200:
                            break
                except (urllib.error.HTTPError, urllib.error.URLError):
                    pass
            time.sleep(.2)
        else:
            raise RuntimeError('Owned Workbench readiness timeout')
        status, _ = request('POST', '/_elsa/identity/login',
                            {'username': 'admin', 'password': 'Password123!'})
        if status != 200:
            raise RuntimeError('Normal demo login failed')

    def stop():
        nonlocal process
        if process is None:
            return
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                state['diagnostics'].append({'stage': 'owned cleanup', 'status': 'graceful stop timed out; owned child killed'})
                process.kill()
                process.wait(timeout=30)
        state['processes'][-1]['exitCode'] = process.returncode
        process = None
        if log_thread:
            log_thread.join(timeout=5)

    def snapshot(stage):
        if process is not None:
            raise RuntimeError('Only a stopped owned host may be captured')
        source = private / 'runtime.db'
        target = output / (stage + '-runtime.sqlite')
        reader_call(stage + '-backup', '--backup-sqlite', source, target)
        before = digest(target)
        with sqlite3.connect(target.as_uri() + '?mode=ro&immutable=1', uri=True) as connection:
            integrity = connection.execute('PRAGMA integrity_check').fetchone()[0]
            raw = {}
            for table in TABLES:
                cursor = connection.execute('SELECT * FROM "' + table + '"')
                columns = [column[0] for column in cursor.description]
                raw[table] = [dict(zip(columns, row)) for row in cursor.fetchall()]
        if digest(target) != before:
            raise RuntimeError('Read-only observer changed its snapshot')
        write(output / (stage + '-raw-model-and-queue.json'), {'integrity': integrity, 'rows': raw})
        with target.open('rb') as source_file, gzip.GzipFile(filename=str(target) + '.gz', mode='wb', mtime=0) as archive:
            shutil.copyfileobj(source_file, archive)
        target.unlink()
        return raw

    def inspect_all(started, cancellation_id):
        for case_name, start in started.items():
            route = '/bpmn/executions/' + start['executionId']
            status, _ = request('GET', route)
            if status != (200 if case_name == 'control' else 404):
                raise RuntimeError('Unexpected execution inspection; original response retained')
            status, command = request('GET', route + '/commands/r6-start-' + case_name)
            if status != 200 or command.get('pending') != (case_name == 'beyond-date-range'):
                raise RuntimeError('Unexpected retained command inspection; response retained')
            if case_name == 'beyond-date-range':
                status, _ = request('POST', route + '/cancel', {'requestId': cancellation_id})
                if status != 404:
                    raise RuntimeError('Cancellation no longer has original absent-header behavior; response retained')

    try:
        products = reader_call('products-before', '--inspect-host-products', workbench)
        source_commit = products['sourceCommit']
        state['productSource'] = source_commit
        source_diff = subprocess.check_output(['git', 'diff', '--name-only', source_commit, REVIEWED_HEAD,
                                              '--', 'Essentials/src', 'Essentials/apps/Elsa.Workbench'],
                                             cwd=repository, text=True).splitlines()
        state['backendDiffFromReviewedHead'] = source_diff
        if source_diff:
            raise RuntimeError('Products differ from the reviewed backend; use the pinned/equivalent source')
        config = repository / 'Essentials/apps/Elsa.Workbench'
        for name in ('appsettings.json', 'appsettings.Development.json', 'shells.json'):
            shutil.copyfile(config / name, private / name)
        state['configurationSourceHashes'] = {name: digest(private / name) for name in
                                             ('appsettings.json', 'appsettings.Development.json', 'shells.json')}
        (private / 'packages').mkdir()
        shell_config = json.loads((private / 'shells.json').read_text())
        features = shell_config['CShells']['Shells']['default']['Features']
        features['ActivitiesBpmnHosting'] = {'AdmitNewExecutions': True}
        features['ActivitiesBpmnHostingApi'] = {}
        features['WorkflowsRuntimeResumption'] = {'SweepIntervalSeconds': .2}
        for key in list(features):
            if key not in ALLOWED:
                del features[key]
        features['WorkflowsRuntimeEntityFrameworkCore']['ConnectionString'] = 'Data Source=runtime.db'
        (private / 'shells.json').write_text(json.dumps(shell_config, indent=2))
        cases = json.loads(args.case_inputs.resolve(strict=True).read_text())['cases']
        state['inputFileSha256'] = digest(args.case_inputs)
        started = {}
        launch('first')
        for case in cases:
            status, published = request('POST', '/bpmn/artifacts', case['publish'])
            if status not in (200, 201):
                raise RuntimeError('Publication refused: counterexample changed or wrong products; response retained')
            status, start = request('POST', '/bpmn/executions',
                                    {'requestId': case['startRequestId'], 'sourceReferenceId': published['sourceReferenceId']})
            if status not in (200, 201, 202):
                raise RuntimeError('Unexpected start response; retained as diagnostic')
            if case['name'] == 'control' and (status != 201 or start.get('pending') is not False or start.get('result', {}).get('status') != 'Accepted'):
                raise RuntimeError('PT1H positive control did not start normally; diagnostic only')
            if case['name'] == 'beyond-date-range' and (status != 202 or start.get('pending') is not True or start.get('result') is not None):
                raise RuntimeError('Original overflow admission shape was not observed; diagnostic only')
            started[case['name']] = start
        state['started'] = started
        inspect_all(started, 'r6-cancel-initial')
        time.sleep(1)
        stop()
        before = snapshot('before-restart')
        launch('restarted')
        time.sleep(2)
        inspect_all(started, 'r6-cancel-unstarted')
        stop()
        snapshot('final')
        original_queue = before[TABLES[0]]
        if len(original_queue) != 1:
            raise RuntimeError('Expected one retained failing queue input; raw observations retained')
        original = original_queue[0]
        expiry_unix = (original['VisibleAfterUtcTicks'] - 621355968000000000) / 10_000_000
        launch('post-expiry')
        wait_seconds = max(0, expiry_unix - time.time()) + 5
        if wait_seconds > args.expiry_limit_seconds:
            raise RuntimeError('Natural claim expiry exceeds explicit bounded wait; no clock/row is changed')
        end = time.monotonic() + wait_seconds
        while time.monotonic() < end:
            time.sleep(max(0, min(1, end - time.monotonic())))
        inspect_all(started, 'r6-cancel-after-expiry')
        stop()
        after = snapshot('after-expiry')
        successor = after[TABLES[0]]
        state['sameOriginalInputReclaimed'] = len(successor) == 1 and successor[0]['WorkItemId'] == original['WorkItemId'] and successor[0]['ClaimToken'] > original['ClaimToken']
        state['qualification'] = 'adapter counterexample reproduced' if state['sameOriginalInputReclaimed'] else 'diagnostic: expected claim transition not observed'
        products_after = reader_call('products-after', '--inspect-host-products', workbench)
        if products_after != products:
            raise RuntimeError('Actual host/writer products changed during the adapter run')
    except BaseException as error:
        state['diagnostics'].append({'type': type(error).__name__, 'message': str(error),
                                     'status': 'diagnostic only; not a passing qualification'})
        state['qualification'] = 'failed setup/reproduction retained as diagnostic'
        raise
    finally:
        stop()
        state['explicitProductsUnchanged'] = {path: digest(path) == value for path, value in products_before.items()}
        # No private/Identity directories are payload. Preserve Runtime only if a failed setup reached it.
        if state['diagnostics'] and (private / 'runtime.db').exists() and not (output / 'diagnostic-runtime.sqlite.gz').exists():
            try:
                snapshot('diagnostic')
            except Exception as error:
                state['diagnostics'].append({'type': type(error).__name__, 'message': str(error), 'status': 'diagnostic Runtime backup unavailable; original host log retained'})
        write(output / 'adapter-result.json', state)
        shutil.rmtree(private)
        write(output / 'generated-file-manifest.json', {str(path.relative_to(output)): {'sha256': digest(path), 'size': path.stat().st_size}
              for path in sorted(output.rglob('*')) if path.is_file() and path.name != 'generated-file-manifest.json'})
    print(state['qualification'])


if __name__ == '__main__':
    main()
