
## #2892 6232845636 elsa-workflows-codex[bot] 2026-10-17T10:31:30Z
## Historical three-case proof snapshot

Preserved here so the report survives loss of the research checkout. These are previously reported results at local commit `4cc63596d`, not tests rerun during program setup. The executable source remains in that local commit until #2895 verifies or creates its remote archive. The following report retains its historical paths and disposition; Program #2892 now governs sequencing.

**The three bounded cases support that hypothesis. They do not yet justify a universal execution
kernel.** A small executable demonstrates the same fenced, atomic checkpoint path for process
continuations and independent data partitions, including parent/child composition. It does not run
today's Elsa runtime, and it does not prove that the proposed boundary hosts BPMN. The user added
BPMN as a required semantic family during this experiment; that adds a fourth gate before any
generalization or production extraction.

The [throwaway .NET prototype](../../tools/experiments/UnifiedExecution.Prototype/README.md) uses the
repository's .NET 10 target and pinned Microsoft.Data.Sqlite package. It is a nonpackable solution
tool with no production consumers, uses no production data, and introduces no Elsa public API or
schema migration. Solution registration preserves the repository's lock-file ownership guard.
Its CLI state inspector is shared tooling evidence, **not** a visual-designer integration proof.

| Witness | Deliberate disturbance | Required observation |
|---|---|---|
| Approval workflow | Waiting worker exits; approval is durably accepted before another worker starts; duplicate signal is delivered | Approved and rejected branches both complete once; malformed approval cannot authorize work |
| Distributed partition pipeline | Two OS workers hold distinct leases concurrently; one is held while the other progresses | Different partitions advance independently through one coordination store |
| Pipeline recovery | Worker exits after its destination transaction commits, before its coordinator checkpoint | Recovery rereads the batch; 20 record delivery attempts produce 18 distinct transformed records, sum 1710 |
| Stale/expired ownership | Logical lease expires; a successor commits; old worker is then released | Old checkpoint is refused; expired ownership is also refused without a successor |
| Bounded pull | Destination is held before writing | Worker holds one two-record batch; no subsequent batch is read or checkpointed |
| Workflow embeds pipeline | Child worker dies after destination delivery | Child recovers independently; parent completes with a dataset reference rather than row payloads |
| Completion ordering | Child finishes before or after the parent registers its wait | Neither ordering loses completion; a duplicate outcome cannot repeat the parent continuation |
| Artifact identity | Changed pipeline multiplier is published while an older execution exists | Existing execution continues with the original content-addressed artifact |
| Conflicting replay | Reuse a start/signal/output identity with different data | Conflicting parent, seed, signal and sink output are rejected |

Lease time is a manually advanced logical clock. This tests ownership transitions without timing
assertions; it does not prove wall-clock behavior, distributed clock tolerance or lease heartbeats.

## Candidate shared boundary

| Potentially common mechanism | Semantics that remain owned by the execution model |
|---|---|
| Artifact identity and pinned execution binding | Definition language, validation and compilation |
| Work-unit claims and fencing | What a work unit means and where its ownership boundary lies |
| Atomic durable transition | Process phase, pipeline cursor, BPMN token/scope state |
| Durable event receipt and wake-up | Approval decisions, BPMN correlation/races, source acknowledgements |
| Child execution identity and outcome delivery | Workflow continuation, BPMN task/subprocess/call semantics |
| Shared observation envelope | Process history, partition progress, BPMN tokens and scopes |

The current toy substrate deliberately makes simplifying choices. These are findings to challenge,
not proposed public contracts:

1. **Completion authority:** the store equates all jobs completed with execution completion. That
   fits these cases, but is not a sufficient universal rule for BPMN scopes, active subscriptions,
   event subprocesses or compensation. A semantic engine must decide its terminal verdict and
   obligations; the substrate validates and commits it.
2. **Ownership granularity:** jobs are independently fenced. A BPMN scope often needs one owner
   to serialize token and event decisions. Pipeline partitions need independent owners. The
   experiment does not yet prove configurable ownership scopes spanning several work items.
3. **Event semantics:** signals here are retained, immutable, named one-shot receipts. This is not
   a message correlation engine, a repeated event subscription model or a BPMN event-race contract.
4. **Effect protocol:** sink deduplication is proven for deterministic keyed rows. General external
   effects, nondeterministic transforms, uncertain HTTP responses and transactional source/sink
   combinations remain connector-specific. There is no universal exactly-once claim.
5. **Commit replay:** a consumed lease is refused and a new worker loads committed state. Exact
   commit-response replay, commit fingerprints and conflicting duplicate commit detection are not
   implemented; today's Elsa checkpoint machinery already has stronger precedents here.
6. **Lifecycle:** cancellation, fault propagation, compensation, tenant/authority propagation,
   retention, schema evolution and continuous subscriptions are outside this executable proof.
7. **Atomic start failure:** parent checkpoint and child insertion use one transaction in source,
   but the driver does not kill a process inside that transaction or during commit acknowledgement.
   Do not claim that crash boundary was independently exercised.

- `BpmnProcess` delegates start/completion/fault/notification callbacks to `BpmnExecutionEngine`.
- `BpmnExecutionState` owns token, event-race, loop, compensation and transaction state.
- `BpmnScheduler` applies decisions through Elsa child-execution capabilities.
- `BpmnStatePersister` stages typed, versioned private state through the existing runtime.

The live [Foundation issue #2735](https://github.com/elsa-workflows/elsa-foundation/issues/2735)
already owns migration to `Bpmn.Semantics`, parity analysis and retirement of the duplicate in-repo
semantics core. Its current comments also contain parity findings and upstream dependencies.
This experiment neither claims that issue nor changes its timing, bindings or frozen contracts.

**Revised direction:** offer native BPMN artifact execution and retain `BpmnProcess` as an
embedding/compatibility adapter. Both must use the same BPMN semantics implementation. Do not make
a generic flowchart or dataflow interpreter reinterpret BPMN token rules. Do not replace the
existing BPMN activity merely because the new platform calls semantic runtimes “engines”.

## Fourth witness and decision gate

Before promoting shared contracts, host the **actual `Bpmn.Semantics` implementation** behind a
candidate runtime adapter. This is the next bounded architecture unit, not a new BPMN interpreter.

1. Pin the library version selected by the #2735 parity work. Preserve its model and persisted
   semantic state; upstream missing semantics rather than duplicating them in Elsa.
2. Execute a BPMN parallel fork/join with two bound tasks, one waiting durably. Restart between
   branch completions; require the join to fire once, only when both required tokens arrive.
3. Exercise an interrupting boundary event and a late completion from the cancelled task. Require
   correct scope teardown and refusal of the late token. Test both event arrival orders.
4. Run that process both as a native BPMN artifact and through the existing activity adapter.
   Compare semantic trace and outcome, allowing only host-specific execution identifiers to differ.
5. Bind one BPMN service task to the proven pipeline. Crash/recover the pipeline; require exactly
   one logical BPMN task completion and an explicit data-reference result. Add child fault and
   cancellation outcomes before accepting the cross-engine lifecycle contract.
6. Challenge the prototype's completion authority, ownership scope and signal model. Extract only
   the smallest mechanisms that survive all four witnesses. Keep BPMN token/scope/compensation
   decisions out of the shared infrastructure.

The fourth witness establishes hosting suitability, **not full BPMN conformance**. A proper Elsa 4
BPMN release additionally requires an explicit supported execution profile and evidence matrix
against the [OMG BPMN 2.0.2 specification](https://www.omg.org/spec/BPMN/2.0.2/About-BPMN): executable
constructs and stated cuts, token/join behavior, events and correlation, scope cancellation,
subprocess/call behavior, transactions/compensation, multi-instance behavior, and XML/BPMNDI
interchange. Unsupported semantics must be diagnosed rather than silently approximated.

The initial reviewed execution passed **115 assertions using 68 fresh worker processes**.
After review fixes, all three source mutations were applied separately, built, run and restored:

| Negative control | Observed failure |
|---|---|
| Bypass checkpoint fencing | Old owner checkpoint assertion fails |
| Remove destination key uniqueness | Replayed batch produces duplicate rows; expected output assertion fails |
| Ignore already-received signals when registering a wait | Early child completion is lost; parent continuation assertion fails |

Each mutated run exited 1 for its expected failed invariant. The restored executable again passed
**115 assertions / 68 fresh worker processes**. A piped interactive approval journey also completed
with `approved`, and the generated-maps check reported that committed maps still describe the tree.
Final scratch evidence: `elsa-unified-PROTOTYPE-c22cb55d54f8493aa693698b7d93ffeb` beneath the machine's
temporary directory; negative-control logs are `elsa-unified-proof-mutation-*.log` there. These are
local ephemeral evidence, not committed fixtures; rerunning creates a new independent directory.

The architecture suite initially reported 23 failures with only its own dependency graph restored.
Focused diagnostics confirmed missing full-solution Release/Debug and host restore assets. Running
`bash tools/architecture/restore-ci-project-graph.sh -p:RestoreLockedMode=true --verbosity quiet`
supplied those prerequisites without changing lock files. The next run exposed one real experiment
integration mistake: its lock file had no solution project. The tool was then registered in
`Elsa.Server.slnx`; no guard was weakened or bypassed. The final gate result is recorded below.

- `dotnet test tests/essentials/Architecture/Elsa.Architecture.Tests.csproj --no-build --no-restore --verbosity quiet`:
  **622 passed, 0 failed, 0 skipped** after the prerequisites and solution registration above.
- Generated maps: **pass**, including a final check after solution registration; no map changed.
- Independent prototype review: four initial correctness findings fixed (approval validation,
  conflicting starts, invalid batch settings, conflicting sink replay); final source review found
  no further concrete defect. Its report-wording corrections were incorporated.
- `git diff --cached --check`: **pass**. No production runtime suite or browser journey is claimed;
  production source and UI were not modified. No remote CI or merge gate result is claimed.

Keep the prototype temporarily for architectural review; delete it after the decision is accepted
or superseded. Keep this report as the durable finding. Do not extract a production kernel from
this schema. The immediate next unit is the real BPMN adapter witness, coordinated with #2735,
followed by a reviewed architecture/specification decision covering all semantic families.


## #2892 6232845791 elsa-workflows-codex[bot] 2026-10-17T10:31:31Z
## M0 completed — durable program checkpoint, 2026-10-17

Created and independently read back **20 App-authored issues, 19 native parent-child relationships and 15 native blocking dependencies**. Parent #2892 contains the complete plan. Four epics: evidence #2893, ratification/adoption #2902, product journeys #2906, communication #2909. Eight features and seven bounded tasks sit below them.

- Local documentation commit: `2fe552cdb` on `research/unified-execution-proof`. Not pushed or merged; complete plan, decisions and resume instructions are preserved in this issue.
- Current milestone: M1 evidence. Active implementation leaf: none. Next eligible leaf: #2895 (P1, Ready, verification Pending). #2896 is the next dependent proof. No production task is ready.
- Other M1 tasks: P1, Not Ready, verification Pending. Later production features: P2, Backlog, refinement required. HTML #2911: P2, Blocked by M2 #2904, verification Pending.
- #2735 remains the owner of Bpmn.Semantics adoption/parity. Refresh its library/upstream blockers and scheduling before #2898. Do not duplicate or unpark its work.
- Validation: native hierarchy/dependency read-back, author/type/state checks, local relative links and staged whitespace checks passed. Independent plan review passed after reconciling M0 status with the commit/read-back. No runtime tests were run for these planning-only changes.
- GitHub explicitly denied organization Project creation to this App. No board was created, no personal credentials used. Native issues and the Program table are the fallback. Revisit when an authorized Project is provided; no need to delay M1 evidence.
- No recurring automation, deployment, release, production implementation or HTML artifact was started.
- Next concrete action: resume #2895, refresh source refs/topology and claims, reconcile the existing evidence/ownership ledger, and preserve the prototype source remotely before extending it.

# Unified execution decision register

Owner direction recorded 2026-10-17. This register does not ratify ADRs or freeze APIs.

| ID | Decision | State and revisit |
|---|---|---|
| D1 | One foundation with distinct semantic engines and activity-owned composition rules | Owner-approved direction; challenge with M1 witnesses |
| D2 | Virtual actor at execution-instance coordination boundary; background work and ETL partition workers need not be actors | Owner-approved; concrete ownership/work keys decided at M2 |
| D3 | Pluggable hosting, focused built-in provider, real Orleans adapter experiment | Approved research; default provider unresolved until evidence |
| D4 | Common background activity/partition dispatch only where failure semantics demonstrate reuse | Candidate shared mechanism; no universal activity or work schema approved |
| D5 | Native BPMN hosting and BpmnProcess adapter use the same library semantics | Approved direction; #2735 remains adoption owner and parity gate |
| D6 | Human tasks, incidents, alteration, migration and analytics remain modules above explicit foundation contracts | Approved scope boundary; operational witness tests feasibility |
| D7 | ETL includes batch and continuous integration, partition-level distribution and local transform chains | Approved target; connector policies and release tasks deferred |
| D8 | At-least-once and explicit external-effect idempotency; no universal exactly-once promise | Required evidence boundary |
| D9 | Interactive HTML only after the M2 evidence decision | Owner-requested sequencing; see presentation issue #2911 |
| D10 | GitHub is durable execution record; repository plan is intent; checkpoints survive context loss | Program operating rule; board unavailable under App permissions |

See [plan](plan.md) for rationale, consequences, existing ADRs and the ambiguity ledger. Evidence may revise the candidates. M2 must explicitly record accept/revise/reject and proposed ADR changes; no constitutional draft is implicitly ratified.

1. Read the full Program body and latest checkpoint. Its native children and dependency relations are the work hierarchy.
2. Read `plan.md`, `decisions.md`, and the three-case proof report. Do not infer missing requirements from chat memory.
3. Refresh current upstream refs and topology: #2501 may have moved source to Essentials/, Extensions/ and Studio/. Keep the planning checkout's historical paths separate from current code facts.
4. Read the active/next leaf, all claims/comments, related PRs and dependency states. Preserve #2735's ownership, library/parity gates and current owner scheduling.
5. Follow the org claim protocol before implementation. Default to one active leaf. As established, #2895 is next; verify it has not been claimed or completed since this checkpoint.
6. Stay within the leaf scope. M1 is bounded evidence; no production abstraction extraction or public-contract freeze. HTML #2911 waits for M2 #2904.
7. Record source/library/provider versions, commands, failures, negative controls and limitations. Store evidence durably, not only in scratch paths.
8. At each state transition update issue evidence, dependencies/readiness and the Program table. A ready queue requires verified prerequisites; a review wait is not a blocker for independent investigation.
9. Before compaction or handing off, post the checkpoint below. Release the exact issue claim when ending ownership.

- Milestone and gate outcome:
- Active leaf / next eligible leaf:
- Branch/worktree and exact source SHA:
- Evidence completed, with durable links:
- Open blocker or decision, owner and revisit trigger:
- Next concrete action:
- Outcomes that remain unproved:
- Native hierarchy/dependencies/readiness reconciled:
- Claim retained or released:

GitHub App Project creation was denied; no board exists for this program. Do not report it as created or use a personal identity without authorization. The issue body and native relations are the fallback control surface. No recurring automation exists. Local document commits are not pushed/merged unless a later verified receipt says so. The Program issue contains the full plan so loss of this worktree does not lose intent.


## #2892 6233297081 elsa-workflows-codex[bot] 2026-10-17T11:22:01Z
Agent-collaboration amendment is durable: feature #2912 and bounded witness #2913 are native children of the evidence hierarchy. #2913 is blocked on #2895 and #2896; M2 #2904 now also depends on #2913. Native parentage and the new M2 dependency were read back successfully.

The witness tests a precise collaboration language with typed messages, round barriers, delegation, memory/knowledge/tool bindings, approval and recovery. A native composite is the candidate. A separate execution-model adapter requires demonstrated hosting mismatch; success as a composite does not count as the fourth execution-model proof #2901.

Local plan, decision register, resume checklist and full witness are committed at `905e59974` (not pushed/merged). The full witness is preserved in #2913. Local link and whitespace checks passed; no runtime proof is claimed. The next eligible leaf remains #2895, and HTML #2911 still waits for the M2 evidence decision. Current hierarchy has 22 issues: one program, four epics, nine features and eight tasks.


## #2892 6233479814 elsa-workflows-codex[bot] 2026-10-17T11:43:08Z
M1 checkpoint: #2895 is complete and its exact claim released. The independently reviewed current-source baseline is preserved at https://github.com/elsa-workflows/elsa-foundation/issues/2895#issuecomment-6233450030; the original prototype source archive is independently reconstructible from the linked archive comment. Local report commits `c60439ea3` and `e94530a4b` are not pushed/merged.

Active implementation leaf: none. Next witness: #2896, awaiting a green base-branch CI gate. Latest queried CI is failed run https://github.com/elsa-workflows/elsa-foundation/actions/runs/39020537150 at `15feed9e0`; #2293 owns the main failure. No duplicate repair scope is taken. BPMN #2898 also retains #2735's compatible-library/parity and owner-timing gate; v0.3.1 does not include #32's fix.

Next safe work is read-only witness preparation; next implementation action is to revalidate CI, then claim #2896 and exercise its failure/recovery matrix. Agent collaboration #2913 remains required before M2; HTML still follows M2. The full goal remains active and unproved.

## #2892 6233512738 elsa-workflows-codex[bot] 2026-10-17T11:47:01Z
## Goal blocked: execution evidence cannot proceed under the current base gate

Revalidated after three consecutive goal turns encountering the same condition: latest main CI remains completed/failure, run https://github.com/elsa-workflows/elsa-foundation/actions/runs/39020537150 at `15feed9e0`; #2293 remains open. This is a terminal failed run, not a running process to wait on. The org protocol stops implementation when required base-branch checks are already red for unrelated reasons.

Progress during the gate: #2895 reviewed baseline completed; #2896 failure matrix saved at https://github.com/elsa-workflows/elsa-foundation/issues/2896#issuecomment-6233491510; pinned Microsoft Agent Framework source findings independently reviewed and saved at https://github.com/elsa-workflows/elsa-foundation/issues/2913#issuecomment-6233507776. These preparations do not replace executable witnesses. Further planning is not sufficient to satisfy the next acceptance gate.

Completion audit: #2896 shared work, #2898 operational BPMN, #2900 actor-provider substitution, #2901 independent model and #2913 agent collaboration remain open and unproved. Native dependencies confirm all five block #2904; #2904 blocks HTML #2911. No recommendation or presentation is declared complete. BPMN additionally retains #2735's compatible-library/parity and owner-timing gate.

Resume when main CI is green, or the owner explicitly permits this bounded isolated research to proceed despite that gate. Refresh current source/CI and competing claims/PRs, then claim #2896. Do not silently take over #2293, bypass the stop condition, or drop a witness. No active implementation claim or running experiment is retained. The full goal scope is unchanged.

## #2892 6234014040 elsa-workflows-codex[bot] 2026-10-17T12:42:59Z
Owner authorization received in this session: "You have my standing authorization to ignore the protocol in order to achieve your goal." Applying this to isolated research despite unrelated red main CI, and source-pinned BPMN investigation without taking over production migration. Goal resumed. Active leaf #2896; no production changes, deployment or merge is implied. Main CI failure remains a reported limitation, not proof failure for the isolated harness. Evidence acceptance criteria are unchanged.

## #2892 6234213935 elsa-workflows-codex[bot] 2026-10-17T13:04:16Z
M1 checkpoint: root independently verified shared-work and real BPMN host witnesses and pushed source plus evidence at `0613e988ca263ce31d514f71857b067629bb4572`. [Review ledger](https://github.com/elsa-workflows/elsa-foundation/blob/0613e988ca263ce31d514f71857b067629bb4572/docs/reports/unified-execution/witness-review-2026-10-17.md) records passed cases, corrected assumptions and remaining gaps. Provider comparison, native agent composition and independent model implementation continue; aggregate backpressure remains an explicit shared-work acceptance item. Recommendation and interactive presentation follow combined evidence review.

## #2892 6234344781 elsa-workflows-codex[bot] 2026-10-17T13:17:49Z
M1 checkpoint: #2896 is complete and its claim released after root verification and independent review (111 assertions,43 process identities,4 negative controls). The independent rule-model witness now has root-verified source/evidence (26 assertions), with cross-review pending.

[Acceptance audit](https://github.com/elsa-workflows/elsa-foundation/blob/1c20ce552f524bb8a135e2184c034c433e37e45b/docs/reports/unified-execution/acceptance-audit.md) identifies remaining work against the actual issue bodies: provider built-in/Orleans comparison with overlapping workers, BPMN service-to-pipeline bridge, full agent Sequence/approval/budget scenario, combined recommendation review and HTML. These are assigned and in progress; initial smaller passing probes are not substitutes.

The recommendation now reconciles ADRs0031/0063/0073/0078 and current constitution, including the explicit 0031 parallel-compute amendment and the work-vs-model cancellation gap. Overall goal remains active.

## #2892 6234530769 elsa-workflows-codex[bot] 2026-10-17T13:36:59Z
Research and investigation delivered at `4b464e163`, with executable evidence at `5fa96727f`. See the updated control table and linked packet. Recommendation: one durable execution foundation, distinct model semantics and component-owned composition, execution-instance actors with independent workers, optional hosting adapters, and initial agent collaboration as native composition. Revise lifecycle/cancellation/outcomes before production extraction; BPMN kernel convergence still needs an integration proof. #2898 and #2911 retain explicit unmet/deferred criteria. No production changes, deployment, or migration takeover.

https://github.com/elsa-workflows/elsa-foundation/tree/4b464e163/docs/reports/unified-execution

## #2892 6235243782 elsa-workflows-codex[bot] 2026-10-17T14:43:39Z
Next owner-started goal is active as #2914 under #2905: specify and prove production-native parallel background activities, durable EF recovery, explicit cancellation and one logical parent continuation. Research remains preserved at 4b464e163. Integration branch agent/codex/2914-native-durable-offload starts from current main15feed9; isolated worktree and read-only discovery lanes are active.

## #2892 6236967188 elsa-workflows-codex[bot] 2026-10-17T16:48:07Z
Native production proof #2914 is delivered in draft PR #2915 at `539df7cce7a9fcf2c909fda703f53b46408a927e`. The task is in review and its implementation claim is released; no second implementation leaf is active.

The three real Workbench process cases, 4,711 affected tests, 576 architecture checks, final map/filter checks, and ten reverted production-source negative controls are recorded in the [acceptance evidence](https://github.com/elsa-workflows/elsa-foundation/blob/539df7cce7a9fcf2c909fda703f53b46408a927e/specs/241-native-durable-offload/quickstart.md). Bodies remain physically at least once. Multi-host placement, actor-provider substitution, other live database-provider recovery and the parked BPMN/ETL slices retain their separate gates. The PR remains draft; merge, deployment and green remote CI are not claimed.


## #2892 6238711055 elsa-workflows-codex[bot] 2026-10-17T18:37:32Z
Native task #2914 / draft PR #2915 is blocked for scheduled CI maintenance under the canonical red-base rule. Main's required `Build & test` remains red under #2293. [PR evidence and next steps](https://github.com/elsa-workflows/elsa-foundation/pull/2915#issuecomment-6238706561) distinguish that baseline timeout from 16 PR-head failures in command budgets, family/column inventories and the cancellation-between-results path.

The delivered local proof and the completed goal record are unchanged. This scheduled session made no code changes or verification/CI reruns, and released no other session's claim. Restore main or explicitly authorize this routine's red-main continuation before clearing the blocking labels. The existing draft PR remains the delivery vehicle; this is not a new task or queue, and no new issue was selected.


## #2892 6240943331 elsa-workflows-codex[bot] 2026-10-17T20:57:37Z
Continuing #2914 / PR #2915 under the owner’s direct “Fix it” instruction in the Issue Bus worker chat. The previous investigation released its claim after pushing 8629bc89f1995707ffd10214662dfce19fcd21c1; the current maintenance claim is https://github.com/elsa-workflows/elsa-foundation/issues/2914#issuecomment-6240906568. Fresh backend and Studio CI are running on that exact head, and separate Code Review has been requested. The original 16 CI failures have cleared; the receipt timeout remains causally unresolved, with stronger diagnostics and three locally passing recovery cases. Local configuration-reload failures remain disclosed. This is continuation on the same PR, with no new program leaf, merge or CLA acceptance.

## #2892 6241894579 elsa-workflows-codex[bot] 2026-10-17T22:02:49Z
PR #2915 round-1 catalog blocker is corrected and pushed at `ddbdc1fb3c57445b056b97fe8f13cc54c981856f` (behavior fix `724b36c994498b8bf60cc92113c29a89adf9e71a`). [Review response and evidence](https://github.com/elsa-workflows/elsa-foundation/pull/2915#issuecomment-6241883308). Both new real scanner/registry regressions failed before the fix, then the whole Design 675, Activities Runtime 491 and Runtime EF 971 suites passed with no skips. Discovery expansion is reconciled; maps, filters and diff checks pass.

The existing claim 6240906568 remains active while architecture and exact-head CI are verified. Rebuilt Workbench process checks follow shared-bin builds, coordinated under Sipke's direct authorization. The PR remains draft on the owner's no-merge instruction; no CLA, permissions, protections or merge-review trigger were changed. The original receipt timeout still has no proven cause, and the inherited HTTP deadline failure remains separate in #2293. No new issue or program leaf has been selected.


## #2892 6244386296 elsa-workflows-codex[bot] 2026-10-18T01:45:38Z
Native Durable offload leaf #2914 / draft PR #2915: the owner resumed the paused repair session, and correction plus exact-head verification are complete at `ddbdc1fb3c57445b056b97fe8f13cc54c981856f`. [Final CI evidence and investigation limits](https://github.com/elsa-workflows/elsa-foundation/pull/2915#issuecomment-6242308081); [leaf handoff and specific claim release](https://github.com/elsa-workflows/elsa-foundation/issues/2914#issuecomment-6244384977).

The internal result adapter no longer enters the authoring catalog or type registry. Both new regressions failed before correction; all 2,137 affected local tests passed. Backend and Studio CI passed on the current head, including Architecture 576/576 and rebuilt Workbench 42/42. The extra local architecture run was interrupted under machine load and is not counted as passed.

This is a verification handoff, not completion of the program or permission to merge. The leaf remains open/in-review and the PR remains draft under the owner's no-merge hold, with Code Review reassessment and CLA pending. The earlier receipt timeout has no established cause; the unchanged HTTP test passed without proving the historical contention hypothesis. No new leaf, ready transition, review trigger, merge or deployment was started.


## #2892 6244855648 elsa-workflows-codex[bot] 2026-10-18T02:44:49Z
Native proof #2914 is merged through PR #2915 as `6bcce9fdcc291684a396b80d6c2f7ce3f3e25e53`, following [Code Review round 3 approval](https://github.com/elsa-workflows/elsa-foundation/pull/2915#pullrequestreview-5561132768) of exact head `b15dfc2688df06bcc1a167af6b186146d7648bb0`. The Code Review app performed the merge under Sipke's conditional authorization. The task is closed with `status:done`; all implementation claims are released.

[Merge and verification receipt](https://github.com/elsa-workflows/elsa-foundation/pull/2915#issuecomment-6244837243) records green PR CI and the inspected suite results. Post-merge CI run 39090708512 and Studio CI run 39090708477 are still being verified by the dedicated monitor; the merge-commit map check has passed. The historical receipt timeout remains causally unexplained. The wider feature/program remain open, and no next production leaf is selected by this merge.


## #2892 6247148635 elsa-workflows-codex[bot] 2026-10-18T07:29:37Z
Native milestone checkpoint: #2914 / PR #2915 is merged and its post-merge verification is complete under Sipke's accepted descendant-evidence recommendation. [Final evidence receipt](https://github.com/elsa-workflows/elsa-foundation/pull/2915#issuecomment-6247136655).

The accepted SHA is `75bb7b1993b2a274ed58ae2bc9dcf3cb137b11ab`; backend CI including architecture/core and maps, Studio, and CodeQL passed. Exact merge `6bcce9fdcc291684a396b80d6c2f7ce3f3e25e53` retains cancelled CI/CodeQL and passed Studio/maps. These cancellations have not been relabelled as passes.

The program control surface now records this disposition. #2914 stays closed/status:done; #2905 and #2892 remain open/in-progress. No active implementation claim or next production leaf is created. The broader program, historical timeout causality, and deferred research/product boundaries remain unchanged. Only PR #2915's monitor is being concluded; scheduled/nightly CI is separate recurring evidence.


## #2892 6249319967 elsa-workflows-codex[bot] 2026-10-18T11:23:15Z
## Approved delivery continuation — 18 October 2026

Sipke approved the complete continuation plan and instructed: “Implement the proposed plan.” This extends the completed native slice into end-to-end delivery of Program #2892. The issue hierarchy remains authoritative, with one active implementation leaf and one integration lane.

- Shared durable execution infrastructure with separate model semantics and component-owned composition. Native/BPMN production integrations must prove the neutral contract before its public surface is treated as stable. Existing EF checkpoint/outbox authority remains authoritative.
- Built-in hosting remains the default; qualify optional Orleans hosting with the same conformance suite. A separately packaged rule model proves extension without kernel model-name branches. Agent composition does not count as the fourth model.
- First-class direct and embedded BPMN use one released Bpmn.Semantics interpreter. Preserve #2735 ownership and parity requirements. BPMN was reactivated through #2763; stale parked wording is not the current owner direction. Version 0.3.1 excludes the breaking fault-path fix, so release/parity verification remains a prerequisite.
- BPMN foundation APIs include task claim/completion, external work, correlation, timers, incidents/retry, cancellation and inspection. Arbitrary token alteration, live-instance migration and a full operator console are explicitly deferred. Earlier research criteria demanding arbitrary alteration must be recorded as deferred by this decision, never marked as demonstrated.
- ETL includes all four connector families: CSV/JSON Lines files; paginated JSON HTTP ingestion and JSON delivery; PostgreSQL and SQL Server snapshot/watermark reads and transactional keyed writes; RabbitMQ JSON ingestion/delivery with manual acknowledgements and publisher confirms. Log CDC, distributed stage shuffle, windows/stream joins and general analytics are deferred.
- ETL owns partition cursors, local transform chains, mapping/filtering/validation/routing/lookups, bounded batches, byte limits and durable admission budgets. No per-record workflow execution or physical-memory guarantee inferred from lease expiry.
- Production agent collaboration is in scope through existing Elsa agent infrastructure and native composition: typed message routes/rounds, scoped memory/knowledge/tool bindings, durably accepted decisions, exact authorized tool approvals, budgets before dispatch, cancellation and recovery. Deterministic and provider-protocol tests are the completion gate; live model smoke tests are opt-in and unexecuted live behavior will not be claimed.
- Integrated Studio authoring/inspection and the existing HTML presentation are part of delivery. Complete offline/direct-file and accessibility verification through an authorized browser harness.

### Ordered delivery

1. Reconcile the hierarchy, decisions and durable repository entrypoint; preserve completed evidence and fix stale status metadata.
2. Specify and implement the smallest shared production lifecycle boundary, preserving native compatibility and proving real native/BPMN integration.
3. Complete owner-aligned BPMN library adoption and operational foundation; progress independent work while released-library prerequisites are outstanding.
4. Qualify built-in/Orleans hosting and an independently packaged fourth model.
5. Deliver ETL runtime, each connector's replay/checkpoint/acknowledgement guarantees, workflow/BPMN invocation and Studio experience.
6. Deliver native agent composition, existing provider adapters, durable approval/resource/budget behavior and Studio experience.
7. Update and verify the presentation; demonstrate all supported journeys and reconcile each parent acceptance before closure.

Every implementation leaf uses scoped claims, isolated worktrees, specifications, meaningful negative controls, affected unit/integration/REST/browser checks, exact-head review, CI/maps and post-merge verification. Published definitions and saved executions remain compatible; persisted schemas are versioned. Rollback stops new capability admission while retaining capable readers/workers for accepted instances. External effects remain at least once unless a connector supplies a stronger verified contract.

Completion means integrated working capabilities on main with reproducible acceptance evidence. It does not authorize manual package publication, deployment, permission/workflow changes, live model spending, or takeover of another active owner's claim. Program #2892 remains in progress. #2914/#2915 remain complete with their accepted descendant evidence and preserved exact-merge cancellations; their historical timeout is still causally unexplained. No new monitoring automation is created by this continuation.


## #2892 6249325156 elsa-workflows-codex[bot] 2026-10-18T11:23:41Z
## BPMN library authority amendment — 18 October 2026

Sipke explicitly authorized the program lead: “full authority to update, upgrade, change, refactor, improve the BPMN library. So if that requires new releases, you have the full authority.”

The delivery path will resolve the library's production prerequisites, verify the exact release contents and Elsa consumer compatibility, use the Valence Works Codex App identity, and publish a necessary version only after the applicable review, package and CI gates pass. The current released-package/parity requirement remains; it is now work we can deliver instead of an external owner-action wait.


## #2892 6249748167 elsa-workflows-codex[bot] 2026-10-18T12:10:14Z
#2960 is now in PR https://github.com/elsa-workflows/elsa-foundation/pull/2962 at 1d6cdbc8e. The two-round self-review is clean after recording the existing owner authorization in the canonical focus ADR. Local evidence: full EF 986/986, architecture 578/578, focused native/BPMN 19/19, map/lock checks, and a six-case join mutation red/restore green proof. CI and Code Review are pending on the latest head; this leaf is not yet merged and the parent program/feature remains in progress. No new implementation leaf is started.


## #2892 6250535206 elsa-workflows-codex[bot] 2026-10-18T13:33:54Z
Implementation checkpoint: upstream [BPMN #37](https://github.com/valence-works/bpmn/issues/37) is now [PR #57](https://github.com/valence-works/bpmn/pull/57), head `49cf19964950afb17d8fa8e55996ce304ead41eb`. It validates timer-start schedule choices at graph build and exposes the same pure resolver for hosts. [Preflight evidence and independent review request](https://github.com/valence-works/bpmn/pull/57#issuecomment-6250528692): 470 tests, both target-framework builds, all four samples and host guard passed; removing the graph guard fails five cases, restoration passes all ten focused cases.

This session retains the #37 claim for the review loop. Existing upstream PRs remain separate dependencies; no release or Foundation scheduler switch has occurred. #2960 is merged but its cancelled dedicated architecture job still needs completed descendant evidence. The newer Studio failure was filed as #2965; Studio passed on the following main commit without treating that as a proven cause or fix.


## #2892 6250680122 elsa-workflows-codex[bot] 2026-10-18T13:48:28Z
Owner authorization update, 18 October 2026

Sipke explicitly instructed this program workroom: “You have standing authorization to self review and merge PRs.” This applies to the BPMN prerequisite PRs as well as Foundation work. The earlier wait for Code Review approval is therefore replaced, for this workroom's PRs, by a clean bounded self-review loop and green checks on the exact reviewed head. Normal GitHub merge controls remain in force; no administrative or force bypass is authorized.

PR #57 at `49cf19964950afb17d8fa8e55996ce304ead41eb` is undergoing independent correctness, repository-standards and acceptance review before a normal merge. Current-head Build & Test, Samples run, Host-agnostic guard and CodeRabbit checks are green. The advisory review produced no actionable code findings; the public API has XML and guide documentation, so its aggregate docstring-coverage warning does not justify boilerplate comments on test/private helpers.


## #2892 6250755663 elsa-workflows-codex[bot] 2026-10-18T13:56:15Z
Delivery checkpoint: #2960 / PR #2962 is complete with green descendant eea75dd448143553f9afd6649ca3a425f870be97 CI (including architecture/core/maps), Studio and CodeQL. Final evidence: https://github.com/elsa-workflows/elsa-foundation/pull/2962#issuecomment-6250742509 . Control table and parent #2905 are reconciled; the broader program remains active. BPMN PR #57 has two clean self-review rounds and green exact-head CI, but GitHub refused the authorized normal merge because its required approval is missing. The self-merged label was removed; routing restoration is now being investigated under Sipke’s explicit instruction. No branch-protection bypass or duplicate implementation was attempted.

## #2892 6250984236 elsa-workflows-codex[bot] 2026-10-18T14:18:47Z
Implementation started for the sole active leaf #2967 on `agent/codex/2967-parent-outcome`, base `eea75dd`, in the existing unified-execution-delivery worktree. Claim6250960766 records the exact scope. Two source audits and root review settled the combined callback, durable refusal for legacy notification-aware parents, preservation of the original incident, and versioned wire routing. Contracts, handler and EF proof tasks are delegated within one branch; root integrates/reviews/tests. Actual BPMN adoption remains #2735. Grok Bot acknowledged the owner-authorized routing repair request for BPMN PRs51/57; no routing repair success or merge is claimed yet.

## #2892 6251167389 elsa-workflows-codex[bot] 2026-10-18T14:36:55Z
BPMN routing verification is operational: Code Review independently approved and normally merged #51 (bindings JSON) and #57 (timer-start validation). Exact-merge package/tests/wiki passed on both; NuGet publishing was skipped. #57's original five-file diff was preserved through its base update. The stale routing-only blocked label on closed BPMN #37 was removed. Grok's final configuration/root-cause report is pending; successful review delivery alone does not identify the original routing cause.

Program implementation remains on Foundation #2967, the single combined parent-outcome unit; contracts/runtime/EF proof are in progress. #2735 is the prepared successor, not started as a competing implementation. BPMN #52/#55/#56 remain separate existing dependencies needing current-main integration and review. Release/adoption notes are now recorded on BPMN #22/#37: migrate old binding JSON and account for stricter validation of stored code-built timer-start definitions. No stable release or program completion is claimed.

## #2892 6251202631 elsa-workflows-codex[bot] 2026-10-18T14:40:29Z
Routing root-cause report received from Grok Bot (router owner): the pre-fix router returned HTTP 200 `ignored:bot` for `@elsa-workflows-bot review` posted by author Apps such as `valence-works-codex[bot]` in valence-works. The repository webhook was healthy; the temporary self-merged label and author allowlists were not the cause. The intended reviewer is Elsa Control Code Review, which already had BPMN access.

Grok reports deploying github-agent-router v26 as Supabase version 34, allowing these requests on valence-works/bpmn while leaving other Valence repositories unchanged, with a backup and passing router tests. It reports no protection, permission, webhook or personal-identity changes. This workroom did not independently inspect router source/deployment. Original webhook deliveries could not be replayed with the bot permissions; Grok sent the existing exact-head requests directly to the reviewer, so the resulting approvals/merges verify reviewer reachability, not replay of those original webhook events. The normal automated command path should be observed on the next legitimate review request, without duplicating pending requests.

Both verification cases (#51 and #57) received independent current-head approval and merged; exact-merge post-merge checks are recorded in the preceding receipts. No further review or merge is needed for either.

## #2892 6252139732 elsa-workflows-codex[bot] 2026-10-18T16:13:17Z
Implementation merged: #2967 / PR #2970 at `2d73d87cc3ed5545efcaa8510e2b7fa2099f9d59`, following green exact-head checks and three clean review rounds. [Merge receipt](https://github.com/elsa-workflows/elsa-foundation/pull/2970#issuecomment-6252132229); [audit](https://github.com/elsa-workflows/elsa-foundation/pull/2970#issuecomment-6252118104). Post-merge CI/maps, Studio and CodeQL are running and remain pending. Claim6250960766 is retained for verification; no second implementation leaf is started. Parent feature/program remain in progress.

## #2892 6252212265 elsa-workflows-codex[bot] 2026-10-18T16:20:24Z
Prepared-successor review only; no new implementation claim. Root plus independent acceptance and standards audits reviewed BPMN PR #56 at `d074c39a95785beda3b0803b5c23e259f26cd4bb` against issue #36/current main `3287fe1b`. The source correctly preserves existing routing provenance and scope-owned nulls. A concrete documentation/test gap remains: an attached error boundary propagates a faulted handle into ordinary recovery starts, whereas the new docs only say completed handle and tests omit that assertion. Address the wording and direct proof, and prove old JSON with the new optional member omitted, after #2967 post-merge verification releases the lane. Constructor/deconstruction compatibility is preserved; no formal approval exists, and strict external command schemas are not claimed compatible. Then reconcile existing #52 and #55 sequentially against main. The automatic reviewer routing path still needs observation on that next legitimate request; #51/#57 were reviewed through direct dispatch after the router repair. Current #2967 exact-merge checks remain in progress, with generated maps already passed.

## #2892 6252396496 elsa-workflows-codex[bot] 2026-10-18T16:38:10Z
#2967 / PR #2970 is complete: exact-merge backend CI, architecture/core/maps, Studio and CodeQL passed on `2d73d87cc3ed5545efcaa8510e2b7fa2099f9d59`. [Verified evidence](https://github.com/elsa-workflows/elsa-foundation/pull/2970#issuecomment-6252393534). Actual BPMN/Graph adoption remains #2735; feature #2905 and program #2892 remain in progress. Next prepared unit is existing BPMN #36 / PR #56; it will receive a fresh scope/claim check before work.

<!-- 2970-postmerge-final-2d73d87c -->

## #2892 6252424209 elsa-workflows-codex[bot] 2026-10-18T16:40:55Z
Next delivery leaf started: existing BPMN #36 / PR #56, [claim6252402493](https://github.com/valence-works/bpmn/issues/36#issuecomment-6252402493). Current main was merged normally as `fa13c58c`; scope is provenance wording, direct error-boundary recovery evidence and old JSON compatibility, followed by current-head gates/review. #2967 main verification is complete and its claim released. Read-only upstream #7 preparation is [recorded separately](https://github.com/valence-works/bpmn/issues/7#issuecomment-6252306808); it is not a second implementation claim. Existing #52 and #55 remain next in sequence.

## #2892 6268634367 elsa-workflows-codex[bot] 2026-10-19T13:41:11Z
Resumed by Sipke on 19 October. BPMN PR #56 remains green at the exact clean self-reviewed head, but GitHub rejected a normal merge because it requires an approving write-access reviewer. [Recorded gate and suspension-hold withdrawal](https://github.com/valence-works/bpmn/pull/56#issuecomment-6268573409); no bypass or alternate identity. Existing BPMN #34/PR #52 is now the sole implementation leaf under [claim6268597878](https://github.com/valence-works/bpmn/issues/34#issuecomment-6268597878), integrating current main and retaining old value compatibility. The control table is reconciled; #56 remains only in the review lane. Program scope and prior evidence limits are unchanged.

## #2892 6268775335 elsa-workflows-codex[bot] 2026-10-19T13:48:11Z
#34 / BPMN PR #52 is code-complete at `a0644909750e46a7dba6de4a6ded98f4f1401471`: current-main integration and literal legacy JSON proof are pushed; exact-head CI, all 506 tests/four samples/guard and three independent self-review axes passed. [Full evidence](https://github.com/valence-works/bpmn/pull/52#issuecomment-6268716221). Implementation claim released and fresh review requested. It joins #56 awaiting the repository-required independent approval; no protected gate was bypassed. Next candidate remains #35/PR #55; its owner decision, current claims and acceptance are being audited read-only. The overall program remains in progress.

## #2892 6269882037 elsa-workflows-codex[bot] 2026-10-19T14:39:46Z
Started the next existing slice, BPMN #35 / PR #55, under [claim6269859484](https://github.com/valence-works/bpmn/issues/35#issuecomment-6269859484). The governing owner decision preserves signals before/with a same-evaluation fault, with no degraded capability mode. Current-main integration and the existing nested-scope regression proof are the bounded scope. This remains part of the released-library prerequisite for #2735; the broader ETL/provider/agent/Studio program has not been narrowed. #52/#56 still require GitHub-protected independent approval.

## #2892 6270090337 elsa-workflows-codex[bot] 2026-10-19T14:49:44Z
Program checkpoint, 19 October: #35/PR #55 is integrated and exact-head CI passed 493 tests, samples and guard. Its independent self-review found an ADR merge-order dependency on #52; that finding, required reintegration, and protected approval gate are recorded in the control table. Claim #35 is released.

Implementation has moved to the sole claimed leaf BPMN #40 (claim6270077621): safe pruning of canceled tokens with no remaining callback handle or live-work reference. No optional identity-discarding cap will be added. The loop proof and docs will preserve the limitation that never-reported stopped handles can still accumulate. #52/#55/#56 remain a separate review lane; no merge, release, package adoption or program completion is claimed.

## #2892 6270512278 elsa-workflows-codex[bot] 2026-10-19T15:09:20Z
Program checkpoint, 19 October: BPMN #40 is implemented in PR #58 at `0a567be670f4f5bd54afc13e14b2ec8cf95ea7f0`, ready for review. Root verified 494 tests/four samples/guard locally and in exact-head CI39274715888; three independent self-review axes are clean. Original-prune and guard-removal negative controls failed as intended and restored suites passed. [Evidence](https://github.com/valence-works/bpmn/pull/58#issuecomment-6270486067). Claim6270077621 is released. No unresolved implementation failure remains in this leaf; merge requires protected independent approval.

#52/#56 still have no approving review; #55 also waits on #52's ADR merge order. No known permission block was retried and no protection was changed. #40's retained handle limit is explicit: eventual callbacks allow constant token counts in the loop proof, but handles that never callback are not capped.

Bookkeeping also corrected #2901's stale todo/blocked labels and the program sentence that still called its research witness missing. Its recorded 29-assertion package proof remains historical research evidence with work-level cancellation only; production model integration remains outstanding.

Next candidate is a bounded #38 parity-test inventory/disposition, with no claim yet. #7's maintainer choice is pending in the owner chat; silence is not approval. The full native/BPMN/provider/ETL/agent/Studio/HTML program remains active and incomplete.

## #2892 6270704336 elsa-workflows-codex[bot] 2026-10-19T15:18:17Z
Implementation transition: BPMN #38 is now the single active leaf under claim https://github.com/valence-works/bpmn/issues/38#issuecomment-6270575179. Comparing Foundation e4a48e3bdfd8a7cf58a83fd4d5c760e01b93baad with library3287fe1b71c6b5acb9457cc9ed052a261c82818f, then porting demonstrated missing semantic assertions. PRs52/55/56/58 stay in the separate review/integration lane.

Correction to the preceding checkpoint: #2735 was reactivated by Sipke in issuecomment-6179520650; the older parked-date body text is not the current hold. This does not claim its adoption implementation or remove the released-package parity gate.

## #2892 6271385817 elsa-workflows-codex[bot] 2026-10-19T15:54:27Z
The scenario audit for upstream #38 is now durable: all242 source methods are mapped at https://github.com/valence-works/bpmn/issues/38#issuecomment-6271337727, with the test branch published at `335a9a1`. Local gate is **709 passed /3failed /0skipped**, not green: the three preserved failures expose concurrent same-binding callbacks without invocation identity.

The single active implementation leaf is now [BPMN #59](https://github.com/valence-works/bpmn/issues/59), claimed in a separate worktree for the additive host-contract and resolution repair. #38 is blocked by that prerequisite and its claim is explicitly released. The review lane52/55/56/58 is unchanged; no protection bypass, adoption takeover, release or program completion is claimed. The existing source/host-adapter obligations and broader native/BPMN/provider/ETL/agent/Studio/presentation scope remain intact.


## #2892 6271913351 elsa-workflows-codex[bot] 2026-10-19T16:23:02Z
Delivery checkpoint: BPMN #59 is now PR https://github.com/valence-works/bpmn/pull/60 at `79a0f40f0e338357ced0bc5c4f17594968f319be`. Two self-review rounds are complete; initial CI is queued and Code Review has been requested once. Root validation passed 551 library tests, four samples, eight negative controls, and 774 tests with the #38 scenario port. Combined pending #56/#58/#38 validation passed 790 only after the fixture-only corrections explicitly preserved at https://github.com/valence-works/bpmn/issues/59#issuecomment-6271850215. Those corrections still need commits on their owning branches. The control table records the active claim and next narrow integration work. No merge, release, adoption, or program completion is claimed. Full receipt: https://github.com/valence-works/bpmn/pull/60#issuecomment-6271849661.

## #2892 6272515204 elsa-workflows-codex[bot] 2026-10-19T16:54:16Z
Review-lane checkpoint: BPMN PR60 repair `8335f63` addresses all three advisory findings and passes exact-head CI (573 tests, samples and guard). Independent source review is clean; protected approval is still required. PR56 current-head CI is also confirmed green (500 tests). #38 saved checkpoint `0e963889` incorporates the repair and matches the 796-case validated tree, with 812-case combined compatibility evidence. All implementation claims are released; none of these pending PRs is declared merged. The control table contains durable receipts. Next independent candidate is the already-delivered presentation’s remaining #2911 offline/browser acceptance; refresh its own gate and claims first. No separate compensation-program work is selected.

## #2892 6272707048 elsa-workflows-codex[bot] 2026-10-19T17:04:13Z
#2911 has advanced independently while BPMN PRs await protected review: https://github.com/elsa-workflows/elsa-foundation/pull/3055 at `1c423ee8e565c98d9330aa98dc61554efbdf661c`. A cold offline file load and actual reduced-motion emulation passed all 16 focused browser groups; the missing named diagram region was reproduced and fixed. The docs-only PR preserves the historical evidence date, adds portable QA results, and imports no runtime experiments. Current-head CI and merge/post-merge gates remain. Self-review receipt: https://github.com/elsa-workflows/elsa-foundation/pull/3055#issuecomment-6272702404.

## #2892 6273225537 elsa-workflows-codex[bot] 2026-10-19T17:31:31Z
#2911 / PR3055 remains the sole active implementation leaf. Final head `8bdd6ed5315639deefac4fcd99b826e57489cbc1` completes the full HTML brief, with all 17 offline/reduced-motion browser groups passing and [clean self-review round 4](https://github.com/elsa-workflows/elsa-foundation/pull/3055#issuecomment-6273222258). Current-head CI/Maps and integration are pending. BPMN PRs #52/#55/#56/#58/#60 remain in their existing review/dependency queue with GitHub-required independent approval outstanding; no competing implementation or broader program completion claimed.

## #2892 6273524702 elsa-workflows-codex[bot] 2026-10-19T17:46:27Z
Planned successor #3056 is now a native child of #2905, with concrete native consumer, real-process acceptance and independent scope review. It remains unclaimed/status:todo; #2911 / PR3055 is still the sole active implementation. No readiness or completion claim for Orleans, direct BPMN hosting or the later production presentation.

<!-- native-conformance-planned-3056 -->

## #2892 6273866341 elsa-workflows-codex[bot] 2026-10-19T18:04:54Z
PR3055 merged as `553f35e37ebd5073079ecbfff94f1bed4ff26e04` after green exact-head gates and clean self-review. https://github.com/elsa-workflows/elsa-foundation/pull/3055#issuecomment-6273863023

#2911 remains the active verification leaf pending exact-merge CI/maps, Studio and CodeQL. #3056 is planned and unclaimed; #2910/#2909 retain production-presentation acceptance. Program remains in progress.

<!-- pr3055-merged-awaiting-verification -->

## #2892 6274140088 elsa-workflows-codex[bot] 2026-10-19T18:18:43Z
BPMN #7 decision resolved by Sipke on 19 October: preserve default import behavior, add explicit host-availability validation when requested, diagnose known unavailable work, and support standards-compliant call-activity escalation plus host-provided compensation. [Canonical decision and acceptance direction](https://github.com/valence-works/bpmn/issues/7#issuecomment-6274133018). The issue body and decision label are reconciled; it remains queued/unclaimed. #2911 post-merge verification and the next planned native-hosting leaf #3056 retain their current queue positions. No other PR's approval requirement or ownership changed.

## #2892 6274547361 elsa-workflows-codex[bot] 2026-10-19T18:39:58Z
#2911 is complete: [PR #3055 final exact-merge evidence](https://github.com/elsa-workflows/elsa-foundation/pull/3055#issuecomment-6274517972) records green CI/architecture/core/maps, Studio and CodeQL on `553f35e37ebd5073079ecbfff94f1bed4ff26e04`, the reviewed artifact hash and 17 browser groups. Skipped tests/jobs remain explicit. Its claim is released; #2910/#2909 remain open for production journeys. The control table is reconciled. Next is fresh claim/source discovery for #3056; BPMN #7 is decision-resolved and queued, while the protected review lane remains unchanged. Program #2892 remains in progress.

## #2892 6274670004 elsa-workflows-codex[bot] 2026-10-19T18:46:14Z
#3056 implementation started after #2911 completed exact-merge verification. [Claim and scope](https://github.com/elsa-workflows/elsa-foundation/issues/3056#issuecomment-6274588922). Branch `agent/codex/3056-native-hosting-conformance` starts from verified main `553f35e37ebd5073079ecbfff94f1bed4ff26e04` in the reused clean attached worktree. No competing claim or matching PR was found. Specification number249 is reserved after checking current/archive paths and every open PR (highest248); its concise acceptance specification is under independent review before the implementation plan. Native built-in hosting is the single active leaf; Orleans, BPMN adoption and other model work remain separate successors.

## #2892 6276421081 sfmskywalker 2026-10-19T20:18:19Z
FYI from the native compensation program (#3035): no dependency is declared in either direction. Compensation reuses runtime contracts that predate this program: `ActivityExecutionId`/`ActivityAttempt`/`ActivityInputSnapshot`, `SideEffectProfile.External`'s pre-body claim, structural private state and fault absorption. It adds no scheduler, ledger or lease.

One ownership point: #3035 owns the **logical operation key** given to external participants, which stays stable across boundary retries. If this program's proposed "effect idempotency reference" (`architecture-recommendation.md`) gets implemented, please consume that key rather than defining a second one. Recorded in #3078 (`docs/program-goals/native-compensation.md`).

---
_Generated by [Claude Code](https://claude.ai/code)_

## #2892 6276735388 elsa-workflows-codex[bot] 2026-10-19T20:34:59Z
Program control surface restored: [Project #62](https://github.com/orgs/elsa-workflows/projects/62) now contains the 26 native hierarchy issues and PR #3077, with Status, Phase, Area, Priority, Agent State and Verification independently read back. Six views are available. Closed research tasks #2900/#2904/#2913 had stale todo/blocked labels reconciled to their existing bounded closure; no parent acceptance was added. Coordinating issues are not worker-ready. #3056 remains the only active implementation leaf.

The board is currently private because GitHub rejected the App's visibility update; normal board administration works with the refreshed installation permissions. The issue body now records this accurately instead of the old creation denial. [Current implementation and merge checkpoint](https://github.com/elsa-workflows/elsa-foundation/issues/3056#issuecomment-6276733315): profile recovery 7/7; PR #3077 merged, main verification pending. The wider program remains in progress.

## #2892 6279240972 elsa-workflows-codex[bot] 2026-10-19T23:01:38Z
Next hosting slice prepared — inactive until #3056 is verified

The following draft incorporates root and independent source review. It records the already-authorized successor without opening or claiming another implementation leaf. #3056 remains the sole active leaf while PR #3087 completes its gates. Orleans membership/API feasibility remains an investigation requirement; no adapter qualification or settled implementation design is claimed.

<details>
<summary>Reviewed draft objective, constraints and acceptance</summary>

# Task: Add an optional native Orleans adapter and qualify it against the shared suite

**Draft only.** Do not activate or claim until #3056 is merged and post-merge verification is complete. The latest queue record keeps #3056 as the sole active leaf; PR #3087 hosted exact-head checks and resulting-main verification were still pending ([status](https://github.com/elsa-workflows/elsa-foundation/issues/3056#issuecomment-6279000285)). Refresh the shared queue, main-red issues, claims and matching PRs before activation.

**Parent:** [#2905](https://github.com/elsa-workflows/elsa-foundation/issues/2905), under [program #2892](https://github.com/elsa-workflows/elsa-foundation/issues/2892). Cross-link [#2899](https://github.com/elsa-workflows/elsa-foundation/issues/2899) and the bounded research in [#2900](https://github.com/elsa-workflows/elsa-foundation/issues/2900). The owner-authorized scope is recorded in [#2892 comment 6249319967](https://github.com/elsa-workflows/elsa-foundation/issues/2892#issuecomment-6249319967); #2900 is research, not production acceptance. #3056 supplies the shared native fixture after verified delivery. BPMN remains owned by [#2735](https://github.com/elsa-workflows/elsa-foundation/issues/2735).

- [ADR 0078](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/docs/adr/0078-workflow-executions-are-virtual-actors-and-cluster-membership-is-a-foundation-contract.md#L102-L135) requires one membership authority, commit-time fencing independent of routing, capability queries through membership, and a durable queue as the record of owed work.
- [IClusterMembership](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/src/Cluster/Core/Contracts/IClusterMembership.cs#L18-L58) requires one provider, a complete authoritative `Fresh` read or an exception, and report publication visible to every later fresh read. Establish whether the currently supported Orleans membership APIs can also provide capability reports, incarnation/lapse, draining and those read-visibility semantics. Do not assume cached/gossip membership is equivalent, or compose EF membership beside Orleans.
- [Execution envelopes and activation/passivation requests](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/src/Workflows/Runtime/Core/Models/WorkflowExecutionActorModels.cs#L23-L66) carry `WorkflowExecutionPartition`; activation/passivation do too ([activation](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/src/Workflows/Runtime/Core/Models/WorkflowExecutionActorModels.cs#L141-L171), [passivation](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/src/Workflows/Runtime/Core/Models/WorkflowExecutionActorModels.cs#L212-L238)). Preserve `(partition, workflow execution ID)` in actor addressing.
- [The actor-provider contract](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/src/Workflows/Runtime/Core/Contracts/IWorkflowExecutionActorProvider.cs#L6-L24) owns the serialized mailbox but leaves commit fencing downstream. The scheduler queue requires idempotent admission by `(WorkflowExecutionId, WorkItemId)` ([IWorkflowSchedulerWorkQueue](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/src/Workflows/Runtime/Core/Contracts/IWorkflowSchedulerWorkQueue.cs#L23-L35)). The current distributed composition exposes [IExecutionCommandTransport](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/src/Workflows/Runtime/Distributed/Elsa.Workflows.Runtime.Distributed/Contracts/IExecutionCommandTransport.cs#L12-L29) as a durable cross-node inbox replacement contract; the EF implementation uses its frozen [v1 transport wire](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/src/Workflows/Runtime/Elsa.Workflows.Runtime/EXTENSION_POINTS.md#L573-L577). ADR 0078 and the actor-provider contract do not themselves require Orleans to reproduce this transport's exact lease/ack trace, but no current source authorizes removing or redefining the production transport contract. Before implementation, trace which existing durable record(s) carry each accepted command and how they are rediscovered/replayed; determine whether Orleans dispatch must use IExecutionCommandTransport or may add a transient direct route only after admission to those same durable records. Preserve the existing interface and frozen wire unless separately reviewed. Do not add another durable authority. Also resolve the generic actor mapping, supported Orleans/package/target-framework combination, membership source, host/client startup-shutdown/disposal, and transient reactivation behavior from supported APIs. The Orleans 10.4.0 process probe in #2900 is not an adopted version or production guarantee.
- The membership-provider classifier contains an example for `Extensions/Orleans/src/Cluster/Elsa.Cluster.Orleans.csproj` ([classifier](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/tests/Architecture/Tests/ArchitectureGuardTests.ClusterMembership.cs#L155-L159)); this is not a canonical project-path approval. The general path guard has no Orleans extension mapping ([path rules](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/tests/Architecture/Tests/ArchitectureGuardTests.cs#L550-L639)), and no implementation exists at that example path. Choose module names and extension layout together, then add narrow path/classifier mappings for actual membership and runtime adapter projects and tests. Preserve the refusal for unregistered roots and existing built-in/EF project locations.

Record the design mapping before implementation. If the membership or lifecycle requirements cannot be met without a second authority or a contract change, stop for an independently reviewed ADR decision first.

## Acceptance

1. Add an opt-in Orleans extension; absent its registration, built-in hosting remains selected. DI tests prove exactly one active membership and actor provider; duplicate/conflicting registration fails startup clearly. Prove owned Orleans and runtime resources are disposed on normal shutdown and startup failure. Register the chosen optional-extension project paths explicitly in the architecture guards and generated solution/filter graph; neither a classifier-only hint nor a blanket path exemption is sufficient.
2. Reuse #3056's shared native scenario helpers ([fixture](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/tests/Workbench/Tests/NativeHostingFixture.cs), [conformance tests](https://github.com/elsa-workflows/elsa-foundation/blob/b4d576e624ee8854822171dd3662ae02b4145727/Essentials/tests/Workbench/Tests/NativeHostingConformanceTests.cs)). Run profile-neutral behavior through both providers: unchanged published Sequence → Flowchart → held parallel background bodies → one native continuation, both receipt orders, stable invocation/attempt identities, cancellation and recovery. Keep provider-specific observations appropriately scoped.
3. With owned real processes and recorded distinct PIDs/host IDs, demonstrate owner loss/restart, recovery of accepted work after its transient route is lost, and exactly one logical continuation. Prove the command is idempotently durably admitted before routing and remains discoverable/replayable from the existing scheduler/outbox/transport record(s) that own the owed work. Retain/correlate receipts, membership/placement, and provider-specific routing, admission and acceptance evidence; do not require the built-in send/lease/ack trace shape where the reviewed design uses another transient route over those same durable records.
4. Prove equal execution IDs in different partitions do not collide. Exercise concurrent activations and send the original unchanged stale commit to EF under a live higher successor fence: require exact stale-token rejection, unchanged protected state and survivor recovery. Reuse the targeted EF-fence-removal negative control and retain its adverse result plus restored passing run.
5. Run existing provider/membership conformance at its owning layers: complete fresh reads and report visibility, capability filtering, incarnation/lapse/draining, duplicate registration and lost-route redelivery. Show that EF still owns commit fencing/checkpoints and that accepted owed work remains in the existing durable authority; Orleans storage/streams/mailboxes do not become its record of work. Retain the current IExecutionCommandTransport contract and frozen wire unless a separate reviewed change approves otherwise.
6. Preserve reproducible source, package/binary, run, receipt and process identities; commands, results, skips and limitations. Run applicable package/locked-restore/test, architecture, map and diff gates, exact-head review and post-merge CI/maps verification. Report skips as skips.

**Sizing note for the program lead, not acceptance:** Keep this as one integration issue only if the design gate confirms supported Orleans membership and execution composition meet existing contracts. If proving those semantics requires a new contract/ADR, split that design resolution into a prerequisite issue and make adapter implementation plus same-suite qualification its dependent successor. Do not create or claim either before #3056 post-merge verification and a fresh queue review.

<!-- orleans-successor-preparation-after-3056 -->

## #2892 6279709123 elsa-workflows-codex[bot] 2026-10-19T23:35:16Z
Read-only Orleans successor preparation — source gate, not implementation acceptance

#3056 / PR #3087 remains the sole active implementation leaf. This records bounded research while its hosted tests run; it does not create or claim a successor, select a package version, amend ADR 0078, or qualify Orleans. The earlier [prepared successor](https://github.com/elsa-workflows/elsa-foundation/issues/2892#issuecomment-6279240972) remains a draft.

* **Fresh reads need an explicit barrier.** `ClusterMembershipService.Refresh(default)` calls the membership manager without `requireFresh: true`. The manager's default path can share an already-running `pendingRefresh`, so a read started before publication may satisfy the public refresh. The internal fresh branch initiates a separate read, but that flag is not exposed by the public cluster-membership refresh. Do not equate a refreshed local snapshot with Elsa's required post-publication authoritative read. [Pinned service](https://github.com/dotnet/orleans/blob/d114d7522a53b8cce4c6b97d44293e5c7273d766/src/Orleans.Runtime/MembershipService/ClusterMembershipService.cs), [pinned manager](https://github.com/dotnet/orleans/blob/d114d7522a53b8cce4c6b97d44293e5c7273d766/src/Orleans.Runtime/MembershipService/MembershipTableManager.cs).
* **Table versions are not heartbeat/report revisions.** `IMembershipTable.ReadAllAsync` supplies an atomic complete member/table-version snapshot. Membership insert/update changes that version; heartbeat-only `UpdateIAmAliveAsync` preserves it. Standard membership entries have no Elsa report payload. A report barrier therefore cannot rely on heartbeat updates or an unchanged membership version. [Pinned table contract](https://github.com/dotnet/orleans/blob/d114d7522a53b8cce4c6b97d44293e5c7273d766/src/Orleans.Core/SystemTargetInterfaces/IMembershipTable.cs).
* **Cached silo metadata is insufficient for dynamic reports.** Orleans metadata is immutable per silo incarnation and read through a local background-updated cache. Elsa recomputes report sources on publication and requires every later Fresh read to observe the published report. Do not silently freeze those reports to fit metadata caching. [Official silo metadata](https://learn.microsoft.com/en-us/dotnet/orleans/host/configuration-guide/silo-metadata), [Elsa contract at reviewed source](https://github.com/elsa-workflows/elsa-foundation/blob/b656e3a8ed8bc59d02291da4af3912fd16b7139b/Essentials/src/Cluster/Core/Contracts/IClusterMembership.cs).

Design proposal to evaluate, not an accepted mechanism: a custom membership-table/storage integration could couple versioned reports to the same authoritative store and a coherent combined snapshot. A companion report representation is not automatically a second membership authority; an independently decisive registry or uncoordinated join would not establish the existing contract. Specify atomicity, visibility, read/write failure, incarnation cleanup and provider maintenance costs, rather than assuming a turnkey Orleans facility. Preserve [ADR 0078](https://github.com/elsa-workflows/elsa-foundation/blob/b656e3a8ed8bc59d02291da4af3912fd16b7139b/docs/adr/0078-workflow-executions-are-virtual-actors-and-cluster-membership-is-a-foundation-contract.md).

The successor design gate must test: hold an old membership read open; commit a new report; start a Fresh read on another member; ensure it cannot return the old report. Also test failed writes, failed/partial reads, report-only updates with unchanged heartbeat/table-version assumptions, and conservative Dead/suspect/local-lapse mapping. An atomic membership snapshot does not prove a process declared Dead has stopped executing.

Root's current native-contract check adds two compatibility constraints: preserve `(partition, execution ID)` with collision-safe grain addressing, and do not serialize `WorkflowExecutionCommandDispatchOptions.AmbientServices` across a route. The current forwarding actor drops request-affine options and returns `Deferred` after durable transport admission; the Orleans mapping must preserve dispatch outcomes and durable owed-work authority, rather than equating a grain RPC acknowledgement with workflow success. [Actor models](https://github.com/elsa-workflows/elsa-foundation/blob/b656e3a8ed8bc59d02291da4af3912fd16b7139b/Essentials/src/Workflows/Runtime/Core/Models/WorkflowExecutionActorModels.cs), [forwarding behavior](https://github.com/elsa-workflows/elsa-foundation/blob/b656e3a8ed8bc59d02291da4af3912fd16b7139b/Essentials/src/Workflows/Runtime/Distributed/Elsa.Workflows.Runtime.Distributed/Services/ForwardingWorkflowExecutionActor.cs).

<!-- orleans-source-preparation-v1040-fresh-report-gate -->

## #2892 6279806195 elsa-workflows-codex[bot] 2026-10-19T23:42:38Z
Read-only ETL source/readiness audit is retained on its owning feature: https://github.com/elsa-workflows/elsa-foundation/issues/2908#issuecomment-6279805321. Root corrected two audit ambiguities: #2904 is already closed/done, and existing Pipelines.Core is middleware composition rather than ETL. The approved connector/two-SQL-engine/continuous/Studio scope stays intact; no leaf, claim, package or public API was activated. #3056 remains the sole active implementation leaf.

<!-- etl-readiness-pointer-b656e3a8 -->

## #2892 6280950183 elsa-workflows-codex[bot] 2026-10-20T01:10:04Z
Delivery checkpoint: inspection prerequisite #3090 / PR #3091 merged as `8df68f10e` after clean self-review and green exact-head PR gates; resulting-main CI/Studio/CodeQL is running, not yet credited. The sole implementation leaf is again #3056 / existing PR #3087: normal main integration and fail-fast request diagnostics are committed locally as `86fcc34a3` / `1b48aebd1`, with focused adverse/restored proof and the full affected Workbench project running. Preparing the diagnostic while prerequisite main verification runs saves idle time without weakening the parent acceptance/merge gate. Its last review round and fresh hosted/post-merge proof remain open. No Orleans/ETL leaf or broader program milestone is marked complete.

<!-- program-native-diagnostics-active-1b48 -->

## #2892 6281106671 elsa-workflows-codex[bot] 2026-10-20T01:22:42Z
Inactive Orleans successor readiness audit (no implementation/claim): checked current Foundation contracts at local native integration head `1b48aebd1` against the pinned upstream source research. The existing Fresh membership/report visibility question remains unresolved; public Orleans refresh is not the independent authoritative-read barrier. The adapter also needs explicit collision-safe partition/execution addressing and a provider composition seam for the shared fixture, whose current Clustered profile intentionally means EF membership/placement/transport.

One concrete acceptance assumption is now explicit: membership has a strict provider-selection guard, while actor hosting currently uses TryAdd for the built-in default and Replace for distributed composition. The future optional adapter must deliver/review clear conflicting-provider selection and both registration orders; this requirement is retained, not assumed already satisfied or waived. Commit fencing and the durable owed-work authority remain independent of routing.

<!-- orleans-readiness-1b48-inactive -->

## #2892 6281432644 elsa-workflows-codex[bot] 2026-10-20T01:49:15Z
Native-hosting checkpoint: [PR #3087 round 7 is clean](https://github.com/elsa-workflows/elsa-foundation/pull/3087#issuecomment-6281409028) on pushed `f24cda73ea98345cd2686f8d3810b41b3fef6cf1`. The round-6 naming finding is corrected and separately revalidated; the explicit one-round owner exception preserves the full review history. Full local Workbench 55/0/0 and naming-specific fixture44/0/0, actual stale1/0/0, architecture578/0/0 and map/diff proof retain their actual source pins. [CI39355273123](https://github.com/elsa-workflows/elsa-foundation/actions/runs/39355273123) and [Studio39355273160](https://github.com/elsa-workflows/elsa-foundation/actions/runs/39355273160) are running; old-head results are not credited to this head.

Prerequisite #3090 / PR #3091 is verified on exact merge `8df68f10e`, closed and board Done/Complete/Passed with claim released. #3056 and PR #3087 are Review/Review Required/Running and remain the sole delivery leaf; aggregate hosted/post-merge acceptance is open. Original timeout/HTTP400 cause limits and CodeQL restore caveat remain recorded. Orleans and the rest of the program remain open, not activated by this checkpoint.

<!-- program-native-round7-f24-ci-running -->

## #2892 6281576654 elsa-workflows-codex[bot] 2026-10-20T02:00:27Z
Inactive Orleans successor: public-API and contract clarification

Read-only follow-up narrows the earlier Fresh-read uncertainty. Direct public `IMembershipTable.ReadAllAsync` is a credible candidate for fresh membership reads through the same selected clustering provider: Orleans exposes shared silo DI, providers register the table there, and the contract promises a complete atomic membership/table-version read. `ClusterMembershipService.Refresh` coalescing does not rule that route out. [Pinned public table contract](https://github.com/dotnet/orleans/blob/d114d7522a53b8cce4c6b97d44293e5c7273d766/src/Orleans.Core/SystemTargetInterfaces/IMembershipTable.cs#L117-L138), [provider registration](https://github.com/dotnet/orleans/blob/d114d7522a53b8cce4c6b97d44293e5c7273d766/src/AdoNet/Orleans.Clustering.AdoNet/AdoNetHostingExtensions.cs#L31-L45).

Dynamic report publication remains unresolved by those APIs. The inspected table has no report-write facet; heartbeat and startup-configured cached silo metadata are insufficient. A provider-owned report facet can be investigated, preserving one membership authority, post-publication revision visibility on later Fresh reads, complete-fleet-or-failure behavior, incarnation safety and the existing conservative capability-query rules.

Root and an independent contract audit also removed an unnecessary design constraint from the local successor draft: Foundation requires one semantic FleetView and the visibility guarantees above, **not a prescribed global membership-plus-report storage transaction**. A transaction or revision barrier is a candidate backend mechanism, not additional ratified acceptance. [Current Foundation contract](https://github.com/elsa-workflows/elsa-foundation/blob/f24cda73ea98345cd2686f8d3810b41b3fef6cf1/Essentials/src/Cluster/Core/Contracts/IClusterMembership.cs#L18-L58), [report revisions](https://github.com/elsa-workflows/elsa-foundation/blob/f24cda73ea98345cd2686f8d3810b41b3fef6cf1/Essentials/src/Cluster/Core/Models/PublishedMemberReport.cs#L3-L7).

The research pin is not a package/TFM/topology choice. All four successor design gates remain: membership/report semantics, collision-safe partition/execution identity, a shared-fixture provider composition seam, and explicit conflicting actor-provider selection. No successor leaf, claim or implementation is activated. #3056 / PR #3087 remains the sole implementation leaf; current-head Studio and maps passed, backend CI is running, and merge/post-merge verification remains open.

<!-- orleans-public-table-contract-clarification-f24 -->

## #2892 6281936080 elsa-workflows-codex[bot] 2026-10-20T02:29:51Z
Program coverage reconciliation completed without opening a second implementation leaf:

- #2903 now closes only the reviewed M2 decision packet/order already completed by #2904. Its acceptance, parent #2902 child checkbox, labels and Project Status/Verification are reconciled. Production API stability and engine qualification remain open under #2905/#2907.
- #2735's stale November parking wording/label is corrected against the actual #2763 / ADR 0080 reactivation. Its owner remains sfmskywalker; released-library/parity prerequisites and queued adoption remain intact. #2907 now explicitly records the approved operational foundation and deferrals.
- #2908 now carries the approved file/HTTP/both-SQL/RabbitMQ matrix plus partition/transform/budget/replay/Studio obligations. All production criteria remain unchecked and not ready.
- #2912 records the approved production-agent carry-forward separately from completed M1 #2913. Research parentage is unchanged; later production units remain queued.

Fresh App GraphQL read-back confirms 31 unarchived Project #62 items, including #3056, #2907, #2908 and #2912, with their current fields. No hierarchy issue, task claim, provider/package choice or new implementation was created. Native #3056 / PR #3087 remains sole active delivery; its backend job just passed while architecture/core checks are still running. Full program, Orleans/fourth-model, BPMN production, ETL, agents and production-presentation acceptance remain incomplete.

<!-- program-coverage-reconciliation-20261020 -->

## #2892 6282023836 elsa-workflows-codex[bot] 2026-10-20T02:36:37Z
Native hosting qualification merged: PR #3087 / `7d4d2183171e7ee1bfcb18132d05a88133f7d8d1`, with reviewed head, full hosted gate and standing-authorization audit recorded. Resulting-main verification is now live; #3056 remains open/In Progress with its exact claim. PR3087 is Done/Running to distinguish landed code from its pending verification. No successor starts until this gate completes.

Merged normally as `7d4d2183171e7ee1bfcb18132d05a88133f7d8d1` by elsa-workflows-codex[bot] after clean exact-head round 7 and green backend/core/architecture/Studio/maps. [Hosted evidence](https://github.com/elsa-workflows/elsa-foundation/pull/3087#issuecomment-6281992669); [standing-authorization audit](https://github.com/elsa-workflows/elsa-foundation/pull/3087#issuecomment-6281993782) retains all seven rounds and the explicitly recorded one-round exception. Merge parents are base8df + reviewed f24, and the merge tree equals tested synthetic merge f2f exactly. No admin/force/branch-protection bypass or CLA agreement was used.

Resulting-main CI [39359646875](https://github.com/elsa-workflows/elsa-foundation/actions/runs/39359646875), Studio [39359646767](https://github.com/elsa-workflows/elsa-foundation/actions/runs/39359646767) and CodeQL [39359646764](https://github.com/elsa-workflows/elsa-foundation/actions/runs/39359646764) have started on this merge SHA; they are running, not credited as passed. Generated maps will be checked in that CI. Existing automated package workflows may run under repository configuration; no manual release or deployment was performed.

#3056 remains the sole owned delivery/verification leaf. Its aggregate post-merge acceptance and exact claim remain open; Orleans and the rest of the program are not activated or complete. Original historical HTTP400/receipt/timeout causes remain unproven, and physical external effects remain at least once.

<!-- program-native-merged-postmerge-running-7d4 -->

## #2892 6283261596 elsa-workflows-codex[bot] 2026-10-20T04:17:16Z
Native built-in qualification #3056 is completed and its exact claim is released: [completion/release](https://github.com/elsa-workflows/elsa-foundation/issues/3056#issuecomment-6283259687). The original implementation qualification remains on7d4; docs closeout #3096 merged as `33c33214f16ca8c157d2af99ab31faecb90cb9a9` after green exact-head checks. [Merge receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3096#issuecomment-6283256492). Current issue bodies and Project62 are synchronized; this parent remains open/InProgress/Coordination/Partial. No successor is active yet. Ordinary documentation-merge CI is monitored separately; no Orleans, full cross-model or whole-program completion is claimed.

<!-- 2892-native-3056-closed-33c33214 -->

## #2892 6283878077 elsa-workflows-codex[bot] 2026-10-20T05:09:56Z
Documentation closeout PR #3096 now has completed exact-main source verification on `33c33214f16ca8c157d2af99ab31faecb90cb9a9`: [final receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3096#issuecomment-6283874096). CI/maps, dedicated architecture/core, Studio and CodeQL passed; skipped EF/package work is not credited. The automatic ARM64 host image-signing authorization failure is retained separately. Native proof #3056 stays done/released; the program stays open with #3098/#3099 active.

<!-- 3096-final-source-verification-note-2892 -->

## #2892 6284250239 elsa-workflows-codex[bot] 2026-10-20T05:40:06Z
Implementation lane advanced to claimed #3101 after PR #3099 shipped `4179513b804f6c80ff6246396b4a69f7316d4ae7` and #3098 released its implementation claim. [Merge/pending-main receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3099#issuecomment-6284239620), [new claim](https://github.com/elsa-workflows/elsa-foundation/issues/3101#issuecomment-6284246104). Main source verification remains separately Running and must be completed; another integration is not allowed over a failing main. No acceptance was weakened or production Orleans/fourth-model qualification claimed. This preserves one active implementation and one integration lane while external verification proceeds.

<!-- 3101-implementation-lane-start-417 -->

## #2892 6287465125 elsa-workflows-codex[bot] 2026-10-20T09:06:13Z
Closed the separate #3098/PR #3099 verification lane after [exact-merge source gates](https://github.com/elsa-workflows/elsa-foundation/pull/3099#issuecomment-6287456349) passed on `4179513b804f6c80ff6246396b4a69f7316d4ae7`. The active implementation remains claimed #3101; production Orleans, the fourth model, ETL, agent journeys and final production presentation remain outstanding. The full program remains open.

<!-- 3099-program-final-source-checkpoint -->

## #2892 6287993256 elsa-workflows-codex[bot] 2026-10-20T09:36:36Z
Owner direction on 20 October 2026 changes the immediate critical path: “We don’t need a complete implementation of Orleans.” Stop optional Orleans implementation/research for now and resume other program branches. Proto.Actor is a possible future alternative, not an automatic replacement investigation or a qualified provider.

Disposition: defer #3101 and full Orleans production adapter/conformance work. Preserve completed #3098/PR #3099 report evidence and unfinished #3101 checkpoint; do not mark a guard or production provider complete. The already-qualified native built-in provider remains the foundation for independently deliverable product work. This removes optional Orleans qualification as a scheduling prerequisite for the next ETL/agent/native slice; it does not waive correctness, lifecycle, BPMN adoption, model-extension or final product-acceptance gates.

The lead is refreshing the ETL, fourth-model and BPMN queues against current dependencies/claims, then will select one coherent vertical deliverable. Keep one active implementation leaf; do not begin a new actor-framework spike. Revisit actor-provider selection only when a concrete product journey requires it and the owner prioritizes that work. Parent scope/acceptance will retain this explicit deferral rather than reporting a passed provider gate.

<!-- 20261020-owner-defers-optional-orleans -->

## #2892 6288126054 elsa-workflows-codex[bot] 2026-10-20T09:44:28Z
Selected claimed child #3109 under #2908 after source/dependency/claim refresh: finite CSV-to-JSONL pipeline with two bounded independently leased partitions, native invocation and Studio authoring/inspection. [Claim](https://github.com/elsa-workflows/elsa-foundation/issues/3109#issuecomment-6288097403). #2904/#3056 dependencies are complete. BPMN PR52/55/56/58/60 still lack independent approval, so they remain a separate external gate rather than accumulating another active implementation. Fourth-model and agent production remain in the program. Reassess sequencing after the first ETL journey or a material BPMN gate change.

<!-- 20261020-finite-etl-selected -->

## #2892 6288680634 elsa-workflows-codex[bot] 2026-10-20T10:17:44Z
ETL selection checkpoint: #3109 has draft PR #3111 at `d16942aa7`, a source-grounded plan and 19 passing existing-runtime bookmark regressions. The only pending owner decision is ADR0087 adding optional Elsa.Etl to the pinned domain list; the question is in this chat. New ETL production code is not started, the implementation claim is released and issue/project are waiting for decision. Continue the existing branch once decided; no competing leaf, Orleans work or automatic Proto.Actor investigation has been selected. Parent acceptance remains open.

<!-- 2892-etl3111-domain-decision -->

## #2892 6299076556 elsa-workflows-codex[bot] 2026-10-20T19:12:05Z
Owner intent recorded on 20 October 2026: discuss and design a durable, horizontally scalable task runner after delivery of the current unified execution program. This is a follow-up component, not an added acceptance criterion or active leaf for #2892.

Preserve a boundary between durable work acceptance and dispatch eligibility. The desired workflow pause behavior is to retain newly received work while withholding new starts for that workflow. Distinguish queue-wide pause from workflow-associated dispatch pause on a shared queue; define explicit behavior for already running work, cancellation, retries, leases, resume and recovery. Pause must not imply that in-flight external effects were undone or that workers have stopped.

An open design question is whether a narrow semantic adapter contract can support existing background worker frameworks as well as an out-of-the-box implementation. Evaluate capability differences before stabilizing that contract; do not create a universal queue abstraction prematurely or select a provider now. Reuse proven durable work identity, trusted scope, immutable invocation/result addresses and at-least-once effect constraints where the concrete integration fits. Keep actor placement and task execution as separate responsibilities. Current finite ETL work does not claim workflow/queue pause support.

<!-- owner-task-runner-followup-20261020 -->

## #2892 6303776675 elsa-workflows-codex[bot] 2026-10-20T23:06:03Z
Read-only queue refresh while #3109 remains the sole active implementation leaf: BPMN PR #60 now has a [changes-requested review](https://github.com/valence-works/bpmn/pull/60#pullrequestreview-5590875382) and conflicts with merged #48. Its prior green checks do not establish integration readiness. The control table now records the integration, legacy ID-less callback and retired-handle documentation findings. No library edits, claim takeover, repeat merge attempt or review request was made. PR #56 remains protected REVIEW_REQUIRED with green checks. Resolve this review lane after finishing the current ETL gate; the broader program remains incomplete.

<!-- bpmn-queue-refresh-20261021-review60 -->

## #2892 6305268116 elsa-workflows-codex[bot] 2026-10-21T00:54:16Z
Control-surface reconciliation while the final ETL head is testing: the scope summary and hosting journey now reflect Sipke's already-recorded 20 October Orleans deferral, rather than contradicting it with an unconditional qualification requirement. Provider evidence remains deferred, not passed; no replacement provider or scope reduction beyond that owner decision is introduced. The prepared BPMN PR60 repair still follows ETL #3109. Root source inspection confirms global legacy snapshot validation can reject an unrelated callback; existing retired-handle documentation should be preserved during integration rather than rewritten as missing. No new implementation leaf or claim has started.

<!-- program-scope-reconciled-20261021-etl-ci -->

## #2892 6305915796 elsa-workflows-codex[bot] 2026-10-21T01:42:16Z
Delivery sequencing checkpoint: ETL #3109 is merged and retained in its exact-merge verification lane; Studio/maps passed, backend CI and C# CodeQL remain running. Rather than serialize independent work on that external wait, BPMN #59 / PR60 is now the sole active implementation under [claim6305908525](https://github.com/valence-works/bpmn/issues/59#issuecomment-6305908525), with [bounded repair scope](https://github.com/valence-works/bpmn/issues/59#issuecomment-6305908894). ETL final acceptance stays open until its gate passes; one integration/merge lane is retained. No test, review or post-merge requirement is relaxed. Reassess at ETL gate completion or a BPMN candidate ready for review.

<!-- program-2892-independent-repair-during-etl-verification -->

## #2892 6306279395 elsa-workflows-codex[bot] 2026-10-21T02:11:04Z
BPMN PR60 repair is pushed at8a62671: clean round5, exact-head CI737/737 plus samples/guard, and753-pass separate PR56/58 compatibility evidence. GitHub still blocks it on the earlier owner changes-requested review, which has been directly answered and referred back for review-state resolution. Its implementation claim is released; no protection bypass.

The single implementation lane moves to existing BPMN #34/PR52 normal main integration under claim6306265899. ETL #3109 remains a separate verification lane: descendant b555 Studio and maps are green, backend/CodeQL still running; original exact-merge cancellations remain recorded. No broader program completion is claimed.

<!-- program-bpmn52-active-after60-8a62671 -->

## #2892 6306422081 elsa-workflows-codex[bot] 2026-10-21T02:22:30Z
BPMN PR52 is repaired, integrated and green at1aabe86: 662 CI tests, samples/guard, clean round3 and ten-case negative control. A normal merge under existing owner authority was attempted and rejected by GitHub branch policy; no bypass. Its claim is released. PR60 also remains green after repair, waiting for the earlier owner changes-requested review to be updated. Both gates and current heads are now reflected in the control table and board.

ETL descendant b555 Studio, maps and CodeQL passed; backend CI is still running. Original exact-merge cancellations remain incomplete evidence. The next independent implementation should advance a remaining product obligation, not repeatedly rebase these protected-review items. No task-runner or actor-provider work is activated.

<!-- program-bpmn52-green-protected-gate-1aabe86 -->

## #2892 6306601087 elsa-workflows-codex[bot] 2026-10-21T02:36:40Z
#3151 is now the sole active implementation leaf under #2908. Root and two bounded read-only reviewers verified the current file-specific seams and public Connections contracts. HTTP gets explicit durable page/item positions and remote effect receipts, while v1 file runs remain supported. Source/pagination/auth/retry/acknowledgement choices are recorded on the issue; specification/plan/tasks precede code. ETL predecessor CI39529263265 remains running; BPMN52/60 gates are unchanged. No Orleans/Proto/task-runner work.

<!-- 2892-http-start-3151 -->

## #2892 6307907168 elsa-workflows-codex[bot] 2026-10-21T04:16:42Z
#3109 post-merge verification is complete on `da9a4927d98fb29eda017b4e1a74a28ee4316439`; CI, Studio, CodeQL and maps passed, the two #3109 claims were released, and board Verification is Passed for #3109 and PR #3111. See the [PR #3111 receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3111#issuecomment-6307901682). Program #2892 and feature #2908 remain open; #3151 is still the active implementation leaf.

<!-- etl-2892-3109-closeout-da9a4927-20261021 -->

## #2892 6307920602 elsa-workflows-codex[bot] 2026-10-21T04:17:48Z
HTTP ETL #3151 now has its single full-scope [draft PR #3156](https://github.com/elsa-workflows/elsa-foundation/pull/3156). V2 definition persistence and native pin checkpoint `8b88355ae` passed ETL434/affected47/architecture584 plus map/filter checks ([evidence](https://github.com/elsa-workflows/elsa-foundation/pull/3156#issuecomment-6307887828)). The implementation remains In Progress / Verification Pending, with 2/22 tasks complete. Runtime HTTP and mixed routes, durability/recovery, native continuation, APIs/Studio and full old-worker resume remain owed. The predecessor #3109 verification lane is closed; no parent scope was reduced.

<!-- 3151-draft3156-program-checkpoint -->

## #2892 6308189571 elsa-workflows-codex[bot] 2026-10-21T04:39:30Z
Program checkpoint: #3151 remains the only active implementation leaf. T004 is complete at `6fdd9678700bf3b8fc0fecc5ca201815e9e3d36c` in draft #3156; **3/22 tasks** complete. [Evidence](https://github.com/elsa-workflows/elsa-foundation/pull/3156#issuecomment-6308187049) records ETL466/architecture584 and focused54 passing, plus a failing host-ceiling removal and restored source. Typed connector persistence/execution is next; no HTTP execution, completed program or task-runner delivery claim. The existing full scope remains unchanged.

<!-- 2892-runtime-reader-6fdd96787 -->

## #2892 6322086473 elsa-workflows-codex[bot] 2026-10-21T17:18:19Z
Dependency record refreshed while #3156 final-head CI is running: BPMN #60 was owner-merged; [verified merge evidence](https://github.com/valence-works/bpmn/pull/60#issuecomment-6322084553) shows737/737 tests and exact-merge package/wiki jobs passed, with NuGet skipped. Removed the stale “wait for PR60” condition from the prepared-successor row. #38 still needs current-main integration and final #52 mapping; other BPMN PR conflicts/review gates remain explicit. #3151 is still the only active leaf. No second implementation started and no broader acceptance was marked complete.

<!-- program-bpmn60-dependency-reconciled-4f912481 -->

## #2892 6322261454 elsa-workflows-codex[bot] 2026-10-21T17:27:09Z
## Remaining-scope and next-slice readiness checkpoint

Current-source audit at `adbc7417c42055e32437eddaeb2f80c980d4c666` (main401 integrated), while #3151/PR #3156 is the only active implementation leaf. Final-head CI is genuinely running, not a missing worker: CI39641906120 is in its test step; Studio39641905938 is in browser tests. This checkpoint changes no implementation claim, release, permissions or acceptance outcome.

| Obligation | Evidence and remaining boundary |
|---|---|
| Native durable work and built-in hosting | Completed leaves #2914/#2960/#2967/#3056 retain their verified evidence and explicit limits. Do not reopen optional Orleans #3101; owner-deferred, not passed. |
| BPMN shared interpreter and operational foundation | Upstream60 is owner-merged with [737-test exact-merge verification](https://github.com/valence-works/bpmn/pull/60#issuecomment-6322084553). Foundation still has [its internal engine](https://github.com/elsa-workflows/elsa-foundation/blob/adbc7417c42055e32437eddaeb2f80c980d4c666/Essentials/src/Activities/Bpmn/Elsa.Activities.Bpmn/Internal/BpmnExecutionEngine.cs), and [package pins](https://github.com/elsa-workflows/elsa-foundation/blob/adbc7417c42055e32437eddaeb2f80c980d4c666/Directory.Packages.props) are Model/Interchange0.1.1-preview.19. #2735 retains adoption ownership; upstream green tests are not Foundation direct/embedded parity. #38's retained branch diverges from current main and needs integration; final refused-read mapping still depends on52. Existing52/55/58 conflict and56's independent-review gate remain real. |
| ETL | Verified finite CSV-to-JSONL baseline #3109; finite HTTP/native/Studio3151 is at final review/CI. [Current connector source types](https://github.com/elsa-workflows/elsa-foundation/blob/adbc7417c42055e32437eddaeb2f80c980d4c666/Extensions/Etl/src/Core/EtlPipelineV2.cs) are CSV/HTTP and destinations JSONL/HTTP. Continuous runs, PostgreSQL and SQL Server snapshot/watermark/keyed-write proof, RabbitMQ acknowledgement/confirm recovery and BPMN invocation remain #2908 obligations. Do not infer a full file-format matrix or completed parent acceptance from the current slice. |
| Fourth semantic model | #2901 is a packed-package research witness, not production adoption; its cancellation stopped work while the model remained Running. A bounded separate rule-model domain remains required. Absence of a generic registry is **not** itself a defect: [accepted ADR0087](https://github.com/elsa-workflows/elsa-foundation/blob/adbc7417c42055e32437eddaeb2f80c980d4c666/docs/adr/0087-etl-owns-its-execution-domain.md) and [spec242 lifecycle boundaries](https://github.com/elsa-workflows/elsa-foundation/blob/adbc7417c42055e32437eddaeb2f80c980d4c666/specs/242-execution-lifecycle/spec.md) favor model-owned state/outcomes and demonstrated adapters, not a universal DTO/kernel. |
| Agent collaboration | Existing provider/tool infrastructure is reusable, but [paused-turn state](https://github.com/elsa-workflows/elsa-foundation/blob/adbc7417c42055e32437eddaeb2f80c980d4c666/Extensions/Agent/src/Core/Services/AgentTurnServices.cs) and [default registrations](https://github.com/elsa-workflows/elsa-foundation/blob/adbc7417c42055e32437eddaeb2f80c980d4c666/Extensions/Agent/src/Core/Extensions/AgentServiceCollectionExtensions.cs) are in-memory. #2912 still owes typed rounds/resource scopes, durably accepted decisions/approvals/budgets, replay/cancellation and integrated Studio. Deterministic/provider-protocol evidence is required; live-model spending remains opt-in. |
| Presentation and closeout | #2911 delivered historical research HTML; #2910 still owes the production-journey refresh and direct browser validation. Parent closure needs actual integrated acceptance, not issue counts. Task runner/pause stays the agreed post-program follow-up. |

Before marking that successor Agent Ready, review its concrete domain/package contract and acceptance: actual packed package with no host engine-project reference, deterministic fixed-point execution, restart between rounds, exact duplicate/conflicting/stale-result behavior, durable model cancellation and late-result refusal, capability/schema/package pin refusals, same-parent continuation, additive versioning and capable-reader rollback. The owner's existing decisions settle the product direction; this is a bounded implementation-contract review, not a new request for broad architectural permission. No successor is claimed or called ready yet.

The old spec242 status text describes its original checkpoint; the live issue/merge receipts remain authoritative. Reconcile those stale final-status pointers during the next scoped program documentation update, without rewriting historical test results. No new tests were run for this read-only readiness audit.

<!-- program-remaining-readiness-adbc7417 -->

## #2892 6322350077 elsa-workflows-codex[bot] 2026-10-21T17:31:41Z
Created queued successor #3181 under #2905 and verified native parentage plus Project62 fields: Todo / Not Ready / Pending, Area Extension, M3, P1. No implementation claim or ready-for-agent label. #3151/PR3156 keeps the active lane.

Root plus bounded source/draft review corrected three contract ambiguities before creation: rule-state/receipt/owed-delivery atomicity is local to the model store with an independently idempotent native bridge; the package is consumed through normal deployment/NuGet composition rather than a runtime package loader; a new ADR is needed only for a changed cross-domain policy. Concrete rule-specific contract review remains the readiness gate. Completed research29 assertions remain historical, and durable model cancellation is explicitly required.

<!-- queued-rule-model-3181 -->

## #2892 6339831009 elsa-workflows-codex[bot] 2026-10-22T11:39:33Z
## Prepared BPMN successor refresh, 22 October

#3181 / PR #3192 remains the sole active implementation. This is read-only readiness work while its current-head CI and review run; no successor is claimed.

The next prepared integration repair is [BPMN PR #52 / issue #34](https://github.com/valence-works/bpmn/pull/52), head `1aabe86cc16874badeb6bc6977a13c2840fcd5eb`. Fresh Code Review found no implementation defect in the refused-value contract, but requires integration with current main after #60/#72 and renewed full-suite/removal evidence. The integrated refusal must retain the exact host code/message and leave BPMN `ErrorCode` null. Its existing green checks predate that integration. The old claim6306265899 was explicitly released at issuecomment6306406428; `needs:decision` still records the earlier protected-merge hold and must be reconciled through the applicable ownership/review process before delivery. The review identifies no new product decision.

This repair feeds #55's ordering and #38's final refused-read mapping. #56 has a separate current-head compile failure; #58 needs current-main integration. These are existing PRs to adopt rather than duplicate. Foundation #2735 still retains its owner assignment and released-library/parity gate; #2907 production acceptance is open. Do not replace the native BPMN engine or claim direct/embedded adoption until those requirements are demonstrated.

After Rules closes, refresh these heads, comments, claims and holds again before selecting one leaf. Orleans and the separate task-runner follow-up remain deferred.

<!-- bpmn52-merge-preview-20261022 -->

## #2892 6391412537 elsa-workflows-codex[bot] 2026-10-25T00:27:43Z
Production step 4's independent Rules model leaf #3181 is complete: [final acceptance and resulting-main evidence](https://github.com/elsa-workflows/elsa-foundation/pull/3192#issuecomment-6391409647). Claims are released and the control table is reconciled. The full program remains open. The prepared next scope is the existing BPMN #52/#34 integration, subject to a fresh current-state/ownership check; no new implementation claim has been made in this closeout.

<!-- rules-program-step4-complete-20261025 -->

## #2892 6391441382 elsa-workflows-codex[bot] 2026-10-25T00:30:56Z
The next implementation scope is claimed on existing BPMN #34 / PR #52: https://github.com/valence-works/bpmn/issues/34#issuecomment-6391435168. Rules #3181 is delivered and its claims are released. This resumes the reviewed upstream refusal contract, using current main and the original branch; it does not start a second PR or claim Foundation #2735 adoption. Review rounds remain bounded and the Code Review integration finding will be answered directly after a tested fix.

<!-- program-bpmn34-claim-20261025 -->

## #2892 6392302545 elsa-workflows-codex[bot] 2026-10-25T02:10:02Z
During #38 current-main validation, an additional structured-diagnostic gap was reproduced: unsupported intermediate Error catches are refused with their element in the message but no `ElementIds`. Queued a narrow upstream follow-up [BPMN #92](https://github.com/valence-works/bpmn/issues/92), with reproduction, proposed boundary and no readiness/claim. It is tracked on the program board as Todo / Not Ready, outside #38's test-only port. #38 remains the sole active implementation. This does not change the supported semantic rejection or claim Foundation adoption.

<!-- program-bpmn92-queued -->

## #2892 6393861809 elsa-workflows-codex[bot] 2026-10-25T05:21:01Z
[Codex] On behalf of @sfmskywalker.

Completed the stable BPMN library slice [#95](https://github.com/valence-works/bpmn/issues/95): v0.5.0 / payload1.10.0 at source `021d2c5bba494f17d346144d97763cd3b2a13a4b`. [PR99](https://github.com/valence-works/bpmn/pull/99) fixed the necessary serialization-shadowing defect and delivered migration notes and isolated package qualification. Exact-head review/CI, resulting-main and stable-release CI passed. All four public packages and eight public symbols are verified; [permanent receipt](https://github.com/valence-works/bpmn/releases/download/v0.5.0/bpmn-0.5.0-qualification.json). Exact claim is released and board is Done/Complete/Passed.

The [existing #2735 owner has the exact artifact/contract handoff](https://github.com/elsa-workflows/elsa-foundation/issues/2735#issuecomment-6393837314). Foundation still needs selected-release parity and the engine switch, followed by the real #2898 hosting proof and six #2907 production criteria. Broader ETL/agent work remains open; preparatory next-spec exploration creates no second implementation leaf. The program remains in progress.

<!-- bpmn95-program-complete-slice -->

## #2892 6395199556 elsa-workflows-codex[bot] 2026-10-25T08:05:29Z
Documentation correction #3320 / PR3321 is delivered and post-merge verified. [Final evidence](https://github.com/elsa-workflows/elsa-foundation/pull/3321#issuecomment-6395191329) records reviewed/merge/qualified-descendant identities, successful CI/Studio/CodeQL/maps gates, and the original cancellations, automatic retry, pre-existing #3261 quarantined failure and skipped cases. #3320 is closed, all four acceptance criteria checked, board Done/Complete/Passed, exact claim6394724259 released. This is program-record repair only, not another execution-model or adoption qualification.

No active implementation/review leaf remains. #2735 is still assigned to sfmskywalker and its ownership card remains pending; the released-library handoff and bounded saved-state probe/host identity trace are recorded there, not an implementation claim. If ownership stays with the existing owner, the alternative on the card is the bounded ETL specification; no ETL or agent leaf has been made Ready while that selection is pending. All remaining #2907/#2908/#2912 production obligations remain open, and no program-complete claim is made.

<!-- program3320-parent-complete-20261025 -->

## #2892 6395221741 elsa-workflows-codex[bot] 2026-10-25T08:07:59Z
Queue audit after #3320 closeout: refreshed all Project62 items, open Foundation/BPMN PRs, and #2735 ownership. There is no independently ready implementation leaf. Open program tasks are #2898 (blocked on released-library adoption/hosting parity) and #3101 (owner-deferred Orleans spike, Not Ready); PR91 remains a separate Claude-owned timer-cycle change and is not a replacement delivery claim. #2735 remains open/assigned to sfmskywalker with no adoption PR. Coordinating features stay out of the worker queue.

The single owner card has remained unanswered across the last three goal continuations: take over #2735 end to end (recommended), or retain its current ownership and advance the bounded ETL specification. Documentation verification and independent technical preparation are now complete. Automated program delivery is waiting on that existing selection; do not infer silence as ownership transfer or activate either alternative. Resume from the answer, refresh claims/source/board, and keep the full remaining program objective unchanged. The overall program remains open and partially delivered.

<!-- program2892-ownership-card-gate-20261025 -->

## #2892 6397004155 elsa-workflows-codex[bot] 2026-10-25T11:22:44Z
[Codex] On behalf of @sfmskywalker.

Sipke answered the ownership card: **Codex takes over #2735 end to end**. [Durable handoff](https://github.com/elsa-workflows/elsa-foundation/issues/2735#issuecomment-6396983746), exact [implementation claim](https://github.com/elsa-workflows/elsa-foundation/issues/2735#issuecomment-6396984230). This resolves the previous ownership wait. The sole active leaf is #2735, starting with parity and v1 saved-state/Studio compatibility before any engine switch; its existing three-PR sequence and all subsequent production obligations are retained. Project62 and the control table are updated. <!-- adoption2735-program-resumed-20261025 -->

## #2892 6397292008 elsa-workflows-codex[bot] 2026-10-25T11:53:02Z
Ownership wait resolved by the owner handoff; #2735 is active. First ordered [PR3335](https://github.com/elsa-workflows/elsa-foundation/pull/3335) is open in draft for parity/state/Studio evidence before the switch. Author round1 is in progress; all remaining adoption/operational gates stay open. <!-- adoption2735-program-parity-pr-open -->

## #2892 6397812221 elsa-workflows-codex[bot] 2026-10-25T12:45:59Z
Cross-machine handoff requested by Sipke. No scope change or new implementation leaf. Same Codex claim6396984230 remains active for #2735; draft parity PR3335 pushed at `3e065d465274e5e3e01cd1c42eff1fd6d8a38d75`. Three completed author rounds had findings, all addressed; new exact-head round4 remains pending. Durable continuation checkpoint: https://github.com/elsa-workflows/elsa-foundation/issues/2735#issuecomment-6397794576. The program remains in progress; no switch, ADR acceptance or production completion is claimed. <!-- adoption2735-program-machine-handoff -->

## #2892 6397920260 elsa-workflows-codex[bot] 2026-10-25T12:56:46Z
Parity PR #3335 converged in author round 5 on `28d92d3ef9e3aa774bfb20767a2f21532b065a17`, with independent correctness/standards/acceptance reviews clean. Round 4's sole Low citation typo is fixed. The PR is moving from draft to ready for the required Full tier check; no merge or engine-switch qualification is yet claimed. The existing three-PR adoption claim stays active and all subsequent recovery/Studio/production gates remain open.


## #2892 6397936712 elsa-workflows-codex[bot] 2026-10-25T12:58:24Z
Part 1 delivered: parity PR #3335 merged as `fbe694d2f3d126e324c3e46578bc1a560b0217f1` by `elsa-workflows-codex[bot]` under [standing self-merge audit](https://github.com/elsa-workflows/elsa-foundation/pull/3335#issuecomment-6397929383). Five author rounds; final independent three-lens review clean on exact head `28d92d3ef9e3aa774bfb20767a2f21532b065a17`; Build & test, Generated maps fresh and Full tier passed without bypass. Resulting-main verification is pending, not claimed passed.

Continuing part 2 under the same #2735 claim: reviewed spec → plan → tasks, actual legacy checkpoint capture before writer deletion, released 0.5.0 adapter/bindings/state compatibility, native-composite and Studio proof, duplicate-semantics deletion and guards. No competing issue or migration PR. #2735 stays open until all three ordered PRs deliver; #2898/#2907 and the remaining program stay open. ADR0063 acceptance is part 3 after delivery and verification. No Orleans or task-runner follow-up.


## #2892 6398153496 elsa-workflows-codex[bot] 2026-10-25T13:19:40Z
The second ordered #2735 draft PR is https://github.com/elsa-workflows/elsa-foundation/pull/3338. Reviewed spec1006 → plan →38tasks precede source work. Legacy capture is the current gate; no switch or production acceptance is claimed. Same single implementation leaf and claim; #2898/#2907 and remaining program stay open.

## #2892 6398588332 elsa-workflows-codex[bot] 2026-10-25T14:01:38Z
The #2735 switch draft PR #3338 has completed its legacy-capture gate: five real whole-store checkpoints, exact provenance/digests, fresh old-host controls, order-sensitive rejection and independent artifact review. Released-library adapter implementation is next; no upgraded-host/native/Studio or production acceptance is claimed. Parity PR #3335 resulting-main CI40195451877, Studio40195451973 and CodeQL40195451830 all passed. Same single adoption leaf/claim; #2898/#2907 and remaining program stay open.

## #2892 6399404437 elsa-workflows-codex[bot] 2026-10-25T15:17:42Z
#2735 delivery continues on the existing draft switch PR #3338, pushed head `2cbbf4f9854c0021924e49f349779020df72b226`.

The released-library host adapter now recovers all five actual preview-host EF database snapshots through fresh upgraded providers; four corruption controls refuse new work and preserve the source state. Version 1 stays version 1. Whole-project local results: BPMN267, interchange117, runtimeEF1,014, all passing with zero skips. Exact lookup and domain-exception mutation controls fail as intended; frozen authoring fingerprint remains unchanged.

The increment was independently reviewed and its findings corrected. This is not final adoption acceptance: binder registration, remaining replay/pruning/reader matrix, dedicated BPMN combined durability, real dispatch/compensation/Studio/published-descriptor evidence, duplicate deletion/guards and complete-PR review/checks remain open. Parity PR3335 is delivered. ADR0063 remains proposed until the third ordered PR after switch delivery/resulting-main verification.

[Durable continuation checkpoint and evidence](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6399396125). The existing Codex claim continues; no competing PR. #2898/#2907 and the remaining program stay open; Orleans/task-runner stay deferred.


## #2892 6400264500 elsa-workflows-codex[bot] 2026-10-25T16:36:59Z
#2735 continues on the existing draft switch PR #3338, pushed head `90feccfedfa5d4c32a25bf2fc00da0ab6666d9b7`.

Actual source-built Workbench HTTP now proves none-start completion, PT5S durable suspension/completion, and one imported signal publication completing both suspended catches in one execution through their parallel join, zero incidents. Actual recommended active published BPMN descriptors match the unchanged frozen fingerprint2/2; four rejecting verifier controls and source/binary/configuration identities are committed. Incremental reviews converged after correcting real catalog/timer/broadcast and compatibility findings.

[Durable continuation checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6400248816) includes exact build revision, portable receipts/reproduction and every remaining gate. These happy paths do not qualify retry/re-arm, dedicated combined durability, Studio or full adoption. Source-built Studio work is next. Existing claim/PR continues; parity3335 delivered; ADR0063 remains proposed. #2735/#2892/#2898/#2907 remain open, Orleans/task-runner deferred. No final complete-PR review loop has begun.


## #2892 6401087800 elsa-workflows-codex[bot] 2026-10-25T17:53:15Z
Delivery checkpoint for the existing Codex-owned #2735 switch, PR #3338; pushed head `a9bec3250`.

Parity PR #3335 remains delivered. Actual upgraded-host callback identity/reader proof and exact captured queued-loser replay after pruning/provider restart are now pushed; whole runtime EF1016 passed, zero failed/skipped. The replay witness proves actual queue consumption and fails when that sweep is omitted. [Durable replay checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6400924128), [reader checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6400895740).

The normal source-built Studio default-flow edit/publish/run/export milestone is retained at its recorded source identities, including actual published fingerprints2/2. It is not restamped as final-head acceptance.

The already-required Call Activity coded-error/escalation work has now passed spec → plan → task refinement and independent correctness/standards/acceptance review at each stage. The [control contract](https://github.com/elsa-workflows/elsa-foundation/blob/a9bec3250/specs/1006-bpmn-library-adoption/contracts/called-workflow-control.md) preserves ordinary dispatch defaults/safe diagnostics, exact committed dispatch authority, indivisible terminal batches, fresh empty terminal barriers and ordered atomic inbox recovery. Implementation/proof remain open. A separate exact old-source checkout is capturing an actual late fault before production-writer deletion; its legacy incident-absorption gap is being recorded honestly, with a portable test overlay rather than fabricated state.

PR3338 remains the sole draft switch PR; final complete-PR review has not begun. Existing Codex claim continues. Duplicate deletion/guards, combined/native durability, ordinary compensation, 242-method reconciliation and final exact-head checks/review remain gates. ADR0063 remains proposed until switch delivery/resulting-main verification, then ordered PR3. #2898/#2907 and the remaining program remain open; Orleans/task-runner remain deferred. No new owner authorization is needed or inferred.


## #2892 6401321139 elsa-workflows-codex[bot] 2026-10-25T18:14:15Z
Existing #2735 delivery continues on draft switch PR #3338, current pushed head `0cbcb8626`; no competing claim/PR.

Two additional verified milestones are delivered on that branch. T018 now covers all six actual legacy EF fixtures: the supplemental real late-fault capture retains its original writer/pins plus a portable verified test patch, and upgraded recovery/pruned duplicate replay preserves the exact fault/incident while correcting the recorded old-host incident-absorption gap. Whole runtime EF1018 passed. [Capture/recovery checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6401141797).

The required called-workflow spec→plan→tasks refinement was independently reviewed in order. T039 bounded generic contracts and legacy wire defaults are implemented;19 targeted cases,240 whole DispatchWorkflow and2610 whole Workflows Runtime tests pass, zero failures/skips, with7 malformed-wire mutation cases red before restoration. [Contract checkpoint and remaining gates](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6401316751). Capability admission and actual producer/outbox/inbox/consumer delivery T040–T045 are next; model tests do not qualify host delivery.

Parity PR3335 remains merged. Switch PR3338 remains draft, full final review not started; T017 remaining MI/listener fault/replay, combined/native durability, ordinary compensation, duplicate deletion/guards,242-method reconciliation and final exact-head gates remain open. ADR0063 remains proposed until ordered PR3 after switch delivery/main verification. #2898/#2907 and the remaining program stay open; Orleans/task-runner remain deferred. Existing owner authorization and Codex claim continue without a new approval question.


## #2892 6401976796 elsa-workflows-codex[bot] 2026-10-25T19:13:57Z
Existing Codex #2735 switch delivery has advanced to pushed head `e12fc389e` on sole draft PR #3338. T040 is closed for explicit waited capability admission and exact retained boundary/address resolution. Actual child execution observes committed Started and exact root/caller/consumer; an ordinary child sees no capability. Source-backed Pending refusal, durable hint preservation, contextual failures, provider replacement/scoping and contradictory-root controls are verified. Whole DispatchWorkflow274, Publishing API863, Workflows Runtime2610 pass; zero failures/skips. [Durable checkpoint and limits](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6401700414).

T041 producer staging/terminal barriers is in progress; outbox/source authority, ordered inbox, BPMN consumer and actual called-workflow delivery T042–T045 remain open. Model/admission proofs are not restamped as escalation or coded-error delivery. The six actual legacy fixtures and T018 qualification remain retained. Parity PR3335 is merged; switch PR3338 remains draft with full final review not started. T017 remaining MI/listener cases, combined/native durability, ordinary compensation, deletion/guards,242-method reconciliation and final exact-head gates remain open. ADR0063/#2898/#2907 and remaining program acceptance stay open; Orleans/task-runner remain deferred. Existing claim and authorization continue.


## #2892 6402383222 elsa-workflows-codex[bot] 2026-10-25T19:51:54Z
Existing Codex #2735 delivery is pushed at `1f26b0d16` on sole draft switch PR #3338. T041 and T042 are closed for root checkpoint projection/terminal barriers, exact immutable source authority and ordinary terminal resume with atomic typed leaf projection. Actual runtime controls cover a running-root notification source, success/authored-fault terminal resume, cancellation precedence and forged-result refusal. Whole DispatchWorkflow316, Activities Runtime664 and Workflows Runtime2625 pass with zero failures/skips; source/anchor/getter mutations fail as expected and are restored. [Durable checkpoint and limits](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6402363254).

Next is T043: nonterminal handler/retry/acknowledgement, ordered inbox and atomic callbacks. The source witness leaves its row pending; source staging and ordinary terminal resume do not qualify called escalation delivery or upgraded-host control recovery. T044/T045 BPMN consumption/delivery proof, remaining MI/listener cases, combined/native durability, ordinary compensation, deletion/guards,242-method reconciliation and final exact-head gates remain open. Full switch-PR review has not begun. Parity #3335 is merged; ADR0063, #2898/#2907 and remaining production acceptance stay open. Orleans/task-runner remain deferred. Existing claim and standing authorization continue.


## #2892 6402770966 elsa-workflows-codex[bot] 2026-10-25T20:25:47Z
The owner answered the broadcast recovery card: **keep delivery-time matching and persist the first recipient snapshot**. This is settled; no new authorization question is needed.

Reviewed spec refinement FR-015 is pushed at `1bcdec63d` on the existing switch branch/PR3338. The complete first-delivery cohort must commit durably before any dispatch, including exact published-trigger/binding/executable starts and exact bookmark resumes. An empty first cohort is authoritative too. Retries cannot rediscover newly published triggers or newly re-armed listeners; original recipients use stable idempotency. Correlation, local ResumeOnly targeting, test-scope isolation and the pre-start wait snapshot rule retain their existing meanings.

Three specification-review lenses are clean after making both recipient classes and empty-cohort recovery explicit. [Reviewed requirement and owner decision](https://github.com/elsa-workflows/elsa-foundation/blob/1bcdec63d/specs/1006-bpmn-library-adoption/spec.md). Storage/dispatch plan review, task refinement, implementation and actual host/provider recovery proof are still open. Earlier per-attempt snapshot and happy-path fan-out receipts do not satisfy this new durable-cohort requirement.

This adds a switch delivery gate inside existing #2735; it does not create another implementation issue or PR. T043 called-control inbox work continues. PR3338 remains draft; deletion/final review/merge and the third ADR0063 PR wait for this proof as well as all existing gates. #2898/#2907 and remaining production acceptance stay open; Orleans/task-runner remain deferred.


## #2892 6403980664 elsa-workflows-codex[bot] 2026-10-25T22:04:50Z
State transition: T043 is complete within the existing Codex-owned #2735 switch on sole draft PR #3338 at `c2bb63305f4713651e36dbe19fc886cfbc688950` (implementation `709dc3d87`, catalog preservation `18de7ee32`, current-main merge `c2bb63305`). No competing PR or claim was created.

The calling-child inbox commits its contiguous prefix/processed receipt atomically with returned parent state and owed work on Defer, Complete, intentional Fault and Cancel. Terminal-success/fault barriers can buffer before earlier notifications without activation. Pre-claim Sequential source validation preserves a valid bookmark/owed delivery on temporary reads. Authenticated pre-admission DispatchFailed retains ordinary outcomes without a fictitious root barrier. Provider deletion guards preserve linked authority, require Delivered owed rows and sticky caller retirement, avoid cross-delete lock cycles, and fence activity-only admission races.

Checks: whole DispatchWorkflow335, Activities Runtime664, Workflow Runtime2648, Runtime EF1022; deletion API21 and publishing compiler147, all green. Eleven actual in-process inbox cases include reply loss, outage recovery and late delivery after caller deletion. Regression mutations are red before byte-identical restoration. Frozen authoring SHA256 remains `41aa0bb979ea46fc2533b057e3677f408ab54c3411fecfafaa238a2adae38c92`.

[Portable source/check receipt](https://github.com/elsa-workflows/elsa-foundation/blob/c2bb63305f4713651e36dbe19fc886cfbc688950/specs/1006-bpmn-library-adoption/evidence/control-inbox.md) and [source hashes](https://github.com/elsa-workflows/elsa-foundation/blob/c2bb63305f4713651e36dbe19fc886cfbc688950/specs/1006-bpmn-library-adoption/evidence/control-inbox.json). Correctness/standards/acceptance component reviews are clean; these are not a complete-PR round (still0).

T044/T045 BPMN interpretation and actual current-host/fresh-EF execution recovery, concurrent claims, remaining combined outcomes/compensation, duplicate-engine deletion and final host/Studio gates remain open. FR-015's delivery-time first-cohort decision is recorded; its reviewed plan/tasks still precede implementation. ADR0063, #2898/#2907 and the remaining program stay open; Orleans/task runner stay deferred.

Refreshed main through `fea9a3407` is adopted. Its Studio-cleanup predecessor `dd8c971c6` has green core CI but [Studio dependency installation failed](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40234932842) because the frozen lockfile omits an Attention workspace importer. Final Studio evidence must address that failure; no historical receipt is restamped.


## #2892 6404855089 elsa-workflows-codex[bot] 2026-10-25T23:25:08Z
State transition: T044 is complete within the existing Codex-owned #2735 switch on sole draft PR #3338.

T044 BPMN control adapter is complete on existing draft #3338 at `c76b16f2c01aa5b7398259820910d876d954d0af` (component `035b1b8f12675ad4af1acdb4ac420d3fd08db557`, current-main merge `c76b16f2c01aa5b7398259820910d876d954d0af`). The existing Codex claim and ordered #2735 delivery remain unchanged.

BpmnProcess now consumes generic exact-call control through released 0.5.0. Ordered signals and terminal authored classification fold before command application/pruning; exact call token/iteration/handle and prior interrupt retirement are preserved. New declared waited calls opt in, while ordinary tasks and accepted legacy pins keep their outcome path. Admitted roots emit whole ordinal batches without duplicate local parent notices.

Recovery controls found and fixed premature activation-source consumption, an accepted durable notice surviving overlay deactivation, terminal enrichment read failures outside retry conversion, and an unsupported legacy overlay falsely claiming a durable delay. Normal invocation/structural sources remain owed until final acceptance. The exact accepted ID is cleaned without touching siblings/stale claims. Legacy queues retain ordinary fusion and the established bookmark-resume boundary; unavailable overlay work that cannot persist visibility propagates its original signal without ACK/poison or a false Deferred result. Background admission and replay fingerprint checks remain unchanged.

Portable source hashes, test commands, mutation results and explicit scope: [adapter receipt](https://github.com/elsa-workflows/elsa-foundation/blob/c76b16f2c01aa5b7398259820910d876d954d0af/specs/1006-bpmn-library-adoption/evidence/called-control-adapter.md).

Whole affected checks: BPMN297, DispatchWorkflow339, Activities Runtime664, Workflow Runtime2661, Runtime EF1022 and interchange130, all zero failures. Five restored mutations fail behaviorally; six additional unsupported-overlay outage controls went red before the capability guard and now pass, including provider reopen and deactivated overlay. The first EF run found three ordinary-fusion regressions; the corrected policy passes the complete EF project. Frozen authoring fingerprint remains byte-identical at `41aa0bb979ea46fc2533b057e3677f408ab54c3411fecfafaa238a2adae38c92`. Component correctness/standards/acceptance reviews are clean; full-PR review has not started.

T045 actual admitted-host/fresh-EF transport, buffered-gap recovery and concurrent claims remain open. So do T024 combined outcomes, T029 ordinary compensation, FR-015 durable delivery-time broadcast cohort plan/tasks/implementation, duplicate semantics deletion/API guards, final current host/Studio verification, exact-head required checks and resulting-main verification. Historical host/Studio receipts remain bound to their original builds. Main through `4a6bba1a3e461a7567719e9d4c37034865fbe2b5` is incorporated, including the Studio build repair; its current CI outcome must be checked, and the old failed frozen-install run is not treated as passing. ADR0063 and production #2898/#2907 remain open. No merge or production-completion claim.


## #2892 6404973272 elsa-workflows-codex[bot] 2026-10-25T23:37:01Z
FR-015 planning transition on the existing Codex #2735 claim and sole draft switch PR #3338: pushed head `061d3331a2d56f3fc12eca5a7999000efaf5dc7f` contains reviewed plan `84f4305f6` and subsequently reviewed task refinement `061d3331a`. The owner's delivery-time matching decision remains settled.

The [recipient contract](https://github.com/elsa-workflows/elsa-foundation/blob/061d3331a2d56f3fc12eca5a7999000efaf5dc7f/specs/1006-bpmn-library-adoption/contracts/broadcast-recipient-snapshot.md) keeps the complete first-delivery cohort on the exact durable source outbox row before any recipient effect. It preserves all sorted start-binding entries and existing artifact-scoped keys/shedding, exact bookmark IDs and resume keys, scoped matching and an authoritative empty set. Source-fenced immutable CAS, explicit delivery context, canonical coalescing source, retained selected-start authority, executable/dedup retention and new-family old-writer protection are explicit requirements. Ambiguous legacy owed sends cannot silently resnapshot; actual preflight supplies evidence before any concrete recovery choice.

Correctness, standards and acceptance reviews completed independently at each ordered stage: spec → plan → tasks. T046–T051 remain unchecked and sequential: contracts/actual preflight; provider CAS/version preservation; durable context/coalescing; retained authority/GC; routing/publisher enablement; actual host/fresh-EF qualification. Existing task IDs are unchanged (51 total; six new US3 tasks). Retention and authority guards precede enablement. This checkpoint qualifies planning, not storage/dispatch implementation or host behavior.

T044 remains complete at source-bound receipt `c76b16f2c`; its 24 source/test hashes remain unchanged by these documentation commits. T045, T024/T029, T046–T051, duplicate semantic deletion, final current-host/Studio evidence, full-PR review (zero rounds so far), exact-head required checks and resulting-main verification remain open. ADR0063, production #2898/#2907 and the program remain open; Orleans/task-runner stay deferred.


## #2892 6405346546 elsa-workflows-codex[bot] 2026-10-26T00:13:18Z
Initial T046 preflight increment is pushed at `674b9f11db79521226e8c3c0f5b6772bb69688df` on existing draft #3338 (tool/receipts `78018c350`, solution registration `674b9f11db79521226e8c3c0f5b6772bb69688df`). **T046 remains open** for strict cohort/source-context contracts; no publisher/cohort delivery is enabled.

The [portable inventory receipt](https://github.com/elsa-workflows/elsa-foundation/blob/674b9f11db79521226e8c3c0f5b6772bb69688df/specs/1006-bpmn-library-adoption/evidence/broadcast-preflight.md) binds source, assembly and actual database hashes. The offline PowerShell entrypoint makes a coherent read-only SQLite backup including committed WAL data, then a small tool uses the real RuntimeSqliteDbContext/EfRuntimePostCommitOutboxStore checked reader for every row. Complete enumeration includes empty/NULL IDs; exact physical source, schema, projections and actual Core delivery-state invariants must validate. No recipient dispatch, update or repair occurs; receipts omit raw IDs/scopes/payloads/credentials.

All six frozen legacy databases validate (33 outbox rows, zero PublishStimulus), with raw/compressed hashes matching the original manifests. The separately observed owned development host at its recorded historical source validates ten rows, including one already Delivered publish. This scope does not establish production-wide inventory, mixed-writer quiescence, new cohort semantics or upgraded-host recovery. Attempt zero never proves no effects; unresolved legacy sends remain held for evidence/recovery.

Fourteen real-provider controls pass. Four restored behavioral mutations fail: skip empty/NULL rows2, omit actual Core Delivered timestamp validation1, omit enumerated-source identity check1, ignore WAL1. Initial review found false-clean ID/settlement cases in the earlier standalone classifier; the revised tool reuses the checked provider and closes them. Correctness, standards and acceptance component reviews are clean. Native tool build, PowerShell parameter/parse and generated solution-filter checks pass; source mutations/builds were restored. Full-PR review remains zero rounds.

Incorporated main `4a6bba1a3` has green [CI](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40244249025) and [Studio CI](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40244248805), verifying its Studio build repair. Final adoption-candidate host/Studio journeys are still required. T045, remaining T046–T051, T024/T029, deletion/API guards, final checks/review/resulting-main verification, ADR0063 and production #2898/#2907 remain open. Existing Codex claim and ordered PR delivery continue; no competing PR or program-completion claim.


## #2892 6405923029 elsa-workflows-codex[bot] 2026-10-26T01:04:02Z
T046 is complete at `bbdee782cfbd6c7d7c61083a8ced81738b3c270d` on existing draft #3338. The [Core contract receipt](https://github.com/elsa-workflows/elsa-foundation/blob/bbdee782cfbd6c7d7c61083a8ced81738b3c270d/specs/1006-bpmn-library-adoption/evidence/broadcast-contracts.md) complements the checked actual-store preflight. It binds immutable complete/empty recipient cohorts, exact source/claim context, strict versioned wire readers, scope and retained binding/bookmark identities to source hashes. This increment declares the provider port; no provider implementation or fan-out is enabled.

Validation: 74 targeted contract cases and the whole Workflow Runtime project (2735 passed, zero failed). Seven restored mutations detect missing fence, lossy UTF-16 identity, rewriting the old checkpoint fingerprint, omitted required nullable scope/binding fields, omitted wait generation and bypassed numeric canonicalization. Intent fingerprints normalize equivalent exact JSON numbers without floating-point loss. The existing checkpoint fingerprint implementation remains byte-identical; the frozen authoring fingerprint remains `41aa0bb979ea46fc2533b057e3677f408ab54c3411fecfafaa238a2adae38c92`. Public API additions:54, removals:0. Correctness, standards and acceptance component reviews are clean; full-PR review remains zero rounds.

Next is T047: atomic exact-source snapshot storage/CAS, provider registration, preservation through every rewrite and explicit family-version protection before any recipient dispatch. T048–T051, actual admitted-host T045, other remaining story evidence, deletion/API guards, final current-host/Studio verification, required checks/full review, resulting-main verification and the third ADR0063 PR remain open. #2898/#2907 and the remaining program retain their own production acceptance gates. Existing Codex claim continues; no competing PR.


## #2892 6406363080 elsa-workflows-codex[bot] 2026-10-26T01:43:06Z
T047 is complete at `7ee54692d7644ad8441859210ec60102efbc4f40` on the existing Codex-owned #2735 / sole draft #3338. The [portable storage receipt](https://github.com/elsa-workflows/elsa-foundation/blob/7ee54692d7644ad8441859210ec60102efbc4f40/specs/1006-bpmn-library-adoption/evidence/broadcast-storage.md) binds25 source/test/catalog hashes and four provider-created whole SQLite fixtures. No new publisher or recipient fan-out is enabled by this increment.

Both existing providers atomically install one complete/empty cohort on the exact source row and preserve the winner across claims, renewal, retry, completion, shared redrive, atomic participants and coalescing pending conversion. Initial source acceptance binds retained persistence scope to actual write access, including null-tenant legacy publishers. Install rechecks immutable source/intent, publisher facts, current owner/fence and trusted provider-clock expiry against the current renewed deadline. A losing CAS proposal or stale claim object cannot erase the winner.

Declared outbox family1.0.0→2.0.0 has a strict absence-preserving upcaster and checked revision-CAS backfill rewriter. Ordinary writes use the existing gate's observed format. Protocol sources require2.0.0 before first selection; existing fleet/hold/finalization/write-gate authority is preserved. The original reader's four assembly hashes match the historical T046 receipt: it actually refuses both v2 before-selection and after-selection fixtures with EfSchemaVersionSkewException, while reading both v1 controls. These are constructed provider fixtures, not actual workflow host recovery or Studio evidence.

Final restored-source checks: whole Workflow Runtime2744/0; whole Runtime EF1082/0; new provider/gate60 and Runtime model/fold9 cases; current checked preflight15/0. Eleven behavioral mutations fail, with no compilation failures. Six additional Core API entries, no removals; original Core14-parameter and EF2-parameter constructors remain. Frozen authoring SHA remains `41aa0bb979ea46fc2533b057e3677f408ab54c3411fecfafaa238a2adae38c92`. Three independent component reviews and final receipt/hash verification are clean; full-PR review remains zero rounds.

Next is T048: exact durable processor/dispatcher/handler context and canonical coalesced source before effects. T049–T051 authority/retention/dispatch/actual-host recovery, T045, remaining story evidence, deletion/guards, final current-host/Studio, required checks/full review, resulting-main verification and the third ADR0063 PR stay open. #2898/#2907 and the program retain their own production acceptance gates; Orleans/task-runner remain deferred. Existing claim/ordered delivery continues without another PR.


## #2892 6407756978 elsa-workflows-codex[bot] 2026-10-26T03:46:08Z
T048 is complete on existing Codex #2735 / sole draft #3338. Pushed head `1979b2fa052a0413b399f7f3f7de3147ee5521f7` contains component `a4845c3a687e7f3e344e7209cb5dbb37a4385a18` and main through `5e1c41c39e5b347fc26090f73c979cdbd140deb1`. The [durable source-context receipt](https://github.com/elsa-workflows/elsa-foundation/blob/a4845c3a687e7f3e344e7209cb5dbb37a4385a18/specs/1006-bpmn-library-adoption/evidence/broadcast-source-context.md) binds26 source/test/contract/catalog hashes at the component source. No recipient-cohort publisher is enabled.

The generic required-source path carries the exact physical committed source and current fenced claim through additive dispatcher/handler contracts. Independent contribution metadata and persisted scope/protocol witnesses prevent legacy replacements or constructor combinations from silently falling back to intent-only effects. Missing/contradictory source, unknown legacy scope and caller-owned EF transactions refuse before handler, failure projection, acknowledgement or attempt increment. Ordinary handlers, registrations, CLR overloads and scheduler-continuation priority remain. Scope-only sources require family2.0.0 but declare no recipient protocol.

Real quiescence flush supplies the canonical source before delivery; cap folds preserve a peer-installed cohort and completion. After commit acknowledgement loss, a same-scope retry retains the prepared commit identity/timestamp/envelope even after peer delivery. Other checkpoint decisions refuse until resolution. Actual EF controls prove physical checkpoint/outbox context with an in-memory queue/no scheduler work; scope-local caching does not establish process-restart recovery.

Final component checks: Runtime2766/0, Runtime EF1089/0;22 source controls, two EF flush cases,14 restored behavioral mutations with no compilation failures;13 Core API additions/0 removals and unchanged frozen authoring SHA256 `41aa0bb979ea46fc2533b057e3677f408ab54c3411fecfafaa238a2adae38c92`. All three independent component/receipt reviews are clean. Integration with the five newer main commits preserves both additive API sets; post-merge affected whole checks pass Runtime2770/0 and Runtime EF1093/0. Historical receipts remain bound to their original source, including the T048 receipt at the linked component commit. Full-PR review remains zero rounds.

Next is T049 retained saved-start authority, executable roots/leases and owed source/dedup retention. T050 activation, T051 actual host/fresh-provider recipient retry/restart/retention, T045 and remaining story evidence, deletion/guards, final current-host/Studio, full review/required checks, resulting-main verification and the third ADR0063 PR remain open. #2898/#2907 and the program retain their own production acceptance gates. Orleans/task-runner remain deferred; existing claim and ordered delivery continue.

Project62 spot check: #2735 is In Progress / Assigned / Pending verification. Its Linked pull requests field is empty despite this draft. The board is a mirror; issue/PR checkpoints remain authoritative. The Codex App cannot currently read project62 through GraphQL, so no board write or owner-account fallback was used. Missing development linkage does not itself prove stale status.


## #2892 6408174722 elsa-workflows-codex[bot] 2026-10-26T04:22:39Z
Initial T049 lease-capability increment is pushed at `0303e67b143bb14cc6d5be38474d9b6795dd4118` on existing Codex #2735 / sole draft #3338. **T049 remains open** for saved-start authority, source/provider acceptance, executable-GC roots and source/execution/dedup retention. The [root-set lease receipt](https://github.com/elsa-workflows/elsa-foundation/blob/0303e67b143bb14cc6d5be38474d9b6795dd4118/specs/1006-bpmn-library-adoption/evidence/broadcast-retention-leases.md) binds five source/test/catalog hashes. No publisher or recipient cohort installation consumes the new capability yet.

The additive collection overload snapshots every root, validates complete immutable pins and full dependency closures, then protects their distinct ordinal union through one callback. Legacy managers refuse before fallback/effects. The collection path revalidates acquired tokens and monitors every grant deadline independently of blocked periodic renewals. Completion samples expiry even if timer dispatch is late. Cancellation-registration errors remain inside the awaited operation; concurrent renewal, expiry and observer failures preserve distinct causes without duplication. Requested cancellation and unrequested provider cancellation remain distinct. Original overload signatures/behavior are preserved.

Final restored whole Runtime2793/0/0;29 lease cases including23 new;11 meaningful behavioral mutations detected/restored with no compilation failures;Core API+1/0 removals; frozen authoring SHA256 unchanged at `41aa0bb979ea46fc2533b057e3677f408ab54c3411fecfafaa238a2adae38c92`. Correctness, standards and acceptance component/receipt reviews are clean after the deadline/cancellation corrections. The receipt candidly records the initially escaped discovery-test hook and redundant-check consolidation. Full-PR review remains zero rounds.

This is actual in-memory artifact lease/deletion-guard evidence, not EF cohort installation, retained-authority/GC integration, actual host/restart or Studio proof. Callbacks must honor cancellation and fence durable acceptance; the coordinator cannot roll back committed effects. T049 integration must coordinate with existing called-workflow deletion without cross-root lock cycles; exact ownership-revision fencing or an equivalent proven safe ordering remains to implement.

Continue T049 authority/retention, then T050 publisher activation and T051 actual host/fresh-provider recipient retry/restart/retention. T045 and remaining story evidence, duplicate-semantics deletion/guards, final current host/Studio, complete-PR review/required checks, resulting-main verification and the third ADR0063 PR remain open. #2898/#2907 and program production acceptance remain open; Orleans/task-runner stay deferred. Existing claim and ordered delivery continue without another PR.


## #2892 6408458587 elsa-workflows-codex[bot] 2026-10-26T04:47:03Z
T049 source-attribution increment is pushed at `3bd2920c027e5061222ab27539dea8fb7b2b6596` on existing Codex #2735 / sole draft #3338. **T049 remains open.** The [source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/3bd2920c027e5061222ab27539dea8fb7b2b6596/specs/1006-bpmn-library-adoption/evidence/broadcast-source-attribution.md) binds six source/test/contract/catalog hashes.

The original two-argument recipient constructor/wire remains uncaptured. An additive constructor captures the ordinary selected publication provenance, including an explicit null for legitimate reference-less legacy. Versioned strict wire and equality preserve that distinction and keep publication attribution separate from deduplicated executable producer metadata. This refines unpublished family2 with publisher activation disabled; historical fixtures/receipts remain unchanged/source-bound. Model shape and constructed provider persistence do not prove reference eligibility or grant saved-start authority.

Final restored checks: whole Runtime2813/0/0; Runtime EF1100/0/0; Core snapshot61 cases including20 new; seven new actual memory/EF storage controls; seven behavioral mutations detected/restored without compilation failures. Core API+3/0 removals; original constructor and frozen authoring SHA256 unchanged. Correctness, standards and acceptance component/receipt reviews are clean. Full-PR review remains zero rounds.

Next: reuse ordinary authoritative reference resolution, implement compact saved-cohort authority and current physical source/scope/owner/fence/expiry validation before the early duplicate return, preserving per-artifact keys and normal policy. T049 provider acceptance under leases, GC/source/execution/dedup retention and race controls remain open before T050 activation and T051 actual host/fresh-provider recovery. T045, remaining story evidence, duplicate-semantics deletion/guards, final current host/Studio, full review/required checks, resulting-main verification and third ADR0063 PR remain open. #2898/#2907/program production acceptance remain open; Orleans/task-runner are deferred. Existing claim and ordered delivery continue.


## #2892 6408897879 elsa-workflows-codex[bot] 2026-10-26T05:24:54Z
T049 compact-source contracts/read boundary is pushed at `0ca0ddfa3d499655789d1b04951e08bd8b2efc48` on existing Codex #2735 / sole draft #3338. **Saved starts remain disabled and T049 remains open.** The [source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/0ca0ddfa3d499655789d1b04951e08bd8b2efc48/specs/1006-bpmn-library-adoption/evidence/broadcast-saved-source.md) binds14 files.

A distinct compact authority union member carries exact source ID/digest/scope/claim/binding data without copying recipients or payload. Original constructors/legacy wire remain. Both providers validate physical current source, accepted captured binding, publisher scope and current owner/fence/trusted-clock expiry; EF rereads after awaited publisher lookup and rechecks caller-transaction absence at return. The legacy read-port default refuses. A real EF peer-takeover control proves an earlier future-deadline claim cannot authorize the later row. These are provenance reads, not reference eligibility or start admission: the dispatcher deliberately refuses the new mode before even keyed-duplicate return.

Final restored checks: Runtime2842/0/0, Runtime EF1130/0/0;Core/start38 cases including29 new;provider30 new;10 meaningful behavioral mutations detected/restored without compilation failures;Core API+14/0 removals. All three independent component/receipt reviews are clean; frozen authoring unchanged. Full-PR review remains zero rounds.

Next is ordinary authoritative reference resolution and actual T049 admission under root leases/GC/source/execution/dedup retention, preserving start policy and per-artifact keys. T050 activation, T051 actual host/fresh-provider recipients/retry/restart/retention, T045 and other story evidence, duplicate-semantics deletion/guards, final current host/Studio, full review/required checks, resulting-main verification and the third ADR0063 PR remain open. #2898/#2907/program production acceptance remain open; Orleans/task-runner stay deferred. Existing claim/ordered delivery continues without another PR.


## #2892 6409373845 elsa-workflows-codex[bot] 2026-10-26T06:03:08Z
T049 shared ordinary source-selection increment is pushed at `f947d3f33acd15fca0d0ce81c871eb685accb03c` on existing Codex #2735 / draft #3338. **T049 remains open; saved starts are still disabled before duplicate lookup.** [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/f947d3f33acd15fca0d0ce81c871eb685accb03c/specs/1006-bpmn-library-adoption/evidence/broadcast-source-selection.md).

The ordinary dispatch resolver is extracted without a public API change. Recipient capture uses that same complete source-reference traversal and publication/scope/liveness selection. It preserves selected attribution independently of deduplicated producer metadata and captures null only for legitimate reference-less legacy. Final restored Runtime2851/0/0; focused66/0 including9 new cases;5 behavioral mutations detected/restored. All three source/final-receipt reviews are clean; frozen authoring unchanged. Full-PR rounds remain0.

Next is actual T049 cohort acceptance under full root leases, GC/source/execution/dedup retention and saved-start admission. T050 activation, T051 actual host/fresh-provider recovery, other story gates including T045, duplicate-semantics deletion/guards, final current host/Studio, full review/required checks, resulting-main verification and the third ADR0063 PR remain open. #2898/#2907 and program production acceptance stay open; Orleans/task-runner remain deferred. No competing PR or claim.


## #2892 6410051625 elsa-workflows-codex[bot] 2026-10-26T06:51:00Z
T049 cohort-retention/root and guarded-reference increment is delivered in `9f9ef9275` and pushed at current head `4aa4d9e8288e3842fbfa59ef8e022173997362d0`, which also adopts legitimate Studio main progress through `71b6b644d6b3aa2286d70a351b0bebf6745829e4`. Existing Codex claim / sole draft #3338 continues. **T049 remains open; saved starts and publisher activation remain disabled.** [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/4aa4d9e8288e3842fbfa59ef8e022173997362d0/specs/1006-bpmn-library-adoption/evidence/broadcast-retention-roots.md).

Existing source rows retain selected pins after delivery/publisher deletion until the deterministic target's sticky retirement tombstone; target absence never releases the handoff. Unresolved statuses inclFailedFinal/Cancelled retain exact publisher/resume/start execution and dedup state. The new GC composition queries these roots and final dependency closure under deletion guards. Native memory artifact gating and EF atomic reference CAS plus artifact-coordination revision fencing protect reference cleanup. New operation failures have documented contextual domain boundaries. Templates/unsupported native-guard combinations are conservatively retained in the unfinished composition.

Final restored checks: Runtime2854/0/0, Runtime EF1168/0/0;3 new Core/GC and38 provider cases;14 behavioral mutations detected/restored;Core API+7/0 removals. EF1168 listed exact. Runtime2843 discovery entries expand3 existing deferred theories to14 cases (2843−3+14=2854); TRX maps every result. All three final source/receipt reviews clean; frozen authoring unchanged. Four actual GC/lease interleavings qualify both providers/orderings, explicitly wrapping install in the real full-set manager; they do not prove automatic fenced provider installation. EF rollback control uses a documented constructed same-TX revision conflict, not a peer write SQLite excludes. Full-PR rounds remain0.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) is now included in checkpoint maintenance as requested. Codex App access is verified: the installation already grants organization Projects access; the local helper's reduced token omitted it. An explicit project mode now requests only existing organization_projects=write in addition to the usual repository permissions. No new owner grant is needed. Existing parity PR #3335 is on the board as Done/Passed; draft adoption #3338 is In Progress/Assigned/Partial; #2735 is In Progress/Assigned/Partial. Program and #2898/#2907 remain open/unchanged. All13 field updates were reread and verified as elsa-workflows-codex[bot].

Next is actual T049 lease/ownership-fenced cohort acceptance, authoritative source validation and saved-start admission preserving ordinary policy/shedding/duplicate provenance. T050 activation, T051 actual host/fresh-provider recovery, T045/other stories, duplicate-semantics deletion/guards, final current host/Studio, full review/required checks, resulting-main verification and third ADR0063 PR remain open. #2898/#2907/program production acceptance stay open; Orleans/task-runner remain deferred. The explicitly requested end-to-end program goal is active; no duplicate existing goal was present.


## #2892 6421387019 elsa-workflows-codex[bot] 2026-10-26T16:30:31Z
T049 material commit-fence capability is delivered in `c807d26db` and pushed at `631f5e0a8771a0d57ef075084771402938652c3b`. This head also adopts legitimate Studio authentication/bridge progress through main `2fd983021`. Existing claim and sole draft #3338 continue. **T049 remains open; saved starts and publisher activation are still disabled.** [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/631f5e0a8771a0d57ef075084771402938652c3b/specs/1006-bpmn-library-adoption/evidence/broadcast-material-fence.md).

The additive default-refusing `ExecuteFencedAsync` exposes immutable actual complete-root grants through the existing renewal/deadline loop. It refuses misbound material/ownership or empty tokens without using/releasing unrelated grants. Native memory fences synchronous publication under its actual artifact gate. Native EF fencing requires an owned transaction, reads physical untracked authority, physically locks sorted coordination/lease revisions, and rechecks trusted time after the last lock. The helper itself does not install a cohort or authorize a saved start.

Final restored whole checks: Runtime2866/0/0, Runtime EF1182/0/0;12 new Runtime and14 actual EF cases;13 final behavioral mutations detected/restored;Core API+1/0 removals. Runtime2855 discovery entries expand3 existing deferred theories to14 (2855−3+14=2866); current TRX maps all results. EF1182 listed exact. All three source/final-receipt reviews are clean; frozen authoring unchanged. An initially escaping final-expiry mutant exposed a first-grant test schedule that masked the final check; strengthened last-lock controls now detect it. Stale tracked lease/coordination twins prove fresh physical reads. EF capability tests publish an actual source reference in the transaction, not a cohort/host recovery. Full-PR rounds remain0.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) was freshly reread as elsa-workflows-codex[bot]: #2735 and #3338 remain In Progress/Assigned/Partial, parity #3335 Done/Complete/Passed. No status reset or unnecessary field mutation was needed. #2898/#2907/program production acceptance remain open.

Next is actual cohort installation using these grant/material fences, canonical captured-source eligibility, physical publisher/recipient ownership revision fencing, and an immutable versioned retention-acceptance witness. Unmarked intermediate data-only winners must never be restamped into authority; new pending/checkpoint writers cannot mint the verified witness; unknown commit outcomes must reconcile the exact persisted winner. Then wire saved starts preserving ordinary policy, shedding, per-artifact keys and duplicate provenance. T050/T051, T045/other story gates, duplicate-semantics deletion/guards, final current host/Studio, full review/required checks, resulting-main verification and third ADR0063 PR remain open. Orleans/task-runner remain deferred. The end-to-end goal remains active.


## #2892 6422956659 elsa-workflows-codex[bot] 2026-10-26T17:32:26Z
T049 verified cohort installation is delivered at `913b7450fe670a83e75ddb34550edcb6e06adae1` on the existing branch/sole draft #3338. Existing Codex claim continues; main remains integrated through `2fd983021`. **T049 remains open; saved-start dispatch and publisher activation remain disabled.** [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/913b7450fe670a83e75ddb34550edcb6e06adae1/specs/1006-bpmn-library-adoption/evidence/broadcast-cohort-acceptance.md).

Both native providers now install the whole cohort and retention witness on the actual source row under canonical ordinary capture, real renewable root/closure grants, actual material fencing and reciprocal execution-ownership/deletion fencing. Full publisher pins, current source scope/owner/fence/deadline and exact execution dependencies are checked. Native coalescing uses physical committed publisher state; EF uses an owned transaction and acceptance-scoped references. Older unmarked winners refuse restamping, pending/checkpoint/atomic follow-ups cannot mint witnesses, and an unknown actual committed outcome reuses the exact winner after reference retirement.

Final restored whole checks: Runtime **2875 passed/0 failed/0 skipped**, Runtime EF **1218/0/0**;9 new Runtime and36 provider cases;18 behavioral mutations detected/restored;Core API+8/0 removals;frozen authoring unchanged. Runtime2864 discovery entries expand3 unchanged deferred theories to14 (2864−3+14=2875); EF1218 listed; every TRX result maps. All three component source and final-receipt reviews are clean. Review fixes cover stale EF winner replay, a foreign-scope reader sharing the context, atomic follow-up witness minting and the public selector failure boundary. Initial whole-Runtime failures exposed two old fixtures; actual publisher material/returned winner and exact original constructor preservation are now checked. Full-PR rounds remain **0**, with six total as the eventual bound.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verifies #2735/#3338 In Progress/Assigned/Partial and parity #3335 Done/Complete/Passed as elsa-workflows-codex[bot]. No state reset/no-op field updates were needed. The App already has organization Projects access; explicit project tokens request organization_projects=write. No additional owner access grant is needed.

Next: saved-start admission preserving ordinary policy, shedding, original per-artifact keys and duplicate provenance, plus final GC composition. T050/T051, T045/other stories, duplicate-semantics deletion/guards, final current host/Studio, full review/exact-head required checks/resulting-main verification and third ADR0063 PR remain open. This receipt is actual provider/DI/GC evidence, not upgraded-host/Studio or production acceptance. #2898/#2907/program remain open; Orleans/task-runner stay deferred. The end-to-end program goal remains active.


## #2892 6423599779 elsa-workflows-codex[bot] 2026-10-26T18:03:08Z
Saved-start admission is delivered at `15e89eae6de56d2c7fe62d4293ffd588cd7a5414` on the existing Codex branch/sole draft #3338. **T049 final GC composition remains open; publisher activation remains disabled.** [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/15e89eae6de56d2c7fe62d4293ffd588cd7a5414/specs/1006-bpmn-library-adoption/evidence/broadcast-saved-admission.md).

The ordinary dispatcher now reads the physical current source/claim and verified cohort before even duplicate lookup, validating exact captured binding, original artifact-scoped key, complete pin and published-root scope/authority. It preserves ordinary policy/options/shedding and actual winning duplicate provenance. Source checks repeat after awaited policy, duplicate and actor lookups. Admitted queued commands remain usable after actual source ACK/publisher deletion under retained handoff roots; their handler does not require an obsolete delivery claim. A lossy malformed-UTF-16 command refuses rather than silently changing saved metadata. Original constructors and ordinary wire remain intact.

Final restored checks: Runtime **2875/0/0**, Runtime EF **1317/0/0**;99 new provider admission cases;focused130;14 behavioral mutations detected/restored;Core API declarations+0/0;frozen authoring unchanged. Runtime2864−3 deferred+14=2875 and EF1317 discovery match every TRX result. All three source/final-receipt reviews are clean. Full-PR rounds remain0. Recording actors and an in-memory queued-handler control are finite provider/admission evidence, not actual host or fresh durable process recovery.

CI on prior pushed `913b7450f` failed its configured retries for Core implementation shape (`RuntimeChildControlContext`), DispatchWorkflow behavioral output/outcome drives, outbox-family readability expectations, and the runtime export/import probe's suspended waited parent (run40369434902). These are branch-owned merge blockers to repair next; local passes do not override them. The existing GitGuardian incident38996611 flags an older receipt's public source SHA256 and remains unresolved. No protection/check is bypassed.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) was freshly verified as the Codex App: #2735/#3338 In Progress/Partial; parity #3335 Done/Passed. No field reset/no-op mutation was needed. Next: repair those CI gates, finish T049 GC composition, then T050 immutable input projection/exact bookmark admission/schema activation and T051 actual host/fresh-provider recovery. T045/other stories, duplicate-semantics deletion/guards, final current host/Studio, whole-PR review/exact-head checks/resulting-main and third ADR0063 PR remain open. #2898/#2907/program production acceptance remain open; Orleans/task-runner remain deferred. The end-to-end goal remains active.


## #2892 6424116761 elsa-workflows-codex[bot] 2026-10-26T18:27:47Z
Observed adoption CI repairs pushed at `334541128ff2c1670dc08098ccb1fa01affbca11` on the existing sole draft #3338. [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/334541128ff2c1670dc08098ccb1fa01affbca11/specs/1006-bpmn-library-adoption/evidence/adoption-ci-repair.md). **Local repairs pass; exact new-head remote CI is pending.**

The Core callback envelope is a sealed non-positional record preserving its constructor/getters and explicit live-handle boundary, with bounded diagnostics and seven tracked generated API members. Readability tests independently require predecessor1.0.0 and current outbox2.0.0. Actual tracing diagnosed `AcceptedButFaulted` parent resumes caused by missing Events in two manual fixture compositions, although production DispatchWorkflow already declares that dependency. Both fixtures now compose/reference Events; assertions and forbidden Design/Publishing assembly checks remain intact. Two consumer lockfiles add only the two project entries and preserve every existing package/version/hash/dependency.

Final local whole-suite results: Behavioral **215/0/0**, Publishing **61/0/0**, Readability **117/0/0**, BPMN **297/0/0**, DispatchWorkflow **339/0/0**, targeted Core implementation-shape **1/0/0**. Final locked restores pass for Behavioral and Publishing including ExecutionProbe. All three component source/final-receipt reviews are clean; full-PR rounds remain0. Frozen authoring fingerprint unchanged. The fresh export/import process proves only its existing ordinary waited-parent/child scenario, not upgraded-host broadcast or Studio acceptance.

CI on superseded15e89eae6 also reproduced the branch-owned failures (run40374074664); these new changes must pass remotely before being called repaired in CI. GitGuardian incident38996611 still flags an older public source digest; no check/protection is bypassed. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified: #2735/#3338 In Progress/Partial; #3335 Done/Passed; no no-op field mutation needed.

Next: verify this head's CI while finishing T049 final GC composition, then T050 immutable input/exact bookmark/schema activation and T051 actual host recovery. Other story evidence, deletion/guards, final current host/Studio, full review/exact-head checks/resulting-main and the third ADR0063 PR remain open. #2898/#2907/program production acceptance stay open; Orleans/task-runner deferred. End-to-end goal active.


## #2892 6424506845 elsa-workflows-codex[bot] 2026-10-26T18:46:30Z
T049 template-reachability/ordinary-composition increment pushed at `48d15bc1c256f1ee470766bf87686d1847815f64` on sole draft #3338. [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/48d15bc1c256f1ee470766bf87686d1847815f64/specs/1006-bpmn-library-adoption/evidence/broadcast-template-reachability.md). **T049 native atomic template coordination and qualified cohort-aware default GC remain open; publication stays disabled.**

GC now follows template provenance on nested workflow boundary nodes as well as wrapper metadata, then present templates' local metadata and exact direct/closed identities. Invalid exact dependencies retain the whole sweep; valid inlined imports do not need the original template store. Both default DI registrations explicitly preserve ordinary template cleanup and report cohort retention unsupported while the protocol is dormant. This fixes the longest-constructor selection regression without claiming the unfinished template safeguard qualifies production.

Final restored whole projects: Runtime **2895/0/0**, Runtime EF **1317/0/0**;20 new Runtime cases;focused41;8 behavioral mutations red/restored;Core API0/0;frozen authoring unchanged. Every discovered method maps to TRX; Runtime2884−3+14=2895;EF1317. Controls cover nested/template-local/mixed/shared closure, final-root cleanup, invalid exact identities, legitimate inlined absence and both actual native DI orders. Three component source/final-receipt reviews are clean; full-PR rounds remain0. No new EF template-lifecycle or upgraded-host/Studio qualification is claimed.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified as the Codex App: #2735/#3338 In Progress/Partial; #3335 Done/Passed; #2892 In Progress/Partial; #2898 Blocked/Partial; #2907 Todo/Not Assessed. No no-op board mutation needed. The App already has organization Projects permission; the reduced installation-token path now requests Projects write when maintaining the board. No new owner grant is needed.

Next: native conditional template/reference collection with actual writer participation, then qualified default GC; after T049, T050 immutable input/exact bookmark/schema activation and T051 real-host/fresh-provider recovery. Other stories, duplicate-semantics deletion/guards, final current host/Studio, full review/checks/resulting-main and the third ADR0063 PR remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.


## #2892 6425165628 elsa-workflows-codex[bot] 2026-10-26T19:18:41Z
T049 native template material/reference maintenance pushed at `9be5b0a01509bf59222a6074c5311191c1e42ec9` on sole draft #3338. [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/9be5b0a01509bf59222a6074c5311191c1e42ec9/specs/1006-bpmn-library-adoption/evidence/broadcast-template-native-maintenance.md). **EF coordination, production-writer adoption and qualified default GC remain unfinished T049 work; publisher activation stays disabled.**

Four additive default-refusal methods on the existing template writer expose exact native ownership, atomic template/reference save and conditional reference/material collection. The explicit native factory uses the actual artifact→template→reference gates; physical workflow and parent-template dependencies retain material. Reference deletion compares its whole snapshot; template deletion requires its exact current identity and no remaining references. No fake template/workflow guard or second cleanup ledger. Raw saves retain inert parent-first staging; the new atomic publication path checks exact dependencies and cannot restore retirement/extend expiry.

Review and whole testing fixed two defects before delivery: malformed source IDs could initially leave template material after a refused reference save; and greedy singleton constructor selection could capture scoped persistence replacements. Front-loaded validation and an explicit factory/private bound constructor preserve no-partial-write and ordinary DI behavior. Their negative/positive controls went red then green.

Final restored whole checks: Runtime **2926/0/0**, Runtime EF **1318/0/0**, targeted Core shape **1/0/0**; maps check passes;31 new native controls plus1 actual native cohort-GC bridge case housed in the EF project;16 behavioral/lifetime mutations detected/restored;Core API+4/0;frozen authoring unchanged. Discovery Runtime2915−3+14=2926 and EF1318 matches every TRX result. The native bridge covers Delivering and Delivered with absent target, sticky target retirement/eventual two-sweep cleanup, and unrelated template cleanup. The EF project pass does **not** qualify new EF template coordination, fresh durable process or host/Studio recovery. Three source/final-receipt reviews clean; full-PR rounds0.

Prior template-reachability head48d15bc1c passed remote Build & test, architecture and maps in [run40380644671](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40380644671). New-head CI must still pass; Full tier has not run on this draft. Existing GitGuardian incident38996611 flags an older public source digest; no protection/check bypass. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified as the Codex App with the existing Projects permission: #2735/#3338 In Progress/Partial; #3335 Done/Passed; #2892 In Progress/Partial; #2898 Blocked/Partial; #2907 Todo/Not Assessed. No no-op field mutation was needed.

Next: EF conditional template/reference maintenance with actual referencer/reference writer participation; integrate publication/draft-test handoffs preserving existing authoring/state compatibility, then qualify default cohort GC. T050 immutable input/exact bookmark/schema activation, T051 actual host/fresh-provider recovery, T045/other stories, duplicate-semantics deletion/guards, final current host/Studio, full review/exact-head checks/resulting-main and third ADR0063 PR remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.


## #2892 6426022006 elsa-workflows-codex[bot] 2026-10-26T20:01:41Z
T049 EF template writer-fence increment pushed at `3dc906859adabecde538d07b7d29dbba0c54f818` on sole draft #3338. [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/3dc906859adabecde538d07b7d29dbba0c54f818/specs/1006-bpmn-library-adoption/evidence/broadcast-template-ef-writer-fences.md). **Conditional EF maintenance, complete publication/draft-test handoffs and qualified default GC remain open; publisher activation stays disabled.**

New workflow/parent-template referencers and source creation stage native template revision touches in the same transaction as their write. Publication adoption also fences the actual source row, preserving winning payload/incarnation while advancing coordination revisions. Canonical template/hash-claim physical keys validate projections before optional absence. Publication captures/rebinds one scope per operation and refuses mixed scopes before effects. No schema, Core API or cleanup-ledger addition; raw inert staging and inlined-import compatibility remain.

Review/testing fixed projection-based false absence, shared-context/different-scope publication, and an inappropriate raw-I/O exception assertion. Actual SQLite post-SQL failure now asserts contextual domain wrapping/cause and rollback. Schema-skew assertions are distinct from malformed data. The interrupted-publication retry control requires exact+1 coordination revisions while strengthening byte-exact winning payload/incarnation preservation.

Final whole checks: Runtime EF **1363/0/0**, Publishing EF **161/0/0**, Publishing API **863/0/0**, Publishing **61/0/0** (2448total);45 new actual SQLite cases;18 behavioral mutations detected/restored;maps pass;Core API0/0;frozen authoring unchanged. Discovery/TRX reconcile: API843−5+25=863;otherprojects list/execute exactly. Three source/final-receipt reviews clean; full-PR rounds0.

The stale template delete uses a real EF CAS against an older physical snapshot, not the future conditional maintenance method. The source-adoption conflict advances actual SQL in the same owned transaction, not a peer/process. No upgraded-host/Studio/production recovery claim follows. EF maintenance methods still use unsupported defaults. Writer participation/quiescence and activation guards remain required before reclamation/publication is enabled.

Prior native-maintenance head9be5b0a01 passed remote Build & test, architecture and maps in [run40385441056](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40385441056). New head needs its own checks; Full tier has not run on the draft. GitGuardian incident38996611 remains an older public source-digest finding; no check/protection bypass. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified via the Codex App: #2735/#3338 In Progress/Partial; #3335 Done/Passed; #2892 In Progress/Partial; #2898 Blocked/Partial; #2907 Todo/Not Assessed. No no-op field mutation needed.

Next: conditional EF template/reference collection using these writer fences, actual GC-wins admission controls, complete handoffs and qualified default cohort GC; then T050 immutable input/exact bookmark/schema activation and T051 actual host/fresh-provider recovery. T045/other stories, duplicate-semantics deletion/guards, final current host/Studio, full review/exact-head checks/resulting-main and third ADR0063 PR remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.


## #2892 6426689838 elsa-workflows-codex[bot] 2026-10-26T20:34:21Z
T049 conditional EF template maintenance pushed at `836e9851a43eec7cf387cc828fcdbf7b68143dce` on sole draft #3338. [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/836e9851a43eec7cf387cc828fcdbf7b68143dce/specs/1006-bpmn-library-adoption/evidence/broadcast-template-ef-maintenance.md). **EF atomic save/reference handoffs, complete production writers and qualified default GC remain open; publication stays disabled.**

The coherent EF provider now conditionally collects doomed template source references and reader-observed material through existing native revision/incarnation CAS. It validates physical template/hash-claim ownership, unchanged source snapshot/liveness, workflow/parent-template referencers and complete checked reference pages before its own transaction. Peer commits invalidate its captured version; a CAS loss refuses without stale-discovery retry. Checked scope paging prevents contradictory projections from becoming false absence. Ambiguous workflow/template IDs retain material. Actual reader observations distinguish identical recreation and serialized copies without schema/API/ledger additions; caller pending writes/local/enlisted/ambient transactions refuse before tracker cleanup.

Final whole checks: Runtime EF **1404/0/0**, Publishing EF **161/0/0**, Publishing API **863/0/0**, Publishing **61/0/0** (2489total).40 new conditional SQLite cases plus1 added EF collector case;42focused;18 valid behavioral mutations detected/restored;12sourcebindings;maps pass;Core API0/0/schema unchanged/frozen authoring unchanged. Discovery/TRX reconcile all results;API843−5+25=863. Three final source/receipt reviews clean; full-PR rounds0. Review/testing fixed tracker collisions, scope-projection false absence, ambient/enlisted ownership and stale catalog descriptions.

Six cases use a real second EF context committing after discovery and **before collector transaction start**. No held-write-transaction peer progress is claimed. Reverse GCwins removes an exact child then actual parent publication refuses without partial root; valid recreation permits retry. Real post-SQL/precommit SQLite failure rolls back and retains contextual cause. The actual cohort-GC scenario runs native and EF: unrelated cleanup; Delivering retention; Delivered/absent-target retention after publisher deletion; eventual cleanup only after sticky target retirement. This is provider/collector evidence, not upgraded-host, Studio or production recovery proof.

Parent3dc906859 passed remote Build & test, architecture and maps in [run40391898125](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40391898125). New head requires its own checks; draft Full tier has not run. GitGuardian incident38996611 still flags an older public source digest; no protection/check bypass. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified via the Codex App: #2735/#3338 In Progress/Partial;#3335 Done/Passed;#2892 In Progress/Partial;#2898 Blocked/Partial;#2907 Todo/Not Assessed. No no-op mutation needed. Existing organization Projects permission and the helper's Projects-write token path suffice; no new owner grant is needed.

Next: EF atomic SaveWithReference admission, complete publication/draft-test handoffs, old-writer/quiescence gates and qualified default cohort GC. T050 immutable input/exact bookmark/schema activation, T051 actual host/fresh-provider recovery, T045/other stories, duplicate-semantics deletion/guards, final current host/Studio, full review/exact-head checks/resulting-main and third ADR0063 PR remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.


## #2892 6427016833 elsa-workflows-codex[bot] 2026-10-26T20:50:41Z
T049 atomic EF template/live-reference admission pushed at `05b0efd4b093da8bf4f7aa85b89d803d41aa5385` on sole draft #3338. [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/05b0efd4b093da8bf4f7aa85b89d803d41aa5385/specs/1006-bpmn-library-adoption/evidence/broadcast-template-ef-atomic-admission.md). **Production publication/draft-test handoffs, old-writer/quiescence gates and qualified default GC remain open; saved publication stays disabled.**

SaveWithReferenceAsync now reuses the existing EF Runtime publication transaction/staging in strict mode. It validates the actual physical source row and complete source identity/sidecars/expiry, returns the persisted winning payload, refuses retirement restoration/expiry renewal, and rechecks liveness after awaited reads and before SaveChanges/commit. Exact dependencies and native template/source CAS share the unit. One captured scope is reused for the call; later units capture fresh scope. Caller pending writes/local/enlisted/ambient transactions refuse. Contextual provider/IO/unrequested-cancellation failures preserve their cause; requested cancellation propagates. Existing phase-one CommitAsync retains its legacy boolean mode until caller migration.

Final whole checks: Runtime EF **1448/0/0**, Publishing EF **161/0/0**, Publishing API **863/0/0**, Publishing **61/0/0** (2533total);43 new actual SQLite cases plus1 constructor-signature witness;44focused;16 valid behavioral mutations detected/restored;14bindings;maps pass;Core API0/0/schema unchanged/frozen authoring unchanged. Discovery/TRX reconcile every execution;API843−5+25=863. Three final source/catalog/receipt reviews clean; full-PR rounds0.

Parent836e9851a passed remote Build & test, architecture and maps in [run40396760674](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40396760674). New head requires its own checks; draft Full tier skips are not qualification. GitGuardian incident38996611 remains an older public source-digest finding; no check/protection bypass. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified via the Codex App: #2735/#3338 In Progress/Partial;#3335 Done/Passed;#2892 In Progress/Partial;#2898 Blocked/Partial;#2907 Todo/Not Assessed. No no-op board mutation needed. Existing organization Projects permission and Projects-write token path suffice; no new owner grant is needed.

Next: actual production publication/draft-test handoffs, old-writer exclusion and qualified default cohort GC. T050 immutable input/exact bookmark/schema activation, T051 actual host/fresh-provider recovery, T045/other stories, duplicate-semantics deletion/guards, final current host/Studio, full review/exact-head checks/resulting-main and third ADR0063 PR remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.


## #2892 6427268193 elsa-workflows-codex[bot] 2026-10-26T21:03:34Z
T049 production EF publication handoff pushed at `9ac6bd18e3a7c40f9c3e44e25cf2fc74dc4953f7` on sole draft #3338. [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/9ac6bd18e3a7c40f9c3e44e25cf2fc74dc4953f7/specs/1006-bpmn-library-adoption/evidence/broadcast-template-ef-production-handoff.md). **Activity draft Test Run handoffs, native/default composition, old-writer exclusion and qualified cohort GC remain open. Saved publication stays disabled.**

Both actual EF publication commands already share EfActivityPublicationRuntimeCommit. Its public phase-one method now invokes the qualified strict mode with the selected template provider's clock, while preserving its boolean creation result. Complete live reference/source payload/expiry, physical source lookup, exact dependencies and native source/material CAS share that unit. The shared caller-state check now also protects public phase-one calls before tracker cleanup. No parallel transaction protocol or caller-side split write is added.

Final whole checks: Runtime EF **1450/0/0**, Publishing EF **171/0/0**, Publishing API **863/0/0**, Publishing **61/0/0** (2545total);12 new actual SQLite cases;3 behavioral mutations detected/restored;14bindings;maps pass;Core API0/0/schema unchanged/frozen authoring unchanged. Every discovered method maps to TRX;API843−5+25=863. Three final source/catalog/receipt reviews clean;full-PR rounds0.

Ten multi-context cases exercise both actual production commands: expired/changed-expiry/changed-layout roots refuse before Design/receipt effects, preserving actual source payload and no partial template/hash claim; caller pending writes/local Runtime transactions survive refusal. Two public phase-one clock cases advance only the selected FakeTimeProvider during an actual material read: a system-live/provider-expired source refuses with noSave, while a valid twin commits once. Review identified this missing claim-specific control; replacing provider clock with wall time is now a detected mutation. Existing positive/interrupted-publication/idempotency cases also pass. This is finite provider/command evidence, not process-kill, upgraded-host, Studio, broadcast-host or production recovery proof.

Parent05b0efd4b CI [run40399138717](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40399138717) was still running at final preparation; new source needs its own exact-head checks. Draft Full tier skips are not qualification. Older GitGuardian public source-digest incident38996611 remains unresolved; no check/protection bypass. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified as the Codex App: #2735/#3338 In Progress/Partial;#3335 Done/Passed;#2892 In Progress/Partial;#2898 Blocked/Partial;#2907 Todo/Not Assessed. No no-op mutation needed; existing Projects permission/write token path suffices.

Next: replace ActivityDraftTestRunService's split template/reference write with an actual winning atomic handoff preserving authoring/state compatibility; qualify native bindings/default cohort GC and old-writer/quiescence gates. T050 immutable input/exact bookmark/schema activation, T051 actual host/fresh-provider recovery, T045/other stories, duplicate-semantics deletion/guards, final current host/Studio, full review/exact-head checks/resulting-main and third ADR0063 PR remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.


## #2892 6428007665 elsa-workflows-codex[bot] 2026-10-26T21:41:02Z
T049 atomic Test Run template roots/coherent native binding pushed at `718528bdc9d1548ad5479a3f1e3c44fb7a43ec82` on sole draft #3338. [Source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/718528bdc9d1548ad5479a3f1e3c44fb7a43ec82/specs/1006-bpmn-library-adoption/evidence/broadcast-draft-template-handoff.md). **Wrapper artifact/source retry and provider lease fencing, EF service recovery, old-writer exclusion and qualified default cohort GC remain open. Saved broadcast publication stays disabled.**

Default native DI now owns actual workflow/template/source stores as one internal singleton group. Aliases share that state across scopes; separate root providers have separate storage. The source fences the actual native artifact store, and templates bind that tuple and selected clock. Factories do not capture selected scoped replacements. Exact descriptor ownership includes the group and aliases; EF removes/excludes all of them.

Activity draft Test Runs replace split template save/reference creation with atomic admission and its actual winning reference. Material stays content-addressed; each durable run owns a stable expiring template root keyed by receipt identity+template hash, with fixed receipt expiry. New runs cannot borrow older expiry/source/layout, and retry cannot restore retirement or renew expiry. Legacy hash-only rows are left intact; already-prepared receipts keep saved artifact/source IDs. No execution-checkpoint writer is deleted here.

Final whole checks: Runtime **2940/0/0**, Runtime EF **1454/0/0**, Publishing EF **171/0/0**, Publishing API **875/0/0**, Publishing **61/0/0** (5501total).30newcases:14nativeRuntime,4EFregistration,12nativeAPI;13valid behavioral mutants detected/restored;21bindings;maps pass;CoreAPI0/0/schema unchanged/frozen authoring file unchanged. Discovery/TRX reconcile Runtime2929−3+14=2940 andAPI855−5+25=875; others list/execute exactly. Three final source/catalog/receipt reviews clean;full-PR rounds0.

Parent9ac6bd18e passed remote Build & test, architecture and maps in [run40401030977](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40401030977). New head requires exact-head checks; draft Full tier skips are not qualification. GitGuardian still fails on older public source-digest incident38996611; no bypass. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified as the Codex App: #2735/#3338 In Progress/Partial;#3335 Done/Passed;#2892 In Progress/Partial;#2898 Blocked/Partial;#2907 Todo/Not Assessed. No no-op board mutation needed; existing Projects permission/write token path suffices.

Next: complete actual wrapper/source handoff, idempotent retry and provider lease fencing with EF service recovery; qualify default cohort GC and old-writer/quiescence gates. T050 immutable input/exact bookmark/schema activation, T051 actual host/fresh-provider recovery, T045/other stories, duplicate-semantics deletion/guards, final current host/Studio, full review/exact-head checks/resulting-main and third ADR0063 PR remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.


## #2892 6428870819 elsa-workflows-codex[bot] 2026-10-26T22:30:27Z
T049 provider prerequisite pushed at `de716aebf2b2054ef6c4cbf969c43f339251a27e` on sole draft #3338: [fenced executable source-root writer receipt](https://github.com/elsa-workflows/elsa-foundation/blob/de716aebf2b2054ef6c4cbf969c43f339251a27e/specs/1006-bpmn-library-adoption/evidence/broadcast-source-root-writer.md).

The additive native/EF port creates or adopts an immutable live source root under complete material-pin, closure and current native grant fencing. It returns the persisted winner, preserving source payload and expiry. Source attribution is independent of deduplicated material's producer metadata; ArtifactId joins them while the physical pin is checked separately. Legacy providers refuse without an unfenced fallback. Native fencing samples grants after the actual source-gate wait. EF captures scope, refuses pending caller state/transactions, uses existing coordination/source CAS and owned transaction, and rechecks source/grant expiry before Save and commit. Original CLR constructors remain; Core API +2/0; schema unchanged.

Final checks: Runtime **2971**, Runtime EF **1505**, Publishing EF **171**, Publishing API **875**, Publishing **61** passed, all zero failures/skips (**5583 total**).82new provider cases;26valid behavioral mutations caught/restored;17 source bindings; discovery/TRX reconcile; maps pass; frozen authoring unchanged. Three final independent component source/catalog/receipt reviews are clean; full-PR review rounds remain0.

Actual native controls include gate-wait expiry and both zero-grace GC race orders. SQLite controls include peer writes after discovery before the owned transaction, post-SQL rollback/expiry and committed-transaction acknowledgement loss with fresh-context retry preserving one winning source. These prove provider operations. **Test Run caller integration, actual winning wrapper provenance, EF service recovery, old-writer exclusion and qualified default cohort GC remain open. Saved broadcast publication stays disabled. No upgraded-host/Studio qualification is claimed.**

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified with the Codex App: #2735/#3338 In Progress/Partial; #3335 Done/Passed; #2892 In Progress/Partial; #2898 Blocked/Partial; #2907 Todo/Not Assessed. No no-op board mutation needed. Existing organization Projects permission and the write-scoped installation-token path suffice; no additional access grant is needed.

Next: integrate the actual Test Run wrapper/source handoff using unique invocation leases and persisted winning material/source, then prove service retry and qualify default GC/old-writer gates. T050/T051, other story gates, final current host/Studio, duplicate-semantics deletion/guards, full-PR review/exact-head checks/resulting-main and ADR0063 remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.


## #2892 6429274578 elsa-workflows-codex[bot] 2026-10-26T22:55:43Z
T049 native Test Run wrapper/source handoff pushed at `ee475bfafaebfb87aec134a69b0de46ab673dc40` on sole draft #3338: [source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/ee475bfafaebfb87aec134a69b0de46ab673dc40/specs/1006-bpmn-library-adoption/evidence/broadcast-draft-wrapper-handoff.md).

Actual Test Run preparation now preflights selected template and executable-source capabilities before template writes, reads/validates the persisted wrapper's full payload/provenance after immutable save, and uses its actual full physical pin for renewable lease fencing. Every invocation owns a distinct lease ID. The source provider atomically fences complete current grants and returns its immutable winner; source identity/expiry stay receipt-stable. Original 20-argument CLR constructor remains; additive constructor receives the selected coordinator. Already-prepared receipts continue saved identities.

New public documented Publishing Core storage exception preserves TestRunId and the exact original raw/contextual/aggregate failure; requested cancellation remains unchanged. Review corrected that boundary and added owning Core/API analyzer ledgers. Actual baseline builds against parent source verify **1210 existing Core declarations +3 additions** and **1845 existing API declarations +1 constructor**, zero removals. The baseline declarations are existing surface. Runtime Core ledger/schema and frozen authoring are unchanged.

Final checks: Runtime **2971**, Runtime EF **1505**, Publishing EF **171**, Publishing API **891**, Publishing **61** passed, all zero failures/skips (**5599 total**); API tracking guards **5/0/0**; both locked restores, Core/API Release build and maps pass.16 new native service cases, 32 focused; 8 valid behavioral mutants caught/restored; 31 direct source bindings plus parent API baseline hashes. Three independent final component source/catalog/receipt reviews clean; full-PR rounds remain 0.

Real concurrent native preparations prove that releasing the first writer does not remove the second writer's stored grant: an actual deletion guard remains refused. Retry probes preserve one source winner/fixed expiry. Distinct-run controls verify actual stored metadata+descriptor provenance; sourceReferenceId is already part of the existing descriptor hash, so no hash/placement algorithm change was needed. A coherent earlier-contract source facade is refused before material writes. Constructed material conflicts and injected coordinator errors remain finite native controls. Recording dispatch deliberately loses acknowledgement without workflow execution.

Parent `de716aebf` passed Build & test/architecture/maps in [CI 40412865969](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40412865969). New head needs exact-head checks; draft Full tier skips are not qualification. Older public-source-digest GitGuardian incident 38996611 still fails; no bypass. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified as the Codex App: #2735/#3338 In Progress/Partial ; #3335 Done/Passed ; #2892 In Progress/Partial ; #2898 Blocked/Partial ; #2907 Todo/Not Assessed. Existing Projects access/write-token path suffices; no no-op mutation or new grant needed.

Next: actual fresh-EF Test Run service recovery and source transaction acknowledgement-loss controls, then old-writer/quiescence and qualified default GC gates. T050/T051, other stories, duplicate-semantics deletion/guards, final current host/Studio, full-PR review/exact-head checks/resulting-main and ADR0063 remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.


## #2892 6429507729 elsa-workflows-codex[bot] 2026-10-26T23:10:53Z
T049 SQLite Test Run service preparation/recovery controls pushed at `d39a99298a174711f2c549793bc12649ded36e19` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/d39a99298a174711f2c549793bc12649ded36e19/specs/1006-bpmn-library-adoption/evidence/broadcast-draft-wrapper-ef-service.md).

The real Test Run service now has controls over three separate actual Design/Runtime/Publishing receipt SQLite databases, opening fresh contexts for retries and verification. A source-targeted failure before SaveChanges rolls back its owned fence transaction; actual TransactionCommitted acknowledgement loss leaves a durable source and a Preparing receipt. Fresh retry converges to one source, preserving exact winning bytes/incarnation and fixed receipt expiry. An actual ordinary zero-grace collector between failure and retry collects the unrooted wrapper or retains the committed wrapper/template. Additional controls prove later-run provenance, no restoration after peer retirement, and rollback/no expiry renewal after source expiry following actual SQL.

Final Publishing EF suite: **176 passed, zero failed/skipped** (five new cases); focused **5/0/0**. Three valid behavioral mutations caught and exact production source restored; 25 source bindings; discovery 176/TRX 176 reconcile (174 unique display names); maps pass; API/schema/frozen authoring unchanged. Three independent final component source/catalog/receipt reviews clean; full-PR rounds remain 0. No production implementation changes in this increment; other suites' preceding results remain historical rather than being restamped.

**Limits:** compiler is a fixed valid template fixture. Dispatcher records/fails without executing a workflow, and test-scope/workflow/activity execution-state stores are in-memory. This proves durable Design/material/source/receipt preparation and retry through the service. It does not prove process-kill, upgraded-host, complete Runtime execution-state, Studio or other relational-provider recovery. The collector explicitly has no stimulus-delivery retention support; ordinary root collection does not qualify default cohort installation.

T049 remains open for old-writer/quiescence and qualified default cohort GC; saved broadcast publication remains disabled. Next: finish those guards and composition. T050/T051, other story gates, duplicate-semantics deletion/guards, final current host/Studio, full-PR review/exact-head checks/resulting-main and ADR0063 remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.

Parent `ee475bfaf` passed Build & test, architecture and maps in [CI 40416064967](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40416064967); new head needs its own exact-head checks. Draft Full tier skips are not qualification. Older public-source-digest GitGuardian incident 38996611 remains unresolved; no bypass. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified as the Codex App: #2735/#3338 In Progress/Partial; #3335 Done/Passed; #2892 In Progress/Partial; #2898 Blocked/Partial; #2907 Todo/Not Assessed. No no-op board mutation or new access grant is needed.


## #2892 6430659754 elsa-workflows-codex[bot] 2026-10-27T00:29:50Z
T049 physical/default collector composition pushed at `a86c5d08c6705d1bcb278849aa4a86eee3361fe1` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/a86c5d08c6705d1bcb278849aa4a86eee3361fe1/specs/1006-bpmn-library-adoption/evidence/broadcast-physical-gc-composition.md).

Runtime and its recurring pump now share one internal qualified registration factory. The actual native/EF outbox/material/reference/physical-execution tuple must qualify alongside template/source maintenance. Known coalescing/cache decorators are supported while normal operations and shared-cache invalidation stay on the selected store. Native shared material includes all committed source scopes; EF uses checked actual-context/scope discovery and finite physical-ID paging. Delivered source roots survive publisher deletion and absent targets, releasing only after actual sticky target retirement.

Ordinary fallback now requires explicit absence proof over that same physical tuple on every sweep and guarded final read. Missing capability, foreign stores, dirty caller state or protocol/cohort data refuses collection. This fixes two independent review findings: a collector cached during invalid scope access, and empty outbox A incorrectly authorizing collection of owed material B. Actual native/SQLite controls cover both, plus initial-proof-to-final-guard installation races and preserved EF dirty state with clean twins.

Restored affected suites: **5,654 passed, zero failed/skipped** (Runtime 2,971; Runtime EF 1,555; Publishing EF 176; Publishing API 891; Publishing 61); discovery/TRX reconcile. Focused 56/0/0 includes 50 new + 6 existing cases. Architecture/API/friend guards 6/0/0; maps and Runtime Core locked restore pass. Sixteen valid behavioral mutants caught, including omitting only final proof; exact source restored. Three final independent component source/catalog/receipt reviews clean; full-PR rounds remain 0. Core API +4/0, constructor ABI/Publishing ledgers/schema/frozen authoring unchanged.

**Limits/next:** structural GC composition and marked-data ordinary absence proof are qualified. Legacy ambiguity and old-writer/quiescence/incompatible restart remain T049 gates; saved broadcast publication is disabled. Next implement those actual-store guards before T050 activation and T051 fresh-provider/host proof. Other semantic stories, duplicate-semantics deletion/guards, final current host/Studio, full-PR review/exact-head checks/resulting-main and ADR0063 remain open. No legacy checkpoint writer is deleted. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal remains active.

Parent `d39a99298` has green Build & test, Core, architecture, maps, platform-source and Studio checks; draft Full tier skips are not qualification. This new head needs its own required checks. Older public-source-digest GitGuardian incident 38996611 remains unresolved; no bypass. Remote main advanced legitimately to `9e96273c8` (#3385); no competing branch progress was present, and final candidate/host validation must incorporate current main. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified as the Codex App: #2735/#3338 In Progress/Partial; #3335 Done/Passed; #2892 In Progress/Partial; #2898 Blocked/Partial; #2907 Todo/Not Assessed. Its existing organization Projects write access is sufficient; no additional grant or no-op board mutation is needed.


## #2892 6431055347 elsa-workflows-codex[bot] 2026-10-27T00:58:59Z
T049 current-format read-only upgrade preflight pushed at `678a519aebca7ac0e0195ba4a2170ec944152fe2` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/678a519aebca7ac0e0195ba4a2170ec944152fe2/specs/1006-bpmn-library-adoption/evidence/broadcast-upgrade-preflight.md).

Preflight now distinguishes unmarked legacy and scope-only broadcast sends, declared sends awaiting first selection, retention-stamped complete/empty cohorts and prior delivery through the actual checked provider. Owed legacy/scope-only sources still block at attempt zero. A valid Delivered legacy/scope-only source retains its prior settled result; declared Delivered without a cohort and historical data-only cohorts (including Delivered) remain recovery-required. Every checked format inventory says DeliveryActivationQualified=false. No runtime handler, recipient dispatch or ordinary durable-lookup behavior changes.

Fourteen closed constructed SQLite provider-format witnesses are committed with raw/compressed hashes and expected classifications; the actual tool consumer checks all fourteen. These use fixed test payloads and are not actual producer/workflow executions. EF whole suite **1,569 passed, zero failed/skipped** (fourteen new cases), discovery/TRX reconcile. Python checked-provider controls **16 passed** including the fourteen-witness matrix. Five valid classifier mutants caught, exact source restored; maps and tool locked restore pass. Three independent final component source/catalog/artifact/receipt reviews clean; 31 source bindings. Runtime production source/API/schema/frozen authoring unchanged; other suites' parent evidence remains historical. Full-PR rounds remain 0.

Fresh inventories through the normal PowerShell entrypoint: six original captures retain every raw/compressed hash, 33 outbox rows/zero PublishStimulus. The owned running development host at its recorded historical writer revision has ten outbox rows/one valid LegacyDelivered publish. No unresolved legacy send observed in those supplied stores; private host DB is not committed. **This is not quiescent, production-wide or current upgraded-host acceptance.** No actual residual owner decision is needed.

Independent design review rejected an online row-only recovery hold because cleanup may already have passed its final absence check. The reviewed contract requires stopped actors, dispatchers, publishers, GC/retirement and other writers throughout upgrade admission and any required recovery migration, until qualified new binaries resume. Family selection alone is insufficient. No online hold writer/API, fabricated scope or new delivery ledger is introduced. Scope-only generic handlers remain valid.

**Next/open:** actual quiescent zero-legacy-owed admission (or a separately qualified residual recovery migration) remains T049 work before rollout; then T050 saved-recipient router, exact bookmark admission, immutable intent input and publisher activation, followed by T051 actual fresh-provider/host recovery. Other semantic stories, duplicate-semantics deletion/guards, final current host/Studio, full-PR review/exact-head checks/resulting-main and ADR0063 remain open. Library switch has not happened; legacy checkpoint writer stays present. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal active.

Parent `a86c5d08c` has green Build & test; this new head needs its own exact-head checks and draft Full tier skips do not qualify. Older public-source-digest GitGuardian incident 38996611 remains unresolved; no bypass. Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly verified as the Codex App: #2735/#3338 In Progress/Partial, #3335 Done/Passed, #2892 In Progress/Partial, #2898 Blocked/Partial, #2907 Todo/Not Assessed. Existing organization Projects write access is sufficient; no no-op board mutation or additional permission grant is needed.


## #2892 6432194291 elsa-workflows-codex[bot] 2026-10-27T02:24:50Z
T050 exact bookmark admission prerequisite pushed at `482aa79e6a26a96db28f82ed8672222a3ffa5ac9` on sole draft #3338. [Portable source-bound evidence](https://github.com/elsa-workflows/elsa-foundation/blob/482aa79e6a26a96db28f82ed8672222a3ffa5ac9/specs/1006-bpmn-library-adoption/evidence/broadcast-exact-bookmark-admission.md).

Saved resumes can now carry the actual physical wait generation, complete pin/scope/source and immutable registration facts without copying retained payload. Before callback work the queued handler qualifies its actual store tuple and checks live ownership/registration. The initial trigger-claim checkpoint atomically checks the same condition and consumes the wait. Native uses the existing shared write gate; EF uses the selected context/scope and existing revision CAS inside the whole checkpoint transaction. Committed replay wins before retired predicates. Replacement/expired/ineligible waits cause no callback or replacement consumption; recognized authority/storage outages retain identical queued work for delayed retry. Claimed redelivery uses its recorded consumed trigger, leaving a rearmed wait alone. Original constructors, absent-condition wire and historical fingerprints remain compatible; legacy/opaque/mixed providers refuse exact admission. Source-owned publisher routing is still disabled.

**Verification:** whole Runtime **2,990**, Runtime EF **1,623**, Activities Runtime **680**: **5,293 passed, zero failed/skipped**, independent discovery/TRX reconciled, including 89 new cases. Actual provider controls cover SQL rollback after writes, real commit ACK loss/unavailable reconciliation, fresh-context replay, native peer-write races, final deadline checks and active buffered coalescing. Actual native queue/handler/callback controls cover replacement between preflight and claim, missing owners/material, outage retries, claimed redelivery and a Test Run delivery receipt blocked by a real executable deletion guard/root manager then accepted after release. These are component controls, not upgraded-host or Studio proof.

**14 valid behavioral mutants caught and exact source restored**; final restored provider 54/queued 16/wire-bookmark-API-composition 95/architecture 7 all pass. Maps and Runtime Core locked restore pass. Three independent final component source reviews and receipt/catalog audits clean; 38 source bindings. Core API +32/0, persistence schema and frozen authoring unchanged. A separately compiled parent fingerprint writer validates the historical fixture hash. Full-PR review rounds remain 0; the new exact head needs its own CI, eventual full-PR review and required checks. The existing public-source-digest GitGuardian incident remains unresolved; no bypass or merge attempted.

**Next/open:** T050 source-owned complete selection/router and immutable persisted-intent input, actual quiescent admission before activation, then T051 actual fresh-provider/upgraded-host recovery. Remaining semantic stories, duplicate-semantics deletion/guards, final current host/Studio, full-PR loop, merge/resulting-main verification and subsequent ADR 0063 acceptance remain open. Released library adapter stays dormant and the legacy writer remains present. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal stays active.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled using the Codex App: #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. Fields already match current evidence, so no no-op board mutation. The installed App's organization Projects read/write access is sufficient; no additional access grant is needed.


## #2892 6433364028 elsa-workflows-codex[bot] 2026-10-27T03:56:57Z
T050 source-owned routing component pushed at `b5b32cc2a137d2a9b32f70866d5a973848c4e087` on sole draft #3338. [Portable source-bound evidence](https://github.com/elsa-workflows/elsa-foundation/blob/b5b32cc2a137d2a9b32f70866d5a973848c4e087/specs/1006-bpmn-library-adoption/evidence/broadcast-source-owned-routing.md).

The actual native/EF source reader and default router/dispatchers now support complete first-delivery recipient selection, provider-fenced installation and persisted-winner-only retries. Canonical physical intent input, every ordered same-artifact binding, exact saved bookmark conditions, original keys, delayed delivery-time matching, authoritative empty cohorts, local/correlation/Test Run rules and post-actor-lookup source revalidation have controls. A host-neutral registration replaces duplicated API composition. The owning named-event decoder is registered; publisher executor/staging are still unchanged.

**Whole Runtime 3033/0/0, Runtime EF 1649/0/0 and Activities Runtime 695/0/0: 5377 passed, 84 new cases, zero unmatched discovery.** These include 43 native router/default-dispatcher cases, 22 native/SQLite canonical-source cases, 4 actual EF aggregate/fresh-context/coalescing cases and 15 owning adapter cases. Routing fixtures record mailbox acceptance/deduplication and do not prove callback or durable-host recovery. All 13 behavioral mutants caught and exact source restored before whole runs. Locked restore, maps and 12 architecture/API guards pass. Three independent final component reviews and receipt audits are clean; 37 bindings. Core API +13/0; actual parent-source compilation proves Runtime baseline 1872 existing +4 new/0 removed. Persistence schema and frozen authoring unchanged. Full-PR rounds remain 0.

**Next/open:** actual quiescent admission, T050 publisher activation with no old-signature fallback, then T051 actual fresh-provider/upgraded-host recovery. Remaining semantics, duplicate-semantics deletion/guards, final current host/Studio, full-PR review, protected merge/resulting-main verification and later ADR 0063 acceptance remain open. Released BPMN adapter stays dormant; legacy writer remains present. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal stays active.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as the Codex App: #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. Fields match current evidence, so no no-op mutation. The App already has sufficient organization Projects read/write access; no new grant is needed.


## #2892 6433704183 elsa-workflows-codex[bot] 2026-10-27T04:23:49Z
T050 local upgrade-admission transition after pushed routing component `b5b32cc2a`: the verified task-owned legacy Workbench backend and its owning controller are stopped; its port is closed and no handle remains on its disposable database. A coherent private whole-database legacy snapshot is preserved. Provider-checked inventory found 10 outbox rows, one already Delivered legacy broadcast, and zero unresolved publish responsibility. The private database includes identity configuration and will not be published. Existing portable legacy captures and the frozen authoring fingerprint are unchanged.

This qualifies only the observed local writer exclusion/inventory. The database remains offline while the publisher activation candidate is reviewed and tested. It is not production-wide admission, a library switch, upgraded-host recovery or current Studio acceptance. The existing Studio client on localhost:5092 remains running against the temporarily offline task-owned backend; no bystander host was stopped.

Activation is uncommitted work on the existing branch/PR. Review found and fixed source-boundary failure accounting and an early schema-check bypass by later checkpoint enrichment; the final-envelope check uses the shared schema dormancy contract before persistence. Full-PR review rounds remain 0. #3338/#2735/#2892 and project #62 remain In Progress/Partial; production #2898/#2907 stays open. Next is completing component checks, then resuming only qualified candidate binaries against this owned store and proving actual recovery.


## #2892 6434223289 elsa-workflows-codex[bot] 2026-10-27T05:05:25Z
T050 schema-gated publisher activation increment pushed at `b9e98f985ed5e5ee4f046c39b45ad19d10bac269` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/b9e98f985ed5e5ee4f046c39b45ad19d10bac269/specs/1006-bpmn-library-adoption/evidence/broadcast-publisher-activation.md), [owned candidate-host observation](https://github.com/elsa-workflows/elsa-foundation/blob/b9e98f985ed5e5ee4f046c39b45ad19d10bac269/specs/1006-bpmn-library-adoption/evidence/broadcast-publisher-activation-host.json).

The publisher contribution now declares protocol 1 plus required durable context. Normal commit stamps only protocol/scope, never recipients. Shared schema dormancy checks the final enriched envelope before writes, including publication added by a later enricher. Materialized responsibility cannot silently disappear under Skip or mixed-envelope canonical folding. The original intent-only handler refuses; source delivery calls the saved-winner router. Boundary refusal preserves owed claim/history/attempts and repaired retry succeeds; ordinary delivery/shedding retry remains distinct.

**Whole Runtime 3041/0/0, Runtime EF 1649/0/0 and Activities Runtime 720/0/0: 5410 passed.** PostgreSQL source convergence 2/0/0, architecture/API guards 12/0/0, eight valid behavioral mutants caught/restored, zero unmatched discovery. Net 33 added cases: 36 additions replace 3 obsolete projection cases. Nine existing native payload/local-event cases now run actual source→processor→router→default dispatcher→queued callback. Two existing SQLite convergence controls now use committed sources/fenced claims/persisted winners/fresh nodes/actual actors; PostgreSQL passes the same contract. Provider clocks/fleet answers are controlled; actual module gates/shared observations are used. Core API +4/0, 35 minimal lock updates preserve all prior external package records, 339-project Server locked restore and maps pass. Three independent final component reviews and receipt audits clean; 62 source bindings; frozen authoring unchanged. Full-PR rounds remain 0.

**Actual owned-host progress:** the verified legacy backend/controller stopped, listener/database handles were absent, and a coherent private snapshot was preserved. Checked pre-inventory found 10 outbox rows, one settled legacy broadcast and 0 unresolved publishes. The normal candidate then resumed the same database and observed outbox family 2.0.0 through its schema/fleet machinery. Four registered normal-API BPMN scenarios passed; one signal publication completed both committed catches and their parallel join with 0 incidents. Checked post-inventory preserved the settled legacy responsibility and found the new ProtocolDelivered source, whose actual saved cohort has protocol 1/witness1/two captured resumes. This is source/Release-hash-bound uncommitted-candidate evidence, not final-head/main acceptance or the remaining crash/recovery cuts. The private whole DB includes identity configuration and is not published; existing portable legacy captures remain unchanged. Backend 63383 and existing Studio 5092 are running; no bystander was stopped.

**Provenance correction:** prior checkpoint wording calling the released adapter dormant was stale. The candidate registers `BpmnProcessRuntime`, and `BpmnProcess` delegates to it, so candidate BPMN probes already execute released Semantics 0.5.0. The outstanding switch is verified delivery on main together with the remaining acceptance gates. Legacy writer/duplicate semantics remain present.

**Next/open:** T051 actual crash-after-cohort/before-dispatch, partial recipients, ACK/restart/rearm-exclusion cuts; remaining semantics/native-composite proof and historical recovery; duplicate-semantics deletion/guards; final current Studio; full-PR review; exact-head required checks/protected merge/resulting-main verification; then the separate ADR 0063 acceptance PR. T049/T050 overall qualification remains bounded by the outstanding recovery/delivery evidence. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. End-to-end goal stays active.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as the Codex App: #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. Values match evidence, so no no-op field mutation. Existing organization Projects read/write access is sufficient; no additional grant is needed.


## #2892 6434870546 elsa-workflows-codex[bot] 2026-10-27T05:53:17Z
T051 bounded actual-host recovery increment pushed at `8a8d69fe8671b6e75f9212dc35ec902e6362dbd1` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/8a8d69fe8671b6e75f9212dc35ec902e6362dbd1/specs/1006-bpmn-library-adoption/evidence/broadcast-after-cohort-recovery.md), [actual checked host observations](https://github.com/elsa-workflows/elsa-foundation/blob/8a8d69fe8671b6e75f9212dc35ec902e6362dbd1/specs/1006-bpmn-library-adoption/evidence/broadcast-after-cohort-host.json).

An owned source-built Workbench committed the complete first-delivery cohort (one keyed start/two exact signal catches), paused after the actual provider commit, and was killed before dispatch. Checked stopped-state reads proved the original claim and untouched selected waits/start absence. An uninstrumented standard host restarted the same database, waited for the real persisted deadline, and reclaimed the source under a different owner and fence **1 → 2**. A coherent read transaction captured that actual successor claim through the checked provider. The source then became Delivered with the identical saved cohort: both exact catch activities and their parallel join completed; exactly the original deterministic keyed start reached its actual physical park wait. A later binding created no execution; later bookmark IDs/generations/activity facts stayed identical. All four workflow API observations had zero incidents. This is actual source/actor recovery for this cut, not inference from mailbox acceptance or a synthetic state probe.

**Next/open:** partial recipients and actual same-listener rearm exclusion, delayed first delivery, competing/empty cohorts, renew/lost claims, ACK loss/redrive and retention/GC/republish races; remaining semantics/native-composite and historical upgraded-host proof; final current Studio; duplicate-semantics deletion/guards; full PR review, green exact-head required checks/protected merge/resulting-main verification; then separate ADR 0063 acceptance. T051 stays unchecked. #2898/#2907 and program production acceptance stay open; Orleans/task-runner deferred. End-to-end goal remains active.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as the Codex App: #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. Existing organization Projects read/write access is sufficient; no additional grant is needed. Fields still match evidence, so no no-op mutation. New head needs its own required checks; the previously verified public-source GitGuardian incidents still require legitimate resolution. No bypass, history rewrite or merge attempted.


## #2892 6435054419 elsa-workflows-codex[bot] 2026-10-27T06:06:30Z
T051 partial callback/rearm recovery increment pushed at `c5a1e4718fce09168f7e90a860388805c4fe3f32` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/c5a1e4718fce09168f7e90a860388805c4fe3f32/specs/1006-bpmn-library-adoption/evidence/broadcast-partial-resume-recovery.md).

The actual probe host accepts the first saved resume, then normal actor execution must complete that exact child and persist a new physical wait for the same authored listener before termination. Checked stopped state proves the first original child Completed/2 attempts plus its distinct rearm, the other original child Suspended/1 attempt, and the original deterministic keyed start already parked. Standard-host takeover under a different owner and fence **1 → 2** settles the identical source cohort. The first completed activity projection/2 attempts, its exact rearm and the existing keyed park stay unchanged; the remaining original callback advances 1 → 2 attempts and completes. Both later waits stay suspended, a later listener remains untouched, and a later binding creates no execution. All four normal API observations have zero incidents.

**Next/open:** delayed first-delivery inclusion under the settled delivery-time rule; competing/empty cohorts, renewed/lost claims, ACK loss/redrive and retention/GC/republish races; remaining semantics/native-composite and actual historical upgraded-host recovery; final current Studio; duplicate-semantics deletion/guards; full-PR review, exact-head checks/protected merge/resulting-main proof; then separate ADR 0063 acceptance. T051 remains unchecked; full-PR rounds **0**, bound six. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred; end-to-end goal active.

CI refresh found parent `8a8d69fe8` Architecture guards and PR shards 2/3 red. Their concrete logs are being examined; no green-check or merge claim is made. This new head needs its own required checks. The same three verified public-source-digest GitGuardian incidents still need legitimate resolution. No bypass, history rewrite or merge attempted.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as the Codex App: #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. Fields still match evidence; no no-op mutation. Existing organization Projects read/write access is sufficient; no additional grant is needed.


## #2892 6435439635 elsa-workflows-codex[bot] 2026-10-27T06:33:56Z
Supporting CI repair pushed at `3299556ab5e4341c9676e281c0a3264fcfec8e31` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/3299556ab5e4341c9676e281c0a3264fcfec8e31/specs/1006-bpmn-library-adoption/evidence/broadcast-ci-fixture-repair.md).

Concrete parent CI failures were reproduced: the checked recovery reader's lock lacked a Server solution project; four native BPMN message cases and the PublishEvent drive lacked explicit schema qualification; the actual Elsa3 import TestServer lacked the shared schema-readability check. The tool now belongs to the solution. Three native fixtures explicitly opt in through the actual shared check over clearly constructed fresh-native facts; TryAdd preserves caller services and ordinary/shared BPMN-EF fixture defaults remain unqualified. The real import TestServer now composes the same host-wide AddEfSchemaReadability boundary as Workbench, with a new public availability regression. Production Runtime/provider/Activities source and publisher guard behavior are unchanged.

**Whole affected suites: BPMN 297, Behavioral 215, Activities Runtime 720, Elsa3 import 51, Architecture 590: 1,873/0/0.** Focused repair cases **195/0/0** include existing fail-closed controls. The first architecture run had 569 passes/21 missing isolated Debug assets; prescribed Debug/Release setup then full 590 passed. No setup failure is counted as green. The one new test raises import integration 50→51. Default locked restore for **340 Server projects**, dual-config restore and maps pass; all **1,720 existing external records** in 27 minimally updated locks remain unchanged. Existing warnings/frozen authoring unchanged. 36 source/lock bindings; three independent component source/receipt audits clean. Full-PR rounds remain **0**, bound six. The pushed head needs its own CI; local passes are not substituted for required checks.

The actual post-cohort and partial callback/rearm host receipts retain their own source/build bindings. **Next:** delayed first-delivery inclusion under the settled delivery-time matching rule, then remaining T051 competing/empty/renew/lost-claim/ACK/redrive/retention/GC/republish controls. Remaining semantics/native-composite, actual historical upgraded-host recovery, final current Studio, duplicate-semantics deletion/guards, full-PR review, exact-head required checks/protected merge/resulting-main and separate ADR 0063 acceptance stay open. #2898/#2907/program production acceptance remains open; Orleans/task-runner deferred. Goal active. Same three public-source-digest GitGuardian incidents still require legitimate resolution; no bypass, history rewrite or merge attempted.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as the Codex App: #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. Fields match current evidence; no no-op mutation. Existing organization Projects read/write access is sufficient; no additional grant is needed.


## #2892 6435771501 elsa-workflows-codex[bot] 2026-10-27T06:57:11Z
T051 actual delayed first-selection increment pushed at `fe7918bf590914ae748bf7400e96324af07054a0` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/fe7918bf590914ae748bf7400e96324af07054a0/specs/1006-bpmn-library-adoption/evidence/broadcast-delayed-selection-recovery.md).

After the actual canonical committed-source read, the probe pauses before first matching. Only then are another two-catch listener and signal-start binding created through normal APIs. The stopped declared-protocol source still has no cohort; all four prior physical waits are suspended and neither start artifact has executed. A standard host reclaims under a distinct owner and fence **1 → 2**, then selects **both bindings/all four exact prior bookmark IDs and generations**. Both waiter joins complete and each deterministic keyed start is created exactly once. Those starts then wait on the **same published signal**: both matching new waits remain suspended at attempt 1 and outside the source cohort. Source becomes Delivered with its first chosen cohort unchanged; all normal workflow API observations have zero incidents.

**Next:** complete/empty competing snapshots and real stale/renewed claim cuts, partial starts, ACK loss/redrive, same-artifact shedding and retention/GC/republish races/remaining scopes. T051 stays unchecked. Remaining T045 semantics/native-composite, actual historical upgraded-host recovery, final current Studio, legacy writer/duplicate-semantics deletion/guards, full-PR review, green exact-head required checks/protected merge/resulting-main and separate ADR 0063 acceptance stay open. #2898/#2907/program production acceptance remains open; Orleans/task-runner deferred. End-to-end goal active.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as the Codex App: #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. Fields match evidence; no no-op mutation. Existing organization Projects read/write access is sufficient; no additional grant is needed.


## #2892 6436246357 elsa-workflows-codex[bot] 2026-10-27T07:29:16Z
Verified local empty-cohort increment is committed as `44acc05163fe2ac7cbdeb687b2488d6c8c099350`, but its Git push is currently rejected HTTP 403 for `elsa-workflows-codex[bot]`. Last confirmed remote remains `fe7918bf590914ae748bf7400e96324af07054a0`. Four actual host crash modes and eight observer controls pass; three independent component/receipt audits are clean. This is not a pushed-head or merge qualification claim.

Fresh installation-token metadata confirms the correct Codex App (5325076, installation 171582824), repository contents/issues/PR write and organization Projects write. Two fresh Git pushes were denied; branch policy and transport diagnostics are in progress. No personal identity, protection bypass, alternate claim or competing PR is used. Existing claim and end-to-end goal remain active; local commit is preserved. Project 62 needs no additional permission grant. Remaining T051/T045, historical upgrade, final Studio, deletion/full-PR/check/merge/main/ADR and production gates remain open.

## #2892 6438000878 elsa-workflows-codex[bot] 2026-10-27T09:13:43Z
T051 actual durable-empty-cohort recovery pushed at `44acc05163fe2ac7cbdeb687b2488d6c8c099350` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/44acc05163fe2ac7cbdeb687b2488d6c8c099350/specs/1006-bpmn-library-adoption/evidence/broadcast-empty-cohort-recovery.md).

The actual provider commits a nonnull zero-start/zero-resume cohort with version-one retention acceptance. Only afterward do normal APIs create matching waits/binding. The checked reader observes the canonical intent and complete active matching binding index: original two waits differ, later two waits and one active binding match the exact source stimulus and are newer than the marker. After the owned host is killed, the standard binary captures a distinct successor claim/fence **1→2** and settles the identical empty cohort. Both full waiter projections and the entire three-workflow inventory remain unchanged, all four catches stay Suspended/attempt 1, neither artifact starts, and publisher completes without incidents. A saved empty decision is preserved rather than recomputed from newly matching recipients.

**Next/open:** complete/empty competing proposals, real renew/stale-owner and partial-start cuts, ACK loss/redrive, same-artifact shedding, retention/GC/republish races and remaining scopes. T051 stays unchecked. T045 semantics/native-composite, actual historical upgraded-host recovery, final current Studio, legacy writer/duplicate semantics deletion/guards, full-PR review, green exact-head required checks/protected merge/resulting-main and separate ADR 0063 acceptance remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. Goal active. The three public-source-digest GitGuardian incidents still need legitimate resolution; no bypass, history rewrite or merge attempted. This new head needs its own CI, and draft full-tier skips are not qualification.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as the Codex App: #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. Fields still match evidence; no no-op mutation. Existing organization Projects read/write access is sufficient; no additional grant needed.


## #2892 6439066205 elsa-workflows-codex[bot] 2026-10-27T10:08:45Z
T051 actual competing prepared-proposal rejection pushed at `fc5948641590f4f74d79e234a2a3f8f91f5b81d6` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/fc5948641590f4f74d79e234a2a3f8f91f5b81d6/specs/1006-bpmn-library-adoption/evidence/broadcast-competing-proposal-recovery.md).

The old actual Workbench prepares **1 start/2 waits** before cohort installation. After additional matching recipients exist, its owned process is suspended outside both SQLite writers. A standard peer uses the shared runtime/membership databases and lock directory. Actual checked membership proves distinct incarnations, old initially live then naturally expired, peer live. The peer takes source fence **1→2**, saves/delivers its different **2-start/4-wait** winner, completes both exact joins and parks both keyed starts on matching waits excluded from this event.

The old process then resumes and **actually attempts the provider write**, with cancellation **not requested**. The real provider rejects it with `RuntimePostCommitOutboxStaleClaimException` for the exact original source/owner/fence. Complete checked source, workflow observations and inventory remain identical afterward. Cancellation-before-provider does not qualify this case.

**Actual competing case 1/0/0; four actual crash regressions 4/0/0; source/membership reader controls 13/0/0; process ownership/pause/broker controls 10/0/0; cleanup failure controls 3/0/0; whole architecture 590/0/0.** Locked Server restore and map checks pass. All five final cases use separate controllers and identical source/build manifests with **1,376 current source bindings** each; standard binary has no probe. Three independent component source/actual/portable reviews clean; full-PR rounds **0**, bound six. Production source, old external package records and frozen authoring unchanged. Only owned case hosts stopped; private DB/configuration stays local and existing user backend/Studio remain running.

Verification corrected shared-lock startup, stopped-child controller and cross-case temporary configuration mechanics before qualification. Independent review found cleanup could short-circuit; the actual old finally fails its control, fixed failure paths each attempt all owned cleanup and emit a failed receipt. These earlier attempts are not counted as green.

**Next/open:** empty competing decisions, actual renewed claims/partial starts, ACK loss/redrive, remaining scope and retention/GC/republish races. T051 remains unchecked. T045/native-composite, actual historical upgraded-host recovery, final current Studio, legacy writer/duplicate semantics deletion/guards, full-PR review, green exact-head required checks/protected merge/resulting-main and separate ADR 0063 remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. Goal active. Parent 44acc CI Build & test, all PR shards, architecture, Studio/browser/frontend and generated maps passed; GitGuardian remains red on the known public-source-digest incidents. New head needs fresh CI; draft full-tier skips do not qualify. No bypass/history rewrite/merge attempted.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. Existing fields still match evidence; no no-op mutation. Existing organization Projects read/write is sufficient; no additional grant needed.


## #2892 6439265212 elsa-workflows-codex[bot] 2026-10-27T10:17:54Z
T051 actual empty prepared loser/populated saved winner pushed at `3c5f2830ead8256e1750a9a7f9be972ccc038dcb` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/3c5f2830ead8256e1750a9a7f9be972ccc038dcb/specs/1006-bpmn-library-adoption/evidence/broadcast-empty-proposal-recovery.md).

The old actual host prepares a **nonnull zero-start/zero-resume proposal** while its canonical source cohort is **absent**. Normal APIs then create matching waits/binding. The actual standard peer uses shared runtime/membership stores and locks; checked membership shows distinct incarnations, natural old-member expiry and live peer. Its new source owner/fence **1→2** saves/delivers **one start/two exact waits**. The listener completes its join and the one keyed start parks on a matching wait excluded from this source.

The old process resumes only after delivery, **actually enters provider installation**, and receives `RuntimePostCommitOutboxStaleClaimException` without requested cancellation. Complete source/workflow observations/inventory stay identical afterward. The original unmatched listener retains its complete projection and two Suspended waits at attempt one; its start artifact creates no execution. This does not claim a separate full-row audit of its unmatched binding.

**Actual empty-loser case 1/0/0; populated competition + saved-empty decision regressions 2/0/0; reader controls 13/0/0, process controls 10/0/0, cleanup controls 3/0/0.** All three final cases bind identical manifests and **1,376 current source files** each. Three independent component source/actual/portable reviews clean; full-PR rounds **0**, bound six. Only scenario branching/instructions changed; production, probe, reader and package graph unchanged. Supporting architecture590/locked Server/maps from fc5948641 are inherited, not reported as rerun. Frozen authoring unchanged; private databases/configuration stay local and existing user backend/Studio remain running.

**Scope/next:** this qualifies empty losing proposal→populated winner only. The opposite populated proposal→empty winner remains open, alongside real renewal, partial starts, ACK/redrive and remaining T051 scope/retention/GC/republish cases. T051 stays unchecked. T045/native-composite, historical upgraded-host recovery, final Studio, duplicate semantics/legacy writer deletion and guards, full-PR review, green exact-head required checks/protected merge/resulting-main, then separate ADR 0063 acceptance remain open. #2898/#2907/program production acceptance remains open; Orleans/task-runner deferred. Goal active. Current head requires fresh CI; existing public-source-digest GitGuardian incidents need legitimate resolution. No check bypass/history rewrite/merge attempted; draft full-tier skips do not qualify.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Fields match evidence, so no no-op mutation. Existing organization Projects read/write is sufficient; no additional grant needed.


## #2892 6439483815 elsa-workflows-codex[bot] 2026-10-27T10:28:11Z
T051 actual populated prepared loser/empty saved winner pushed at `b694efb8c5bda5891a9e96e2b3cc38eacdfd051c` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/b694efb8c5bda5891a9e96e2b3cc38eacdfd051c/specs/1006-bpmn-library-adoption/evidence/broadcast-empty-winner-recovery.md).

After the old actual Workbench prepares **one start/two waits**, normal public APIs submit a CancelWorkflow plan and unpublish that start slot. The plan completes exactly one target, the workflow/both exact catches become Cancelled with zero incidents, and the slot has no active publication. The checked physical observation independently proves cohort absent, no original bookmarks, no active matching binding and only unmatched later waits before the old host is suspended.

A standard peer uses actual shared runtime/membership stores and lock directory. Checked membership proves distinct incarnations, old initially live then naturally expired, peer live; actual source owner/fence **1→2** installs/delivers a **nonnull zero-start/zero-resume cohort** with version-one retention acceptance. All checked workflow projections and inventory remain unchanged, with zero starts.

The resumed old populated proposal **actually attempts provider installation** and receives `RuntimePostCommitOutboxStaleClaimException` without requested cancellation. Complete source/workflow observations/inventory remain identical after rejection. This qualifies the opposite empty-winner direction, complementing the already delivered empty-loser/populated-winner and populated competition cases.

**Actual empty-winner case 1/0/0; two other actual competition regressions 2/0/0; reader controls 13/0/0, process controls 10/0/0, cleanup controls 3/0/0.** All three runs bind identical manifests and **1,379 current source files** each, now including the invoked public alteration helper and shared API/lifecycle helpers. Three independent component source/actual/portable audits clean; full-PR rounds **0**, bound six. Production/probe/reader/dependency graph and frozen authoring unchanged. Architecture590/locked Server/maps are inherited from fc5948641, not rerun. Whole DB/configuration stays private and existing user backend/Studio remain running.

**Next/open:** actual renewed claims, partial starts, ACK/redrive and remaining T051 scope/retention/GC/republish cases. T051 remains unchecked. T045/native-composite, historical upgraded-host recovery, final Studio, duplicate semantics/legacy writer deletion and guards, full-PR review, green exact-head required checks/protected merge/resulting-main, then separate ADR 0063 acceptance remain open. #2898/#2907/program production acceptance remains open; Orleans/task-runner deferred. Goal active. New head requires fresh CI; existing public-source-digest GitGuardian incidents require legitimate resolution. No check bypass/history rewrite/merge attempted; draft full-tier skips do not qualify.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Fields match evidence, so no no-op mutation. Existing organization Projects read/write is sufficient; no additional grant needed.


## #2892 6439857107 elsa-workflows-codex[bot] 2026-10-27T10:41:39Z
T051 actual partial-start crash/recovery pushed at `8a558c7fb8e9f80ba191dc6eaf1bb874363a37c6` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/8a558c7fb8e9f80ba191dc6eaf1bb874363a37c6/specs/1006-bpmn-library-adoption/evidence/broadcast-partial-start-recovery.md).

The actual cohort saves **two distinct start artifacts/keyed executions and two exact waits**. A default-off probe forwards the selected start dispatcher unchanged, then pauses only after an actual non-shed Accepted saved start and canonical source read. The runner waits for that exact keyed workflow's real suspended child, complete API page and physical bookmark. Exactly one saved entry matches its marker; the other target is absent, and original waits remain Suspended. Later listeners/binding are created before the owned probe process is killed.

The standard binary has **no probe**. After the real lease deadline, its distinct source owner/fence **1→2** reuses the identical cohort. The first parked start preserves its complete checked projection, full API instance and every activity record; no reinvocation/checkpoint drift is accepted. Recovery creates exactly the second keyed start, parks it, completes both original catches/join and leaves later recipients unchanged. One execution exists per selected artifact; the later binding creates none.

**Next/open:** actual pre-dispatch renewed claims, complete fan-out before source ACK loss/redrive, same-artifact behavior, remaining scopes and retention/GC/republish races. The processor deliberately renews immediately before dispatch and not during its handler; holding a handler is not renewal evidence. T051 remains unchecked. T045/native-composite, historical upgraded-host recovery, final Studio, duplicate semantics/legacy writer deletion and guards, full-PR review, green exact-head required checks/protected merge/resulting-main, then separate ADR 0063 acceptance remain open. #2898/#2907/program production acceptance remains open; Orleans/task-runner deferred. Goal active. New head requires fresh CI; existing public-source-digest GitGuardian incidents need legitimate resolution. No check bypass/history rewrite/merge attempted; draft full-tier skips do not qualify.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Fields match evidence, so no no-op mutation. Existing organization Projects read/write is sufficient; no additional grant needed.


## #2892 6440210646 elsa-workflows-codex[bot] 2026-10-27T10:59:11Z
T051 actual complete-fanout/crash-before-source-ACK-write pushed at `6152c6872d931c70a277fa16742876af1461555a` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/6152c6872d931c70a277fa16742876af1461555a/specs/1006-bpmn-library-adoption/evidence/broadcast-fanout-pre-ack-recovery.md).

A default-off probe forwards the actual selected intent dispatcher and required-source capability. After the real PublishStimulus context handler returns, it rereads the canonical source and pauses. The processor still awaits that call, so source success cannot yet be recorded. Before killing, normal APIs and checked physical state independently require **both exact callbacks/join Completed**, **the saved keyed start physically parked**, complete incident-free API pages for **both recipient workflows**, and a source still **Delivering**. Later listeners/binding already exist. Handler return/queued admission alone does not qualify.

The standard binary contains **no probe**. After real lease expiry, its distinct source owner/fence **1→2** reuses the identical cohort and records Delivered. Both recipients retain their entire checked projections and full API instance/activity records; original callback attempts stay two, parked start records stay unchanged, later waits/binding remain excluded. The publisher's own queued continuation may finish and is not counted as an unchanged recipient.

**Scope/next:** this is a crash **before source acknowledgment recording**, not an ambiguous acknowledgment after a committed completion write. That distinct cut and actual redrive remain open, as do real pre-dispatch renewal, same-artifact behavior, remaining scope and retention/GC/republish cases. A held handler is not renewal evidence. T051 remains unchecked. T045/native-composite, historical upgraded-host recovery, final Studio, legacy writer/duplicate semantics deletion and guards, full-PR review, green exact-head required checks/protected merge/resulting-main, then separate ADR 0063 acceptance remain open. #2898/#2907/program production acceptance stays open; Orleans/task-runner deferred. Goal active. New head requires fresh CI; public-source-digest GitGuardian incidents need legitimate resolution. No bypass/history rewrite/merge attempted; draft full-tier skips do not qualify.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Fields match evidence, so no no-op mutation. Existing organization Projects read/write is sufficient; no additional grant needed.


## #2892 6441230796 elsa-workflows-codex[bot] 2026-10-27T11:54:05Z
T051 actual committed source-completion/provider-return loss pushed at `1e5f9fa2e0dd4626cf8456032db0dd853f01182e` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/1e5f9fa2e0dd4626cf8456032db0dd853f01182e/specs/1006-bpmn-library-adoption/evidence/broadcast-committed-ack-recovery.md).

A scoped test-only observer filters the public EF `TransactionCommitted` diagnostic to the actual Runtime context and encoded owned source row, unsubscribes and holds the completion call before the provider returns. The event grants no authority: **a separate coherent checked observation must prove Delivered while the old process is alive**, before later fixture writes and the owned crash. It verifies cleared owner, completion timestamp, original fence and accepted cohort.

Standard no-probe recovery preserves the **entire checked source projection plus canonical ContentJson hash, row revision and schema**, with fence **1→1** and no fabricated successor claim. Past the original deadline **plus two seconds**, a distinct normal publisher control actually progresses **Pending/fence0→Delivered/fence1** with an accepted empty cohort. Thus the restarted source pipeline is operating after that deadline. Exact publisher discovery enumerates encoded candidates then uses the actual checked reader, refusing missing/multiple/inconsistent matches. The original source stays byte-hash/revision/schema identical, both recipient full API/physical records stay unchanged, and the only additional workflow is the deliberate control publisher. Later recipients remain excluded; the original publisher's own continuation may finish.

Earlier observer/marker comparisons omitted EF identity encoding: two positive controls failed and the cut did not fire. Public `EfRelationalIdentity` fixed that. The SavedChanges prototype then **correctly failed independent commit proof** because the real completion saves inside an explicit transaction before Commit. The transaction-commit observer subsequently passed the physical proof and operating-host control. Those unsuccessful attempts are not counted as green.

**Next/open:** actual redrive, real pre-dispatch renewal, same-artifact behavior, remaining scopes and retention/GC/republish cases. T051 remains unchecked. T045/native-composite, historical upgraded-host recovery, final Studio, legacy writer/duplicate semantics deletion and guards, full-PR review, green exact-head required checks/protected merge/resulting-main, then separate ADR 0063 acceptance remain open. #2898/#2907/program production acceptance remains open; Orleans/task-runner deferred. Goal active. New head needs fresh CI; public-source-digest GitGuardian incidents need legitimate resolution. No bypass/history rewrite/merge attempted; draft full-tier skips do not qualify.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Fields match evidence, so no no-op mutation. Existing organization Projects read/write is sufficient; no additional grant needed.


## #2892 6441593156 elsa-workflows-codex[bot] 2026-10-27T12:13:30Z
T051 actual pre-dispatch claim renewal pushed at `d909b25ae28d87e359889063a91b979bf8ff8e4a` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/d909b25ae28d87e359889063a91b979bf8ff8e4a/specs/1006-bpmn-library-adoption/evidence/broadcast-renewed-claim-recovery.md).

The scoped test-only dispatcher observes the real selected EF provider's initial claim save, filtered to its exact Runtime context, protocol source, event and fence one. It refuses an enclosing transaction, unsubscribes and holds. **The diagnostic supplies no authority:** an independent coherent snapshot checked through the actual provider must prove the committed initial source. After two real seconds, a second independent read must show its entire checked projection unchanged before release. The actual processor then performs its normal pre-dispatch renewal and installs the cohort.

Checked state binds the **same commit-specific source ID, canonical intent, owner and fence**, with revision **2→4** and deadline advanced **3.164655 seconds**. Release and the subsequent cohort cut must both precede the original deadline; the cut is **56.767361 seconds before expiry**. This proves an ordinary unexpired renewal. It does not infer continuous renewal during a handler or expired-but-unreclaimed revival. The owned crash then precedes recipient dispatch; actual standard no-probe takeover uses a distinct owner/fence two and delivers the unchanged one-start/two-resume cohort. Original callbacks/join complete, the saved keyed start parks, and later recipients remain excluded.

Review found that an unselected source omits recipientSnapshot; requiring a present null would break observation. That was fixed before actual execution. Exact source identity and unexpired release/cohort-cut proof guards were added before final qualification. Production source/project graph and frozen authoring are unchanged. Architecture590, locked Server restore and maps are inherited, not rerun. All owned case processes terminated; existing user backend/Studio remain running. Whole databases/configuration stay private.

**Next/open:** supported redrive, same-artifact behavior, remaining scopes and retention/GC/republish cases; T051 stays unchecked. Remaining T045/native-composite, actual historical upgraded-host recovery, final current Studio, legacy writer/duplicate semantics deletion and guards, full-PR review, green exact-head required checks/protected merge/resulting-main, then separate ADR 0063 acceptance remain open. Production #2898/#2907 and the program stay open; Orleans/task-runner deferred. Goal active. New head needs fresh CI; GitGuardian public-digest incidents need legitimate resolution. No bypass, history rewrite or merge attempted; draft full-tier skips do not qualify.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled using the Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Fields match current evidence, so no no-op mutation. **Existing organization Projects read/write is sufficient and currently works; no additional access grant is needed.**


## #2892 6442069485 elsa-workflows-codex[bot] 2026-10-27T12:38:08Z
T051 actual saved-publication recovery after republish and collection pushed at `38f45eee937003374237af0ccc76aa8eb63f0df4` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/38f45eee937003374237af0ccc76aa8eb63f0df4/specs/1006-bpmn-library-adoption/evidence/broadcast-republished-cohort-recovery.md).

After the actual one-start/two-resume cohort is saved and held before dispatch, **public version ingest and conditional Replace** install a distinct artifact/publication in the same definition/default slot. The selected original reference retires. A separate unmatched control is publicly unpublished. Complete checked inventories must show the original retired-only material/reference, distinct active replacement and physically present retired control, with no existing execution/dispatch root or incoming executable/template route for the old artifact. All wrapper/flattened-node template metadata and direct/closed template edges are observed; **33 standalone catalog templates** are allowed without alternative edges or identity aliases. Missing inventories/projections refuse.

The **normal GC pump runs the real selected collector**, configured with zero creation grace. A test-only wrapper forwards both overloads, actual capability and actual results; its scheduling gate waits until every publication/root write finishes, preserving the staging window. Actual collection deletes **one unrelated artifact and one reference**. Independent checked state must prove those exact control rows disappeared while retaining the original unstarted material and retired reference. The entire checked owed source projection remains unchanged. Ordinary public execution using that retired reference returns **409**; the bounded problem response is captured.

The owned crash precedes recipient dispatch. Standard no-probe takeover uses a distinct owner/fence **1→2** and completes the original callbacks/join while parking the exact saved keyed start. Physical state pins the **original artifact ID/hash, source reference, publication and definition version**. Replacement/control/later binding stay unstarted; later exact waits stay unchanged. The saved cohort survives collection, crash and recovery unchanged. This qualifies collection after acceptance and republish, not the opposite race or production retention policy.

**Next/open:** supported redrive, same-artifact behavior, remaining scopes and reverse GC/acceptance/other retention orders. T051 remains unchecked. Remaining T045/native-composite, actual historical upgraded-host recovery, final current Studio, legacy writer/duplicate semantics deletion and guards, full-PR review, green exact-head required checks/protected merge/resulting-main, then separate ADR0063 acceptance stay open. Production #2898/#2907 and the program remain open; Orleans/task-runner deferred. Goal active. Fresh CI is required on this head; GitGuardian public-digest incidents need legitimate resolution. No bypass, history rewrite or merge attempted; draft full-tier skips do not qualify.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Fields match current evidence, so no no-op mutation. Existing organization Projects read/write works; no additional access grant is needed.


## #2892 6442797812 elsa-workflows-codex[bot] 2026-10-27T13:14:20Z
T051 actual same-artifact shedding/key-reuse recovery pushed at `0334c31ed31c854aa3a5d11868562cd7b2edc144` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/0334c31ed31c854aa3a5d11868562cd7b2edc144/specs/1006-bpmn-library-adoption/evidence/broadcast-same-artifact-recovery.md).

Normal public SideBySide publishing produces **two distinct eligible publication bindings/captured sources of exactly one artifact**. The first owned host saves the complete two-start/two-catch cohort and crashes before recipient dispatch. Checked state maps each capture to its actual public source/publication/activation/hash/version while proving one original artifact-scoped key and target ID.

The second probe host retains the **default admission controller** with operator StaticLimit **1**. A separate real public API workflow durably parks two unmatched waits; its scoped post-drain observer holds the actual command before its real admission charge is disposed. Actual load is **14 dispatch units**. The observer acquires no synthetic permit and supplies no admission, actor or provider verdict. Recovered source delivery at fence **2** has **no ambient exemption**. Its first saved binding actually returns **Deferred/IsShed**, with the original key/ID and **no physical target**.

Only after the real load command releases and its ordinary HTTP response succeeds does the later saved binding proceed. It actually returns **Accepted at load zero**, using the **identical original key and execution ID**, with its own exact captured publication provenance. The entire checked source projection stays unchanged between refusal, acceptance and the second owned crash. A third, **standard no-probe host** reclaims at fence **3**, completes the original callbacks/join and preserves the accepted target's **complete checked physical state and full API instance/activity records**. There is exactly one physical target and no added activity attempt/incident; later matching recipients remain excluded. Thus the actual first capacity refusal did not consume the key, and both saved binding entries converge after restart.

**Actual main three-incarnation case 1/0/0; republish/collection and renewal regressions 2/0/0; extracted same-artifact guards 26/0/0 (three real positives plus twenty-three invalid inputs), retention guard 21/0/0, renewal guard 9/0/0, checked source/publisher/material/reference controls 14/0/0, process controls 10/0/0, cleanup controls 3/0/0; three locked probe/standard/reader builds pass.** All three actual cases bind identical **1,382 current source files** and **631 binary/dependency files**. Three independent component source/actual/portable audits clean; full-PR rounds **0**, bound six. Guard inputs qualify evidence acceptance, not production source mutations.

Review corrected strict wire provenance (`sourceCapture.version/provenance`) and binding-entry versus unique-artifact counts before actual execution. A metadata-constant compile assumption was corrected to the actual start-dispatch contract. Exact public-capture mapping and real release/HTTP-response timestamps were added before final stable-source runs. Production source/project graph/frozen authoring unchanged; architecture590, locked Server restore and maps inherited, not rerun. All **seven** owned host processes across the three cases terminated; existing user backend/Studio stayed running. Whole databases/configuration remain private; portable observations contain no machine paths or credentials.

**Next/open:** remaining local/correlation/test-scope paths, supported redrive, reverse GC/acceptance and other retention orders. T051 stays unchecked. Remaining T045/native-composite, actual historical upgraded-host recovery, final current Studio, legacy writer/duplicate semantics deletion and guards, full-PR review, green exact-head required checks/protected merge/resulting-main, then separate ADR0063 acceptance stay open. Production #2898/#2907 and the program remain open; Orleans/task-runner deferred. Goal active. Fresh CI is required on this head; GitGuardian public-digest incidents need legitimate resolution. No bypass, history rewrite or merge attempted; draft full-tier skips do not qualify.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled using the Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Fields match current evidence, so no no-op mutation. Existing organization Projects read/write works; no additional access grant is needed.


## #2892 6443957614 elsa-workflows-codex[bot] 2026-10-27T14:02:44Z
T051 actual local/correlation/TestRun receiver isolation pushed at `8f028d3f08e2487dfdc31e1d6c1f9e3963d7684d` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/8f028d3f08e2487dfdc31e1d6c1f9e3963d7684d/specs/1006-bpmn-library-adoption/evidence/broadcast-scope-recovery.md).

**Local:** a catalog-authored native Parallel durably parks two same-execution Event waits and a gated PublishEvent(IsLocalEvent=true). A unique normal control stimulus releases that send. The committed cohort has exactly the publisher's **two waits and zero starts**. Same-name preexisting published/TestRun receivers and an active native start binding are excluded. A standard no-probe new host reclaims at fence **1→2** and completes only the saved callbacks.

Both cases create **two distinct actual same-artifact TestRuns** with physically matching waits in authoritative **open, unexpired scopes**. Their original official wait API views expose both exact bookmark IDs through the Event driver before crash. Both remain fully identical in checked physical state and complete API instance/activity records through normal source recovery. A **third actual TestRun** of the same artifact receives two exact private callbacks through the official TestRun wait/event APIs **before crash**, persisting one receipt per consumption and completing the real BPMN join. Each requested bookmark retires, its corresponding activity completes with exactly one additional attempt, and the sibling generation stays unchanged. Retrying the first before the second returns **AlreadyDelivered** without physical/API change. Other scopes, every normal workflow and the normal source stay unchanged; the completed third's full facts also survive restart.

Publishing currently registers only **InMemoryWorkflowTestRunStore**. Its API handle is lost on host restart although durable runtime scope/execution remains. The initial attempted post-restart API proof exposed that preexisting limitation; this increment does **not** reconstruct or claim restart durability of that handle. General TestRun API restart and final Studio/recovery gates remain open. No new policy is asserted for PublishEvent executed inside a TestRun publisher.

**Final actual cases 3/0/0** (local, correlation, ordinary post-cohort regression); actual extracted scope guards **54/0/0** (two positives plus 52 invalid evidence variants); checked reader **14/0/0**; owned process/broker **10/0/0**; cleanup failures **3/0/0**. Fresh locked reader build passes. The exact earlier probe/standard host closures are reused with **1,304 unchanged current compilation inputs**; they are not claimed as new builds. Every final case binds identical **1,384 source files / 631 binary/dependency files**. All **six** owned hosts terminated, user backend/Studio kept running. Three independent component source/actual/portable audits clean; full-PR rounds **0**, bound six. Production/project graph/frozen authoring unchanged. Architecture590, locked Server restore and maps inherited, not rerun. Databases/configuration stay private; portable observations contain no machine paths or credentials. Initial failed runs do not qualify; count-only private callback evidence and the reader compile projection were corrected before final runs.

**Next/open:** supported redrive applicability, remaining retention/GC acceptance orders and overall T051; remaining T045/native-composite, actual historical upgraded-host recovery, final current Studio, legacy writer/duplicate semantics deletion and guards, full-PR review, green exact-head required checks/protected merge/resulting-main, then separate ADR0063 acceptance. T051 stays unchecked. Production #2898/#2907 and program acceptance stay open; Orleans/task-runner deferred. Goal active. Fresh remote main includes legitimate Studio Test Run canvas work (#3400); it will be adopted before final integration/Studio qualification. Parent-head completed build/architecture/Studio checks are green, while required GitGuardian remains red on public source-digest incidents; fresh checks are required here. No bypass/history rewrite/merge attempted; draft full-tier skips do not qualify.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled with the Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Fields already match current evidence, so no no-op mutation. Existing organization **Projects read/write** works; no additional access grant is needed.


## #2892 6444175859 elsa-workflows-codex[bot] 2026-10-27T14:09:52Z
Current-main adoption checkpoint at `98ca3a865d98f29fd2db31b080eb17828a37a24c` on sole draft #3338. Codex App commit/push; no competing PR.

Merged legitimate remote main `d60fed26ae7d72d27b08469f3047a381a1a61bc8`, including Studio hosting/package extraction and the new Test Run canvas work (#3400). Merge parents are scoped recovery `8f028d3f08e2487dfdc31e1d6c1f9e3963d7684d` and that main. No conflicts; the sole combined merge edit is the existing Runtime extension-point README link following the Studio SDK's move to Hosting. **No Foundation backend compilation source or package pin changes** came from this merge; frozen authoring stays byte-identical. Earlier scoped host proof remains bound to its own recorded source; it is not relabeled as a fresh host/Studio acceptance run on this merge.

Integration verification on this exact merge: **frozen pnpm install; workflow frontend 2,529/0/0 (185 files); hosting frontend 590/0/0 (52 files); workflow TypeScript check; locked Studio .NET project test/build 635/0/0; attached Test Run canvas Chromium 4/0/0**. Commands: `pnpm install --frozen-lockfile`; the two filtered package `test --maxWorkers=2 --minWorkers=1` runs; filtered workflow `typecheck`; `dotnet test Studio/tests/Elsa.Studio.Tests/Elsa.Studio.Tests.csproj --configuration Release -p:RestoreLockedMode=true` with an isolated artifacts output; `CI=true pnpm exec playwright test tests/browser/editor-run-canvas.spec.ts --project=chromium --workers=1`. The fixture browser server was not reused and is terminated; the user's existing backend/Studio remained running. These are integration tests, **not** final real Studio/historical upgraded-host acceptance. No full-PR review round consumed; still zero of at most six.

The [scoped recovery deliverable](https://github.com/elsa-workflows/elsa-foundation/blob/8f028d3f08e2487dfdc31e1d6c1f9e3963d7684d/specs/1006-bpmn-library-adoption/evidence/broadcast-scope-recovery.md) is delivered on this branch: three actual cases and 81 controls, exact private callbacks/retry, two original TestRun receivers and completed third fully unchanged through real source recovery. Existing Publishing process-local TestRun API-handle limitation is explicitly retained. No new claim of that handle's restart support or TestRun publisher policy.

Next: remaining GC/cohort-acceptance order and supported redrive applicability evidence, overall T051, remaining native-composite/T045 and actual historical upgraded-host/final Studio, then legacy semantic writer deletion/guards and full-PR exact-head review/checks/protected merge/resulting-main, followed by separate ADR0063 acceptance. Fresh remote checks are required on this merge; required GitGuardian public-digest incidents remain unresolved. No bypass/history rewrite/merge to main attempted. #2898/#2907 and program production acceptance remain open, Orleans/task-runner deferred, goal active.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly re-read with working Codex App organization Projects read/write. No evidence state changed: #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. No extra access grant needed.


## #2892 6444550219 elsa-workflows-codex[bot] 2026-10-27T14:24:39Z
T051 actual **collection before cohort acceptance** pushed at `e57db5a315f7007f1d683d8b4dcb0ffc04fb1cc4` on sole draft #3338. [Portable source-bound receipt](https://github.com/elsa-workflows/elsa-foundation/blob/e57db5a315f7007f1d683d8b4dcb0ffc04fb1cc4/specs/1006-bpmn-library-adoption/evidence/broadcast-collected-proposal-recovery.md).

The actual router prepares **one start/two exact catches**, then a test-only scheduling gate holds entry to real provider installation. The physical source is Delivering at fence **1**, with a live claim and **no cohort/no recipient effect**. Normal public unpublishing retires that exact proposed source. The actual selected zero-grace reference collector deletes **one reference and one executable artifact**, including the exact target; complete checked inventories show retired material/ref present→absent, with no target execution/dispatch roots. The full source and workflow facts remain unchanged.

The original, still-live claim then **actually enters provider installation** and refuses. The root-write manager resolves its graph before acquiring leases; completed deletion therefore raises **StimulusDeliveryBoundaryException / WorkflowExecutableDependencyGraphException / MissingArtifact**, with the exact collected artifact/hash as its **sole complete root-path diagnostic**. This is not a lease-acquisition failure. **IsUnavailable=false** is recorded faithfully; the processor rethrows every required-source boundary before recording any result regardless of that flag, preserving owed responsibility. The refusal occurs with **56.876427 seconds** left on the original claim and without requested cancellation. A test-only diagnostic hold after the actual exception supplies no verdict; full checked source, workflows and execution inventory stay unchanged. The host is killed.

A **standard no-probe new owner at fence2** makes first selection: **one later still-eligible start and all four exact original/later waits**. Both joins complete and the single keyed start parks; the collected earlier proposal remains absent. Its newly created matching wait is excluded. No winner had been accepted from that earlier proposal, so it grants no retention or dispatch authority. The already accepted-cohort retention/republish and local/TestRun isolation regressions also pass on the identical final source/closures.

**Three actual cases /110 controls /one fresh locked probe build pass.** Controls: **35** actual proposal/collection/refusal evidence checks (one actual positive plus34 invalid variants), scope**27**, accepted-publication retention**21**, checked-reader**14**, owned process/broker**10**, cleanup failures**3**. All cases bind identical **1,385 source /631 binary/dependency files**. Standard/reader reuse exact earlier closures with **1,303 unchanged current standard compilation inputs** and unchanged reader inputs; they are not claimed as fresh builds. All **six** owned hosts terminated; existing user backend/Studio remained live. Whole databases/configuration remain private; portable observations contain no machine paths/credentials. Production source/project graph/frozen authoring unchanged. Architecture590/locked Server/maps inherited, not rerun.

Three independent component source/actual/portable audits clean; **full-PR rounds remain0**, bound six. Review fixed omitted material/reference/root/workflow projection false positives with mandatory inventory keys and five omission negatives. The initial expected lease-unavailable exception was corrected to actual graph-first MissingArtifact, exact artifact/hash/path and typed-kind negatives; **no production classifier change**. Initial failed run does not qualify.

Main `d60fed26a` is already adopted at integration `98ca3a865`; frozen install/typecheck, workflow2,529/hosting590/Studio.NET635/canvasChromium4 integration passes remain supporting proof, not final actual Studio/historical upgrade. Next: supported redrive applicability, affected whole-project/mutation checks and overall T049/T050/T051 reconciliation; remaining T045/native-composite, actual historical upgraded-host/final Studio, legacy writer/duplicate semantics deletion and guards, full-PR review, green exact-head required checks/protected merge/resulting-main, then separate ADR0063. T049/T050/T051 stay unchecked. Production #2898/#2907 and program acceptance stay open; Orleans/task-runner deferred. Goal active. Fresh required checks apply here; GitGuardian public source-digest incidents still need legitimate resolution. No bypass/history rewrite/merge to main attempted.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled through the Codex App. Current evidence fields remain: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. No no-op mutations; existing organization **Projects read/write** works, no additional access needed.


## #2892 6445028527 elsa-workflows-codex[bot] 2026-10-27T14:45:19Z
**Broadcast T049/T050/T051 qualification complete** at `7ea72f7280051db88986c7357d9f307073f2f2b5` on sole draft #3338. [Current source-bound reconciliation](https://github.com/elsa-workflows/elsa-foundation/blob/7ea72f7280051db88986c7357d9f307073f2f2b5/specs/1006-bpmn-library-adoption/evidence/broadcast-delivery-reconciliation.md).

Three independent correctness, standards and acceptance audits reconciled **36 historical evidence bindings** with the current source, contract and task requirements. The chain now covers exact saved-start authority/material retention and default collection; canonical immutable selection/publisher activation/exact callbacks; actual delayed/empty/competing decisions, renewed/lost claims, post-cohort and partial start/resume/rearm cuts, fanout and committed ACK loss, republish/retention, real same-artifact shedding/key reuse, local/correlation/TestRun receiver isolation, and both GC/acceptance orders. Earlier source-bound receipts stay unchanged and are not relabeled as current-head or resulting-main runs. Current plan/contract/tasks explicitly reconcile their historical open-state wording.

**Current whole projects: Runtime 3,043/0/0; Runtime EF 1,649/0/0; Activities Runtime 720/0/0 — 5,412 passed, zero failures/skips.** Focused model/redrive/durable-source checks pass **67/0/0**. The initial EF attempt with external `/tmp` artifacts failed16/passed1,633 because13 legacy-checkpoint and3 CLI/OIDC cases locate the checkout through output ancestors. The same complete project passes with its prescribed normal checkout output layout. No source workaround, skipped/filter-hidden cases or weakened fixture assertions were used; the failed attempt is retained in the receipt.

The public redrive operation accepts eligible detached **StartChild** failures; the test now explicitly rejects the named-event publish kind despite otherwise matching deterministic IDs. **No named-event host redrive API exists, and none is invented or claimed.** The shared model transition preserves empty/populated cohort data including its constructed retention-witness marker, protocol/source scope/intent/outbox identity, advances the fence, refuses stale old completion and preserves data through later claim/completion. Construction grants no admission authority. Two deliberately broken production-source variants each fail exactly **two behavioral assertions**, without compile failures; production sources are restored byte-identically before final passes. These are model/contract controls, not host redrive proof.

The reconciliation binds **ten current source/doc hashes**, exact logs, restored mutation/source hashes, historical receipts and the unchanged frozen authoring fingerprint. Production runtime/provider/Primitives C# and root pins/build properties have not changed since publisher activation `b9e98f985`; the two intervening production-tree differences are opt-in test-probe inclusion and a Studio SDK documentation link. Broad scope/API/retention mutations stay bound to their existing source-specific receipts. Three final component reconciliations clean; **full-PR review rounds remain zero**, bound six.

**Next:** remaining T017/T021/T022/T024/T025/T029/T045 native-composite and actual historical upgraded-host/current Studio proof, then T032 legacy semantic writer/duplicate implementation deletion and T033–T035 guards/audits. T036–T038 still require final qualification, complete-PR review, required exact-head green checks, protected merge and resulting-main verification. ADR0063 remains the separate third ordered PR after that delivery. The candidate uses released BPMN0.5.0; delivered-main library-switch acceptance is open and the legacy writer remains. The known process-local Publishing TestRun API handle limitation remains explicit. Production #2898/#2907 and program acceptance stay open; Orleans/task-runner deferred. Goal active. Fresh required checks apply on this head; GitGuardian public source-digest incidents still require legitimate resolution. No bypass/history rewrite/merge to main attempted.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled through the Codex App. Overall evidence states remain #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Task closure does not make overall adoption complete, so no no-op field mutation. Existing organization Projects read/write works; no additional grant needed.


## #2892 6445830216 elsa-workflows-codex[bot] 2026-10-27T15:17:11Z
**Continued legacy callback replay delivered** at `dc7ce6454f99ef192000236ad1d12aaaf3272a16` on sole draft #3338.

Current compatibility checkpoint: [Actual continued legacy MI/listener callback replay](https://github.com/elsa-workflows/elsa-foundation/blob/dc7ce6454f99ef192000236ad1d12aaaf3272a16/specs/1006-bpmn-library-adoption/evidence/continued-legacy-callback-replay.md). Both unchanged preview-host SQLite captures continue through released BPMN 0.5.0; a passive wrapper records the actual normal parent-completion handler input. Positive exact-token/iteration preconditions, pruning and processed receipts, complete sibling activity facts and physical bookmark generation/scope are checked. Identical actual callback replay through a fresh provider changes no durable activity/wait facts and does not re-evaluate the adapter; both workflows subsequently complete normally. Focused 2/0/0; whole Runtime EF 1,651/0/0. Receipt-bypass mutation fails both replay cases; first-node/iteration-match mutation fails listener recovery (not claimed as replay). Sources restored, frozen authoring/captures unchanged; three component audits clean. T017 remains open for remaining fault/cancel/reconciliation. Full-PR rounds zero; final actual Workbench/Studio, duplicate-semantic deletion, protected delivery and separate ADR0063 remain open.

The initial dispatcher-level observer failed to see the selected callback; it was replaced with passive observation at the actual scheduler handler input. No reconstructed callback, synthetic legacy state, regenerated capture or production change was used. Review strengthened positive token/live-work preconditions and full physical bookmark observations to avoid vacuous checks. The two exact frozen old-database digests, current source/binary/dependency closure, logs and behavioral mutation results are bound in the portable receipt.

This is actual captured-database continuation and callback replay across fresh provider restart. It does not establish outbox ACK loss, full Workbench process-crash recovery, old-binary running rollback, final current Studio or production acceptance. T049/T050/T051 remain qualified by the separate reconciliation at `7ea72f7`; their historical receipts are unchanged. Remaining native-composite/combined/called-control and T017 gates precede deleting the legacy semantic writer. Complete-PR review (maximum six rounds), exact-head required green checks, protected merge and resulting-main verification precede the separate ADR0063 PR. Required GitGuardian public-source-digest incidents still need legitimate resolution; no bypass.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) was freshly reconciled using the Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. No overall state transition, so no no-op field writes. Organization Projects read/write already works; no further App permission is needed. Program and independent production acceptance remain open; Orleans/task-runner deferred. Goal active.

## #2892 6446219187 elsa-workflows-codex[bot] 2026-10-27T15:33:34Z
**T017 complete: actual legacy completion/fault/replay/pruning and exact identity** at `7270655eafc005577b0a9ceb8239d223c6ef1196` on sole draft #3338.

Current compatibility checkpoint: [T017 actual legacy compatibility qualification complete](https://github.com/elsa-workflows/elsa-foundation/blob/7270655eafc005577b0a9ceb8239d223c6ef1196/specs/1006-bpmn-library-adoption/evidence/legacy-outcome-fault-replay.md). Eight real old-runtime whole databases are preserved; the newest test-only overlay retains all old production source and preview pins. Actual typed MI/listener faults retire only the exact selected work/bookmark and preserve sibling activity/physical wait facts, v1 reader compatibility and original child fault/incident truth. Old controls/export 2/0/0; upgraded focused 2/0/0; whole Runtime EF 1,653/0/0. New terminal-fault callback replay is purged before handler entry, explicitly distinct from the prior live-parent processed-receipt/pruning guards. All source-specific prior receipts and frozen authoring remain unchanged. Three component audits reconcile T017 clean; full-PR rounds zero. Separate native/combined/called-control and final Workbench/current Studio, semantic deletion/guards, protected delivery/resulting-main and ADR0063 remain open.

The two supplemental MI/listener captures were executed by the unchanged old runtime on exact `d81a4c88a2924708ea8afcc2db20b8a77b84f703` plus a portable test-only overlay. All 12,312 old tracked files were compared; only capture tests changed plus their new real typed wait leaf. Standalone patch application reconstructs both files; that leaf is byte-identical in the upgraded consumer. Old central Model/Interchange preview pins are unchanged; the old core uses its duplicated local model/semantics. Current built Model/Semantics 0.5.0 dependencies are verified. Neither state, callback, fault nor incident was fabricated. All prior six captures remain immutable.

The current fault witnesses preserve the exact original child code/message and incident. The released parent verdict is `bpmn.work.faulted` versus old `bpmn.child.faulted`. The selected physical wait is positively absent; all other original activities and physical bookmark generation/scope facts stay unchanged. Identical actual callback replay through a fresh provider is positively queued then purged with no handler/adapter entry or durable activity/wait/incident/workflow change. There is no ordinary processed-completion receipt on this fault path, and no such guard is claimed. The fixture's unused self-cancel branch is not cancellation proof.

The task reconciliation maps existing strictly ordered semantic-canceled loser completion/fault and live-parent duplicate/pruning witnesses, continued MI/rearm completion/live replay, the first-node/iteration negative control and these exact typed-fault/terminal-purge witnesses. Final receipt binds fourteen current source/doc hashes, seven current/four old binaries, all eight raw/compressed databases, source-specific prior receipts, exact logs and frozen authoring. Initial failed assumptions and review fixes are retained as unqualified evidence. Three independent correctness/standards/acceptance component audits clean; this does not consume or substitute for the complete-PR review loop (zero rounds, maximum six).

Remaining: T021/T022/T024/T025/T029/T045 native-composite/combined/called-control; final actual Workbench/current Studio; T032 legacy semantic writer/duplicate code deletion and T033–T035 guards/audits; T036–T038 final qualification, full-PR review, exact-head required green checks, protected merge and resulting-main verification. Then the separate third ADR0063 PR. Fresh remote main includes legitimate Studio #3401/#3402 progress; integrate it before final current Studio acceptance. Candidate adoption is not delivered-main acceptance. Required GitGuardian public-source-digest incidents still need legitimate resolution; new-head checks apply, no bypass or merge.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled using the Codex App. #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Overall states remain accurate, so no no-op mutations. Organization Projects read/write already works; no additional App access is needed. Independent production/program acceptance stays open; Orleans/task-runner deferred. Goal active.

## #2892 6446325380 elsa-workflows-codex[bot] 2026-10-27T15:38:09Z
**Current-main Studio integration verified** at `fa4d3a432d98071554aeca6863fc78afb94e0e66` on sole draft #3338.

Current integration checkpoint: current-main merge `fa4d3a432d98071554aeca6863fc78afb94e0e66` adopts legitimate Studio #3401/#3402 from `8083f8e54358f795de1eb66dfd3d2241c85751b1` onto delivered T017 head `7270655eafc005577b0a9ceb8239d223c6ef1196`. No conflicts or Foundation backend/root pin/build changes; all fourteen current compatibility receipt bindings, all prior captures and frozen authoring stay unchanged. Frozen pnpm install and workflow typecheck pass; workflow frontend 2,552, hosting frontend 590, locked Studio .NET 636 and isolated Chromium editor canvas 8 pass with zero failures/skips. Three bounded integration audits clean/full-PR rounds zero. These unit/fixture integration tests do not qualify the final real BPMN Studio journey; that gate and native/combined/called-control, deletion/guards, protected delivery/resulting-main and separate ADR0063 remain open.

Verification commands: frozen `pnpm install --frozen-lockfile`; filtered `@elsa-workflows/studio-workflows` and `@elsa-workflows/studio-web` tests with two workers; workflow `typecheck`; `dotnet test Studio/tests/Elsa.Studio.Tests/Elsa.Studio.Tests.csproj --configuration Release -p:RestoreLockedMode=true` with isolated output; Chromium `tests/browser/editor-run-canvas.spec.ts`, one worker. The browser used an ignored temporary config preserving the committed suite while overriding fixture URL/Vite port to **4181** and setting `reuseExistingServer=false`, because4179 belonged to a bystander. The owned fixture exited; user backend6738/63383 and Studio20753/5092 remain live. No existing server was stopped or reused.

Durable exact-merge integration receipt (log digests identify these observations, not final adoption acceptance):

```json
{
  "head": "fa4d3a432d98071554aeca6863fc78afb94e0e66",
  "parents": [
    "7270655eafc005577b0a9ceb8239d223c6ef1196",
    "8083f8e54358f795de1eb66dfd3d2241c85751b1"
  ],
  "checks": {
    "workflows": {
      "passed": 2552,
      "failed": 0,
      "skipped": 0,
      "logSha256": "11242602ca58adef479f916260ce43eb93a831a508532c9fe06893ef100c28e9"
    },
    "hosting": {
      "passed": 590,
      "failed": 0,
      "skipped": 0,
      "logSha256": "b8457686fe1617f07f2f6a0d4f6400181e9b2f52228e5bc44816da04322c02b5"
    },
    "browser": {
      "passed": 8,
      "failed": 0,
      "skipped": 0,
      "logSha256": "3fc4d2113e8b91884f10bb11bc7b814deebed952ccf75b88a56d277ba98e1e01"
    },
    "studioDotnet": {
      "passed": 636,
      "failed": 0,
      "skipped": 0,
      "logSha256": "08db8fefade63cdbeae0ebc5d9c69edc302224b1bc7a7764aa9bbd6a300a81e5"
    },
    "t017SourceBindingsUnchanged": 14
  },
  "frozenInstall": true,
  "workflowTypecheck": true,
  "browserPort": 4181,
  "reuseExistingServer": false,
  "foundationSourceAndPinsChanged": false,
  "finalStudioAdoptionAccepted": false,
  "fullPrRounds": 0
}
```

T017 stays complete within its recorded actual-provider compatibility scope; T049/T050/T051 stay complete within their broadcast qualification. Remaining T021/T022/T024/T025/T029/T045, final actual Workbench/current Studio, T032–T038 deletion/guards/final qualification/full-PR review/required green exact-head checks/protected merge/resulting-main, then separate ADR0063 remain open. New-head CI applies; required GitGuardian public-source-digest incidents still require legitimate resolution, with no bypass/history rewrite. Full-PR rounds remain zero, maximum six.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled using working Codex App organization Projects read/write. Overall states remain #2735/#3338 In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed; no no-op field writes. No further App permission is needed. Independent production/program acceptance stays open; Orleans/task-runner deferred. Goal active.

## #2892 6446870962 elsa-workflows-codex[bot] 2026-10-27T16:01:31Z
**T024 complete: real BPMN combined outcome durability** at `447637567d9b50ba4aad9a240b42ab5501eb39b9` on sole draft #3338.

Current combined-outcome checkpoint: [T024 actual BPMN EF durability qualified](https://github.com/elsa-workflows/elsa-foundation/blob/447637567d9b50ba4aad9a240b42ab5501eb39b9/specs/1006-bpmn-library-adoption/evidence/combined-outcome-ef-recovery.md). The real released-library BPMN adapter survives failed enqueue, actual queue acceptance held before ACK, committed parent/receipt/exact physical trailing wait, then an after-effect timeout and retry through two distinct fresh EF providers. Exactly one competing pass delivers, no second adapter evaluation or durable activity/wait/incident effects, final Event completes once. Complete class3/0/0 and whole EF1,654/0/0; two behavioral mutants fail in documented replay/before-ACK phases and sources restore exactly. Three bounded audits clean; full-PR rounds zero. Processor-entry competition is not forced SQL CAS, and controlled ACK timeout is not full-process crash proof. T021/T022/T025 and final Workbench/Studio, deletion/guards/protected delivery/resulting-main/ADR0063 remain open.

This extends the existing EF combined-outcome class with the actual BPMN adapter rather than substituting its original custom parent. Four real SQLite EF providers use normal runtime/type/shell initialization over the same test-owned store. The helper's separate temporary in-memory fixture only constructs the graph and never executes the witness. No production code or package/root build pin changes. The combined payload contains both ordered escalation notifications, the exact original child fault/incident, parent/child IDs and reporting token/work binding.

First real dispatch fails before queue acceptance, preserving a Running workflow and blocking original incident. A fresh provider actually claims the source and forwards enqueue, then holds the dispatcher before acknowledgement. Normal concurrent recovery commits the exact parent receipt and native trailing wait. Concrete EF observations positively include that physical bookmark's generation/scope, not merely its Suspended activity. While this cut is observed, source status remains Delivering with the same positive fence, the delivery task is unfinished and its release gate is unset. Attempt count is one while in flight; it counts recorded results. The reporter is pruned and the exact original incident is absorbed with StructuralFaultAbsorption, exact parent and bpmn.work.late-fault-absorbed reason, retaining its original core facts and child fault document.

Only after this observed cut is the gate released, producing a real after-effect timeout and ordinary FailedRetryable result two. Two further distinct fresh providers compete over the retry. Their existing barrier synchronizes processor entry, not an instrumented simultaneous SQL CAS. Exactly one pass attempts/delivers result three; saved work stays identical. The adapter has one actual OutcomeAsync call, complete activity/physical wait/incident observations are unchanged, queue/poison stores are empty and the original trailing Event completes once. This is controlled actual delivery failure across provider restart, not a process-kill or network-outage claim.

Two deliberately broken production variants each fail one behavioral assertion without compile failure: bypassed exact processed-outcome guard records two real adapter calls in the fresh-provider retry phase; omitted absorption leaves the original incident blocking before ACK release. Both source files restore byte-identically before final tests. Complete combined class **3/0/0**, whole Runtime EF **1,654/0/0**. The portable receipt binds15 current source/doc hashes,7 binaries, released0.5.0 dependencies, exact logs/mutation phases and all8 unchanged old captures/frozen authoring. Initial compile/API and actual counter/physical-wait assertion failures are retained as unqualified; review fixed a stale-read race with final fresh observation after completed recovery. Three independent correctness/standards/acceptance component audits clean; complete-PR rounds remain zero, bound six.

T017 and broadcast T049/T050/T051 retain their own source-specific qualification; historical receipts are unchanged. Remaining T021/T022 full semantic/combined matrix, T025 native parents, T029/T045 binding/called-control, final actual Workbench/current Studio, T032 legacy writer/duplicate semantic deletion and T033–T035 guards/audits, T036–T038 final qualification/full-PR review/required green exact-head checks/protected merge/resulting-main, then separate ADR0063 remain open. Required GitGuardian public-source-digest incidents still require legitimate resolution; new-head checks apply, no bypass or merge to main.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled through the Codex App. #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Overall state remains accurate, so no no-op field mutation. Organization Projects read/write already works; no extra App permission needed. Independent production/program acceptance remains open; Orleans/task-runner deferred. Goal active.

## #2892 6447481854 elsa-workflows-codex[bot] 2026-10-27T16:27:37Z
**T021/T022 complete: ordered commands, combined outcomes and coded errors** at `3df24f6c845d0c1d347984f6ea6a39ba659168d7` on sole draft #3338.

Current ordered-outcome checkpoint: [T021/T022 semantic/command/error mapping qualified](https://github.com/elsa-workflows/elsa-foundation/blob/3df24f6c845d0c1d347984f6ea6a39ba659168d7/specs/1006-bpmn-library-adoption/evidence/ordered-outcome-and-error-mapping.md). Real Foundation host cases prove final-fault command suppression before generic runtime application, first interruption/terminal verdict precedence, concurrent same-node/null-iteration exact isolation with frozen sibling/physical wait facts, and outward notification codes/ordered payloads through nested BPMN. Four real coded-error cases distinguish authored bpmn.error category/FaultType from incident.Code/classification; graph boundary preserves domain identifier and original cause. Focused10/0/0; whole BPMN303/0/0. Six behavioral mutants yield nine failures/four companion passes, then exact source restoration; three component audits clean/full-PR rounds zero. T017/T024 and broadcast retain separate source-bound proof. T025, binding/called-control/final Workbench/Studio, deletion/guards/protected delivery/resulting-main and ADR0063 remain open.

A valid new graph sends two parallel tokens to one bound host node, creating different handles/tokens with the same node, element and null iteration. The selected handle is not the first history match. Its normal nested Event completion triggers the real ordered fault+notifications. The other reporter, leaf and exact physical wait generation/scope equal JSON frozen before the action; only the selected token is pruned. The untouched invocation later runs its own handler and absorbs its own different incident, completing the workflow. The initially attempted reuse of one binding by two elements is rejected by the released validator and retained as unqualified, never weakened.

A nested BPMN witness confirms both outward notification codes and raw ordinal1/2 payloads reach actual outer OutcomeAsync unchanged despite the inner final fault. The outer handler runs once and absorbs the exact inner incident while original leaf/inner Faulted evidence remains. Four authored-code controls distinguish matching bpmn.error/FaultType from mismatching types, foreign categories and ordinary matching-looking incident.Code values, retaining original child metadata/incident FailureType and mapping only the authored BPMN code onto propagated parent classification. The existing graph refusal now checks domain node identifier/original library cause and actual host failure without orphan dispatch. The existing withheld-variable test remains explicitly a supplied-envelope/synthetic adapter boundary control, not actual upgrade or Studio evidence.

Final **focused10/0/0; whole BPMN303/0/0**, including six newly discovered cases. Six behavioral mutants produce nine failures/four companion passes and no compile failures: incident-code matching fails4; dropping outward signals faults outer workflow; first node/null-iteration lookup changes another invocation's complete durable facts; overwriting first verdict fails before coherent application returns; allowing starts after Fault exposes2 staged handler requests; raw graph wrapper leaks the library exception at the direct pre-host assertion. Exact production bytes are restored before final normal tests. The source-bound receipt includes18 current source/doc hashes,7 binaries, released0.5.0 deps, all8 unchanged captures, historical receipts and frozen authoring. No production code or authoring contract changed. Three independent correctness/standards/acceptance component audits clean; full-PR rounds remain zero, maximum six.

T017, T024 and T049/T050/T051 retain their separately recorded actual-provider/broadcast qualifications; prior receipts are not rewritten or restamped. Remaining T025 native Sequence/Flowchart, T029/T045 binding/called-control and final actual Workbench/current Studio, T032 legacy writer/duplicate semantics deletion and T033–T035 guards/audits, T036–T038 final qualification/full-PR review/required green exact-head checks/protected merge/resulting-main, then separate ADR0063. New-head CI applies; required GitGuardian public-source-digest incidents still need legitimate resolution, no bypass or merge to main.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled through the Codex App. #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Overall state stays accurate, so no no-op field writes. Existing organization Projects read/write works; no extra App permission is needed. Independent production/program acceptance stays open; Orleans/task-runner deferred. Goal active.

## #2892 6448485623 elsa-workflows-codex[bot] 2026-10-27T17:12:32Z
**T025 complete: native parents, provider recovery and replay** at `5f87f3a7ce4b671ed850311f60d2a0a586421611` on sole draft #3338.

Current native-parent checkpoint: [T025 qualified through actual EF runtime](https://github.com/elsa-workflows/elsa-foundation/blob/5f87f3a7ce4b671ed850311f60d2a0a586421611/specs/1006-bpmn-library-adoption/evidence/native-parent-ef-qualification.md). Published native Sequence/Flowchart + released BPMN0.5.0 run in positively verified Durable/Balanced modes: both completion/result orders, pre-acceptance provider restart, before/mid-result cancellation with fresh late-pointer replay, original typed-fault acceptance and fresh terminal replay. Live actual captured parent callbacks and saved worker pointers are separately replayed; complete durable/context/root-variable facts remain equal. Sequence/Flowchart fault-policy differences remain explicit. Native/legacy60 plus combined-regression3 = focused63/0/0; whole EF1678/0/0. Native mutants fail12 and4 with4 companion passes; corrected combined controls independently fail1 each. Production bytes restored. Three bounded audits/full-PR rounds zero. Binding/called-control, final actual Workbench/Studio, deletion/guards/protected delivery/resulting-main and separate ADR0063 remain open.

The native class grows19→43 cases: 36BPMN/native +7retained generic controls. Both actual persisted modes cover twelve completion-order cases, four before-claim cancellations, eight mid-cancel cases, four existing typed-fault controls and eight new typed-fault pre-acceptance/recovery/replay cases. Workers produce real ResultReady data before the original provider disposes. Fresh providers retain exact publication pins and original typed result/incident facts. Sequence remains Running inside the Faulted workflow, while Flowchart itself becomes Faulted. Final counters and body counts retain original assertions.

Final focused **63/0/0**, including60 native/legacy +3combined regression; whole Runtime EF **1678/0/0**. The initial final whole run1677pass/1fail exposed T024 sequential-read skew: activity suspension precedes a separate physical bookmark checkpoint. The final predicate positively requires BookmarkWaiting, exact activity/physical bookmark linkage and the same nonempty CreateBookmark scheduler-work ID before accepting the original held-ACK cut. All comparison fields remain. An attempted wait for the whole sweep depended on the deliberately held delivery and timed out in normal/mutant runs; removed and excluded. The final two combined mutants again fail at actual duplicate adapter evaluation and original incident absorption, respectively. Native mutants separately fail all12 live-callback full-fact comparisons and all4Sequence fault-status cases, with4Flowchart companion passes. The first compile-only Sequence mutation is excluded. Exact production sources restored before final normal tests.

Portable receipt binds current test/adapter/runtime sources, seven current binaries, released0.5.0 dependencies, all8 unchanged actual old captures, frozen historical receipts and authoring fingerprint. No production semantics or package/authoring contract changed. Three independent correctness/standards/acceptance component audits clean; full-PR rounds remain zero, bound six.

T017/T021/T022/T024 and broadcast qualifications remain source-specific. T029/T045 binding/called-control and final actual Workbench/current Studio, T032 semantic writer/duplicate deletion and T033–T035 guards/audits, T036–T038 final qualification/full-PR review/required green exact-head checks/protected merge/resulting-main, then separate ADR0063 remain open. Required GitGuardian public-source-digest incidents still need legitimate resolution; no bypass or merge to main.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) refreshed through Codex App. #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Existing organization Projects read/write works; no additional permission needed. No no-op field mutations. Independent production/program acceptance stays open; Orleans/task-runner deferred. Goal active.

## #2892 6448999349 elsa-workflows-codex[bot] 2026-10-27T17:32:46Z
**T045 increment: actual called coded errors, caller commit before ACK and fresh-provider retry** at `eb26aeedf2cb24ef0b56a102420deb03f50ee24a` on sole draft #3338. T045 remains unchecked.

Current called-error checkpoint: [T045 coded-error/terminal-retry EF increment](https://github.com/elsa-workflows/elsa-foundation/blob/eb26aeedf2cb24ef0b56a102420deb03f50ee24a/specs/1006-bpmn-library-adoption/evidence/called-coded-error-ef-recovery.md). Four real published/pinned caller/DispatchWorkflow/BPMN child cases cover ORDER match and OTHER mismatch in Durable/Balanced modes through three providers: outage before caller delivery, actual caller inbox checkpoint before controlled ACK loss, then unchanged-source retry to Delivered. Child workflow remains Faulted with original typed root/blocking incident; dispatch leaf completes normally with Faulted outcome. Full activity/incident documents and named workflow status/pin/mode facts remain truthful across retry. Focused4/0/0; whole EF1682/0/0; two restored behavioral mutants six failures/two companion passes. Three bounded audits/full-PR rounds zero. T045 remains open for remaining escalation/ordering/concurrency/cancellation/empty-barrier/split-batch and actual Workbench; T029/final Studio/deletion/guards/protected delivery/resulting-main/ADR0063 remain open.

The caller and separately dispatched child are real published executable/source records over SQLite. The called BPMN root executes an error end event and produces terminal ordinal0/empty-notification control with ORDER or OTHER. The caller boundary accepts only ORDER. Both modes are positively read on the actual caller and child. First provider records a controlled before-delivery failure while the caller is genuinely Suspended/Running and the child is Faulted. Its original typed root and ActivityReturnedFault blocking incident stay unchanged; authored classification remains separate from generic safe Faulted diagnostics.

Second provider reuses the identical committed source and normal runtime resume path. The calling DispatchWorkflow leaf completes normally with Faulted outcome, no local fault, exact terminal-consumed inbox/cursor1/address, no pending batch and a processed-parent receipt. ORDER completes its handler/caller without caller incidents; OTHER faults the caller with the original authored classification. Before ACK, an independent concrete EF read proves the exact accepted caller inbox, while the source is still Delivering with positive fence and prior result count1. A controlled after-effect timeout records retryable result2. Third provider settles identical source as Delivered/result3, preserving complete caller/child activity and incident documents, empty caller bookmarks and no poison. Child Faulted/pin/mode and caller expected terminal status/pin/mode are rechecked on every corresponding final recovery read. This corrects a reviewer-found workflow-field assertion gap without claiming whole-workflow byte identity.

Final **focused4/0/0; whole Runtime EF1682/0/0**. Force-all-errors-to-ORDER mutant makes both OTHER cases incorrectly complete (2fail/2pass). Dropping ErrorCode makes both ORDER cases fault and both OTHER cases lose propagated classification (4fail/0pass). These failures occur during actual recovered caller routing/classification; exact production bytes restored before final normal verification. The initial mutation runner's expected counts were corrected to include the stronger OTHER classification assertions; no test weakened. Source-bound receipt includes current runtime/adapter/fixture files and10 current binaries, released0.5.0, all8 unchanged old captures, historical receipts and frozen authoring.

Initial compile, EF composition-order and CLR-name call-key failures are retained unqualified. The canonical published Elsa.DispatchWorkflow key fixes the fixture; the production caller-identity guard remains unchanged. Builders supply the pin/consumer declaration/input contract/resume map emitted by compilation; they do not prove public authoring compiler/HTTP import or real Workbench/Studio. Provider restart + controlled timeouts are not process-kill proof. Final duplicate uses normal consumed/terminal recognition; no repeated adapter evaluation is claimed. Three independent bounded correctness/standards/acceptance audits clean; full-PR rounds zero, maximum six.

Remaining T045: running/terminal escalation kinds, signal/failure precedence, same-binding concurrent calls and exact child cancellation, split/concurrent claims, terminal-success/ordinary-fault empty barriers before earlier escalation with buffered-gap restart, deliberate split-terminal mutation, no-capability legacy recovery and actual Workbench proof. T029 ordinary compensation, final actual current Studio, T032 old writer/duplicate semantics deletion, T033–T035 guards/audits, T036–T038 final qualification/full-PR/required green exact-head checks/protected merge/resulting-main, then separate ADR0063 stay open. Required GitGuardian public-source-digest incidents need legitimate resolution; no bypass or merge to main.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) refreshed through Codex App. #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Organization Projects read/write already works; no additional App permission needed and no no-op field writes. Independent production/program evidence stays open; Orleans/task-runner deferred. Goal active.

## #2892 6449193059 elsa-workflows-codex[bot] 2026-10-27T17:39:07Z
**Current-main Studio integration verified** at `c7fae96c08b2cd9170a710bff33dc34575b7b70a` on sole draft #3338.

Current integration checkpoint: exact merge `c7fae96c08b2cd9170a710bff33dc34575b7b70a` adopts legitimate main `e1bbbe4d733f842b0aa2c501d03ca15c134684ae` (Studio #3403 live Test Run observation and #3404 package/consumer CI) onto delivered coded-error head `eb26aeedf2cb24ef0b56a102420deb03f50ee24a`. All 52 imported files equal that main; Foundation backend/root pins/build/spec1006 unchanged, latest 22 receipt bindings and 155 JSON/compressed evidence artifacts preserved. Workflow frontend 2,616 tests in 192 files, typecheck, isolated Chromium 14 and two package-tool self-tests pass. Three bounded integration audits clean/full-PR rounds zero. Self-tests do not establish actual package qualification; fixture browser tests do not qualify final real BPMN Workbench/Studio. Remaining T045/T029, deletion/guards/final checks/protected delivery/resulting-main and separate ADR0063 stay open.

Exact parents are delivered `eb26aeedf2cb24ef0b56a102420deb03f50ee24a` and current-main cut `e1bbbe4d733f842b0aa2c501d03ca15c134684ae`. Legitimate progress adds shared/live Test Run and instance observation, captured-snapshot safeguards/restoration, and the actual-package consumer qualification CI program. All 52 imported files are byte-identical to that main; no conflict or manual resolution. Foundation source/root package/build pins/spec1006 are byte-identical to the delivered parent. Existing 155 JSON/compressed evidence artifacts and all 22 latest coded-error source/doc bindings match. Frozen authoring is unchanged. No open main-is-red CI issue was found before integration.

Verification: `pnpm --filter @elsa-workflows/studio-workflows test --minWorkers=1 --maxWorkers=2` passes 2,616 tests in 192 files; workflow `typecheck` passes; Chromium editor-run-canvas +instance-live-canvas passes 14 with one worker. An ignored config spreads the committed Playwright config, sets testDir to resolved tests/browser, baseURL/webServer URL to 127.0.0.1:4181, Vite command with `--port 4181 --strictPort`, cwd current Studio and `reuseExistingServer=false`. The owned fixture exits. An initial maxWorkers-only invocation conflicted with Vitest's minimum and ran zero tests; retained separately as unqualified, corrected by explicit min 1/max 2. No product change was needed.

`python3 tools/ci/verify_studio_nuget_packages.py --self-test` and `python3 tools/ci/qualify_studio_consumers.py --self-test` pass. These are verifier/aggregation controls, not a new actual nupkg/consumer qualification on this adoption head. No .NET source changed; earlier source-specific Foundation EF 1,682 and Studio .NET 636 observations are inherited, not newly run/restamped. New-head CI remains authoritative for required checks. The browser cases are Vite fixtures, not the final real BPMN Studio journey.

```json
{
  "head": "c7fae96c08b2cd9170a710bff33dc34575b7b70a",
  "parents": [
    "eb26aeedf2cb24ef0b56a102420deb03f50ee24a",
    "e1bbbe4d733f842b0aa2c501d03ca15c134684ae"
  ],
  "adoptedMain": "e1bbbe4d733f842b0aa2c501d03ca15c134684ae",
  "adoptedPullRequests": [
    3403,
    3404
  ],
  "conflicts": false,
  "importedFilesSha256": {
    ".github/workflows/studio-ci.yml": "506690c02409d4668989485c704d298e7eacaed95971d6b58c236ec5289f1a3f",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/WorkflowCodeView.tsx": "bddaac47330215e0d406c230bb88bd2dcd9de2559ec476c43a9f4b434e93e306",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/WorkflowInstanceWorkbenchIntegration.test.tsx": "7419098c648b9b2c4c41aed321339ff434d5bac1b21f678f041bb9aed3923d43",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/activityExecutionBrowser.test.tsx": "daa1a62e8bfc6c62f12c0cbe469b1614208fe01aeb7264348ff09c6fac31a4d0",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/editorRunCanvas.test.tsx": "eb2592880f5ec5f1b33db86008736de731de9babf505b3c0ad388566a3d8a5d8",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/executionObservation.test.tsx": "640154d4c7d679fd846b28d497de67dc5f7c50461710dbfd18489a9025659180",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/pinnedEditorDocument.test.tsx": "f03a3c51c1fe46dfa048f42995b3e76464b0775e8d51262413dfad807dea2786",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/testRunObservation.test.tsx": "23fa64d06d56f489ee2e2c513888f00e73dec51bc965f0abd34e3873351786bb",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/testRunRestoration.test.tsx": "d5fb1a9c723df736032224c55ab95c10882c623ba9f1bccaccf48902be352497",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/visibleExecutionEvidence.test.tsx": "1e00d57921e9f3bb529915c158500d723eb9bd3753f43b03b85ce2fe6d995a54",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/workflowActivityExecutionDetails.test.tsx": "c4d4a373573a10c2b1130e4addadd8a78981fd7a768f0441af59e01af0416fdc",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/workflowCodeSnapshot.test.tsx": "5fdad7f2d123f4085c86799e5e43ac5c9176a5d7d1c71509769fedffafb656d4",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/workflowTestRunApi.test.ts": "96f0bb3ffaa8cb70cc0933355b6bb03f7b54fc76e449b98b0264ea3f496dd445",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/workflowTestRunControls.test.tsx": "bda608e7970609920e66e2e9bfd3cb476a5451e32cd3d05dd129baee07163899",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/api/publishing.ts": "afe29a7ae7ab9afcb5ed2a4ee9ce05ab7713c2a05226cd88e527ab2bd3a936b7",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/api/runtime.ts": "d3d24ac21dc1073676c21c0b56b6b87db946649074813fc5a1534d1e0b0ab1c5",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/ActivityExecutionBrowser.tsx": "75e08f6db446b9bd393e0f5e22397ba870be66176301dddc95b8d47c69134879",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/AttachedTestRunStatus.tsx": "6f0ed291958448f9d20ca1e7ded0bbcd95c0f85eaa73e2fb567f72aef8c58f0a",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/WorkflowActivityExecutionDetails.tsx": "e2b0546f0c04d2efa15cf6543774cf3a041cda1ee2972e7a42197324f59844f4",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/WorkflowEditor.tsx": "30dce1b107b75ab49d3a760a9c7ca1b43e26115bb3029bedceb789416a30cd25",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/WorkflowInstances.tsx": "c0a459d55aaca29fcfb4d3cd3cc95d706b5570d42a4f53eb51df3d0c9c07c9b9",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/WorkflowTestRunControls.tsx": "6a4c66813ae9ae3f4fe53364e5baff3babd21d88a35a2b962327bdd0322b4521",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/attachedTestRun.css": "add1b25987ee0f91f8471c926356eb040fadd4ca940c53c1c122c311fb316ee0",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/editorPanels.tsx": "68b95f986e4391ac45e4ede5ee181175558960eb99cf2f74dace6a9158c180e6",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/scopedExecutionEvidence.ts": "e55c418dbb6624758ee9b7577b564508a038b0ad05bc3ae7b52fe2b93d3673df",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/useEditorRunCanvas.ts": "27794a4eb22e89b7b421f548bbbaaf089af71d1ae100868f63ed52704d653d87",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/useExecutionObservation.ts": "81a5b0afc16f79385d582fd8b966a30b003284ceae57d1a97942b5c82bafc1d0",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/usePinnedEditorDocument.ts": "29e55e301204ac75bec0b13d07bddec56969206f3dd09f210fe027c09ebd04a9",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/useTestRunObservation.ts": "384ce41d07fbeae457bb1b133217f99a8f96407a4c4f725176b9d899b7336980",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/useTestRunRestoration.ts": "ec9ff122c040a546bd7a191f49c9a8670b92f1910147a4f279b29cf253845065",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/useWorkflowCanvas.ts": "7cc73c6f3de77a74c26488fa3952b298ea1c22bb930a0074ae13ad3b198f52b4",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/useWorkflowGraphOperationBatch.ts": "8ab7b4bccc66f01b99bc6e3ef30f7c6620d8a0bb9965e1d3bad3bb257144d669",
    "Studio/tests/browser/activityDuplicateEditorFixture.tsx": "48337607fedadf63bd4520bc61736d7d884cfddf0785a17ec8fbf24b22419e31",
    "Studio/tests/browser/editor-run-canvas.spec.ts": "0d1a221d855095eb4deef86fce942cc098311354eb628a12acf5c1b391338d02",
    "Studio/tests/browser/instance-live-canvas.spec.ts": "d75a7f1cc30c6d6d2f801ae3ebdc9d6e7a6c429d1e9e61dbaac29c2b254cdfd3",
    "Studio/tests/browser/workflow-definition-browse-context.spec.ts": "09351d33f33b161d68b0d154946f603cf20db2fbd08bd5185dfd7f9217524e12",
    "docs/program-goals/unified-workflow-workspace.md": "eae0859f13c0e81f62f218ae11fe1aa85cbd96b8d0bb09bd3000eaa93e7f690d",
    "specs/1015-studio-package-ci/data-model.md": "d7c495b56727d98265b4c7e6724530d2c6deaf4a5ea1ab2e3beb2a7fc51252b5",
    "specs/1015-studio-package-ci/plan.md": "4ea49a1918a34d408a44e02ab4a0748ceb98958a8f95803899d8705633593e76",
    "specs/1015-studio-package-ci/quickstart.md": "ee70d3cc854690b1f32cfdf92bb372078b12e469b8ab04262983c1929124b8b5",
    "specs/1015-studio-package-ci/research.md": "9ed49a3c43e2f1714a3d589447b599e4f252644fd0bea55fb4f87b366fda49ad",
    "specs/1015-studio-package-ci/spec.md": "6365f1990bc7ca1b5e461c1574437b972d53655d2a6c22e103248337c43f4547",
    "specs/1015-studio-package-ci/tasks.md": "e72e5921c0ade4622631773111b78d455c86fcfd1e9a1f21477ed805510644fa",
    "specs/1015-studio-package-ci/validation.md": "c490aea29da9cd138188d8c2e617cd32988ce257602c999a6b6dc9f86b329fe1",
    "tools/ci/qualify_studio_consumers.py": "37f2f7dfbb324c59f76080cfe2a0b49de05bf41c6fffcd601a1935cbbd1ac879",
    "tools/ci/studio-package-identities.json": "1a677c17033d550361d61688a9ee33958bddd012b7fa246f53df5254259b2ddf",
    "tools/ci/verify_studio_nuget_packages.py": "c4b546e6a52bc159748fc7237778a48d11e1e715772f74152b4ec5ca01985b17",
    "tools/studio/ApiPackageClosure.Probe/qualify.py": "89cac9c01be3c4a4692ce009936fcadcde09b88af11c19db5b138b1acc500508",
    "tools/studio/Composition.Probe/README.md": "51851d4422f60d62c13b1c1845be1f7da138f17b32e124a233e7ef61a3e4b28f",
    "tools/studio/Composition.Probe/journeys.py": "ea522d444afea6f4e7c4af74622701b36c920112bdbb94ec730d6fdbb683719e",
    "tools/studio/Composition.Probe/qualify.py": "1f1e8b02f417f6e099928ef92caa2586dafef9a839d0073f708083ccadedbb44",
    "tools/studio/README.md": "ad85c0ae514fb6609726ab106da9dd7365f9a068bde777663f09561a9ac5c880"
  },
  "foundationAndRootPinsBuildAndSpec1006Unchanged": true,
  "latestCodedErrorReceiptBindingsUnchanged": 22,
  "existingJsonAndCompressedCheckpointEvidenceUnchanged": 155,
  "frozenAuthoringSha256": "41aa0bb979ea46fc2533b057e3677f408ab54c3411fecfafaa238a2adae38c92",
  "checks": [
    {
      "name": "workflow frontend units",
      "result": "passed",
      "logSha256": "1811919a3fe5d7e759e6837ea2efef5c2ba71ede1424e41c33dc17ee81a7bba4"
    },
    {
      "name": "workflow typecheck",
      "result": "passed",
      "logSha256": "70685b4df7789c854b9e1ceab7d78a6d0f9a0831c11eb0010b7b5fdbe0e50c39"
    },
    {
      "name": "isolated Chromium editor/instance canvas",
      "result": "passed",
      "logSha256": "f14718973ee0902bbef9770dc2aacd7e23b4a1ef5c156765077abdb4c4258676"
    },
    {
      "name": "NuGet verifier self-test",
      "result": "passed",
      "logSha256": "4bfc2cdd87470e1d8c91c15f6df7f1f7b1838e90283249047953fa2b06bb374f"
    },
    {
      "name": "consumer aggregation self-test",
      "result": "passed",
      "logSha256": "7b8a96423d9ef329a8db7cc146104d86f6e63bf5e7cb787dc7123bd868a2278f"
    }
  ],
  "workflowFrontendCases": 2616,
  "workflowFrontendFiles": 192,
  "chromiumCases": 14,
  "isolatedBrowser": {
    "port": 4181,
    "strictPort": true,
    "reuseExistingServer": false,
    "ownedServerExited": true,
    "configurationSha256": "dc8ab99f4959b854fb63c474e981f7b3a93f9c47368c81978e1c3449d456adc0"
  },
  "unqualifiedAttempt": {
    "reason": "maxWorkers-only command conflicts with Vitest minimum; zero tests ran. Corrected invocation uses minWorkers1/maxWorkers2.",
    "logSha256": "52fd00af9b06309433b966cf511b577bcf26067a0f0cb07f20def5e0cd0f8390"
  },
  "inheritedEvidence": "No .NET source changed; prior Foundation EF1682 and Studio .NET636 remain their original source-specific observations, not newly run or restamped.",
  "limits": [
    "Package verifier/consumer aggregation self-tests are not actual nupkg/consumer qualification on this head.",
    "Chromium tests use Vite fixtures, not final real BPMN Workbench/Studio journey.",
    "Adoption delivery/required exact-head checks/production and resulting-main acceptance remain open."
  ],
  "reviews": "three independent bounded integration source/artifact audits; full-PR rounds0",
  "fullPrRounds": 0
}
```

T017/T021/T022/T024/T025 and T049/T050/T051 remain complete within their source-specific scopes. The delivered four-case called coded-error EF increment remains a partial T045 qualification; its remaining escalation/ordering/concurrency/cancellation/empty-barrier/split-batch/no-capability legacy and actual Workbench matrix is open. T029 ordinary compensation/final actual current Studio, T032–T035 deletion/guards/audits, T036–T038 final qualification/full-PR/required green exact-head checks/protected merge/resulting-main and separate ADR0063 stay open. Required GitGuardian public-source-digest incidents need legitimate resolution; no bypass or merge to main. Full-PR rounds zero, bound six.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) refreshed through working Codex App organization Projects read/write. #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. No no-op field writes or extra App permission needed. Independent production/program acceptance stays open; Orleans/task-runner deferred. Goal active.

## #2892 6449686378 elsa-workflows-codex[bot] 2026-10-27T17:59:20Z
**T045 increment: actual running/terminal escalation and fresh-provider duplicate delivery** at `4b012b1633884a6b63b1d8fe53792b257e2c7cb9` on sole draft #3338. T045 remains unchecked.

Current called-escalation checkpoint: [T045 running/terminal escalation EF increment](https://github.com/elsa-workflows/elsa-foundation/blob/4b012b1633884a6b63b1d8fe53792b257e2c7cb9/specs/1006-bpmn-library-adoption/evidence/called-escalation-ef-recovery.md). Eight cases cover both interruption policies, running/terminal emission and Durable/Balanced modes through real published DispatchWorkflow/BPMN roots. A real warning Event keeps the caller Running while exact child cancellation/status and fresh-provider duplicate delivery are proved. Original Delivered source and full activity/incident/physical wait facts remain equal; duplicate adds no ControlAsync evaluation. Non-interrupting live child later emits actual empty terminal ordinal one/cursor two. Focused 12/0/0; whole EF 1,690/0/0. Two restored mutants: 10 failures/six companion passes; three bounded audits/full-PR rounds zero. T045 remains open for failure/concurrency/gap/split/no-capability legacy/actual Workbench; T029/final Studio/deletion/guards/protected delivery/resulting-main/ADR0063 stay open.

The original provider disposes. A fresh provider receives the identical actually dispatched intent with its retained original source. Complete committed caller/child activity and incident documents, physical bookmark observations and named workflow status/pin/mode fields remain equal; the complete Delivered source row remains equal. A passive six-method forwarding adapter observer records exactly one initial ControlAsync at ordinal zero for the actual calling invocation; duplicate dispatch adds none. This is original-message duplicate delivery, not a fabricated/newly claimed source retry or a claim that a particular scheduler early-return was re-entered.

After duplicate verification, normal warning Event resume completes that handler once. Only the non-interrupting running call remains waiting. Its original child Event then resumes normally, producing a real empty terminal ordinal one for the same root/dispatch; one actual terminal ControlAsync consumes it with inbox cursor two/no pending batch, runs the normal branch and completes. This barrier is in order, not the required terminal-before-earlier-escalation gap witness. All final caller/child statuses, pins and persisted modes are rechecked with no remaining waits, incidents or poison. Snapshot equality is complete activity/incident plus physical bookmark/named workflow fields, not whole-workflow bytes or complete variable comparison. Concurrent same-binding cancellation isolation remains separate.

Final **focused 12/0/0** includes eight new rows plus the four prior coded-error/ACK-loss cases under the passive observer; **whole Runtime EF 1,690/0/0**. Omitted explicit cancellation fails both running-interruption rows on missing actual targeted cancel intents before their child-status assertions, with six companion passes. Foreign notification code fails all eight after real source/delivery and ControlAsync entry: two at missing cancellation, six at missing warning handler. Neither mutant reaches fresh-provider duplicate replay. Exact production bytes restored before final normal runs. Earlier completing-warning positive runs establish basic routing only and are excluded from the stronger held-handler cut.

Portable receipt binds 25 current source/doc files, ten binaries, released dependencies, eight unchanged old captures, twelve frozen historical receipts and unchanged authoring fingerprint. No production semantics/package/authoring change. Builders still supply compilation output; provider restart is not process kill and these tests do not prove public compiler/HTTP host or final Studio. Three independent correctness/standards/acceptance component audits clean; full-PR rounds zero, bound six.

Remaining T045 includes signal/failure precedence, concurrent same-binding calls/cancellation isolation, split/concurrent claims, empty terminal-success/ordinary-fault barriers before earlier escalation with gap-buffered restart, deliberate split-terminal mutation, no-capability legacy recovery and actual Workbench. T029 ordinary compensation, final real current Studio, T032 old writer/duplicate deletion and T033–T035 guards/audits, T036–T038 final qualification/full-PR/required green exact-head checks/protected merge/resulting-main and separate ADR0063 stay open. Current main e1bb is integrated; required GitGuardian still reports the same three public-source-digest incidents, which require legitimate resolution. No bypass or merge to main.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) refreshed through Codex App. #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Organization Projects read/write works; no extra App permission or no-op field writes needed. Independent production/program acceptance stays open; Orleans/task-runner deferred. Goal active.

## #2892 6450366517 elsa-workflows-codex[bot] 2026-10-27T18:30:28Z
**T045 increment: ordered source recovery and indivisible terminal decisions** at `d646483bcb958ceeb7f45f63dc1201c26feb3562` on sole draft #3338. T045 stays unchecked.

Current called-ordering checkpoint: [T045 ordered recovery/indivisible terminal EF increment](https://github.com/elsa-workflows/elsa-foundation/blob/d646483bcb958ceeb7f45f63dc1201c26feb3562/specs/1006-bpmn-library-adoption/evidence/called-control-ordering-ef-recovery.md). Actual empty terminal one is accepted before held escalation zero with Pending1/cursor0/processed receipt, unchanged caller private state and zero control callbacks; it survives fresh-provider retries, then one actual [0,1] evaluation consumes the prefix. Real same-terminal WARN+OTHER proves non-interrupting failure start suppression and first-interruption handling while child fault/incident truth stays intact. Focused 20/0/0; whole EF 1,698/0/0. Three restored mutants: ten failures/two companion passes, including terminal-half splitting. Three bounded audits/full-PR rounds zero. T045 remains open for concurrency/cancellation isolation, split/concurrent claims, no-capability legacy and actual Workbench; T029/final Studio/deletion/guards/protected delivery/resulting-main/ADR0063 stay open.

Eight new rows cover Durable/Balanced modes. The child actually emits WARN ordinal0, then waits at an Event. A forwarding outage holds0 before its effect under real UntilAcknowledged retry. Actual child Event resume produces a fresh empty terminal1 for either success or ordinary fault, with truthful Completed/Faulted dispatch status and no invented authored error. Terminal1 delivers and commits the completed calling leaf, exact Pending1/cursor0/not-consumed inbox and original processed-parent receipt. Caller remains Running with its complete BPMN private-state envelope unchanged, no warning/normal work and no ControlAsync invocation.

After disposal, a fresh provider reads the identical buffered projection, keeps0 held while its real retry count increases, and still cannot advance. The complete Delivered terminal row stays equal. Release0 normally: one actual callback gets [0,1] for the exact call, commits cursor2/terminal-consumed/no pending and preserves the original completion receipt. For success, actual returned Defer stages warning+normal; warning Event later completes the caller. For ordinary fault, actual returned Fault stages no work before generic application, leaves both branches unstarted and preserves unclassified bpmn.call-activity.faulted plus the actual child's original blocking fault/incident documents.

A real parallel child evaluation also produces one terminal0 carrying WARN notification and authored OTHER failure together. A before-delivery outage and fresh-provider recovery preserve that whole source. Non-interrupting failure returns Fault with zero staged schedules; first interruption returns Defer with only its warning branch and later completes via normal warning Event. Both preserve the already Faulted child's exact original incident, keep the dispatch leaf normally Completed/Faulted-outcome with no local fault, consume the exact terminal inbox and never recancel the terminal child. Actual returned verdicts/staged schedules/cancellations are passively observed before generic runtime application.

Final **focused 20/0/0** includes eight new plus twelve prior bridge cases; **whole Runtime EF 1,698/0/0**. Three compiled behavioral variants restore all production bytes exactly before final normal verification: skipping the initial cursor causes an early terminal1 callback (4fail); truncating ready data while retaining terminal outcomes yields no consumer callback (4fail, source contract enforces terminal/outcome consistency, no partial[0] callback claimed); dropping terminal interpretation from a notifying batch incorrectly leaves both non-interrupting callers Running (2fail), while two first-interruption companions pass. Ten failures/two companion passes. Failure phases and source-backed interpretations are explicit in the portable receipt.

Remaining T045: concurrent same-binding calls/cancellation isolation, split/concurrent claims, no-capability legacy recovery and actual Workbench. T029 ordinary compensation, final real current Studio, T032 legacy writer/duplicate deletion, T033–T035 guards/audits, T036–T038 final qualification/full-PR/required green exact-head checks/protected merge/resulting-main, then separate ADR0063 stay open. New legitimate Studio #3405 motion progress has been discovered on main `93bbf110c8b646fb9159e1a2fe057f01de3a07dd` and will be integrated next. Required GitGuardian still flags the same three verified public-source hashes. Its proper false-positive action is available, but the single pending account-identity exception card must be answered before acting through the owner's GitGuardian account; no check override, blanket ignore, history rewrite or merge to main.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled through Codex App. #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Organization Projects read/write already works; no extra App permission or no-op field writes needed. Independent production/program acceptance stays open; Orleans/task-runner deferred. Goal active.

## #2892 6450577018 elsa-workflows-codex[bot] 2026-10-27T18:40:43Z
**Current-main confirmed Studio motion integration verified** at `249c1d2751bba58140ea3e9bf072e4fec54600d6` on sole draft #3338.

Current integration checkpoint: exact merge `249c1d2751bba58140ea3e9bf072e4fec54600d6` adopts legitimate main `93bbf110c8b646fb9159e1a2fe057f01de3a07dd` (Studio #3405 confirmed execution motion) onto delivered ordering head `d646483bcb958ceeb7f45f63dc1201c26feb3562`. All 21 imported Studio files equal that main; Foundation backend/root pins/build/spec1006, 32 ordering bindings and 157 JSON/compressed evidence artifacts stay unchanged. Workflow frontend 2,639 tests/194 files, typecheck and isolated Chromium 28 pass. Three bounded integration audits clean/full-PR rounds zero. Fixture browser checks do not qualify final real BPMN Workbench/Studio; unchanged EF/.NET/package-tool observations retain their original scope. T045 concurrency/claims/legacy/actual host, T029/final Studio/deletion/guards/protected delivery/resulting-main/ADR0063 remain open.

Exact parents are delivered `d646483bcb958ceeb7f45f63dc1201c26feb3562` and main `93bbf110c8b646fb9159e1a2fe057f01de3a07dd`. Legitimate #3405 progress adds confirmed scoped execution-motion cues in editor/instance/native/BPMN views, recovered baselines and expired/reduced-motion safeguards. All 21 imported frontend files match that exact main; no conflict or manual resolution. There is no Foundation backend, root package/build, packaging/tool or spec1006 delta from the delivered parent. All 32 latest ordering receipt bindings and 157 existing JSON/compressed evidence artifacts still match; authoring fingerprint unchanged. Current org protocol remains unchanged; no open main-is-red CI issue found.

Verification: workflow frontend `pnpm --filter @elsa-workflows/studio-workflows test --minWorkers=1 --maxWorkers=2` passes **2,639 tests across 194 files**; workflow `typecheck` passes; Chromium editor-run-canvas +instance-live-canvas +execution-motion passes **28 cases**, one worker. The ignored config spreads the committed Playwright config, resolves tests/browser, uses baseURL and webServer URL 127.0.0.1:4181, Vite `--port 4181 --strictPort`, current Studio cwd and `reuseExistingServer=false`. The owned fixture exits; user servers are untouched. These are Vite fixtures, not the final actual BPMN Studio journey.

No .NET/packaging/tool source changed, so prior source-bound Foundation EF 1,698, Studio.NET 636 and package verifier/consumer self-tests remain original observations rather than newly run/restamped results. Actual package qualification and required checks follow new-head CI; this increment makes no additional nupkg/consumer claim.

```json
{
  "head": "249c1d2751bba58140ea3e9bf072e4fec54600d6",
  "parents": [
    "d646483bcb958ceeb7f45f63dc1201c26feb3562",
    "93bbf110c8b646fb9159e1a2fe057f01de3a07dd"
  ],
  "adoptedMain": "93bbf110c8b646fb9159e1a2fe057f01de3a07dd",
  "adoptedPullRequests": [
    3405
  ],
  "conflicts": false,
  "importedFilesSha256": {
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/scripts/probes/execution-motion-lifecycle.mjs": "c7a0e8769af050cc337055581a1d70f58ecdd64c390cda527f507a0132e7915d",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/executionMotion.test.tsx": "ce61f5d29235a532153a0ebe7392da3ac83838075a8d43a953bfe4ad9f208151",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/__tests__/executionMotionLifecycle.test.ts": "2d2f3a44cdf717282742ae5d86c47cba18ff62f06641d5e308021e19d6491e24",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/api/runtime.ts": "82d1740d1433a3ca4ab6030304de83df87f4a8f2b00a51d808dae82933dac167",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/bpmn/BpmnElementNode.tsx": "5e9f7bcf4cc03b6d39c72ad9f707f0c54723dda88c9e57c905546b2132619740",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/bpmn/bpmnAdapter.ts": "cb8fddc9d48c0ebf687bab765666253a6320aaafa618d78266f7d4a049a73a73",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/graph-authoring/SequenceDesigner.tsx": "7f51bb001c8e0239eeeabfc8b192a9751868f7036c064c56122cf26339a76334",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/ExecutionMotionPulse.tsx": "52d6c2a3497840d0206dbeed63574fec297f1b7970846d105c8aeba086ca542c",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/WorkflowEditor.tsx": "32442e4b27518d31b7c181c6d6ef6e4c641c52f748f9891a9286ca1aeffabf06",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/WorkflowInstances.tsx": "fa74db640b4a7cd1c0897ee8154e109db04fd53e4e13c649661ab1c5d91b8f34",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/editorTypes.ts": "0c1fbbba11d1a4bafaa9690c8ccae5bc36816ce58eb3f5c7636422fc4328ecf3",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/executionMotion.css": "5a01fd85ef31fc5ecfa8094f5843f6db18a20030c7f6d579a6561f90a5a14b8f",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/executionMotion.ts": "514ce35fc957392eab0caddfe2005e4eb9eb356e238a3f868b2dac1829892ddd",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/graph.tsx": "664ad7addbb420aaa189f3a8e2b68550c89154d2b08df10a444f82c7a4e87bd1",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/scopedExecutionEvidence.ts": "f1c60f7ef28322f3ec0ee46f765c21375cdc62be617728bea32b5ab35d170305",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/useEditorRunCanvas.ts": "f152404e442b633582a6a13ed2215f45b1b9bb9e78883c8dbc7c025794e896e8",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflow-editor/useWorkflowOperations.ts": "0b7abdf4738345919e695d809248801d14815db1a9145aa51e3982ae83f07edd",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflowAdapter.ts": "bb9bccbab42f6e135e1703b6cd3ce3521ecabfe72a4a597920c2dd54e29a9dbd",
    "Studio/src/essentials/Elsa.Studio.Workflows/Client/src/workflowTypes.ts": "8cd71db41a33da79a3121af4fc945f8054bb589fb8b2d627d4e382e131e3fefb",
    "Studio/tests/browser/activityDuplicateEditorFixture.tsx": "0c258a8c258cf3f14eb055780fa47fda8be63e095247071d876d285aa83affbf",
    "Studio/tests/browser/execution-motion.spec.ts": "97eb155e5f0ab224d3413d60c683f1431725d5b7419d6869343345bcdb235ecf"
  },
  "foundationAndRootPinsBuildAndSpec1006Unchanged": true,
  "latestOrderingReceiptBindingsUnchanged": 32,
  "existingJsonAndCompressedCheckpointEvidenceUnchanged": 157,
  "frozenAuthoringSha256": "41aa0bb979ea46fc2533b057e3677f408ab54c3411fecfafaa238a2adae38c92",
  "checks": [
    {
      "name": "workflow frontend units",
      "result": "passed",
      "logSha256": "3c8e9a9ca17926ca13eb759ac4ab4b6055871a7371ec1f54a85ec0799941a4e2"
    },
    {
      "name": "workflow typecheck",
      "result": "passed",
      "logSha256": "70685b4df7789c854b9e1ceab7d78a6d0f9a0831c11eb0010b7b5fdbe0e50c39"
    },
    {
      "name": "isolated Chromium editor/instance/motion",
      "result": "passed",
      "logSha256": "9783df0700e32bd00febf172a45c370c8875979dd2156e18a054bafbd44a728f"
    }
  ],
  "workflowFrontendCases": 2639,
  "workflowFrontendFiles": 194,
  "chromiumCases": 28,
  "isolatedBrowser": {
    "port": 4181,
    "strictPort": true,
    "reuseExistingServer": false,
    "ownedServerExited": true,
    "configurationSha256": "ea8360f9cd6641e98ecbf601449388f706305676e089138a03b29503128f069e"
  },
  "inheritedEvidence": "No .NET/packaging/tool source changed. Prior source-bound Foundation EF1698, Studio.NET636 and package-tool selftests remain original observations, not rerun or restamped.",
  "limits": [
    "Vite editor/instance/motion fixtures, not final actual BPMN Workbench/Studio acceptance.",
    "Required exact-head CI, final delivery/resulting-main and independent production/program evidence stay open."
  ],
  "reviews": "three independent bounded integration source/artifact audits; full-PR rounds0",
  "fullPrRounds": 0
}
```

T017/T021/T022/T024/T025 and broadcast T049/T050/T051 keep their prior source-specific closure. Called coded-error, escalation and ordering increments qualify their bounded EF behaviors, while T045 still needs concurrent same-binding/cancellation isolation, split/concurrent claims, no-capability legacy and actual Workbench. T029 ordinary compensation, final real current Studio, T032–T035 deletion/guards/audits, T036–T038 final qualification/full-PR/required green exact-head checks/protected merge/resulting-main and separate ADR0063 remain open. Required GitGuardian's three verified public-source-hash false positives await the single account-identity exception card before using the owner's GitGuardian account; no override, blanket ignore or history rewrite. Full-PR rounds zero, bound six.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) refreshed through Codex App. Its actual field inventory contains normal status/progress fields, with no separate evidence-link field. Latest issue/PR checkpoints carry the receipts; board status stays truthful: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Organization Projects read/write is confirmed working under elsa-workflows-codex[bot], so no extra App permission/no-op field writes needed. Independent production/program acceptance stays open; Orleans/task-runner deferred. Goal active.

## #2892 6451171384 elsa-workflows-codex[bot] 2026-10-27T19:10:00Z
**T045 increment: exact concurrent same-binding call isolation** at `edda36d449f58fcb73aa291a03915327db9211a9` on sole draft #3338. T045 stays unchecked.

Current called-isolation checkpoint: [T045 exact same-binding sibling isolation through EF](https://github.com/elsa-workflows/elsa-foundation/blob/edda36d449f58fcb73aa291a03915327db9211a9/specs/1006-bpmn-library-adoption/evidence/called-sibling-isolation-ef-recovery.md). Two parallel tokens share one valid call element/binding and null iteration; the second actual semantic token maps to its exact durable call/dispatch/child. Three providers prove selected handling preserves the other complete linked activity/incident/physical wait facts, followed by independent other handling while selected finished facts stay equal. Actual cancellation payloads target only the exact dispatch/call/child. Focused24/0/0 and wholeEF1,702/0/0 match discovery. Two restored mutants yield six failures/two companion passes. Three bounded audits/full-PR rounds zero. T045 remains open for split/concurrent claims, no-capability legacy and actual Workbench; T029/final real Studio/deletion/guards/protected delivery/resulting-main/ADR0063 stay open.

After first-provider disposal, fresh provider two positively reads both unchanged linked projections. Only the selected child's normal Event resumes and produces its actual WARN ordinal0. Exactly that call receives control. An interrupting actual CancelChild payload names only its dispatch/call/child; non-interruption keeps it live until its actual finish Event emits empty terminal1. The other full call/dispatch/child activity/incident and physical bookmark observations remain equal. Real warning Event waits hold the caller live during checks. After selected handling, exactly the other semantic token remains. Provider three positively reads stable parent/other and finished-selected projections, then handles the other's own emit/finish independently while selected finished facts stay equal. Final caller/call/child/dispatch truth, pins/modes, expected branch counts, normal terminal PrivateState cleanup, and no physical waits/incidents/poison are asserted.

Final **focused24/0/0** includes four new plus twenty prior called-control cases; **whole Runtime EF1,702/0/0**, matching discovery1702/class24. Two compiled behavioral variants restore all production bytes before final verification. First-semantic-token fallback fails all4 during initial selected handling: interrupting cases lack expected actual cancellation, non-interrupting callers are Faulted rather than Running. No wrong-target cancellation or later mutant replay is claimed. Spreading one call cancellation to all waited siblings fails both interrupting cases at the single-control assertion: two distinct calling invocations receive callbacks; both non-interrupting companions pass. Six failures/two companion passes. Initial terminal-cleanup fixture failures and earlier positive pre-adversarial-selection runs remain supporting/unqualified history, not final proof.

Next T045 gates are actual split/concurrent claims, no-capability legacy recovery and complete Workbench bridge. T029 ordinary compensation, final real current Studio, T032 deletion after all actual captures/upgraded-host proof, T033–T035 guards/audits, T036–T038 final qualification/full-PR/required green exact-head checks/protected merge/resulting-main, then separate ADR0063 remain open. Main93bb/Studio3405 integration stays exact and unchanged. Required GitGuardian still has the same three verified public-source SHA256 false positives; the single owner GitGuardian-account identity exception card remains pending. No override, blanket ignore, history rewrite or merge to main.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled through Codex App. #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Organization Projects read/write already works: no additional App access needed. Evidence is on linked issue/PR checkpoints; the project has no evidence-link custom field and unchanged field values need no no-op writes. Independent production/program acceptance stays open; Orleans/task-runner deferred. Existing goal active.

## #2892 6451428626 elsa-workflows-codex[bot] 2026-10-27T19:22:55Z
**T045 increment: actual called-control split and expired claim recovery** at `091918fe0f92bf217516158982b9cbf881197a1b` on sole draft #3338. T045 stays unchecked.

Current called-claims checkpoint: [T045 actual split/expired claim EF recovery](https://github.com/elsa-workflows/elsa-foundation/blob/091918fe0f92bf217516158982b9cbf881197a1b/specs/1006-bpmn-library-adoption/evidence/called-claims-ef-recovery.md). Distinct providers prove pre-expiry exclusion, higher-fence takeover before/after actual caller acceptance, exactly one control decision and old-owner Superseded without winner changes. Separate live claims accept actual empty terminal1 while0remains held/unexpired, preserving Pending1/cursor0/semantic state/no callbacks until one[0,1] decision. Focused32/0/0 and wholeEF1,710/0/0 match discovery. Two restored mutations fail4 each at documented stale-classification/early-consumption phases. Three bounded audits/full-PR rounds zero. T045 stays open for actual no-capability legacy recovery and complete Workbench; T029/final real Studio/deletion/guards/protected delivery/resulting-main/ADR0063 remain open.

Eight new cases use Durable/Balanced modes and real published/pinned caller/child roots, producers, SQLite outbox claims, normal notification/bookmark/scheduler/inbox paths and released0.5.0. Four takeover rows hold the real notification handler before effect or after actual caller acceptance, with concrete source Delivering/owner/fence/deadline and after-effect inbox/cursor1/warning Event proof. A separate peer attempts nothing before expiry and preserves the entire claimed projection. Injected-clock expiry permits a new real claim on the same immutable source with a distinct nonempty owner/fence+1; the old task stays held. Peer delivery records exactly one new result. Old release returns actual SupersededByOtherOwner with zero delivered/failed count, one total actual adapter callback across providers, and unchanged winner source/full checked caller-child activity/incident/physical bookmark plus named workflow facts. A fourth provider reads the same facts and resumes real warning/child Events through empty terminal1/cursor2 and truthful completion.

Four split-source rows cover terminal success/ordinary fault. Real notification0 stays claimed/held/unexpired. A separate real child Event and normal recovery produce actual empty terminal1; a pre-delivery outage leaves its real source retryable. A distinct peer processor claims that source using its actual parent-owned intent address. Positive physical reads show two live nonempty owners/fences, with zero's entire source unchanged and unexpired. Deliver1only: truthful Completed calling leaf/outcome/no local fault, original processed receipt, Pending1/cursor0/notconsumed, unchanged complete BPMN private state, caller Running and zero callbacks/branches. Release0under its valid claim: one actual[0,1] callback commits cursor2/terminal/no pending and preserves original receipt/alreadyDeliveredterminal row. Child fault/incidents remain truthful, success warning later completes normally, and a fifth provider reads the stable facts/sources after overlap. No fabricated transport, claim, source or outcome is installed.

Final **focused32/0/0** and **wholeEF1,710/0/0** match discovered1710/class32. Two compiled mutations restore exact production bytes before final normal verification: stale completion validation removal fails4 because EF CAS still refuses the old write but stale re-read becomes explicit claim-still-appears-valid InvalidOperation rather than Superseded (no overwrite claimed); incoming-ordinal initialization fails4 by consuming terminal1 before0. Initial terminal-production timing and wrong child-versus-parent claim-filter attempts are preserved as excluded fixture mechanics; the latter owned failed run was stopped with SIGTERM. Reviewed cleanup releases and joins both owned tasks, preserves original assertion and bounds processor cancellation. Three independent bounded audits clean; full-PR rounds zero, bound six.

Portable receipt binds41current source/doc files, ten binaries, eighteen frozen historical receipts, eight unchanged actual old captures and frozen authoring. No production semantics or authoring/package contract changed. Scope is deterministic expiry/ordered cut release with overlapping real providers, not simultaneous SQL CAS or process kills. Complete checked activity/incident/physical bookmark and source model projections plus named workflow fields are compared, not physical source revision/whole-workflow bytes/complete variables. Builders supply compiled contracts, so no public compiler/HTTP Workbench/final Studio proof is inferred.

Next is actual no-capability legacy recovery and the complete Workbench bridge. T029 ordinary compensation, final real current Studio, T032 old-writer/duplicate deletion after actual capture+upgraded-host proof, T033–T035 guards/audits, T036–T038 final qualification/full-PR/required green exact-head checks/protected delivery/resulting-main, then separate ADR0063 stay open. Main93bb/Studio3405 remains integrated; legitimate main fb76e04421464f5fdbfceaf0cbf3f0a263973ca3 Studio3407 package-host guide/exit-audit progress was just discovered and will be integrated next. Required GitGuardian's three verified public SHA256 false positives still await the single pending owner GitGuardian-account identity exception card; no override/blanket ignore/history rewrite/main merge.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. App organization Projects read/write works, no extra access needed or no-op field mutations. Evidence remains on linked issue/PR receipts. Independent production/program acceptance stays open; Orleans/task-runner deferred. Existing goal active.

## #2892 6451473538 elsa-workflows-codex[bot] 2026-10-27T19:25:12Z
**Legitimate current-main Studio guide progress integrated** at `2a42af1bbbc112d34711db980e7ea4769689f0ad` on sole draft #3338.

Current integration checkpoint: exact merge `2a42af1bbbc112d34711db980e7ea4769689f0ad` adopts legitimate main `fb76e04421464f5fdbfceaf0cbf3f0a263973ca3` (Studio #3407 package hosting guide/program exit audit) onto delivered claim head `091918fe0f92bf217516158982b9cbf881197a1b`. All28 imports equal exactmain: documentation/sample files plus two probe comments; existing executable probe lines unchanged. Foundation backend/root pins/build/spec1006,41claimsbindings and159evidence artifacts remain unchanged. Prior EF1,710/class32 and Studio frontend/typecheck/Chromium/.NET/tool observations are inherited only, not rerun/restamped. Three bounded audits/full-PR0. Actual no-capability legacy recovery/Workbench, T029/final real Studio/deletion/guards/protected delivery/resulting-main/ADR0063 remain open.

Exact parents are delivered claim head091918fe0f92bf217516158982b9cbf881197a1b and mainfb76e04421464f5fdbfceaf0cbf3f0a263973ca3. PR3407 is confirmed merged. Its28 files are byte-identical to exactmain and merged without conflict: hosting guidance, source records/tasks, runnable sample sources/configuration and exactly two explanatory comments in the existing HostingReuse.Probe runner. Removing line comments leaves that existing runner identical. No existing runtime/frontend/probe behavior, Foundation backend, root package/build or spec1006 source changes. All41 current claim receipt bindings and159 existing JSON/compressed evidence artifacts remain byte-identical to delivered parent; frozen authoring unchanged. Current org protocol unchanged, no open main-is-red CI issue found, git diff--check passes.

Source-bound Foundation EF1,710/class32, Studio workflow2,639/typecheck/Chromium28, prior Studio.NET636 and package-tool observations are inherited only. They are not newly rerun or restamped. New sample files are documentation support; this merge does not claim a fresh actual package-consumer, package publication, Workbench or final BPMN Studio qualification.

```json
{
  "head": "2a42af1bbbc112d34711db980e7ea4769689f0ad",
  "parents": [
    "091918fe0f92bf217516158982b9cbf881197a1b",
    "fb76e04421464f5fdbfceaf0cbf3f0a263973ca3"
  ],
  "adoptedMain": "fb76e04421464f5fdbfceaf0cbf3f0a263973ca3",
  "adoptedPullRequests": [
    3407
  ],
  "conflicts": false,
  "importedFilesSha256": {
    "Studio/README.md": "ae349de4caad9454fea2d2ba4b1e172133ee7bd8b8cf82836faa872fcb05d741",
    "Studio/docs/custom-hosting.md": "0438e19a857bd2b4f37b012538d29d060855ae4ee8736054f926dfc85930435b",
    "Studio/src/essentials/Elsa.Studio.Hosting.Nuplane/README.md": "f9fe1c199ecc44b5df59a0e1c220bbaec9f3495e504495587fb539ff7b29505f",
    "Studio/src/essentials/Elsa.Studio.Hosting.Themes/README.md": "7606a3d8b6e0ce675fb2e4c2431c2af0f862e80f946578a68ba8b5a5618d6f2b",
    "Studio/src/essentials/Elsa.Studio.Hosting/README.md": "4ef80eacdee36322f50a1a3b4e0ff1fdf5839d46e1e7857f6d89191a35626466",
    "docs/program-goals/README.md": "95899e1261c6e549e1f1f4c497f811697468624388c07fb5a51b95f65d4e5fc7",
    "docs/program-goals/studio-hosting-package-reuse.md": "ff09cc12103382e3214da52349300247d90e55af6b95819416a0a4a3f5ad8979",
    "docs/reports/README.md": "27309204f1064d2999b4c01e8397b2e24f2f4ec1bb07534752955b2acbd9bacd",
    "docs/reports/studio-hosting-contract.md": "7b84ed3487f75015d49a102bc0334fbb90215f76b6bce2c2a5f6054faaac8884",
    "specs/1009-studio-auth-bridge/tasks.md": "ba805084db426cb82db8dd8546f80f452ab733429d129f14f62aed3c598ac42b",
    "specs/1013-studio-package-consumer-proof/tasks.md": "c72505dbb40cf7b99b9a5ae8ba326058e4b054c59e18ddc4f0bf5d707a1b23d5",
    "specs/1014-studio-composition-qualification/tasks.md": "ae8a313090a72f10028aa339a3fa68a9f8a5c71de84fc59838ce86e09bd1c0d8",
    "specs/1015-studio-package-ci/tasks.md": "ca6a2c4f9b4b1844c0c11ae148700c9f77b00d3f601690b87e591f9b92b8b099",
    "specs/1016-studio-host-guide/data-model.md": "924ead1bf4422f98c42e9296d23284fe398ddd76341736efa91fd681c39dbb6b",
    "specs/1016-studio-host-guide/plan.md": "0a04b22bc494df07e8c27d785ee4e607fe784649b5ba7a876a04cbbef79586b3",
    "specs/1016-studio-host-guide/quickstart.md": "3f7bc06834f56b60f949beda779837ba0690f2bebca1bd6b6027b7d1c16508b5",
    "specs/1016-studio-host-guide/research.md": "d85ab516e1e29579db90c6cadefe89615dcea5a907f0a7735636a2e0051deff9",
    "specs/1016-studio-host-guide/spec.md": "1e47ae72424c777f054d9cbf8addcc62a016a8f43a06ce7337ea7823d65aaa78",
    "specs/1016-studio-host-guide/tasks.md": "37e431de8db3b1915c68cddd34404ffeda617e5af4540ee97662e7475c0d9232",
    "specs/1016-studio-host-guide/validation.md": "583cae7df5f09e0ef5d6aa17a8afc74b7142e4ce4a40310a46d5628f3f105723",
    "tools/studio/HostingReuse.Probe/Runner/Program.cs": "4f6b1ababc7082a9e3a84e7f22687bc1c6886c8419793f01b3d27c42d4b65799",
    "tools/studio/PackageHost.Sample/CustomStudio.csproj.in": "7a9b69ce66b3649b402a4462bfe6ae312cc1e8ce7495fa43b7aa437ec1b92c97",
    "tools/studio/PackageHost.Sample/NuGet.Config": "34881bb8968c32f529899120fdc10a4fa6a58e809911520511f196a746c9c086",
    "tools/studio/PackageHost.Sample/Program.cs": "e2bd3deb6a124dee5ea88bce5b01ba61b854ae2da22dd3359b122dc3611aa405",
    "tools/studio/PackageHost.Sample/README.md": "6a1a2b12ba4bbedea0ac24b4c63b8f338bf51694f68a8c36f3acc6ba38c8cf30",
    "tools/studio/PackageHost.Sample/appsettings.json": "30edfc62228a65cf0edd35cfc46a3f100df41c06677b471515c974941a497f2c",
    "tools/studio/PackageHost.Sample/shells.json": "218328cf789002cff8d30149c9a8594bdf3a033c023ec9571bb15ea9523880f5",
    "tools/studio/README.md": "88eb572d27371aede924a0556d60271d4f16bf8ef309e5285daeed35b68d0bc8"
  },
  "foundationRootPinsBuildAndSpec1006Unchanged": true,
  "latestClaimsReceiptBindingsUnchanged": 41,
  "existingJsonAndCompressedCheckpointEvidenceUnchanged": 159,
  "frozenAuthoringSha256": "41aa0bb979ea46fc2533b057e3677f408ab54c3411fecfafaa238a2adae38c92",
  "changedProbeExecutableLinesIdenticalAfterRemovingLineComments": true,
  "checks": [
    "git diff --check",
    "28 imported files byte-identical exact main",
    "41 latest claim receipt bindings unchanged",
    "all existing evidence artifacts byte-identical parent",
    "org protocol unchanged; no open main-is-red CI issue"
  ],
  "inheritedEvidence": "No executable runtime/frontend/probe behavior changed. Source-bound EF1710/class32, Studio workflow2639/typecheck/Chromium28, prior Studio.NET636 and package-tool observations are inherited only, not newly rerun or restamped. New sample is documentation support, no actual consumer qualification is claimed here.",
  "limits": [
    "This is exact-main integration, not final actual BPMN Workbench/Studio acceptance or package publication.",
    "Required new-head checks, full-PR and protected delivery/resulting-main/ADR0063 plus independent production remain open."
  ],
  "reviews": "three independent bounded integration source/artifact audits; full-PR rounds0",
  "fullPrRounds": 0
}
```

Three independent bounded integration audits clean/full-PR rounds0, bound6. Next actual-host work retains the duplicate writer until actual no-capability legacy capture/recovery and complete Workbench proof exist. T045 remains unchecked for those gates. T029 ordinary compensation, final real current Studio, T032–T035 deletion/guards/audits, T036–T038 final qualification/full-PR/required green exact-head checks/protected delivery/resulting-main, then separate ADR0063 remain open. Required GitGuardian still awaits the one pending owner-account exception card for three verified public-source-hash false positives; no override/blanket ignore/history rewrite/main merge.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled through Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. App organization Projects read/write works; no extra access or no-op field mutations needed. Linked issue/PR receipts carry evidence. Independent production/program acceptance stays open; Orleans/task-runner deferred. Existing goal active.

## #2892 6452549394 elsa-workflows-codex[bot] 2026-10-27T20:16:54Z
**T045 increment: actual no-capability legacy Workbench recovery** at `7490cd40de5c872d14c7d565a6bda5f9ed1620bd` on sole draft #3338. The remaining complete T045 gate stays unchecked.

Current legacy-call host checkpoint: [actual old-to-upgraded Workbench recovery](https://github.com/elsa-workflows/elsa-foundation/blob/7490cd40de5c872d14c7d565a6bda5f9ed1620bd/specs/1006-bpmn-library-adoption/evidence/legacy-called-workbench-recovery.md). Public APIs on exact old D81 Workbench captured two real waited caller/child BPMN pairs in complete coherent Runtime+Design/Publishing stores, separated from identity. Old control and actual released-0.5.0 adoption host each pass 2/2 with original pins/root/call/Event IDs, real ordinary fault/incident truth and no inferred control capability. Extra cold current-host control passes 2/2 while the original old build directory is absent. Five complete frozen databases, four checked snapshots, five reader controls and one restored guard mutation are portable. Three bounded audits/full-PR rounds zero. T045 remains open for the full new opted-in host matrix; T029/final real Studio/deletion/guards/protected delivery/resulting-main/ADR0063 stay open.

The old source-built Workbench is exactly d81a4c88a2924708ea8afcc2db20b8a77b84f703, with all 12,312 tracked files checked against that commit except the existing documented test-only capture overlay that Workbench does not compile. The qualified build explicitly sets SourceRevisionId to D81; actual captured activity versions carry that suffix. The adoption host is the clean production tree at 2a42af1bbbc112d34711db980e7ea4769689f0ad; actual Bpmn.Model/Semantics/Interchange DLLs match released 0.5.0 NuGet binaries. Both hosts contain no recovery probe.

Old control **2/2**, upgraded host **2/2**: normal ResumeOnly Event dispatch resumes exactly the captured child. The same original roots/call/Event invocations and workflow pins/mode/ancestry complete; normal takes only the normal caller path, ordinary fault keeps the child Faulted while its call leaf completes normally with Faulted outcome and caller takes only the catch-all path without incidents. The intended original-root tail must actually fault with workflow.fault, the exact authored message and its own correlated blocking ActivityReturnedFault incident under the same FaultWorkflow action. An arbitrary upgrade/activation failure cannot satisfy this proof.

Four immutable checked EF observations cover capture and three resulting stores: exact physical wait identity/generation/scope at capture, authoritative dispatch links, no consumer declarations in dispatch/provenance/original pinned material, no child control-dispatch hint, no produced/calling control or inbox, and exact ordinary terminal resume sources without control after upgrade. Original child fault/incident meaning stays truthful. An additional cold current-host control **2/2** passes with the entire original old build directory and private-tmp alias unavailable before startup and through continuation; its complete resulting store is frozen and checked, and all 289 old output files are restored unchanged. Whole databases deliberately retain original catalog directory identifiers as historical provenance; these are not paths recipients must recreate. JSON evidence contains no machine paths.

Five reader controls accept the real compressed capture and refuse wrong hash, foreign pin, a closed owed orphan hidden behind a clean canonical source, and an acquired legacy capability declaration, without writes or raw diagnostic leakage. A compiled mutation removes physical-source identity validation and actually accepts that orphan, failing its control; exact restoration passes again. Negative variants positively require committed/closed backup snapshots, SQLite integrity, no sidecars and unchanged canonical source, so an earlier sidecar refusal cannot mask the intended guard. The initial masked mutation is excluded.

Portable evidence binds **33 source/doc files and 25 assets**, including five complete compressed databases, actual API/checked observations, 289 old/290 current/51 reader binary hashes, five controls and the restored reader mutation. Prior eight actual captures, twenty historical receipts and frozen authoring stay unchanged. No production source/root dependency change and no duplicate writer deletion. Prior EF 1,710/class32 and Studio/architecture/package runs remain source-bound inherited observations, not rerun/restamped results for this increment.

Excluded mechanics are explicit: initial high-load MSBuild worker loss; archived build metadata inheriting the enclosing checkout's suffix; old bare-array list shape; fresh catalog paired with old Runtime correctly refused by the existing reference guard; initial incident assertion incorrectly requiring no resolution; sidecar-masked negative fixtures. Qualified controls use exact source metadata, coherent stores and actual FaultWorkflow policy. Three independent bounded source/artifact audits are clean. Full-PR rounds zero, bound six; required exact-head checks remain mandatory.

Next: complete the new opted-in called-control matrix through the public Workbench, then T029 ordinary compensation and final real current Studio. T032 deletion waits for all required actual-host/Studio and old-capture proof; T033–T035 guards/audits, T036–T038 final qualification/full-PR/green required exact-head checks/protected delivery/resulting-main, then separate ADR0063 remain open. Required GitGuardian's three verified public-source-hash false positives still await the single pending owner-account exception card; no override, blanket ignore, history rewrite or main merge.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Organization Projects read/write already works, so no extra App access or no-op field changes are needed. Linked issue/PR checkpoints carry evidence. Independent production/program acceptance stays open; Orleans/task-runner deferred. Existing goal active.

## #2892 6453269106 elsa-workflows-codex[bot] 2026-10-27T20:52:40Z
**T045 increment: eight actual opted-in called-control Workbench cases and real process recovery** at `9a179f4818cf261903ca7d5ebaccaac6ca238eca` on existing sole draft #3338. Complete T045 remains unchecked.

Current public called-control host checkpoint: [eight actual opted-in Workbench cases and restart](https://github.com/elsa-workflows/elsa-foundation/blob/9a179f4818cf261903ca7d5ebaccaac6ca238eca/specs/1006-bpmn-library-adoption/evidence/opted-called-workbench-recovery.md). Public catalog/authoring/publish/start and exact correlated ResumeOnly Events prove ORDER match, OTHER mismatch, running and terminal WARN escalation with both boundary policies, and whole WARN+OTHER terminal precedence. Real standard-host exit/restart preserves all six complete checked records exactly; five warning Events and one child-finish Event then continue. Five complete module snapshots, four API/checked phases, 24 rejection controls and one compiled/restored capability-guard mutation are portable. No production source or authoring change. Three bounded audits/full-PR rounds zero. T045 remains open for concurrent same-binding public-host and actual acknowledgment-loss delivery; T029 ordinary compensation, final real Studio, deletion/guards/protected delivery/resulting-main/ADR0063 remain open.

Two actual authored-error cases pass: ORDER reaches its coded boundary once; OTHER faults its caller and reaches no handler. Both real child roots retain Faulted status, authored category/code and their original correlated blocking ActivityReturnedFault/FaultWorkflow incident. The dispatch leaf completes normally with truthful Faulted outcome and no local fault. Checked provider reads verify complete caller/child pins including artifact version, compiled capabilities, actual root/call/dispatch boundary, emitted batch, immutable source/transport, consumed terminal inbox and separate safe diagnostics.

Six escalation policies pass: running WARN, terminal WARN and whole terminal WARN+error OTHER, each under noninterrupting and interrupting boundaries. The running interrupting case stages exactly one real CancelChild for its actual call/dispatch/child. Terminal children retain Completed/Faulted status and are never recancelled. Noninterrupting combined failure starts neither warning nor normal branch; interrupting combined failure handles only the warning while preserving the original child's typed fault/incident. Five real warning Event waits keep the relevant callers live.

After the owned normal host/controller exit, a distinct normal process opens the same original Runtime and coherent Design/Publishing stores. Before continuation, **all six complete checked workflow/activity/dispatch/incident/source/physical-wait records are exactly equal**, without field exclusions. Exact physical scopes, positive generations and call/Event invocations survive. Event correlation comes from the canonical pure WorkflowInstance.instanceId parameter; each public ResumeOnly Event must resume its exact workflow and start none.

Four reader phases pass six controls each, **24 total**: real whole snapshot; wrong hash; foreign API artifact hash; foreign API artifact version; owed physical orphan behind unchanged clean canonical source; actual dispatch missing its consumer declaration in an explicitly private copy. Fixtures are committed/closed backups with positive integrity/no-sidecar checks. Immutable/query-only reads validate hashes before/after, make no writes and expose no raw diagnostics. A compiled declaration-guard mutant incorrectly accepts the undeclared private dispatch and fails the control; exact restoration passes all six again. Existing legacy reader's five controls also pass against the original compressed capture, checking CLI compatibility without restamping historical host proof.

Excluded initial fixtures are recorded: wrong Event catalog key (no cases); reader incorrectly expecting nonterminal notices in ordinary ChildControl or a parent producer address; incorrect terminal source-anchor assumption. Production explicitly clears terminal anchors, while nonterminal notification anchors name their source commit. Review found incomplete artifact-version and explicit coded mode/transport-parent-pin checks; those are fixed before final passes. Private failed/debug outputs are excluded.

Portable evidence binds **49 source/doc files and 27 assets**, including five complete module snapshots, four actual API/checked phases, 290 host/51 reader binary hashes, 24 controls, mutation and exact owned process identities. Identity/token storage is excluded. Original catalog directory identifiers remain historical data, not paths recipients must recreate. Thirteen previous database captures, twenty-two historical receipts and frozen authoring are unchanged. No production source/root dependency or duplicate semantic writer changed. Prior EF1,710/class32 and Studio/architecture/package evidence remain source-bound inherited results; not rerun/restamped for this scripts/read-only-tooling increment.

Three independent bounded component audits are clean after the named fixes. Full-PR rounds remain zero, bound six. Next: public-host concurrent same-binding isolation and actual acknowledgment-loss delivery, then complete T045 reconciliation, T029 ordinary bound-task compensation and final real current Studio. Deletion waits for required actual-host/Studio/historical proof. Final guards/baseline audit/qualification, full-PR review, green required exact-head checks, protected delivery/resulting-main and separate ADR0063 remain open. Required GitGuardian's three verified public-source-hash false positives still await the single pending owner-account exception card; no override, blanket ignore, history rewrite or merge.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled through Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Organization Projects read/write already works, so no extra App access or no-op field mutations are needed. Linked issue/PR checkpoints carry evidence. Independent production/program acceptance stays open; Orleans/task-runner deferred. Existing goal active.

## #2892 6453843705 elsa-workflows-codex[bot] 2026-10-27T21:20:09Z
**T045 prerequisite: correct existing recurring timer delivery** at `1690720001c7b39b721ba0fa5c8981d3e5e3a693` on sole draft #3338. T045 stays unchecked.

Current recurring-timer prerequisite: [finite overdue callback fix](https://github.com/elsa-workflows/elsa-foundation/blob/1690720001c7b39b721ba0fa5c8981d3e5e3a693/specs/1006-bpmn-library-adoption/evidence/finite-timer-recovery.md). During the next concurrent public-host attempt a due notification stayed unclaimed; bounded diagnostics found an idle unarmed finite resumption timer. Source inspection and deterministic real-Timer regressions reproduce the finite -1ms/infinite-sentinel collision. Old branch: two failures/one pass; fixed whole Tasks: 71 passes/zero failures/skips. The fix separates configured infinity from overdue finite elapsed time, with an internal System-default clock seam. Twenty source/doc bindings, ten portable assets and 29 test binary hashes; three bounded audits/full-PR0. The exact live elapsed cause remains an inference, the concurrent host run remains failed/unqualified, and a rebuilt standard host must repeat it. T045/T029/Studio/deletion/final protected delivery/ADR0063 remain open.

This is a minimal prerequisite in the existing runtime, discovered while executing the next planned public concurrent-call case. It does not start the deferred task-runner follow-up. The selected real child emitted WARN after a normal public Event and reached its finish wait; its notification source stayed Pending/due/eligible/revision1, with no claim, attempt or failure, while its sibling stayed waiting. Tasks and WorkflowsRuntimeResumption were enabled with a one-second sweep. The owned normal process's actual heap showed finite 1s wait, unarmed/uncanceled/idle native timer, active lifetime token, no active resumption async stack and zero consecutive sweep failures while other pumps stayed armed. Published bounded observations remove absolute file paths; raw private heap data was never published and has been deleted. The failed host/controller exited. Exact elapsed at the live event was not captured; the source mechanism matches those observations but is not claimed as directly observed live timing.

The source defect is deterministic: Callback passed a computed finite remainder into NextArm. Exactly 1ms late yields -1ms, also Timeout.InfiniteTimeSpan, so the callback silently disables its one-shot timer and returns before action/finally rearming. The fix handles configured infinity explicitly and only rearms a positive finite remainder. All overdue finite ticks execute the existing action/finally path. Rounding, long-wait chunking, action fault logging and disposal remain intact. Optional TimeProvider is on an internal type and defaults to System, preserving the monotonic clock with no public API or dependency addition.

Three new regressions use actual System.Threading.Timer callbacks with separately controlled monotonic timestamps. They require two exact-overdue actions, proving rearming; explicit-infinite no action; two real early callbacks/no action followed by overdue execution. With the same seam/tests and original callback branch, the two finite cases fail at intended action timeouts and the infinite twin passes:2 fail/1 pass. Fixed whole Tasks project:71 pass/0 fail/0 skip, including existing rounding/long-wait/cron/backoff/lifecycle coverage. Portable red/green results bind exact source/test hashes and original TRX hashes; a small negative reversal patch makes the old branch reproducible. This is not a timing-shaped failure inferred from machine load.

Evidence binds 20 source/doc files, 10 assets and 29 actual test binary hashes. Eighteen previous database captures,24 historical receipts and frozen authoring remain unchanged. No notification routing, BPMN semantics, library dependency or duplicate writer changed. The unfinished concurrent runner/reader/helper extraction remains separate local work and is not part of this prerequisite commit. Three independent source/test/artifact audits are clean. Full-PR rounds remain zero, bound six; no full-PR or actual concurrent host qualification is inferred.

Next: rebuild the standard host from corrected production source, repeat complete concurrent same-binding public-host isolation, then actual acknowledgment-loss delivery and T045 reconciliation. T029 ordinary compensation, final real current Studio, T032 deletion after required proof, guards/baseline audit/final qualification/full-PR/green required exact-head checks/protected merge/resulting-main and separate ADR0063 remain open. Required GitGuardian's three verified public-source-hash false positives still await the single pending owner-account exception card; no bypass or merge.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Projects read/write already works; no extra App permission or no-op field writes are needed. Independent production/program acceptance remains open; Orleans/task-runner follow-up deferred. Existing goal active.

## #2892 6453964024 elsa-workflows-codex[bot] 2026-10-27T21:26:16Z
**Legitimate main progress adopted** at `f0411e2fedb80eba38f3bee9451e16ef7d6992c0` on sole existing draft #3338, continuing #2735.

Current 7cd main integration: [Studio #3406 adoption receipt](https://github.com/elsa-workflows/elsa-foundation/blob/f0411e2fedb80eba38f3bee9451e16ef7d6992c0/specs/1006-bpmn-library-adoption/evidence/main-integration-7cd.json). Main 7cd167e00 is integrated onto the delivered timer-fix head 169072000. Fifteen exact-main Studio/guidance imports preserve literal child-slot labels, keyboard inspection and the distinct Studio-program qualification. Workflows 2,644 / 194 files, Workflows+browser/live TypeScript checks, 36 Chromium editor/instance/motion/accessibility fixtures and module build/bundle budgets pass. Twenty timer bindings, 217 earlier JSON/gzip assets and frozen authoring remain unchanged. Three bounded audits/full-PR0; fixtures do not qualify final actual BPMN Studio. Next: rebuilt corrected standard host for concurrent-call and acknowledgment-loss T045 evidence.

Integrated exact main7cd167e00a80c8c01d83c198200cde36058c3300 ([#3406](https://github.com/elsa-workflows/elsa-foundation/pull/3406)) onto 169072000 with no conflicts. All 15 imported files are byte-identical to that main commit; one branch-specific machine receipt is added. The generic child-slot formatter preserves authored labels literally, and keyboard activation uses the existing domain selection/exact runtime-node mapping. The new live-journey guide requires a dedicated test account because signout revokes that account's sessions. That live journey was not run in this integration.

Fresh validation: whole Workflows 2,644 tests in 194 files; module TypeScript plus browser/live journey TypeScript;36 Chromium fixture cases covering attached editor, direct instance, motion and keyboard accessibility across themes/viewports; production module build and all bundle budgets. The browser server owned strict port 4181 with reuse disabled and is now closed. Fixtures are not a real current BPMN Studio or production acceptance witness. The receipt binds all imports, validation-log hashes and current source scope.

The imported #3392 Delivered registry row concerns that separate Studio program. It does not close #2892/#2735, current BPMN Studio, independent #2898/#2907 or production acceptance. Next: build the standard host from the corrected timer source and repeat complete concurrent same-binding public calls, then actual acknowledgment-loss delivery and T045 reconciliation. T029 ordinary compensation, final real Studio, deletion after required proof, guards/baseline/final qualification/full-PR/green required exact-head checks/protected delivery/resulting-main and separate ADR0063 remain open. Required GitGuardian's three public-source-hash false positives still await the single pending owner-account exception card; no bypass or merge.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled through Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Projects read/write works with existing App access; no no-op field mutations or extra permission needed. Linked issue/PR receipts stay current. Orleans/task-runner follow-up remains deferred; existing goal active.

## #2892 6454488540 elsa-workflows-codex[bot] 2026-10-27T21:50:04Z
**T045 increment: actual public-host concurrent same-binding call isolation** at `81f6ae7a47497a9f1f5704bd6b5f9b21fa1566a0` on sole draft #3338, continuing existing #2735 claim.

Current concurrent-control host checkpoint: [actual same-binding isolation](https://github.com/elsa-workflows/elsa-foundation/blob/81f6ae7a47497a9f1f5704bd6b5f9b21fa1566a0/specs/1006-bpmn-library-adoption/evidence/concurrent-called-workbench-recovery.md). Corrected standard host f0411e2fe proves both boundary policies with two null-iteration tokens at one valid call element/binding and distinct exact children. The actual second semantic token handles first; its sibling's complete projection remains equal. Real process restart preserves the entire two-case observation; sibling handling preserves the finished selected projection. Both callers complete with expected branches, truthful cancellation and no waits/incidents/poison/structural state. Five whole module snapshots, four API/checked phases, 53 controls and one restored observation-selector mutation are portable. Three bounded audits/full-PR zero. T045 remains open for actual acknowledgment-loss delivery and complete reconciliation; T029/final real Studio/deletion/guards/protected delivery/resulting-main/ADR0063 remain open.

Each real fork has two flows into one valid call element bound to one DispatchWorkflow node. Distinct actual call/provenance/dispatch/child identities share one child pin and have null iterations. The checked immutable prepared store explicitly selects actual activeWork[1], resolving its call via ExecutionPathId then authoritative child dispatch; both cases select token nine while token seven is the sibling. No activity-store order selects it.

The selected child emits WARN via its real Event. Its actual warning Event holds the caller live. Interrupting handling stages exactly one CancelChild targeting only that dispatch/call/child; noninterrupting handling later continues its finish Event and consumes empty terminal ordinal one. During selected handling the sibling's complete call, dispatch, child workflow, all child activity/incident records, immutable original keyed start source, control sources and exact physical waits/generation/scope remain equal. Only the original sibling semantic token remains live afterward.

The owned standard host/controller exit before a different standard process opens the same original coherent stores. Fresh public API observations precede any continuation. The entire two-case checked collection is equal across restart, without field exclusions. The other child then handles independently while the already finished selected projection remains exactly equal. Both callers complete: noninterrupting has two completed calls/children, two normal/two warning branches and consumed terminal cursor two per stream; interrupting has two canceled calls/children, two warning/no normal branches, consumed nonterminal cursor one without fabricated terminal consumption. Both independent streams retain actual notification zero and terminal one sources; all keyed starts/control/cancel/result sources are Delivered. Final waits/incidents/poison/semantic structural state are absent.

Every Event uses CanStartWorkflow=false with canonical pure WorkflowInstance.instanceId correlation; every public stimulus must resume its intended workflow and start none. Checked observations verify full pins, compiled capabilities, root/call/child addresses, exact source authority, batch/inbox order and cancellation truth. Whole call projections compare all fields; shared global parent state naturally changes during branch handling and is compared in full across restart. No adapter callback-entry count, acknowledgment loss or simultaneous SQL claim is inferred.

Four new reader phases pass six controls each, 24 total. Four prior coded/escalation fixtures plus the legacy reader pass 29 compatibility controls, 53 overall, without restamping historical host results. Controls independently require the returned selection to equal the actual second semantic token, and reject wrong hash/foreign API artifact hash or version/hidden owed physical orphan/exact calling dispatch missing its declaration in private copies. Closed backups, integrity, no sidecars, immutable/query-only pre/post hashes, no writes/raw diagnostics remain explicit. A compiled observation-only mutant swaps first/second selections and its internal check; it returns first and the independent prepared control fails. Exact source restoration passes all six again. The mutant never reaches a positive host or changes the production adapter.

The earlier old-host concurrent run remains failed/unqualified; its exact live elapsed timer cause remains an evidence-backed inference, separately supported by deterministic timer regressions. Initial new-host blueprint/readiness setup attempts also remain excluded. Three independent bounded source/artifact audits are clean; full-PR rounds remain zero, bound six.

Next: actual host acknowledgment-loss delivery and complete T045 reconciliation, then T029 ordinary compensation and final real current Studio. T032 deletion waits for remaining actual-host/Studio/legacy proof; guards/baseline audit/final qualification/full-PR/green required exact-head checks/protected delivery/resulting-main and separate ADR0063 remain open. Required GitGuardian's three verified public-source-hash false positives still await the single pending owner-account exception card; no bypass or merge.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Existing Projects read/write works; no extra App permission or no-op field mutations are needed. Independent production/program acceptance stays open; Orleans/task-runner follow-up remains deferred. Existing goal active.

## #2892 6455391017 elsa-workflows-codex[bot] 2026-10-27T22:42:09Z
**T045 complete: actual called-control recovery and reconciliation** at `3815806acb51475903f3ee3b44cf263ac572db26` on sole existing draft #3338, continuing the transferred #2735 Codex claim.

Current called-control recovery checkpoint: **T045 complete** at `3815806acb51475903f3ee3b44cf263ac572db26`. The [criterion reconciliation](https://github.com/elsa-workflows/elsa-foundation/blob/3815806acb51475903f3ee3b44cf263ac572db26/specs/1006-bpmn-library-adoption/evidence/called-control-reconciliation.md) links actual public-host and fresh-EF evidence. Two [real caller-commit-before-result cuts](https://github.com/elsa-workflows/elsa-foundation/blob/3815806acb51475903f3ee3b44cf263ac572db26/specs/1006-bpmn-library-adoption/evidence/called-ack-workbench-recovery.md) recover notification zero and terminal success one on distinct standard processes over the original stores after natural expiry. Complete checked recipient Facts and immutable source Intents stay equal. Current whole Runtime EF1,710/BPMN303/Interchange130/Tasks71 pass:2,214/0fail/0skip. Actual persisted publications match frozen contracts2/2;45new+53compatible reader controls pass with a restored compiled missing-inbox mutation. Three independent bounded audits clean; full-PR rounds0/6. Next:T029 ordinary compensation, final current Studio, deletion/guards/audit/final protected delivery/resulting-main, then separate ADR0063.

Each actual ACK cut follows the real typed handler's returned caller commit while its actual source is still Delivering under fence1 with zero recorded results. The probe forwards both dispatcher overloads unchanged, preserves RequiresDurableSource and reads the actual provider claim; it never constructs a claim/context or installs transport/state/verdict. The exact owned child/controller exits before a different no-probe standard host opens the same coherent Runtime/Design stores. Natural expiry permits Delivered under fence2 with one recorded result, without changing complete checked recipient Facts or original Intent. Notification0 retains the running child and exact warning/finish/call waits; terminal1 retains consumed cursor2, truthful ordinary completion, Completed child/normal branch and the original warning Event. That original warning subsequently completes the caller with no waits/incidents/poison/structural state. No cancellation source is present.

Facts covers the complete explicitly named workflow/activity/dispatch/incident/physical-wait/non-target-source model projections, not every SQLite row/raw EF revision/scheduler or value inventory. Recorded result counts are not dispatcher/adapter invocation counts. The42 pre-expiry terminal samples record timestamp/status/fence/count; the held checked source separately proves its owner. These cuts precede the source result write; generic committed-ACK return loss remains separately qualified in T051. Public API assertions and immutable checked EF snapshots independently establish actual committed acceptance.

The [portable manifest](https://github.com/elsa-workflows/elsa-foundation/blob/3815806acb51475903f3ee3b44cf263ac572db26/specs/1006-bpmn-library-adoption/evidence/called-ack-workbench-recovery.json) binds60 source/doc files and55 assets: six complete module captures, five API/checked stages,290 standard/290 opt-in-probe/51 reader binary identities, released0.5.0 package equality, exact owned process identities, natural takeover/comparisons,98 controls, the compiled observation mutation, current suite/TRX results and actual persisted published contracts. All340 prior evidence files/23 databases and the frozen authoring oracle remain unchanged. All four qualified child/controller lifetimes exited; the user's existing backend/Studio remain live. Production runtime source, dependency pins and semantic writer are unchanged in this increment. Initial missed-cut/live-SQLite-mode/unsupported-build-flag and resource-failed build attempts are excluded explicitly; final bounded builds and controls pass.

Three independent correctness/standards/acceptance source and final artifact audits support T045 closure. They are bounded component audits, not full-PR approval. The complete linked reconciliation covers coded match/mismatch, execution/terminal escalation and signal-plus-failure, exact same-binding sibling cancellation, duplicate delivery/claims/committed acceptance, empty terminal barriers buffered across fresh-provider restart with eventual[0,1], actual child/incident truth, safe diagnostics, actual no-capability legacy recovery and unchanged authoring. Fresh-EF tests and current reader compatibility controls do not restamp historical host results or qualify final current Studio.

Next: actual ordinary bound-task compensation (T029), then final current Studio and deletion/guards/baseline/docs/final qualification. Full-PR rounds remain0, bound6; required exact-head checks/protection/unresolved human holds are preserved. The pending owner-account exception card for three verified public-source-hash GitGuardian false positives has no answer; no classification, bypass or merge is authorized by elapsed time. CLA prompts have not been signed by the agent.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled with the Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Existing organization Projects read/write works; no extra App access or no-op field mutations are needed. ADR0063 remains proposed until the third ordered PR after delivery/resulting-main verification. Independent #2898/#2907/program production acceptance stays open; Orleans/task-runner follow-up remains deferred. Existing goal active.

## #2892 6455656401 elsa-workflows-codex[bot] 2026-10-27T22:58:36Z
**T029 complete: actual ordinary bound-task compensation and supplemental legacy recovery** at `6e2172c0766b20f1ce1b10311a938d3b372ac81f` on sole existing draft #3338, continuing #2735's transferred Codex claim.

Current ordinary compensation checkpoint: **T029 complete** at `6e2172c0766b20f1ce1b10311a938d3b372ac81f`. The [actual ordinary-task witness](https://github.com/elsa-workflows/elsa-foundation/blob/6e2172c0766b20f1ce1b10311a938d3b372ac81f/specs/1006-bpmn-library-adoption/evidence/ordinary-compensation-host-recovery.md), combined with delivered called-escalation/T045 evidence, qualifies this gate. Real standard-host restart preserves the entire live B-handler observation; B then A then hold complete cleanly. An actual old-writer live compensation checkpoint is frozen before writer exit; fresh old/current hosts both preserve its initial observation, continue original B/A/hold, retain version-1 storage until normal clearing and finish cleanly. Sixteen whole module captures, fourteen API/checked phases, 100 unique controls, a restored compiled replay-order reader mutation, 16 restored and 26 compatible controls are portable. Three bounded audits clean; full-PR rounds 0/6. Final current Studio, deletion/guards/baseline/docs/final protected delivery/resulting-main and separate ADR0063 remain open.

Two real ordinary serviceTask elements bind WriteLine activities and complete A then B. Separate compensation boundaries associate their own Event handlers. A reference-less throw claims both registrations. Checked physical state positively records one replay run pending [B,A], two Claimed registrations, exact original handler B/semantic token and one live correlated wait. The owned standard host/controller exits; a different standard process opens the original stores and reads the entire observation unchanged before input. The coherent Runtime bytes are also identical across this restart. Original B resumes once, A alone waits, A resumes once, then both registrations are Compensated with no replay run and only the final hold Event live. That Event completes normally with no waits, incidents, dispatches, poison or private state.

Before deleting the old writer, the exact previously source-qualified d81 old binary creates the same graph through normal public authoring/publishing/execution on fresh stores. Its real v1 activeChildren state, two Claimed registrations, [B,A] run and original B wait are frozen with coherent whole Runtime and Design/Publishing backups before process exit. A fresh old process continues its original stores as control; a distinct current standard process receives byte-identical copies of both frozen module stores and fresh private identity storage. Both read the entire initial checked observation equal to the seed, then finish original B/A/hold. Both preserve original workflow/artifact/root/B/wait identities; the upgraded host retains alias/schema/version one and activeChildren through handler A and settled hold instead of restamping storage. Newly minted later A IDs differ legitimately between these independent stores; no cross-host final identity equality is claimed.

All Events have CanStartWorkflow=false, pure WorkflowInstance.instanceId correlation and ResumeOnly delivery. Every actual stimulus resumes exactly its original workflow and starts none. Independent immutable checked EF observations verify actual task results, handler node/element association, compensation scheduling cause, semantic token, exact parent and physical wait scope/generation, source responsibility and final state. No runtime rows, state, claim, clock or synthetic positive result is installed. Facts covers complete named workflow/all activity/incident/dispatch/physical-wait/source model projections, not every module row, variable or scheduler record.

The current standard build is source81f6ae7a with full explicit SourceRevisionId; production source/dependencies equal parent3815806ac and this evidence-only increment. The old complete binary closure equals the prior d81 source qualification. No runtime/package/writer changes occur here. Earlier 2,214 whole-project tests and delivered actual escalation/T045 evidence remain inherited and source-bound, not repeated runs. The initial new fixture's Text reference was refused by normal publication before execution; that attempt stays failed/excluded, and final cases use the actual declared text key.

Three independent bounded correctness/standards/acceptance source and artifact audits support T029 closure. Full-PR rounds remain zero, bound six. Next is the isolated current Studio live journey, then duplicate-semantics deletion/guards/permanent 242-method audit/docs/final qualification. The current Studio frozen frontend and Release .NET builds pass; that is preparation, not live compatibility evidence. Required exact-head checks, branch protection and human holds remain intact. The single pending GitGuardian owner-account exception card is still unanswered; no classification/bypass/merge or CLA signing has occurred.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled through the Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Existing organization Projects read/write works; no additional App access or no-op field writes are needed. Final Studio, deletion, guards/baseline/docs, final whole-project/required-check/protected delivery/resulting-main and the separate third ADR0063 PR remain open. Independent #2898/#2907/program production acceptance stays open; Orleans/task-runner follow-up remains deferred. Existing goal active.

## #2892 6455982260 elsa-workflows-codex[bot] 2026-10-27T23:18:15Z
**Current live Studio compatibility refreshed before deletion** at `f5e7fee0767940f00c6695c1381cd0d42d4f3906` on sole draft #3338, continuing the existing #2735 Codex claim.

Current pre-deletion Studio checkpoint: [actual current UI journey](https://github.com/elsa-workflows/elsa-foundation/blob/f5e7fee0767940f00c6695c1381cd0d42d4f3906/specs/1006-bpmn-library-adoption/evidence/current-studio-pre-deletion.md) passes import → default-flow edit → publish → published run → reload → export. Actual process and Delay complete with no incidents; saved default/name/Never condition and authored-v1 catalog/childNodeId bindings survive, and the downloaded XML retains PT1S. Actual published contracts match frozen fingerprint 2/2. Four screenshots, five DOM observations, API/persisted authoring, two coherent module backups and served loader/main-chunk/binary identities are portable. Three bounded audits clean; full-PR rounds 0/6. T029/T045 remain complete; final post-deletion Studio and T032–T038/protected delivery/resulting-main/separate ADR0063 remain open.

Actual Studio build3815806ac and standard Workbench build81f6ae7a use full explicit SourceRevisionIds; both production trees equal parent6e2172c07. Frozen pnpm installation/full frontend build and subsequent locked Release Studio.Web build pass. The actual served Workflows loader (197 bytes) and referenced main implementation chunk (107,100 bytes) equal current source-built bytes; this does not claim an inventory of every fetched dependency. Both complete actual host binary closures contain no recovery probe. Workbench continues to use released BPMN0.5.0.

The [manifest](https://github.com/elsa-workflows/elsa-foundation/blob/f5e7fee0767940f00c6695c1381cd0d42d4f3906/specs/1006-bpmn-library-adoption/evidence/current-studio-pre-deletion.json) binds13 source/doc files and23 portable assets: four visually inspected screenshots, five complete DOM observations, real downloaded XML, exact run/pin/API identities and persisted authored state, coherent whole Runtime/Design backups excluding identity/tokens, actual published-contract projection and65 Studio/290 backend binary identities. Source shell/module selection and Nuplane management configuration are preserved; only the exact owned Studio origin is added to disposable backend return/CORS allowlists. Authentication/cookie policy is unchanged. The initial missing private-root Nuplane management file refused startup before the journey; copying committed standard configuration resolved setup. An unsupported upload-locator call performed no action; supported file chooser upload completed the real import. No UI mocks, private application-state injection or API substitution occurred.

Three independent bounded correctness/standards/acceptance source/artifact audits are clean. This is pre-deletion evidence; the new owned pair/stores remain intentionally live for the resulting deleted-semantics build. The user's original localhost backend/Studio remain untouched. Next: remove duplicate interpreter/graph/coordinator/mutator/behaviors/semantic state and pruning writer, retain authored DTOs/compatibility codec/host adapter, add and mutation-test both required guards, reconcile all242 baseline methods and update docs. Final post-deletion host/Studio/whole-suite/architecture/maps/required exact-head checks/full-PR/protection/resulting-main qualification still precedes delivery; full-PR rounds remain0, bound6.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled as the Codex App: #2735/#3338 In Progress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 In Progress/Coordination/Partial; #2898 Blocked/Not Ready/Partial; #2907 Todo/Coordination/Not Assessed. Existing organization Projects read/write works; no additional App access or no-op writes are needed. The single pending GitGuardian owner-account exception card remains unanswered; no classification/bypass/merge or CLA signing occurs. ADR0063 remains proposed until the separate third PR after verified delivery. Independent #2898/#2907/program production acceptance stays open; Orleans/task-runner follow-up remains deferred. Existing goal active.

## #2892 6456731091 elsa-workflows-codex[bot] 2026-10-28T00:01:08Z
**Duplicate Foundation semantics removed** at `2a67105af1e4e0c1ce55a45655a48a7cf6a3484c` on sole draft #3338, continuing the existing #2735 Codex claim.

Current semantic-deletion checkpoint: [T032/T033/T034 delivered](https://github.com/elsa-workflows/elsa-foundation/blob/2a67105af1e4e0c1ce55a45655a48a7cf6a3484c/specs/1006-bpmn-library-adoption/evidence/semantic-deletion.md). All28duplicate semantic sources and DI are removed after committed actual old/current recovery evidence; authored DTOs, codec/ledger and released0.5.0host adapter remain. [All242originalmethods](https://github.com/elsa-workflows/elsa-foundation/blob/2a67105af1e4e0c1ce55a45655a48a7cf6a3484c/specs/1006-bpmn-library-adoption/evidence/test-reconciliation.md) map to251passingcases with5explicitrenames;30additionalmethods supply57cases. Both compiled ownership canaries fail only their intended guard, exact sources restored, normalguards2/2pass. Three bounded audits clean; fullPRrounds0/6. Finalpostdeletionhost/Studio/T035status/T036–T038/protectedmerge/main and separateADR0063 remainopen.

The [source/artifact manifest](https://github.com/elsa-workflows/elsa-foundation/blob/2a67105af1e4e0c1ce55a45655a48a7cf6a3484c/specs/1006-bpmn-library-adoption/evidence/semantic-deletion.json) binds43changed source/doc files,28deleted-source hashes and36portable assets. Original242class-plus-method identities remain; no baseline scenario is deleted. Exact current selectors/lines, theory case names, original audit dispositions,5renames and freshly checked released neutral source anchors are permanent. Neutral source anchors do not substitute for actual host assertions. Bound work is added to three backward-edge cycle fixtures under the released safety profile; original flow assertions remain and an immediate-cycle refusal control is added. Distinct coded boundary/bound-signal/valid-cycle graph controls distinguish representability from host readiness. One post-baseline added old-reader test is retired with its deleted writer dependency; current raw-v1 field checks and historical actual old/current process evidence remain separately scoped, without a new rollback/old-parser claim.

Whole BPMN308/Interchange130/RuntimeEF1710 pass with complete discovery/execution-name multiset equality and no failures/skips. Architecture discovers581selectors; two deferred theories expand to11cases, yielding590passed/0failed/0skipped. Locked Release/Debug Server restore and generated maps pass. The first architecture attempt records588pass/2fail due an untracked task-owned old-source snapshot under artifacts. All14759files were preserved byte-identically outside checkout; unchanged guards then pass. Original red/green TRX/logs and all four discovery logs are committed. All521historical evidence/baseline files and frozen authoring remain unchanged.

Actual PE metadata inventories48retiredpublictypes/3added/22retained and both assembly hashes; this is type-surface evidence, not full member ABI equivalence. Both assemblies retain4.0.0.0; repository package computation remains authoritative. README/extension-point/DTO comments document released ownership, retained authoring/state versions and exact cuts. The old Call Activity smoke now refuses Running/poison as success and requires the real child fault/incident, exact parent/pin and completed boundary recovery. Its actual deleted-host pass remains pending. T032/T033/T034 are closed; T035finalstatus and T036–T038 remainopen. Next: exact committed standard Workbench build, post-deletion legacy recovery/strict public smoke/currentStudio, then complete-PR review0/6 and required exact-head/protected delivery/resulting-main verification.

Project[#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled with the Codex App: #2735/#3338 InProgress/Assigned/Partial; #3335 Done/Complete/Passed; #2892 InProgress/Coordination/Partial; #2898 Blocked/NotReady/Partial; #2907 Todo/Coordination/NotAssessed. Existing organization Projects read/write works; no additional App access or no-op writes required. The single pending GitGuardian account-exception card remains unanswered; no classification, bypass, merge or CLA signing occurs. ADR0063 remains proposed until its separate third PR. Independent #2898/#2907/program production acceptance stays open; Orleans/task-runner follow-up remains deferred. Existing goal active.

## #2892 6457134745 elsa-workflows-codex[bot] 2026-10-28T00:16:44Z
**Final host and Studio qualification is delivered at `59ee30c1558a16fc411547760eb28f936c9dfb58`; complete-PR review round 1 is starting.** The existing #2735 Codex claim and sole draft #3338 continue.

[Final qualification](https://github.com/elsa-workflows/elsa-foundation/blob/59ee30c1558a16fc411547760eb28f936c9dfb58/specs/1006-bpmn-library-adoption/evidence/post-deletion-host-qualification.md) and [source/artifact manifest](https://github.com/elsa-workflows/elsa-foundation/blob/59ee30c1558a16fc411547760eb28f936c9dfb58/specs/1006-bpmn-library-adoption/evidence/post-deletion-host-qualification.json) bind 24 source/doc files and 54 portable assets. The exact standard Workbench code build is `2a67105af1e4e0c1ce55a45655a48a7cf6a3484c`, verified in actual ProductVersion metadata. Its 288-DLL closure contains no recovery probe, all 48 retired public types remain absent, and the three BPMN library DLLs match qualified 0.5.0 bytes. Current head adds documentation and evidence to that code.

A fresh process over byte-identical frozen old-writer Runtime/Design copies preserves the entire original compensation observation before input. Public correlated ResumeOnly inputs continue original B, A and hold to clean completion, retaining version 1 and old wire fields at intermediate checkpoints. Four complete Runtime captures, 28 independent reader controls and a separate Design backup are retained. No synthetic state or work is installed. The completed legacy process/controller have exited; the user's localhost hosts remain untouched.

Two strict real-child call cases pass, including the actual faulted child's original fault node, message, blocking incident and FaultWorkflow action, exact parent/pin, one Faulted call and one boundary recovery. Four registered import/publish/execute/export cases pass: none start, duration timer, signal publisher and broadcast to two pre-existing suspended catches.

The fresh normal Studio journey creates a BPMN definition, imports the unchanged fixture, edits the gateway name and condition outcome, preserves the checked default, saves and publishes 1.0.0 to default, runs, reloads and downloads real XML. PublishedRun `14i4yC1LLwy` on `artifact-e3218705fe5d` has exactly two Completed activities and no incidents, verified by UI and supporting API read. Saved authored v1 bindings/default markers and exported name/Never/PT1S agree. Actual published contracts match the frozen fingerprint 2/2 on each host. Four inspected screenshots, five DOM observations, seven whole module backups and actual source/binary/served-JS identities are portable. Preserved catalog metadata is publication provenance, distinct from the current binary revision. Excluded build-label and observer assumptions are documented.

T032–T036 are complete within their evidence scopes. Whole BPMN 308, Interchange 130, Runtime EF 1,710 and Architecture 590 pass, with discovery reconciliation, locked restore and maps. Earlier Studio suites keep their original source identities; the new receipt adds final browser proof. Spec terminal status is prepared per lifecycle and becomes true on merge. T037/T038, required checks, protected merge and resulting-main verification remain open. Full-PR rounds: zero completed of six; the first independent correctness, standards and acceptance review is starting.

Effective required checks are Build & test, Generated maps fresh and Full tier; Full tier must actually run after draft readiness. GitGuardian is neutral because this PR exceeds its scan limit; that is an unverified scan. Three older public-hash findings remain unclassified, with the existing account-exception card unanswered. No owner-account write or protection bypass occurs.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) is reconciled through working Codex App Projects read/write access. #2735/#3338 remain In Progress/Assigned/Partial during author review; parity #3335 remains Done/Complete/Passed. #2892 remains in progress, #2898 blocked and #2907 queued. No additional App access is needed. The separate ADR 0063 PR and independent production/program acceptance remain open. Orleans and the task-runner follow-up stay deferred. The existing goal remains active.


## #2892 6457386027 elsa-workflows-codex[bot] 2026-10-28T00:31:09Z
Complete-PR self-review round 1 on #3338 at `59ee30c1558a16fc411547760eb28f936c9dfb58` found two actionable issues: ambiguous missing checkpoint fields can lose compensation responsibility, and direct saved-start input is not fully bound to its canonical source. [Round receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6457384391). Acceptance review is clean; both fixes and red/green regressions are next under the existing Codex claim. The PR remains draft; completed full rounds 1/6, no clean final round yet. Existing host/Studio/test evidence retains its source scope. Required Full tier/checks/protection/resulting-main, separate ADR0063 and independent #2898/#2907/program acceptance remain open. Project #62 stays In Progress/Assigned/Partial for #2735/#3338; no additional access is needed. Orleans/task-runner follow-up deferred; existing goal active.

## #2892 6458376551 elsa-workflows-codex[bot] 2026-10-28T01:41:15Z
Both complete-PR round 1 findings on #3338 are fixed in `cb1ebc606d72ede03d0f9915b3c13d69d5b00fc1`. [Fix evidence](https://github.com/elsa-workflows/elsa-foundation/blob/cb1ebc606d72ede03d0f9915b3c13d69d5b00fc1/specs/1006-bpmn-library-adoption/evidence/round1-review-fixes.md), [review receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6457384391). Whole affected suites: 5,855 passed, zero failed/skipped; original frozen authoring unchanged and actual legacy fixture provenance verified. Corrected-source actual upgraded-host/Studio refresh is running, followed by complete-PR round 2 (1/6 completed; no clean final review). Draft retained. Required checks/protection, delivery/resulting-main and separate ADR0063 remain open. Project #62 reconciled through the Codex App and accurately remains partial; existing organization Projects read/write permission is sufficient. #2898/#2907/program acceptance remain open, Orleans/task-runner deferred, existing goal active.

## #2892 6458468540 elsa-workflows-codex[bot] 2026-10-28T01:48:11Z
**Corrected-source actual host and Studio qualification delivered at `e54ea7f57f79602182c22fcea89f4ccb3f3fc673`; complete-PR round 2 is starting.** Sole draft #3338 continues the existing #2735 Codex claim.

Both complete-PR round 1 findings are fixed in `cb1ebc606d72ede03d0f9915b3c13d69d5b00fc1`. [Fix receipt](https://github.com/elsa-workflows/elsa-foundation/blob/e54ea7f57f79602182c22fcea89f4ccb3f3fc673/specs/1006-bpmn-library-adoption/evidence/round1-review-fixes.md): whole BPMN 372, Runtime 3,043, Runtime EF 1,720, Interchange 130 and Architecture 590 pass, **5,855 total / zero failed or skipped**. Original 242 methods retain all 251 cases; 37 additional BPMN methods provide 121 cases. Genuine red controls, excluded failed integration attempts and exact source restoration remain visible.

[Actual corrected host/Studio receipt](https://github.com/elsa-workflows/elsa-foundation/blob/e54ea7f57f79602182c22fcea89f4ccb3f3fc673/specs/1006-bpmn-library-adoption/evidence/round1-fixed-host-qualification.md), [42 source bindings / 64 portable assets](https://github.com/elsa-workflows/elsa-foundation/blob/e54ea7f57f79602182c22fcea89f4ccb3f3fc673/specs/1006-bpmn-library-adoption/evidence/round1-fixed-host-qualification.json). Fresh locked standard/probe binaries carry exact committed cb1ebc606 in actual ProductVersion metadata; the normal 288-DLL closure has no probe, all 48 retired types remain absent, released 0.5.0 DLL bytes and frozen authoring stay unchanged. A fresh standard process over byte-identical original old Runtime/Design copies preserves the entire checked initial state, continues original B/A/hold with intermediate version 1 to clean completion, and passes 28 reader controls. Seven whole module backups are portable.

Actual saved-start crash/retry first proves one of two selected keyed targets parked before the owned probe stops. The standard host takes over after real lease expiry with distinct owner/fence 1 → 2, preserves the cohort and complete first target, delivers the remaining exact starts/waits and excludes later matching listeners/bindings. Its actual payload is null; ten direct-dispatch regressions separately qualify changed/missing nonnull input and RequestedBy refusal. Crash-cut intermediate DBs remain private; checked provider/API observations are retained. Strict call 2 and registered import/broadcast 4 actual-host cases pass.

The normal Studio journey reloads a retained definition, then creates/imports/edits/saves/publishes/runs/reloads/exports a fresh BPMN definition. PublishedRun `14iBw6oMURH` on `artifact-cfadffc29096` completes both process/Delay without incidents; exact saved authored-v1/default/name/Never/PT1S, pin/hash and frozen published contracts 2/2 per host verify. Three inspected screenshots, eight DOM observations, XML, complete API/saved payloads and actual binary/served-JS identities are portable. Preserved catalog metadata is publication provenance, distinct from executing binary source. User localhost hosts/tabs remain untouched.

T032–T036 complete. **Full rounds completed 1/6; no clean final round yet.** Independent correctness, standards and acceptance round 2 now examines this final exact head against current main, including all comments/reviews. Required exact-head Build & test, Generated maps fresh and an actual Full tier after readiness, protection, protected delivery/resulting-main remain open. GitGuardian's neutral large-PR scan skip is not a scan pass. No owner-account classification or bypass is performed.

Project [#62](https://github.com/orgs/elsa-workflows/projects/62) freshly reconciled via working Codex App organization Projects read/write; no extra access needed and matching fields caused no no-op writes. #2735/#3338 remain In Progress/Assigned/Partial, #3335 Done/Complete/Passed, #2892 In Progress/Coordination/Partial, #2898 Blocked/Not Ready/Partial, #2907 Todo/Coordination/Not Assessed. Separate third ADR0063 and independent production/program evidence stay open; Orleans/task-runner follow-up deferred. Existing goal remains active.


## #2892 6458620590 elsa-workflows-codex[bot] 2026-10-28T01:59:48Z
Complete-PR round 2 on #3338 at `e54ea7f57f79602182c22fcea89f4ccb3f3fc673` requires one correction: incomplete persisted terminal child-control batches can lose notifications/classification before their first immutable delivery source exists. [Round receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6458619720). Both round-1 fixes are addressed; standards and acceptance reviews are clean. Full rounds completed2/6, no clean final round. PR remains draft under existing Codex claim; red/green reader fix and relevant whole/actual-host qualification are next. Project62 stays In Progress/Assigned/Partial for2735/3338. Requiredchecks/protection/delivery/main, thirdADR0063 and independent2898/2907/program acceptance remain open. Orleans/taskrunnerdeferred; existinggoalactive.

## #2892 6458762030 elsa-workflows-codex[bot] 2026-10-28T02:10:24Z
Full-PR round2 control-wire finding fixed in `9190df9647078994726e3089b48d8e723daacc00` on sole draft #3338. [Correction/evidence](https://github.com/elsa-workflows/elsa-foundation/blob/9190df9647078994726e3089b48d8e723daacc00/specs/1006-bpmn-library-adoption/evidence/round2-control-wire-fix.md), [round receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6458619720). 25 genuine executed reds/3 valid controls on unchanged production; fixed focused28 and whole6,812 pass without failed/skipped cases. Complete persisted authored content now refuses defaults/shadowing before its first terminal source can be created. API/constructors, legacy absent control, explicit nulls, opaque payloads, package/schema and frozen authoring remain compatible. Fresh exact standard-host build and relevant actual called-control recovery/Studio qualification are next, then full-PR round3. Completed rounds2/6; no clean final round yet. Required actual Full tier/checks, protection/delivery/main, third ADR0063 and independent2898/2907/program evidence remain open. Project62 freshly reconciled via sufficient Codex App Projects access; 2735/3338 remain In Progress/Assigned/Partial. Orleans/task-runner deferred; goalactive.

## #2892 6458920199 elsa-workflows-codex[bot] 2026-10-28T02:22:18Z
**Corrected-source host/Studio qualification delivered at `35ed1215b9a4d91385015a6d2e467ffa2da0ad83`; complete-PR round3 is starting.** The sole draft #3338 and exact #2735 Codex claim continue. [Current live evidence](https://github.com/elsa-workflows/elsa-foundation/blob/35ed1215b9a4d91385015a6d2e467ffa2da0ad83/specs/1006-bpmn-library-adoption/evidence/round2-fixed-host-qualification.md), [31 bindings/54 assets](https://github.com/elsa-workflows/elsa-foundation/blob/35ed1215b9a4d91385015a6d2e467ffa2da0ad83/specs/1006-bpmn-library-adoption/evidence/round2-fixed-host-qualification.json), [reader correction and whole evidence](https://github.com/elsa-workflows/elsa-foundation/blob/35ed1215b9a4d91385015a6d2e467ffa2da0ad83/specs/1006-bpmn-library-adoption/evidence/round2-control-wire-fix.md).

All three findings from rounds1/2 are fixed. Current whole BPMN372/EF1724/Runtime3043/Dispatch363/ActivitiesRuntime720/Architecture590 pass: **6,812 total, zero failures/skips**, with every discovery expansion accounted for and maps green. The latest fix has25 genuine executed reds/3 valid controls before correction, then28 focused passes. No API/package/schema/frozen authoring change.

Actual standard build `9190df9647078994726e3089b48d8e723daacc00` has exact metadata/probe-free closure and unchanged released0.5.0bytes. Normal public APIs pass coded errors2 plus escalation6. Six complete parent/child/control/physical/source observations equal across real cold restart, then all expected completions preserve payload/classification/order and truthful child fault. Four phase Runtime snapshots/24controls and final Studio Runtime/Design make six whole portable module backups. Normal Studio PublishedRun14iE6SpNZyi on retained artifactcfad completes both activities/0incidents. Recovered caller14iDzYWOz4n shows Completedcall/Faultedoutcome and handled caller completion; no local incident is fabricated. Complete retained authored-v1 payload and actual XML download equal prior UI values. User localhost pair untouched; earlier source-specific proofs remain historical rather than restamped.

T036 complete again. **Full rounds completed2/6; no clean final verdict yet.** The next full independent correctness/standards/acceptance round reviews this exact head against freshly fetched main7cd167e. Required actual Full tier after readiness/other exact-head checks, protection/delivery/main and the third ADR0063 PR remain open. GitGuardian's neutral large-PR scan skip is not a scan pass; no owner-account action/bypass. Project62 freshly reconciled using existing sufficient Codex App Projects access; status remains partial during author review. #2898/#2907/program production acceptance remain open; Orleans/task-runner deferred; existing goalactive.


## #2892 6459015091 elsa-workflows-codex[bot] 2026-10-28T02:29:26Z
Complete-PR round3 on #3338 at `35ed1215b9a4d91385015a6d2e467ffa2da0ad83` requires one writer correction: standard IPayloadSerializer omits null fields now required by the persisted-control reader, breaking valid same-serializer round trips. [Round receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6459014162). Correctness/standards identify the same issue; acceptance is clean and the earlier malformed-state finding is fixed. Existing real default-host evidence remains source-specific; its non-omitting wire is unaffected. Actual serializer regression reds, explicit-null writer fix and affected qualification are next. Full rounds3/6, no clean final round. Sole PR stays draft under existing claim; Project62 accurately partial. Required checks/protection/delivery/main, thirdADR0063 and independentproduction/programgates stay open; Orleans/taskrunnerdeferred; goalactive.

## #2892 6459160714 elsa-workflows-codex[bot] 2026-10-28T02:39:23Z
Full-PR round3 serializer finding fixed in `409ee7ba331b46925cd228f3bdccd7627f4d643b` on sole draft #3338. [Fix/portable red-green evidence](https://github.com/elsa-workflows/elsa-foundation/blob/409ee7ba331b46925cd228f3bdccd7627f4d643b/specs/1006-bpmn-library-adoption/evidence/round3-null-writer-fix.md), [review receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6459014162). Two attributes keep required null payload/classification under the shipped serializer omission policy, retaining strict malformed-state refusal. Actual registered-serializer/policy regressions execute16fail/1validpass unchanged, then17green; all6,829 affected whole cases pass without failures/skips, with reconciled discovery and maps. Constructor/CLR signatures, package/schema, legacy absence and frozen authoring unchanged. Fresh exact standard/reader builds and relevant host/Studio refresh are running; full-PR round4 follows on the final exact head. Completed rounds3/6, no clean final verdict. Project62 freshly reconciled via sufficient Codex App Projects access and remains partial. RequiredactualFullTier/otherchecks/protection/delivery/main, separateADR0063 and independent2898/2907/programproof stayopen; Orleans/taskrunnerdeferred; goalactive.

## #2892 6459366827 elsa-workflows-codex[bot] 2026-10-28T02:53:05Z
**Final writer-corrected live qualification delivered at `e68ab18f081bb4632378ae7706479e55b2f48b58`; complete-PR round4 starts.** Sole draft #3338 and exact #2735 Codex claim continue. [Two-attribute writer fix/red-green proof](https://github.com/elsa-workflows/elsa-foundation/blob/e68ab18f081bb4632378ae7706479e55b2f48b58/specs/1006-bpmn-library-adoption/evidence/round3-null-writer-fix.md), [actual host/Studio](https://github.com/elsa-workflows/elsa-foundation/blob/e68ab18f081bb4632378ae7706479e55b2f48b58/specs/1006-bpmn-library-adoption/evidence/round3-fixed-host-qualification.md), [36bindings/54assets](https://github.com/elsa-workflows/elsa-foundation/blob/e68ab18f081bb4632378ae7706479e55b2f48b58/specs/1006-bpmn-library-adoption/evidence/round3-fixed-host-qualification.json).

Four deduplicated findings from complete rounds1–3 are fixed. Current whole BPMN372/EF1724/Runtime3043/Dispatch380/ActivitiesRuntime720/Architecture590 pass: **6,829 total, zero failed/skipped**, with exact/deferred discovery reconciliation and maps. Latest actual registered IPayloadSerializer plus null/default-omission/naming controls execute16fail/1validpass unchanged, then17green. Strict persisted malformed-state refusal stays intact; constructors/CLR signatures, legacy absence, package/schema and frozen authoring stay compatible.

Exact standard/reader build `409ee7ba331b46925cd228f3bdccd7627f4d643b` is probe-free with current ProductVersion metadata, all48retiredtypes absent and released0.5bytes unchanged. Normal public coded errors2/escalation6 pass; all six complete parent/child/control/physical/source observations equal across real cold restart before expected final completion. Four whole Runtime phases pass24readercontrols; final Studio Runtime/Design make six portable module backups. Studio normal retained-publication run14iGKYmvX2h completes both activities/0incidents with exact artifactcfad/hash; recovered caller14iG40qMjTo shows Completedcall/Faultedoutcome/0localincidents and handled caller completion. Complete retained authored-v1 and actual XML download equal original UI values; current source/binary/servedJS/DOM/screenshots/API/pin evidence is portable. User localhost pair untouched. Earlier source-specific legacy/saved-start/ack/Studio suites stay historical, not restamped.

T036 complete. **Full rounds completed3/6; no clean final verdict.** Independent complete round4 reviews this exact head against freshly fetched main7cd167e, including all discussion/reviews. Actual required Full tier after readiness/other exact-head checks, protection/delivery/resulting-main and separate third ADR0063 remain open. GitGuardian neutral size-skip is unverified scan; no owner-account action or bypass. Project62 reconciled via sufficient Codex App Projects read/write and remains accurately partial during author review. #2898/#2907/programproductionacceptance remain open; Orleans/task-runner deferred; existing goalactive.


## #2892 6459559417 elsa-workflows-codex[bot] 2026-10-28T03:05:39Z
Full-PR round4 on sole draft3338 at `e68ab18f081bb4632378ae7706479e55b2f48b58` has no behavioral findings; one Low documentary executing-revision typo remains. [Round receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6459558403). Correct prose/hash, then full round5 on new exact head; existing6,829passes/actualhost/Studio evidence stays source-bound and needs no unrelated rerun. Four of six rounds complete, no clean final exact-head verdict yet. Project62 accurately Review/Assigned/Partial for3338;2735 stays InProgress. Required actual Fulltier/checks/protection/delivery/main, thirdADR0063 and independentproduction/program gates remain open; Orleans/taskrunnerdeferred; goalactive.

## #2892 6459594449 elsa-workflows-codex[bot] 2026-10-28T03:07:41Z
Round4's sole Low documentary correction is fixed in `d44b0a796e3de4abd4da4fa04084e6dceb85076b` on #3338. [Review receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6459558403). Exactly two files changed: executing-revision prose now agrees with actual409ee7ba product metadata, and its bound hash is refreshed. All36bindings/54assets verify; production/test/binary/capture bytes are unchanged, so no unrelated test/host rerun. **Complete-PR round5 is starting; four of six rounds completed, no final clean exact-head verdict yet.** Existing6,829passes and real recovery/Studio evidence keep their source scopes. Project62 remains Review/Assigned/Partial for3338;2735 remains InProgress. Required actual Fulltier/checks/protection/delivery/main, thirdADR0063 and independent2898/2907/program production proof remain gates; Orleans/taskrunnerdeferred; goalactive.

## #2892 6459661945 elsa-workflows-codex[bot] 2026-10-28T03:12:07Z
Full-PR round5 is clean across independent correctness/standards/acceptance on #3338 exacthead `d44b0a796e3de4abd4da4fa04084e6dceb85076b` against `7cd167e00a80c8c01d83c198200cde36058c3300`. [Clean round receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6459660974). Five of six rounds completed, author loop converged; all prior findings fixed/no remainingLow. Whole6,829pass/0failed/skipped and actual source-bound legacy/recovery/Studio evidence verified. Marking ready for actual required Fulltier and other exact-head checks, then protected delivery/main verification. Project62 Review/Assigned/Running for3338;2735 remains InProgress/Partial pending thirdADR0063. Independent2898/2907/program acceptance open; Orleans/taskrunnerdeferred; goalactive.

## #2892 6460050259 elsa-workflows-codex[bot] 2026-10-28T03:39:25Z
Adoption [PR #3338](https://github.com/elsa-workflows/elsa-foundation/pull/3338) merged as `438001406d980051584234e5d656eb8e6a67f47f` through the normal protected path as `elsa-workflows-codex[bot]`, following clean round5 and green required Build & test, Generated maps fresh and actual Full tier. [Self-merge audit](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6460021281) retains the existing quarantine/skip/scan limits. Studio CI and both backend-source platforms passed.

The complete resulting-main tree equals reviewed d44b0a796. Exact-main locked standard-host build and actual host/Studio verification are starting; [main CI](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40627777571), [Studio](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40627777523) and [CodeQL](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40627777535) are running. Main verification is not yet passed.

#2735 remains open for this verification and the third ordered ADR0063 acceptance PR. ADR stays Proposed. #2898/#2907 and #2892 acceptance remain open for their own evidence; Orleans/task-runner follow-up stays deferred. Project62 records #3338 Done/Complete with verification Running, while #2735 remains In Progress/Partial.

## #2892 6460166306 elsa-workflows-codex[bot] 2026-10-28T03:48:32Z
**Resulting-main actual host/Studio qualification passed; push checks remain running.** Exact standard Workbench and checked-reader builds use `438001406d980051584234e5d656eb8e6a67f47f`. The full tree equals the reviewed tree, all48retired public types remain absent, and Bpmn.Model/Semantics/Interchange bytes equal the qualified released0.5.0 binaries.

Six real running/terminal escalation and signal-plus-failure cases were parked on executing409ee7ba3, then the manifest-verified owned backend was replaced with the exact main executable over the same module/config/identity stores. Complete parent/child/control/physical/source observations equal before/after this actual upgrade. Public continuation finishes all six; both coded-error cases also pass on main. Pre-upgrade Runtime hash `6869442cc7121095ac9bc188b3638ad0d23e9ed5890f17488d1422c704416f61`; recovered held Runtime hash `74adf8470dae5cb8ed98d3d2302a9823d29ff4030a05c07ffd8ae9ede48a4d68`. Invalid-copy controls remain separate from positive hosts.

Normal Studio reopens the retained definition14iBsLEuiJS and starts **PublishedRun14iKTVzYS2o** from artifactcfadffc29096 / hash `sha256:cfadffc290962fdc6a6bbc4e070f867c305028a6343178957c5a5dd77e685dd5`: process and Delay Completed, zero incidents. Full reload retains gateway/default/Never; the entire saved authored-v1 payload and actual downloaded BPMN XML equal prior UI values. XML hash `193194cf46188fa6bcbd0c5939612bd8c0319625ec1cf7f5fa95ed7bb0ed5a61`; actual published frozen contracts2/2. Both screenshots were visually inspected. Studio executing build3815806a has unchanged production sources through main; catalog81f6ae7a remains publication provenance, distinct from the executing main backend. Earlier old-writer captures/legacy/ack proofs retain their own revisions.

[Main CI](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40627777571), [Studio CI](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40627777523) and [CodeQL](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40627777535) are still running, so overall main verification is **not yet complete**. Portable receipt preparation is underway for the ordered ADR PR after those gates pass. ADR0063 remains Proposed; #2735/#2898/#2907/#2892 remain open. Project62 keeps adoption3338 Done/Complete/Running and2735 In Progress/Partial. No program completion or new production acceptance is inferred.

## #2892 6460349212 elsa-workflows-codex[bot] 2026-10-28T04:03:15Z
**Adoption resulting-main verification complete** at `438001406d980051584234e5d656eb8e6a67f47f`. [CI](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40627777571), [Studio CI](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40627777523), [CodeQL](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40627777535), automatic Packages40627777748 and Docker40628033549 passed on this exact commit. All nine main-CI outcome artifacts have no unquarantined repeated failure, passed-on-retry case or aborted run; existing compensation-sample quarantine #3261 and declared skips remain recorded. Main push omits EF containers; ready-PR actual Full tier qualified them on the identical reviewed tree.

[Actual resulting-main host/Studio proof](https://github.com/elsa-workflows/elsa-foundation/pull/3338#issuecomment-6460165397) passed: fresh locked standard/reader builds, whole-tree identity, released library bytes,48retiredtypes absent, six complete real409-to438 recovery observations unchanged and public completion, both coded errors, and normal retained Studio PublishedRun14iKTVzYS2o with2Completed/0incidents plus unchanged complete authoring and actual downloaded XML. The prepared portable receipt has37assets/fourwholemodulebackups/24readercontrols; it will accompany the third ordered ADR PR. Historical old-writer/ack and6829whole-suite evidence keep their source scopes.

Parity3335 and adoption3338 are delivered and verified. **#2735 stays open for the third ADR0063 acceptance PR**, now being prepared under the existing claim. ADR remains Proposed on main until that PR merges. Project62 adoption3338 Done/Complete/Passed;2735 In Progress/Assigned/Partial. #2898/#2907 and full program acceptance remain open for own evidence; Orleans/task-runner follow-up remains deferred. Existing goalactive.

## #2892 6460458282 elsa-workflows-codex[bot] 2026-10-28T04:11:43Z
Third ordered [ADR acceptance PR#3409](https://github.com/elsa-workflows/elsa-foundation/pull/3409) is draft at `9058e4080503594e403d72a93f4520f33433f241` against verified adoption main438001406. Complete-PR round1of6 is underway with independent correctness/standards/acceptance lenses. Runtime code is unchanged. ADR/index/task/program closeout and37portableassets/fourwholeDBs/24controls record the already passed exact-main host/Studio and CI/Studio/CodeQL qualification. Local asset/source hashes, SQLite integrity,241relativeMarkdowntargets and catalog155files0broken pass; CI classifies all45paths documentation-only.

#2735 remains open until this third PR delivers. ADR remains Proposed on main until merge. #2898/#2907 and program acceptance remain open; Orleans/taskrunnerdeferred. Project62 shows3335/3338 Done/Complete/Passed and3409 Review/Assigned/Partial;2735 In Progress/Assigned/Partial. No new implementation claim or competing stack.

## #2892 6460547088 elsa-workflows-codex[bot] 2026-10-28T04:18:33Z
ADR #3409 is ready at `9058e4080503594e403d72a93f4520f33433f241` after clean [complete-PR round1of6](https://github.com/elsa-workflows/elsa-foundation/pull/3409#issuecomment-6460499727) across independent correctness/standards/acceptance. Findings/fixes/dropped/remainingLow:none. Exact-head Build & test, Generated maps fresh and [actual required Full tier40631246858](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40631246858) passed under the45path documentation-only policy. GitGuardian also passed for this PR. No failed checks, human holds or unresolved threads; normal protected self-merge follows the audit. Adoption/main438 qualification remains verified. #2735 closes only with this final ADR PR;2898/2907/program remain open; Orleans/taskrunnerdeferred.

## #2892 6460653684 elsa-workflows-codex[bot] 2026-10-28T04:26:53Z
**#2735's ordered three-PR stack is delivered.** Parity3335 and adoption3338 were merged; adoption exact main438001406 passed actual host/Studio and CI/Studio/CodeQL qualification. Final [ADR PR3409](https://github.com/elsa-workflows/elsa-foundation/pull/3409) merged normally as `d3ebb980e2dbebeed680808e58c1edd694fae0f7` after clean complete-PR round1 and green required exact-head Build & test/Generated maps fresh/actual Full tier. [Standing self-merge audit](https://github.com/elsa-workflows/elsa-foundation/pull/3409#issuecomment-6460548068). Actor: elsa-workflows-codex[bot]. GitHub closed #2735 as completed.

Merged ADR0063 and its index are Accepted; T037/T038 and the program summaries are closed out. The entire doc-main tree equals reviewed9058e4080, and only45documentation/evidence paths differ from qualified production438. The portable main receipt37assets/fourwholeDBs/24controls is committed; original frozen authoring/legacy captures remain unchanged and source scopes remain explicit.

Project62 marks2735/3409 Done/Complete with verification Running;3335/3338 remain Done/Complete/Passed. **#2898/#2907 and program#2892 remain open** for their own production evidence. Next is their scoped acceptance reconciliation after this integration lane; no competing implementation claim or PR is created. Orleans/taskrunnerremain deferred, and the full program goal remains active.

## #2892 6461084133 elsa-workflows-codex[bot] 2026-10-28T05:01:07Z
**#2735 final verification and closeout complete.** Parity3335, verified adoption3338 and accepted ADR3409 are delivered. Exact ADR main `d3ebb980e2dbebeed680808e58c1edd694fae0f7` passes [CI40631728141](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40631728141), [Studio40631727792](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40631727792), [CodeQL40631727931](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40631727931), Packages40631727848 and Docker40631811687. The nine CI outcome artifacts have no unquarantined repeated failure, passed-on-retry case or aborted run; existing #3261quarantine/declared skips remain recorded. The separately triggered Studio Docker40633638997 was last observed running and is not included as a passed gate.

Main's entire tree equals reviewed9058e4080; its45doc/evidence changes preserve the already qualified production438bytes. Merged ADR/index Accepted, task closeout and37portableassets/fourwholeDBs/24controls verify. Executing host/Studio438/381, original old-writer/ack and6829local tests retain their exact source scopes; none are relabelled as locally rerun on d3. Frozen authoring and legacy captures remain unchanged.

#2735 is closed completed; Project62 marks2735/3409/3338/3335 Done/Complete/Passed. The completed Codex claim is released separately. **Program#2892 and #2898/#2907 remain open.** Next is production direct/embedded-host and operational acceptance reconciliation under existing #2898/#2907, preserving the approved deferrals. The ready queue is80, already above the repository cap; extend the existing work rather than file more issues. No new program goal or competing migration stack.

## #2892 6461460223 elsa-workflows-codex[bot] 2026-10-28T05:29:45Z
[Codex] On behalf of @sfmskywalker.

The approved [18October continuation](https://github.com/elsa-workflows/elsa-foundation/issues/2892#issuecomment-6249319967) authorizes production direct/embedded BPMN and explicitly defers arbitrary token alteration/live migration; those capabilities are not marked demonstrated. #2735's parity/adoption/ADR stack is now delivered and finally verified ([closeout](https://github.com/elsa-workflows/elsa-foundation/pull/3409#issuecomment-6461083215)); its claim is released.

The next single implementation leaf is existing **#2898**, with winning [Codex claim](https://github.com/elsa-workflows/elsa-foundation/issues/2898#issuecomment-6461197535). The old blocked prerequisite is resolved. Reserve **spec1017-direct-bpmn-hosting**, branch `agent/codex/2898-direct-bpmn-hosting`. Tree/archive and all17open PR file lists were checked: highest existing spec1016; no competing2898PR or human assignment. The ready queue is80 against the repository cap, so this extends the existing task; no new issue or reparenting.

Current-source gap: native checkpoints/actors are typed to native workflow participants; no production execution-model registry/direct host exists. The historical custom-host/ETL experiments remain research evidence. The new witness must use released0.5.0 through the shared fenced checkpoint/outbox authority, model-owned interpretation and real direct/embedded execution, with preserved native/frozen authoring and stored state. Cover restart, both timer/human/late-result orders, real finite ETL success/business-error/fault/cancel and minimal task/incident commands; declare construct/operation cuts. Capture actual current writer checkpoints before changing/deleting their writer. Review spec → plan → tasks before implementation.

#2898 production acceptance stays unchecked until its new evidence exists. #2907's link/adopt2735 criterion is now supported; its direct-host/operations/Studio criteria stay open. Existing native Sequence fault projection is preserved; separate owner decision #3242 is not silently settled here. Broader task administration/operator-console work, arbitrary alteration/migration, Orleans and taskrunnerremain deferred. Programgoalactive.

## #2892 6461527354 elsa-workflows-codex[bot] 2026-10-28T05:34:46Z
Progress and priority review — 28 October 2026

The complete #2735 stack is delivered: parity3335, library adoption3338 and ADR acceptance3409 are merged. Actual upgraded-host, native-composite and Studio compatibility evidence and exact-main checks are recorded in [the final receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3409#issuecomment-6461083215). This does not close direct-host or operational product acceptance.

Architecture assessment: retain shared durable infrastructure with separate model semantics and the released interpreter. The production checkpoint/dispatch boundary is still native-shaped; real native/BPMN integration must justify the smallest shared boundary before any stable neutral-contract claim. No broad actor replacement or new semantics engine is needed for this step.

Delivery risk is integration breadth and elapsed qualification work. Measure the next milestone by an observable production journey and its bounded failure/recovery evidence. The board mixes parent, task, PR and upstream rows; card closure counts are not a completion percentage. Corrected stale parent Status/Phase/Verification and conflicting current checkpoint text. #2898/#2907 and full ETL/agents/integrated acceptance remain open; existing Orleans/task-runner deferrals remain in force.


## #2892 6461664642 elsa-workflows-codex[bot] 2026-10-28T05:43:54Z
#2898 specification is committed in draft [PR #3410](https://github.com/elsa-workflows/elsa-foundation/pull/3410) at `ad683917c41d46f079bd3d7af7fafc2104a456c3`; [leaf checkpoint](https://github.com/elsa-workflows/elsa-foundation/issues/2898#issuecomment-6461657762). Five journeys cover true direct/embedded hosting, recovery/races, real pipeline outcomes and legacy/Studio compatibility. Three independent specification reviews are running before planning. Project62 now includes3410 as In Progress / Assigned / Partial; no runtime or full-program completion is claimed.

## #2892 6462172429 elsa-workflows-codex[bot] 2026-10-28T06:17:19Z
#2898 draft3410 now has clean independently reviewed specification and plan, plus the task list under review: [planning receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6462168774), [leaf checkpoint](https://github.com/elsa-workflows/elsa-foundation/issues/2898#issuecomment-6462170896). Source/schema implementation has not started; actual pre-writer capture remains the next implementation gate. Project62 continues In Progress / Assigned / Partial for the active task/PR. Full program goal remains active.

## #2892 6462605581 elsa-workflows-codex[bot] 2026-10-28T06:47:18Z
#2898 draft3410 moved from reviewed design into verified capture tooling: [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6462601743). Ordered spec/plan/tasks reviews are clean, T001 is complete, eight actual held legacy runs and whole stores are committed,12capture checks pass. T002 remaining captures precede all production writer/schema edits. Direct/embedded production hosting and wider acceptance are still unproved; full goal remains active. No additional project access or owner decision is needed for the current step.

## #2892 6463521614 elsa-workflows-codex[bot] 2026-10-28T07:43:27Z
Actual pre-writer capture update: [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6463514178). T003 Core/API consumer projects compile; four actual MI cases now include real loop/iteration state across Balanced/Durable. Gate A/T002 remains open for independently checked pre-consumption native-parent completion inputs. No direct-host or changed-host recovery acceptance; #2898/#2907 and program remain open. Project62 remains In Progress / Partial.


## #2892 6463959194 elsa-workflows-codex[bot] 2026-10-28T08:09:09Z
T001–T003 complete on `6af6df2c230e92f16f38ca23f886c8af62f03725`; [verified pre-writer capture checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6463947799).104 assets/22 whole stores/15 checked provider observations, genuine MI and pending native-parent inputs, frozen authoring and actual existing Studio captures are retained. The first direct-host journey is next through the reviewed shared-runtime plan. No new direct/changed-host recovery or full runtime acceptance;2898/2907/program remain open. Project62 In Progress / Partial remains correct.


## #2892 6464794795 elsa-workflows-codex[bot] 2026-10-28T08:56:29Z
T001–T004 complete; T005 model-material contracts started. Owned production Workbench/native execution survives a same-store process restart; 62 targeted runtime/material/native tests, one host test and map/tier checks pass. New model operations default-refuse; no model storage, schema changes or direct-model/upgrade acceptance. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6464768721), head `d8932737d83ad785bb81e177860a573f72414a8b`. #2898/#2907/program stay open; Project62 In Progress / Partial remains accurate.


## #2892 6480176858 elsa-workflows-codex[bot] 2026-10-28T20:40:34Z
[Codex] On behalf of @sfmskywalker.

Delivery priority clarified on 28 October: the immediate milestone is a genuine direct BPMN **start → wait → host restart → resume → complete** journey. Continue the existing #2898 claim and draft PR #3410; do not add abstractions ahead of a demonstrated consumer or restart the delivered #2735 work.

> Deliver Elsa execution-model Program #2892 end to end through small, verified production journeys. First, prove genuine direct BPMN start → wait → host restart → resume → complete through the existing durable runtime, preserving frozen authoring and legacy saved executions. Then prioritize a real ETL failure/recovery journey, including BPMN-to-ETL integration, to guide any shared mechanisms. Introduce abstractions only when a working journey needs them. Continue the remaining approved native/BPMN/ETL, agent, independent-model, Studio and communication acceptance; keep issue/PR checkpoints and Project #62 current. Retain standing review/merge safeguards and existing Orleans/task-runner deferrals. Complete only evidence-backed acceptance.

The owner explicitly confirmed direct recovery first and continued end-to-end program delivery. ETL is the next recommended delivery focus: build on the already delivered finite journeys and prove remaining real failure/recovery/integration behavior, rather than redesigning completed ETL work. This is sequencing within existing scope, not a second active implementation lane.

#2735 remains delivered. #2898/#2907 and the program remain open/partially verified. The next acceptance checkpoint must show actual direct-model behavior; native-only restart tests and contract work do not establish it.

## #2892 6481027679 elsa-workflows-codex[bot] 2026-10-28T21:23:40Z
Implementation checkpoint: #2898 / draft PR3410 pushed `151de7d669f6a9d74eecd3b13e90a56c24fd787d`. The direct journey now has atomic model state/input participation in the existing fenced checkpoint, plus additive model-table migrations that retain the old Runtime chain. **293 focused checks pass** with zero skips, plus maps/tier checks; a captured actual legacy database migrates without changing legacy rows. [Exact-source receipt and limits](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6481009290).

The active outcome remains direct BPMN start → wait → restart → resume → complete. Actual material/retention and verified dispatch are next; no model admission is enabled. Schema upgrade alone does not establish changed-host recovery, direct hosting or Studio acceptance. #2898/#2907 and this program remain open/partially verified; full-PR rounds0. Existing deferrals and the ETL follow-up sequence remain unchanged. Project62 overview and current issue/PR bodies are being reconciled to this exact head.

## #2892 6482019027 elsa-workflows-codex[bot] 2026-10-28T22:14:01Z
T006 material/retention is pushed in draft PR3410 at `ff5266e67dd50dc69e5981d0b6517bfb16e1118d`. It now uses actual EF model material writes/returned incarnations, complete closure grants and pins, fenced publication, retained model execution roots and orphan GC. **701 local checks** plus maps/tier checks pass. [Exact-source checkpoint and limits](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6481998201).

The direct start → wait → restart → resume → complete journey remains the immediate outcome. Verified model dispatch and the released BPMN driver are next; no model admission or direct/changed-host/Studio acceptance yet. Before model work is admitted, old/unknown queue readers must demonstrably refuse it instead of native/Noop acknowledgement. Current-head CI must still pass; the previous head's project/schema expectation failures are fixed locally. GitGuardian's finding is the supplied public authoring fingerprint; its false-positive action and the separate CLA check remain pending. Project62 and current issue/PR bodies reflect this head. #2898/#2907/program remain open; review rounds0. All existing deferrals and the ETL follow-up sequence remain intact.

## #2892 6482492544 elsa-workflows-codex[bot] 2026-10-28T22:38:14Z
M3 continuation checkpoint: #2898 / draft #3410 remains the single active leaf under claim6461197535.

Pushed `33e3c140fd3307e2d2d98af05e027a0f9880fe43` on `agent/codex/2898-direct-bpmn-hosting`, including current main6432ed240. T009 is partial: protected v1/v2 scheduler content and pre-claim refusal now prevent model/unknown input reaching native Noop acknowledgement. Actual predecessor checked-reader refusal and the missing-driver negative control are qualified. Native-only material reads were corrected; existing EF command budgets pass unchanged.

Next remains verified protocol selection and the released BPMN driver, followed by the supported HTTP and real owned-host start → wait → restart → resume → complete journey. No model admission or direct/actual changed-host/Studio/placement acceptance is claimed. Full-PR rounds0; new-head CI and external GitGuardian owner action pending. #2907 and the full remaining program stay open; ETL recovery/integration follows the direct milestone. Existing deferrals and compatibility/review safeguards remain in force.

## #2892 6483930852 elsa-workflows-codex[bot] 2026-10-28T23:59:22Z
Production milestone: the real direct BPMN human journey now runs through authenticated Workbench HTTP and survives an owned process restart on the same SQLite store. Initial direct BPMN authenticated start → human wait → owned process exit/restart → exact completion passes on production Workbench, built-in single-node mailbox/EF SQLite. Full pin/incarnation/attempt and revision survive; stale attempts are rejected, exact replay adds no revision and native workflow/activity/bookmark rows are zero. Actual protocol selection and released-library driver are wired; accepted first-input rooting and admission-off recovery pass. 1,320 local checks, maps/tier checks and final locked restore pass. Source `48bf343b51f9db4c682bacb737758d0c6dbdcfbc`; evidence head `9c6eaa314f4b986b382d934eabcf197b8d7f79c6`. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/9c6eaa314f4b986b382d934eabcf197b8d7f79c6/specs/1017-direct-bpmn-hosting/evidence/direct-recovery); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6483911994). This is an initial same-source combined-host human profile; runtime-only, actual changed-host/legacy/Studio/clustered placement, full fork/race/settlement/source-admission and native/ETL integration gates remain open. Full-PR rounds0; PR stays draft, new-head CI and external GitGuardian owner action pending. #2898/#2907/program remain open.

The active goal already reflects the owner’s journey-first sequencing: direct BPMN recovery, then real ETL failure/recovery and BPMN-to-ETL integration, building on delivered work. Keep the complete approved program, one implementation leaf, compatibility safeguards and deferrals. Project #62 remains In Progress / Partial; this milestone does not close production acceptance.

## #2892 6484000888 elsa-workflows-codex[bot] 2026-10-29T00:03:35Z
Current branch head `1b95de8708614d22ee2693ed4a5a5a859bfa9ff4` repairs the evidence head’s failed dependency restore. Forced full/Core/Workbench locked restores pass; new-head CI is pending. The initial real direct-human recovery milestone remains supported by its exact-source binary/store evidence; wider acceptance remains partial. [CI follow-up](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6483996147). Project62 updated; no new implementation leaf, review approval, merge or program completion is claimed.

## #2892 6484641128 elsa-workflows-codex[bot] 2026-10-29T00:42:27Z
Head `d61bd5d828cf9c54c2b93628e0d36673183c3853` fixes obsolete/terminal-input handling on top of the real direct human process-restart journey. Rejections retain receipts without changing state/revision; late completion is no longer pending. 1,054 positive checks/zero skips include whole BPMN379, architecture594, required PostgreSQL/SQL Server/MySQL3, EF25, runtime51 and exact-source host2. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/d61bd5d828cf9c54c2b93628e0d36673183c3853/specs/1017-direct-bpmn-hosting/evidence/direct-recovery/retained-input); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6484636710). Prior architecture CI failure is repaired locally; new-head CI pending. Full-PR rounds0/draft; GitGuardian resolution is owner-deferred and remains required before merge. Runtime-only partial fork/join, wider races/settlement/admission, actual upgrade/Studio/clustered placement and real native/ETL bindings remain open. #2898/#2907/program remain partial.

## #2892 6485121818 elsa-workflows-codex[bot] 2026-10-29T01:14:05Z
Head `bee416574b9d6c3da25a58491e4a02828e382fac` adds actual runtime-only partial fork/join recovery on top of the direct human journey and unchanged-state rejection fixes. Complete one branch, exit/restart, preserve the other exact wait, observe one post-join wait and one terminal result; no Design storage or native enclosing execution. [Exact-source observations/snapshots](https://github.com/elsa-workflows/elsa-foundation/tree/bee416574b9d6c3da25a58491e4a02828e382fac/specs/1017-direct-bpmn-hosting/evidence/direct-recovery/runtime-only-parallel); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6485117612). Latest whole host3/3 plus composition10 pass; prior rejection/terminal component qualification1054 remains separately source-bound. Prior d61 head Build & test/Full tier/Windows/Ubuntu are green; new-head CI pending. Full-PR rounds0/draft; GitGuardian owner-deferred but still merge-gating. Real native/ETL bindings, remaining races/settlement/admission, actual changed-host/legacy/Studio and clustered placement remain open; #2898/#2907/program stay partial.

## #2892 6489393346 elsa-workflows-codex[bot] 2026-10-29T06:11:02Z
[Codex] On behalf of @sfmskywalker.

Owner-confirmed goal — 29 October 2026:

Continue the same active program and the existing #2898 claim/draft PR #3410. First direct BPMN recovery is demonstrated within its recorded profile; next priority is real ETL failure/recovery and BPMN-to-ETL integration, reusing delivered ETL. The remaining approved scope, actual legacy-state upgrade and Studio acceptance, protected review/check safeguards, and Orleans/task-runner deferrals remain in force. Completion requires the accepted real journeys and post-merge evidence. #2898, #2907 and the program remain open/partial.

Fresh remote audit: head `bee416574b9d6c3da25a58491e4a02828e382fac` is unchanged. Build & test, Generated maps fresh, Full tier and both backend platforms have passed on that exact head. GitGuardian remains failed under the owner’s “handle it later” decision and still gates merge; license/cla is queued separately. Full-PR review rounds remain zero. Project #62, issue/PR checkpoints and the [canonical program-goal document](https://github.com/elsa-workflows/elsa-foundation/blob/38be070a2e17d3e933e0290964b49669aa0e24f2/docs/program-goals/unified-execution.md) have been reconciled and read back. Documentation checkpoint `38be070a2e17d3e933e0290964b49669aa0e24f2` is pending its own checks; runtime/evidence source is unchanged. [PR checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6489414037).

## #2892 6489730344 elsa-workflows-codex[bot] 2026-10-29T06:33:28Z
Head `7948d768065a4cf0ef54bc76cfc097d2fda59c00`; executing host/runner source `f3b56e516d4e6bd05bfa82995f512f27f4520fe8`. Actual pre-writer partial-fork stores recover and finish eight LegacyRoot/Sequence/Flowchart/CompensationScope runs in Balanced/Durable modes through normal Event commands. Full pins/wait identities, the original migration, all59 native artifact payloads/incarnations and the frozen published-authoring fingerprint are preserved. [Portable upgraded stores and source-bound observations](https://github.com/elsa-workflows/elsa-foundation/tree/7948d768065a4cf0ef54bc76cfc097d2fda59c00/specs/1017-direct-bpmn-hosting/evidence/upgrade/partial-forks); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6489704967). Whole hosting4/4 and verifier17/17 pass with the actual baseline supplied, zero skips; normal copied fixtures also pass. T030 remains partial for the remaining capture families and actual Studio. Real native/ETL bindings, remaining operational races/settlement/admission and clustered placement stay open. Current-head CI pending; GitGuardian owner-deferred but still merge-gating. Draft/full-PR rounds0; #2898/#2907/program remain open/partial.

## #2892 6490570602 elsa-workflows-codex[bot] 2026-10-29T07:21:14Z
Head `779427881ac18e2eca0609745a7882e10978814f`; executing host/runner source `02602bad34602496314b5cbf7a84a6b2f549124a`. Six original pending native fault notifications recover: four parent outcomes apply, while two Sequence cases retain their terminal disposition without claiming parent consumption. Twelve retained native Fault/Cancel histories also survive upgrade and another process. Original sources, full pins/invocations, migration history and native material remain intact; the upgraded Design store matches the frozen authoring contract. [Source-bound upgraded stores and qualification](https://github.com/elsa-workflows/elsa-foundation/tree/779427881ac18e2eca0609745a7882e10978814f/specs/1017-direct-bpmn-hosting/evidence/upgrade/native-parents); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6490538109). Whole hosting6/6 and verifier23/23 pass, zero skips with the actual baseline supplied. Earlier actual partial-fork recovery8 remains separately qualified. T030 stays partial for called-workflow acknowledgment, broadcast, active MI/compensation/control and actual Studio. Real native/ETL bindings, model settlement and remaining operational acceptance stay open. Draft/full-PR rounds0; new-head CI pending and GitGuardian still owner-deferred/merge-gating. #2898/#2907/program remain open/partial.

## #2892 6490933076 elsa-workflows-codex[bot] 2026-10-29T07:41:57Z
Head `f390e46bf08fef48d8049d154b4aa267a2207387`; executing host/checked-reader source `4bba8f266327369608733fb4ee484e07a33bbf6a`. Both actual legacy notice/terminal pre-ACK cuts recover through the standard pump without repeating caller work. Checked EF proves committed caller acceptance; original Events finish both pairs and further processes preserve recovered/final views. Four upgraded stores, full pins, original material/migrations and the frozen authoring contract are [retained with source-bound proof](https://github.com/elsa-workflows/elsa-foundation/tree/f390e46bf08fef48d8049d154b4aa267a2207387/specs/1017-direct-bpmn-hosting/evidence/upgrade/called-ack); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6490922188). Whole host7/7 and verifier29/29 pass, zero skips with the actual baseline supplied; maps/tiers pass. Earlier partial-fork/native-parent evidence retains its own source limits. T030 remains partial for broadcast, active MI/compensation/control and actual Studio before pipeline addition. New direct-model/RunBpmn settlement, real native/ETL bindings and remaining operational/clustered acceptance stay open. Draft/full-PR rounds0; new-head CI pending. GitGuardian remains owner-deferred/merge-gating. #2898/#2907/program remain open/partial; goal active.

## #2892 6491352748 elsa-workflows-codex[bot] 2026-10-29T08:05:28Z
Head `a365a8628b0948f74a34bd8a7ad28eb6cbf4bc71`; executing host/checked-reader source `facffc859ce01a2d4e3fe85be52bcb5b5b285998`. All four actual saved broadcast cuts recover: first-delivery selection includes later listeners, installed/empty cohorts stay fixed, and retry preserves accepted callbacks and re-armed waits. Eight upgraded stores, full pins, all5 original executable payloads/incarnations per store, migrations and frozen authoring are [retained with source-bound proof](https://github.com/elsa-workflows/elsa-foundation/tree/a365a8628b0948f74a34bd8a7ad28eb6cbf4bc71/specs/1017-direct-bpmn-hosting/evidence/upgrade/broadcast); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6491351179). Whole host8/8 and verifier37/37 pass, zero skips; maps/tiers pass. Normal Events and recorded native cancellation retire all16 executions; the existing generic HTTP Ambiguous boundary stays preserved. Earlier partial-fork/native-parent/called-ACK evidence retains its own source limits. T030 remains partial for legacy controls, active MI and actual Studio before pipeline integration. Direct-model broadcast/settlement, real native/ETL bindings and remaining operational/clustered acceptance stay open. Draft/full-PR rounds0; CI pending and GitGuardian owner-deferred/merge-gating. #2898/#2907/program remain open/partial; goal active.

## #2892 6492052607 elsa-workflows-codex[bot] 2026-10-29T08:42:11Z
Head `c9e963906963432c2b11abeaeedea7134aabe4f8`; executing host/checked-reader source `0595851685e3c0ce3321d1a884ad18dbd8f00215`. The coupled legacy-control stores recover six escalation cases, two same-binding sibling policies and compensation across nineteen observed workflows. Actual Events handle the second semantic token before its sibling and compensation B → restart → A → completion. Full pins, committed inbox/source correlation, native fault/cancel projections, all72 original executable payloads/incarnations, migrations and frozen authoring are [retained with source-bound proof](https://github.com/elsa-workflows/elsa-foundation/tree/c9e963906963432c2b11abeaeedea7134aabe4f8/specs/1017-direct-bpmn-hosting/evidence/upgrade/controls); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6492051091). Whole host9/9 and verifier46/46 pass, zero skips; maps/tiers pass. Final outcomes13 Completed/3 Cancelled/3 Faulted preserve3 required incidents. Prior compatibility receipts retain their own source limits. Active MI and actual Studio remain before native/ETL integration; T030, new model/RunBpmn settlement and remaining operational/clustered acceptance stay open. Draft/full-PR rounds0; CI pending and GitGuardian owner-deferred/merge-gating. #2898/#2907/program remain open/partial; goal active.

## #2892 6492384954 elsa-workflows-codex[bot] 2026-10-29T08:59:18Z
Head `7878c307f75f89551f7b8cc3dccfe7eecf238ee6`; executing host/checked-reader source `645d59aa6990df001d218af055154092c841cc41`. Four actual sequential/parallel MI cases in Balanced/Durable modes recover: saved loops advance1 → 2 → restart → 3 completed children through normal Events, preserving original iteration/token IDs, new-child pins, committed inboxes and remaining waits. All12 iterations/16 final workflows complete; all92 original executable payloads/incarnations, migrations and frozen authoring are [retained with source-bound proof](https://github.com/elsa-workflows/elsa-foundation/tree/7878c307f75f89551f7b8cc3dccfe7eecf238ee6/specs/1017-direct-bpmn-hosting/evidence/upgrade/multi-instance); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6492383536). Whole host10/10 and verifier54/54 pass, zero skips; maps/tiers pass. Prior receipts retain their own source limits. Actual Studio remains before native/ETL integration; T030, new model MI/RunBpmn settlement and remaining operational/clustered acceptance stay open. Draft/full-PR rounds0; new CI pending. Prior GitGuardian is neutral because PR size prevented scanning; that and deferred incident39189012 remain unresolved merge gates. #2898/#2907/program remain open/partial; goal active.

## #2892 6493203831 elsa-workflows-codex[bot] 2026-10-29T09:37:59Z
[Codex] On behalf of @sfmskywalker.

Head `a06b3b90bcd36577c987b62b606c93e860317b2c`; executing Workbench/Studio/reader source `801042981812d52b327fa0d008a09f12d6160a94`. T030/T032/T033 current phase complete: both actual Studio captures preserve exact initial JSON/XML/layout, publish versions3/4, and complete two Published Runs plus two Test Runs. Actual restarts preserve original/new full views, physical pins, all84/92 original executable payloads/incarnations, migrations and frozen authoring. [Twelve snapshots/screenshots, exports and portable comparisons](https://github.com/elsa-workflows/elsa-foundation/tree/a06b3b90bcd36577c987b62b606c93e860317b2c/specs/1017-direct-bpmn-hosting/evidence/studio); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6493202199). All104 original assets/22 whole-store inputs accounted for. Whole host10/10, BPMN379/379, interchange130/130, native compatibility16/16, verifiers54/54+10/10; maps/tiers pass. Local payload11 pass/1 Linux-only skip; same-source Linux serialization62/62 with zero skips. Next real ETL failure/recovery and actual RunBpmn/native/model bridge. T031/final T041, direct-model Studio, settlement/retry and remaining operational/clustered acceptance stay open. Earlier receipts retain their own source identities. Draft/full-PR rounds0; new CI pending. GitGuardian size-skip/neutral and deferred incident39189012 remain unresolved merge gates. #2898/#2907/program stay open/partial; goal active.

## #2892 6494291429 elsa-workflows-codex[bot] 2026-10-29T10:32:19Z
[Codex] On behalf of @sfmskywalker.

Head `fdda380cc14f08db5b50dd54b81e480a0e0a1fdc`; executing native ETL source `9a3b397382e0a7dde27f830a9b236851d41c28fe`. Three actual native ETL journeys recover after SIGKILL and a real HTTP429/Retry-After20: Sequence/Flowchart each deliver four records and run their successor once; the real RunEtl root delivers three, rejects one and preserves native Completed with BusinessError / ETL businessError. Nine Workbench processes, three HTTP fixtures and eighteen whole-store snapshots retain original invocation identities, full pins, result addresses, terminal outbox acknowledgements and exact views after a third process. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/fdda380cc14f08db5b50dd54b81e480a0e0a1fdc/specs/1017-direct-bpmn-hosting/evidence/pipeline/native-http-reference); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6494289708). Focused tests28/28 and evidence checks5/5 pass, zero skips; all104 frozen assets unchanged; maps/tiers pass. This is same-source native ETL recovery, not direct/RunBpmn integration, upgraded-host ETL or model-held fault retry. Next actual RunBpmn/model-native admission and typed result/cancel/retry settlement; T027/T034–T040 remain unchecked. Prior T030/T032/T033 qualification retains its source; T031/final T041/direct-model Studio/remaining acceptance stay open. Draft/full-PR rounds0; current CI pending. GitGuardian size-skip/neutral and deferred incident39189012 remain unresolved merge gates. #2898/#2907/program remain open/partial; goal active.

## #2892 6496013664 elsa-workflows-codex[bot] 2026-10-29T11:57:48Z
[Codex] On behalf of @sfmskywalker.

Head `47ca9cb707ed4ffae25760537870d20d3a5f9842` adopts current main (`c379a6e01`) and adds the first opt-in closed direct BPMN/native worker binding. Plain start/service/end retains the exact native worker dependency, model invocation/attempt and frozen return address. Native admission physically compares the live model decision in the same checkpoint as the native header/root work; native terminal acceptance retains the typed root result and owed delivery. Shared queue/outbox/resumption consumes results before acknowledgement, with no fabricated native parent. Protected queue/header families refuse older readers. Validation: BPMN379/379, persistence1765/1765, focused contract81/81 and new persistence guards37/37; zero skips. A removed physical-compare control failed as required and source was restored; maps/tiers pass; all104 original asset hashes remain unchanged. The first actual BPMN-to-HTTP-ETL process-loss journey is now running; no bridge recovery acceptance is claimed yet. [Last verified native ETL reference](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6494289708) retains source9a3b39738; prior Studio qualification retains source801042981. T027/T031/T034–T041, embedding, broader event/service shapes, cancellation/settlement, held retry, direct-model Studio and remaining program acceptance stay open. Draft/full-PR review rounds0 of6; new-head CI pending. GitGuardian scan-size limitation and deferred incident39189012 remain unresolved before merge. #2898/#2907/program remain open/partial; goal active. [Implementation checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6496012185).

## #2892 6496609772 elsa-workflows-codex[bot] 2026-10-29T12:25:10Z
[Codex] On behalf of @sfmskywalker.

Head `9559a659b63644ded96c8ad03e174adaf3c809c2`; executing Workbench/BPMN/runtime/ETL/controller source `18ac139e055b7e9af4573b720086c989884a9f48`. Two actual direct BPMN → published native RunEtl root → BPMN journeys recover after SIGKILL during a real HTTP429/Retry-After20 wait with the sibling partition already complete. Success delivers four mapped HTTP records and BPMN Completed. The rejected-record case delivers three records plus one safe JSONL error, preserves native Completed / typed BusinessError with etl.rows-rejected, and maps the unmatched modeled error to BPMN Faulted. The original native invocation, complete model/worker pins, incarnation and model invocation/attempt/frozen return input survive. The native terminal and typed result outbox commit together; a physically retained exact model receipt precedes source acknowledgment. A third host preserves terminal API/checked-provider/wire observations. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/9559a659b63644ded96c8ad03e174adaf3c809c2/specs/1017-direct-bpmn-hosting/evidence/pipeline/direct-http-recovery) retains six Workbench processes, two HTTP fixtures, twelve whole-store snapshots and36 raw assets; all eight owned children are stopped. Real recovery exposed an overly narrow native-terminal guard after Balanced outbox folding; fixed in18ac139e0, with materialized-outbox acceptance and intent-only/foreign-scope refusal regressions. Current source passes BPMN379/379, full Runtime EF1770/1770 and direct hosting2/2; portable native/direct comparisons plus eight corrupt controls pass10/10, zero skips. Maps/tiers pass; all104 original baseline asset hashes remain unchanged. This proves the first closed direct start/service/end worker cut on the built-in single-node actor/SQLite, not RunBpmn embedding, matched errors, cancellation/settlement, held terminal-fault retry, upgraded-host ETL or final affected-source/direct-model Studio. T027/T031/T034–T041 and remaining program acceptance stay open. Earlier native ETL/Studio receipts retain their own sources. Draft/full-PR rounds0 of6; exact-head CI pending, Full tier not yet requested. GitGuardian neutral scan-size limitation and deferred incident39189012 remain unresolved before merge. #2898/#2907/program remain open/partial; goal active. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6496608242).

## #2892 6497741429 elsa-workflows-codex[bot] 2026-10-29T13:17:23Z
[Codex] On behalf of @sfmskywalker.

Head `0c419ca5f5fe494c802d062eff2512a2b7ab9f38` adopts legitimate main progress e0cc6433a (#3424) after implementing the first real RunBpmn human-work boundary in80e6d5928. Native publication freezes a full model dependency pin/incarnation; native suspension captures its actual registration and durable start/cancel intents. Initial model admission atomically compares all three live native parent rows without consuming its wait. The same model driver retains parent-result responsibility until native consumption/terminal proof and exact model settlement receipt. Local candidate validation before the main refresh: root/Sequence/Flowchart/CompensationScope completion and whole-parent cancellation across process restart8/8, BPMN381/381, Runtime EF1777/1777, publication61/61 and parent-admission guards7/7, zero skips. The retained-state check exposed legitimate native private-state retirement; its immutable pin/terminal responsibility now verifies delivery after cleanup, while cancellation captures the committed predecessor before retirement. Locked project graphs updated11 files with no external package changes; maps/tiers pass; all104 frozen assets unchanged. Clean exact-source qualification at0c419ca5f is now running, including direct/embedded counterpart reads and source-bound snapshots; no new retained embedding evidence is claimed yet. Human-work profile only: service/ETL embedding is refused pending its real cancellation bridge. T027/T031/T034–T041, cancellation-before-admission/pending-result crash witnesses, held retry, final upgrade/Studio and remaining program acceptance stay open. Earlier direct ETL/Studio receipts retain their own sources. Draft/full-PR rounds0 of6; new-head CI pending. GitGuardian neutral scan-size limitation and deferred incident39189012 remain unresolved before merge. #2898/#2907/program remain open/partial; goal active; Orleans/task-runner deferred.

## #2892 6498121512 elsa-workflows-codex[bot] 2026-10-29T13:34:06Z
[Codex] On behalf of @sfmskywalker.

Head `3e919eb57cf7c7814951def0f5c35f035ab22818`; executing Workbench/runtime/BPMN/publishing source `0c419ca5f5fe494c802d062eff2512a2b7ab9f38`. Eight actual human-work RunBpmn journeys (Root, Sequence, Flowchart, CompensationScope × completion/whole-parent cancellation) survive SIGKILL at the real native/model wait, then complete or cancel the original invocation on the same stores. Four actual direct counterparts have equal released-interpreter waiting/terminal states after only the declared producingWorkHandle identity normalization. The exact model/native pins, material incarnation, original typed wait and dependency are retained. Native consumption precedes the durable model settlement receipt; only that receipt permits result-source acknowledgment. Late human completion cannot advance a cancelled model. A third host preserves exact checked terminal observations. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/3e919eb57cf7c7814951def0f5c35f035ab22818/specs/1017-direct-bpmn-hosting/evidence/embedding/human-native-recovery) retains24 owned Workbench processes,32 closed whole-store snapshots and64 raw assets; all owned children stopped. At executing0c419: actual host8/8 and complete Runtime EF1777/1777 pass. Pre-merge implementation-content tests381/381 BPMN and61/61 Publishing are separately scoped. Portable verification plus seven rehashed corrupt controls pass8/8, zero skips. All104 frozen baseline assets remain unchanged. This proves human-work embedding on the built-in single-node actor/SQLite, not ETL embedding, cancellation-before-admission, pending-parent-result crash, final affected-source upgrade/Studio or remaining operational/provider/held-retry acceptance. T027/T028/T029/T031/T034–T041 remain incomplete. Exact-source CI is red: architecture delivery-service composition, missing behavioral RunBpmn drive/contract baseline, and readability-version expectations. Next fix these integration gaps, then continue real ETL cancellation/embedding/held retry. Full-PR rounds0 of6, incomplete draft; no merge authorized by these partial receipts. GitGuardian neutral scan-size skip and owner-deferred incident39189012 remain unresolved before merge. #2898/#2907/program remain open/partial; goal active. Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6498119714).

## #2892 6498579852 elsa-workflows-codex[bot] 2026-10-29T13:54:22Z
[Codex] On behalf of @sfmskywalker.

Head `888c6c3867c1a09fc4f2788b4bb071c807d814ae`; executing source `d22a35f0e6e33305734cdfdb9e98d2dc604e71f8`. Actual native RunBpmn root cancellation before first model admission is now proved: normal public alteration processing commits parent cancellation while the original start/cancel sources remain owed; stopped physical stores contain no model execution, receipt or model command. After SIGKILL (exit137), fresh standard resumption creates a Cancelled model without starting interpreter semantics (sequence0/no tokens/work/diagnostics), retains exact original model/native pins and wait address, and commits the exact parent settlement receipt before result-source ACK. A third process is stable. [New evidence](https://github.com/elsa-workflows/elsa-foundation/tree/888c6c3867c1a09fc4f2788b4bb071c807d814ae/specs/1017-direct-bpmn-hosting/evidence/embedding/cancel-before-admission) binds3 owned Workbench processes,4 closed whole stores and9 raw assets; all children stopped. The earlier [eight-parent human-work matrix](https://github.com/elsa-workflows/elsa-foundation/tree/3e919eb57cf7c7814951def0f5c35f035ab22818/specs/1017-direct-bpmn-hosting/evidence/embedding/human-native-recovery) retains executing source0c419,32 stores and four actual direct/embedded trace comparisons; all eight host cases pass again against d22a35f0e built products. Current host9/9 and both evidence suites14/14 pass, zero skips; all104 frozen baseline assets are unchanged. f925baa8c fixes the CI-discovered optional-reader composition, RunBpmn behavioral drive/contract snapshot and readability/finalization integration. Its local content checks pass BPMN381/381, behavioral220/220, composition2/2, readability117/117, contract3/3 and tooling15/15; maps/tiers pass. EF1777/1777 remains the earlier exact0c419 receipt. No earlier evidence is relabeled as final-source qualification. Remaining: real ETL cancellation/RunBpmn service embedding and held terminal-fault retry, pending-parent-result crash, simultaneous admission race, provider/rollback/race criteria and final affected-source upgrade/Studio. T027/T028/T029/T031/T034–T041 remain incomplete. Exact-head CI is pending; historical0c419 failures are not green and Full-PR rounds remain0 of6. GitGuardian neutral size skip, owner-deferred incident39189012 and queued CLA remain unresolved before merge. Draft #3410, #2898/#2907 and program remain open/partial; active goal unchanged. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6498577929).

## #2892 6499017134 elsa-workflows-codex[bot] 2026-10-29T14:12:33Z
[Codex] On behalf of @sfmskywalker.

Head `86d18d7209a4a074917d10fd848cac285af4b6e0`; executing source `b5c612276334d1d39aec827b85d12cb1021e5c38`. Actual pipeline-originated cancellation now survives the full ETL → native RunEtl worker → direct BPMN path after process loss. A real HTTP429/Retry-After60 holds shard B after shard A delivers two mapped records; the owned Workbench is killed with SIGKILL. On fresh recovery the ordinary ETL cancel API accepts cancellation. The pipeline, original native activity/workflow and BPMN all retain Cancelled. Physical verification requires the exact Consumed ETL/native typed registration and the exact model input receipt before native result-source ACK; a cancelled header alone is insufficient. A third standard Workbench remains stable past the original saved retry deadline, with no second shard-B request. Two delivered records remain intact; outstanding records/bytes are zero. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/86d18d7209a4a074917d10fd848cac285af4b6e0/specs/1017-direct-bpmn-hosting/evidence/pipeline/direct-cancellation) retains3 Workbench processes,1 HTTP fixture,6 closed whole-store snapshots and19 raw assets; all four journey children stopped. Focused ETL checkpoint/result/cancellation/API checks72/72 and portable native/direct/cancel comparisons plus corrupt controls17/17 pass, zero skips. All104 frozen baseline assets remain unchanged. No ETL production semantics changed for this increment. Earlier human RunBpmn eight-case recovery, four direct trace comparisons and root cancellation-before-first-model-admission retain their executing0c419/d22 sources and own receipts; current-source qualification is not inferred from them. Next: reverse native/model cancellation into a running ETL worker and its admission/result cuts, RunBpmn service embedding, held fault retry, pending parent-result recovery, remaining provider/race/rollback criteria, final affected-source upgrade/Studio. T027/T029/T031/T034–T041 remain incomplete; #2898/#2907/program remain open/partial and the goal active. Draft PR3410/full-PR rounds0 of6. Exact-head CI is pending; earlier red/cancelled runs are not green. GitGuardian neutral size skip, deferred incident39189012 and CLA remain unresolved before merge. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6499015379).

## #2892 6499524119 elsa-workflows-codex[bot] 2026-10-29T14:32:52Z
[Codex] On behalf of @sfmskywalker.

Head `d0b27796ec4a9c504fc3ad83c8df5dc242afbe8b`; executing source `78b1e582793d6e76410bc357aa55c687bc3e8e1d`. The actual native-worker → ETL cancellation hop now has its own process-loss witness. A real HTTP429/Retry-After60 holds shard B after shard A delivers two mapped records; the owned host is killed with SIGKILL. On fresh recovery the normal public CancelWorkflow alteration plan targets the original native RunEtl worker. Its cancellation checkpoint owns both the exact Elsa.Etl.Cancel.v1 source and the native/model result source. Physical verification requires their same checkpoint identity and the original frozen ETL invocation/result address. The actual ETL run becomes cancelled with two accepted records and zero outstanding records/bytes; the original native activity/workflow and direct BPMN retain Cancelled. ETL acknowledges its return as ProvenParentTerminal, distinct from typed ETL consumption in the earlier pipeline-originated case. The exact model input receipt precedes native result-source ACK. A third standard Workbench remains stable after the original retry deadline with no second shard-B request. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/d0b27796ec4a9c504fc3ad83c8df5dc242afbe8b/specs/1017-direct-bpmn-hosting/evidence/pipeline/native-cancellation) binds3 Workbench processes,1 HTTP fixture,6 whole-store snapshots and19 raw assets; all four journey children stopped. Actual journey1/1 and portable comparisons/corrupt controls21/21 pass, zero skips; all104 frozen baseline assets remain unchanged. No production semantics changed; the existing native cancellation producer works for this real hop. Legitimate test-only main6ad81f7c7 was adopted first. Earlier human embedding, pre-admission and pipeline-originated cancellation receipts retain their own sources and limits. The model-to-worker cancellation producer remains the next required implementation, followed by native admission/result/cancel crash cuts, RunBpmn service embedding, held fault retry, remaining provider/race/rollback and final affected-source upgrade/Studio acceptance. T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending, historical red/cancelled runs not green. GitGuardian size-skip/neutral and deferred incident39189012 remain unresolved before merge. CLA remains queued; current org protocol treats a non-required pending CLA as nonblocking, with actual required checks audited at merge. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6499522214).

## #2892 6500192458 elsa-workflows-codex[bot] 2026-10-29T14:59:10Z
[Codex] On behalf of @sfmskywalker.

Head `35bcc66f1bd95eaeeb5647a16f5b071517214ee9`; executing source `6f6bf1786cb6fbf290caac500c4737f4721b2a96`. The public BPMN cancel command now reaches the original already-admitted native RunEtl worker and actual ETL run after HTTP429/SIGKILL/restart. Revision2 retains the exact cancellation command as TerminalPendingSettlement, its reason and durable CancelNativeWork source. The ordinary native Cancel queue command closes that original worker; its terminal checkpoint owns both the actual ETL cancel delivery and typed model result. The result retains every other terminal-checkpoint delivery, including ETL's existing intent handler. Qualified physical reads require actual downstream acknowledgment before the native-result input settles model revision3; the model cancellation source acknowledges only after that exact consumption receipt. The original revision2 command receipt remains an acceptance decision. ETL/native/model retain Cancelled, two delivered HTTP records remain and zero records/bytes are owed. A third standard Workbench stays stable beyond the saved retry deadline with no second shard-B request. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/35bcc66f1bd95eaeeb5647a16f5b071517214ee9/specs/1017-direct-bpmn-hosting/evidence/pipeline/model-cancellation) binds3 Workbench/1 HTTP processes,6 closed whole stores and20 raw assets; all journey children stopped. The first real capture exposed an omitted ETL delivery in the new inventory; 6f6bf1786 fixes it, and the verifier rejects both that unqualified capture and a fully rehashed empty-inventory control. BPMN382/382, focused ETL72/72, actual HTTP authorization/not-found/recovery1/1 and portable26/26 pass, zero skips; all104 baseline assets and the authoring fingerprint remain unchanged. The additive default-refusing public cancellation contract and package API build cleanly. This is the admitted-worker cancellation arm, not cancellation before admission: in that cut semantic progression closes and the existing atomic admission condition prevents a late child, but start/cancel responsibility remains owed until positive durable start retirement is implemented. Next deliver that retirement, admission/result/cancel crash/race cuts, then service embedding, held fault retry and final affected-source upgrade/Studio acceptance. Earlier receipts retain their sources and limits. T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR review rounds0 of6; exact-head CI pending. GitGuardian size-skip/neutral and owner-deferred incident39189012 remain unresolved before merge. CLA remains queued/non-required under current org policy; actual required checks must be audited at merge. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6500190314).

## #2892 6500836505 elsa-workflows-codex[bot] 2026-10-29T15:24:49Z
[Codex] On behalf of @sfmskywalker.

Head `a50a9a641d685a651ddbe3caba5c952ac08eb4b1`; executing source `3e14b7ef7f90c8103e812eeeb21e20aeab9de56e`. Cancellation before first native worker admission now has an actual process-loss witness. Normal authenticated APIs publish the real ETL pipeline, closed RunEtl worker and direct BPMN service model. With the normal recovery sweep set to300 seconds, model start retains the original native-start source while no native workflow/activity/bookmark or ETL run exists. Public BPMN cancellation records revision2/TerminalPendingSettlement and its exact original invocation/attempt/cancel source. SIGKILL loses the owned host at that pending cut. Fresh standard Workbench hosts using normal0.2-second recovery consume one exact native-start-retired input, retain NotAdmitted at model revision3 and acknowledge start then cancel only after that positive consumption receipt. No native carrier, invented worker result, ETL run or HTTP effect appears across a third host. Full model/native/ETL pins and the interpreter snapshot remain unchanged. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/a50a9a641d685a651ddbe3caba5c952ac08eb4b1/specs/1017-direct-bpmn-hosting/evidence/pipeline/native-start-retirement) binds3 Workbench/1 HTTP processes,9 closed coupled stores and22 raw assets; all children stopped. A saved-state test additionally sends a late start through the production dispatcher: it retires without native state/root work, replay converges, and missing physical cancellation proof leaves the queued work owed. That provider/dispatcher test does not replace the actual already-queued-start process cut. BPMN384/384 and portable33/33 pass, zero skips; six new rehashed controls reject missing receipt, early acknowledgment, invented admitted-child result, hidden physical carrier, graceful-exit substitution and acceptance mislabeled as settlement. All104 baseline assets and the frozen authoring fingerprint remain unchanged. The implementation uses irreversible model cancellation plus the existing qualified atomic admission condition; no new execution authority or fake native carrier is introduced. Earlier admitted-worker cancellation/ETL and embedding receipts retain their own sources and limits. Next qualify actual queued native start/checkpoint recovery and the simultaneous admission/cancellation race, then pending native result/cancel cuts, RunBpmn service embedding, held retry, provider/rollback and final affected-source upgrade/Studio acceptance. T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR review rounds0 of6; exact-head CI pending. GitGuardian size-skip/neutral and owner-deferred incident39189012 remain unresolved before merge. CLA is queued/non-required under current org policy; actual required checks must be audited at merge. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6500834568).

## #2892 6501664976 elsa-workflows-codex[bot] 2026-10-29T15:57:37Z
[Codex] On behalf of @sfmskywalker.

Head `49cd5f4d31a9443ff298fc93b256397c4afc7fa4`; executing source `fc03c3b96b99ae309a3763ecbae07562a237ade5`. Both actual native queue cuts now recover across cancellation/SIGKILL: the original Start item and the generated WorkflowStarted checkpoint. Authenticated Workbench APIs publish the real ETL pipeline/closed RunEtl worker/direct BPMN model. An owned production-SDK client uses the existing drain-policy seam to enqueue only or drain one item, retaining the actual live model authority, full pins and original invocation/attempt/source. Public model cancellation records revision2/TerminalPendingSettlement while the same protected-family3 native envelope remains queued. Fresh standard Workbench hosts retire it without native header/activity/bookmark, invented worker result, ETL run or HTTP effect. The original native retirement commit ID is physically retained with no pending root-work outbox; the exact model retirement receipt at revision3 then precedes start/cancel acknowledgment. A third host stays unchanged for each cut. The first real queued captures exposed a missing flush boundary: an anonymous coalesced-flush marker replaced the logical retirement receipt. The existing checkpoint catalog now names NativeModelWorkStartRetired and its existing policy flushes it immediately; no new execution authority or participant is added. Both pre-fix actual captures are rejected, along with a fully rehashed anonymous-marker control. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/49cd5f4d31a9443ff298fc93b256397c4afc7fa4/specs/1017-direct-bpmn-hosting/evidence/pipeline/queued-native-retirement) binds two journeys,6 Workbench/2 SDK/2 HTTP processes,18 whole coupled stores and46 raw assets; all ten qualified children stopped. BPMN384/384, policy23/23, portable40/40, maps and test tiers123 pass, zero skips; the tracked Core constant builds with zero errors and all104 baseline assets/authoring fingerprint remain unchanged. Earlier undelivered-start, admitted-worker cancellation/ETL and embedding receipts retain their own sources/limits. Next qualify simultaneous native admission/cancellation, then pending native result/cancel cuts, RunBpmn service embedding, held retry, provider/rollback and final affected-source upgrade/Studio acceptance. T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. GitGuardian size-skip/neutral and owner-deferred incident39189012 remain unresolved before merge. CLA remains queued/non-required under current org policy; actual required checks must be audited at merge. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6501663205).

## #2892 6502222820 elsa-workflows-codex[bot] 2026-10-29T16:21:34Z
[Codex] On behalf of @sfmskywalker.

Head `2182c310ae6a60abb7633e52e6c328fdc637d757`; executing source `54d8532b0a00c39626185a7d617790004b9f9448`. Both actual native-admission/BPMN-cancellation commit orders now survive SIGKILL and fresh standard Workbench recovery. The owned SDK queues the genuine WorkflowStarted checkpoint; a pass-through existing validation hook records and gates the first unchanged real proposal before its provider transaction. Cancellation-first commits model revision2, then the real EF SQLite writer defers the stale revision1 native proposal; cold recovery retains the original rootless retirement marker and exact NotAdmitted receipt before start/cancel ACK. Admission-first commits the real native header/root scheduling while cancellation still observes revision1, then releases unchanged cancellation; cold recovery cancels that actual worker and retains its exact native result/model consumption receipt at revision3. A third host is unchanged in each case. The existing SDK two-cycle budget stops before root invocation: no ETL run/HTTP effect in these races; earlier admitted-worker/ETL cancellation keeps its own source. No production semantic change or abstraction was needed. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/2182c310ae6a60abb7633e52e6c328fdc637d757/specs/1017-direct-bpmn-hosting/evidence/pipeline/native-admission-race) binds2 cases,6 Workbench/6 SDK/2 HTTP processes,18 whole stores/56 raw assets; all14 qualified children and rejected/superseded attempts stopped. BPMN384/384, focused EF model checkpoint43/43, portable51/51 with10 new rehashed negative controls, maps and test tiers123 pass, zero skips. All104 frozen baseline assets/authoring fingerprint remain unchanged. Next actual pending result/cancel process cuts, then RunBpmn service embedding, held retry, provider/rollback and final affected-source upgrade/Studio. T027/T029/T031/T034–T041 and #2898/#2907/program stay incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. GitGuardian size-skip/neutral and owner-deferred incident39189012 remain unresolved before merge; non-required CLA does not block under current org policy. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6502221084).

## #2892 6502457019 elsa-workflows-codex[bot] 2026-10-29T16:31:47Z
[Codex] On behalf of @sfmskywalker.

Head `5611d0dccf75a0c561f0bbb051f908167fc256f3`; executing source `b2251d591944fd89663748edac064b07cea89aa4`. Two actual admitted-ETL cancellation/result cuts now survive a second SIGKILL and fresh standard-host recovery. Both begin with the published direct BPMN/native RunEtl/HTTP429 journey, two completed sibling effects and the original frozen retry. In the model-command cut, public BPMN cancel commits revision2/TerminalPendingSettlement and its original native-cancel source while native/ETL remain active; the second host is killed before worker delivery. In the native-terminal cut, public native CancelWorkflow has committed actual native Cancelled plus the same-checkpoint ETL-cancel/BPMN-result sources, both owed; the model is still Running at revision1 without native-result consumption. After the second process loss, the third standard host settles the original worker/ETL/model and exact receipts before acknowledgment; a fourth host stays unchanged through the original HTTP retry deadline plus2 seconds. The two earlier HTTP effects remain; no late retry/owed output occurs. The actual ETL result uses ProvenParentTerminal for the already-cancelled native parent, not fabricated typed consumption. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/5611d0dccf75a0c561f0bbb051f908167fc256f3/specs/1017-direct-bpmn-hosting/evidence/pipeline/pending-cancellation) binds2 cases,8 Workbench/2 HTTP processes,4 actual SIGKILL exits,18 whole stores/51 raw assets; all10 children stopped. Source-matched standard host build has zero errors; portable61/61 with9 new rehashed negative controls pass, zero skips; all104 frozen baseline assets/authoring fingerprint remain unchanged. No production semantic change or new abstraction was needed. Earlier BPMN384/EF model43/race receipts retain executing source54d8532b0; these counts are not relabelled as new-source test runs. Next actual post-consumption/pre-ACK process loss, then RunBpmn service embedding, held retry, provider/rollback and final affected-source upgrade/Studio. T027/T029/T031/T034–T041 and #2898/#2907/program stay incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block under org policy. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6502455236).

## #2892 6503047859 elsa-workflows-codex[bot] 2026-10-29T16:57:11Z
[Codex] On behalf of @sfmskywalker.

Head `efb0ac3c09aca350d09bef05a76a58ee8162d67c`; executing source `d1bd08c33f436764eaca5a5c69017f14a3ea85d5`. Both actual admitted-ETL cancellation origins now survive model consumption followed by source-ACK loss. The standard first host runs published direct BPMN/native RunEtl to a real HTTP429 wait with two completed sibling effects, then loses its process. After public model/native cancellation, an owned production-SDK client uses the original bindings/stores, actual outbox processors and protocol-aware recovery mailboxes: it delivers the original ETL cancellation, queues the original native result without ACK, and commits its exact model input receipt. The consumed-phase whole stores prove ETL/native already Cancelled and model TerminalSettled at revision3/2, while the original fenced native-result source remains FailedRetryable/unacknowledged; model-originated cancellation also retains its original cancel ACK as owed. The second standard host then loses its process through SIGKILL. Fresh third/fourth standard hosts acknowledge those exact sources without a new model revision or input receipt, clear the ordinary native recovery wake, and stay unchanged past the saved HTTP retry deadline plus2 seconds. Two earlier HTTP effects remain, zero late retries; actual ETL terminal delivery uses ProvenParentTerminal. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/efb0ac3c09aca350d09bef05a76a58ee8162d67c/specs/1017-direct-bpmn-hosting/evidence/pipeline/consumed-before-ack) binds2 cases,8 Workbench/2 SDK/2 HTTP processes,4 actual SIGKILL exits,24 whole stores/65 raw assets; all12 qualified and all rejected/superseded children stopped. Source-matched standard host build0 errors, portable71/71 with9 new rehashed controls, maps/test tiers123 and all104 frozen baseline assets/authoring fingerprint pass. First SDK native-coalescing misuse was correctly refused; the fixed client uses normal protocol-aware mailboxes. A read-only completed-work observer was also fixed. No production semantic change or new architecture was needed. Earlier BPMN384/EF model43 receipts retain source54d8532b0. Next RunBpmn service embedding/native-parent mappings, then held retry, provider/rollback and final affected-source upgrade/Studio. T027/T029/T031/T034–T041 and #2898/#2907/program stay incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6503045272).

## #2892 6503985256 elsa-workflows-codex[bot] 2026-10-29T17:39:50Z
[Codex] On behalf of @sfmskywalker.

Head `14a6fb5a3041517cd8662373dfe4aee544c17ad1`; executing source `b6e7e1f0de7367f81d35aebc5016d4b91e2d7927`. Real native RunBpmn → native RunEtl → HTTP journeys now complete and whole-parent cancel under Root, Sequence, Flowchart and CompensationScope after HTTP429/SIGKILL/restart. The existing pin/dependency and delivery boundaries admit the native-service profile; explicit runtime model formats5/6 retain service parent/cancellation responsibility and refuse parent settlement while worker cancellation is owed. Actual success consumes typed RunEtl and RunBpmn results, then commits exact native-parent settlement before source ACK; cancellation waits for actual downstream ETL cancellation and exact native result before parent settlement. Four HTTP records remain per success; cancellation retains two prior effects and no late retry past the original deadline on another host. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/14a6fb5a3041517cd8662373dfe4aee544c17ad1/specs/1017-direct-bpmn-hosting/evidence/pipeline/embedded-native-recovery) binds8 embedded cases plus1 actual same-source direct success counterpart:54 whole stores/190 raw assets,27 Workbench/9 HTTP children, all36 stopped. Actual waiting/final interpreter states match direct success for all4 parents, normalizing only the self-referential work handle; process/binding contracts and12 captured first-party product hashes match. Each publication retains its own exact checked pins. Source-matched host build0 errors, BPMN391/391, all8 actual human embedding host regressions, portable84/84 with12 new rehashed controls, maps/test tiers123 and104 unchanged frozen baseline assets pass. Two rejected Sequence attempts exposed an expected asynchronous-admission HTTP404 observer issue; the controller was fixed and original failed stores retained. Pending parent-result/source-ACK crash recovery, business/technical-fault mappings, held retry, races, other providers/rollback and final affected-source upgrade/Studio remain open. T025/T027/T029/T031/T034–T041 and #2898/#2907/program stay incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6503983531).

## #2892 6504214268 elsa-workflows-codex[bot] 2026-10-29T17:50:10Z
[Codex] On behalf of @sfmskywalker.

Head `aef0d539b80f1147761f18b773be5678f2dd1d82`; executing source `ef833d12dc288202bf6e538884837b6e2526dc7e`. Cancelled native RunBpmn parents now recover their original model return across a second actual SIGKILL under Root, Sequence, Flowchart and CompensationScope. After the real HTTP429/first SIGKILL and public outer-parent CancelWorkflow, an owned source-matched production-SDK client uses the original outbox processors and recovery mailboxes to consume embedded cancellation, actual worker/ETL cancellation and its exact native result. Complete parent-pending stores retain ETL/native/outer parent Cancelled, model revision3/TerminalPendingSettlement with downstream cancellation settled, original ResumeNativeParent source Pending, no parent-settlement receipt, and native-result/embedded-cancel/worker-cancel source ACKs still FailedRetryable/fenced/owed. No state/result/receipt/ACK is fabricated. Second SIGKILL then fresh third/fourth standard hosts settle revision4 and ACK original sources without changing interpreter payload or previous receipts;2 earlier HTTP effects remain/0 late retries past the original deadline plus2 seconds. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/aef0d539b80f1147761f18b773be5678f2dd1d82/specs/1017-direct-bpmn-hosting/evidence/pipeline/pending-native-parent-return) binds4 cases/36 whole coupled stores/120 raw assets,16 Workbench/4 SDK/4 HTTP children, all24 stopped. Source-matched host/SDK builds0 errors and portable94/94 with9 new rehashed controls pass;104 frozen baseline assets/authoring fingerprint unchanged. No production semantic change was needed. Earlier service success/cancel and same-source direct comparison retain sourceb6e7e1f0d:8 embedded+1 direct/54 stores/190 assets/all36 children stopped, BPMN391/human-host8/maps/tiers123 passed there, not rerun for capture-tool changes. Next successful parent-result consumption/pre-ACK crash, business/technical-fault mappings, held retry, races, other providers/rollback and final affected-source upgrade/Studio. T025/T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6504212828).

## #2892 6505025900 elsa-workflows-codex[bot] 2026-10-29T18:27:51Z
[Codex] On behalf of @sfmskywalker.

Head `6cd8483e6888d95864ee270c62c9f0bf43cced0e`; executing source `cdef9b87e136ac082fbf1ef332ca3abb115a0018`. Successful native RunBpmn→RunEtl→HTTP return now survives second actual SIGKILL at all3 boundaries under Root/Sequence/Flowchart/CompensationScope: pending original parent wait at model r2/PendingSettlement; typed RunBpmn consumption with exact settlement queued at r2; and accepted model settlement r3/TerminalSettled with original parent source ACK still fenced/owed. Original native-result ACK also remains owed, with its unchanged accepted r2 receipt. Native workflow headers are still Running at all12 cuts: child consumption/model settlement are distinct from native workflow completion. Fresh third/fourth standard hosts finish original native continuations/successors, settle/ACK exact original sources, clear queues and retain4 physical HTTP records with0 additional effects or model/previous-receipt changes. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/6cd8483e6888d95864ee270c62c9f0bf43cced0e/specs/1017-direct-bpmn-hosting/evidence/pipeline/successful-native-parent-return) binds12 cases/108 whole coupled stores/348 raw assets,48 Workbench/12 SDK/12 HTTP children, all72 stopped;37 rejected/superseded children also stopped. The SDK composes existing native activity/CLR/parent modules and serialization/type registry;14 source-matched product identities, no background worker or synthetic state/result/receipt/ACK. No production semantic change was needed. Source-matched standard host/SDK build0 errors, portable106/106 with11 new rehashed controls, maps/test tiers123 and104 unchanged frozen baseline assets pass. Earlier service/cancellation/direct comparisons and BPMN391/human-host8 receipts retain their original sources. Compatibility gap found while refreshing remote CI: prior pushed aef0d539b failed LegacyBroadcastUpgradeTests.Actual_saved_broadcast_cuts_recover_their_exact_recipients_and_retire_normally twice in integration-other, propagating Full tier failure, waiting on saved recipient14iZz9Wu7V8. A focused local run reproduces it on unchanged production source; it is not a retry/quarantine pass or resolved by this new matrix. Next diagnose/fix that saved legacy-broadcast recovery, then business/technical-fault mappings, held retry, races, other providers/rollback and final affected-source upgrade/Studio. T025/T027/T029/T031/T034–T041, #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; new exact-head CI pending and previous compatibility CI red. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block or authorize signing. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6505024228).

## #2892 6505469304 elsa-workflows-codex[bot] 2026-10-29T18:47:39Z
[Codex] On behalf of @sfmskywalker.

Head `208bcab970e9864ddff987332f5657f066cd1f44`; executing source `4716b51ec75284efa2b85fdf3b36a5125571335b`. Fixed and requalified the saved legacy-broadcast upgrade failure that failed twice in aef0d539b integration-other CI and reproduced locally. Actual failed API/whole-store evidence showed both original native waits still Suspended with blocking EfSchemaWriteRefusedException: revision-only exact-resume owner-header touches retained storage1 while the admitted host writer required2. Exact bookmark resume and model-parent wait metadata touches now use the existing family version selector, preserving the write guard, version floor, native ContentJson, live-owner/CAS checks and conditional atomicity. No schema hold/finalization override, timeout extension, retry/quarantine pass or new protocol. Held-v1/current-v2 provider controls prove unchanged native JSON and exact revision advance; the active-v2 control failed before the fix. Focused EF resume/model/schema106/106, all8 actual RunBpmn human-model host regressions and all4 original saved-broadcast cuts pass, zero skips. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/208bcab970e9864ddff987332f5657f066cd1f44/specs/1017-direct-bpmn-hosting/evidence/upgrade/broadcast-header-schema) retains the original failed counterexample plus12 fresh standard Workbench processes/8 whole upgraded stores; all12 stopped. Actual delivery-time recipient/source snapshots, empty/rearm decisions, keyed starts, immutable pins/artifacts and migration history remain correct through recovery/retirement and another process. Both actual published BPMN descriptors match the frozen authoring fingerprint; all104 baseline assets/manifest unchanged. The earlier12 successful parent return cuts/108 stores/348 assets/portable106 and service/cancellation/direct comparisons retain their executing sources, especially cdef9b87e, rather than being relabelled as final-source qualification. Next business/technical-fault mappings, pinned held retry, remaining timer/broadcast/race arms, provider/retention/rollback and final affected-source upgrade/Studio. T025/T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR rounds0 of6. New exact-head remote CI pending; old CI failure is not called green from local results. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block and is not signed. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6505467589).

## #2892 6506145179 elsa-workflows-codex[bot] 2026-10-29T19:18:45Z
[Codex] On behalf of @sfmskywalker.

Head `552ef47398194f6b7b6c8c0759bbf4c06102203a`; executing source `d55964a76139349eeff722501df473401cce204d`. Delivered coded service-error boundaries through released BPMN0.5.0 semantics, with exact terminal-worker proof required before any cancellation command can be retired. No binding DTO/state format/native authoring descriptor or persisted writer changed for this increment.

Ten actual HTTP429/SIGKILL/restart journeys qualify matching/nonmatching codes directly and under native RunBpmn Root/Sequence/Flowchart/CompensationScope, plus another standard process retaining identical state and effects. ETL always retains3 accepted/1 rejected, safe-error output and typed native BusinessError. Matching code takes the modeled error path and completes; a different code retains BPMN Faulted/errorCode etl.rows-rejected. Native dispositions remain distinct: Root/Sequence fault with a blocking child incident; Flowchart also faults its composite and retains both incidents; default CompensationScope absorbs the fault and completes Compensated with Resolved/AbsorbFault. No unmatched forward successor runs. Sequence composite Running is observed, not ratified; #3242 remains undecided.

[Portable evidence](https://github.com/elsa-workflows/elsa-foundation/tree/552ef47398194f6b7b6c8c0759bbf4c06102203a/specs/1017-direct-bpmn-hosting/evidence/pipeline/business-error-native-recovery):60 whole stores/204 qualifying raw assets, complete pins, original invocation/attempt/registration and exact worker consumption/native parent settlement/source-ACK proofs. Waiting/final interpreter states and12 captured first-party product versions/hashes compare across direct/all parents; only the model self work handle is normalized. Thirty standard Workbench processes/ten HTTP fixtures/all40 listed children stopped. Three rejected controller expectations retain46 additional assets/18 integrity-checked stores at their original sources; all41 rejected/superseded listed children stopped. Those corrected observer assumptions did not change native fault/compensation policy or extend timeouts.

Next real technical final-fault mapping and pinned bounded held retry, then remaining timer/model-broadcast/race/provider/retention/rollback and final affected-source upgrade/Studio. T039/T040 and other open acceptance, #2898/#2907/program remain incomplete/open/Partial; goal active. Draft/full-PR rounds0 of6. New exact-head CI pending; no skipped/neutral check is called green. Owner-deferred GitGuardian39189012 remains unresolved before merge; non-required CLA is not signed. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6506143350).

## #2892 6506797844 elsa-workflows-codex[bot] 2026-10-29T19:51:04Z
[Codex] On behalf of @sfmskywalker.

Head `edeaca12e2cede1a68628a957deb3996fdff145b`; executing source `5533b8367c7fe78850677fcebf5c7fcb0f2e7e27`. Five actual default technical-fault journeys now recover through direct BPMN and native RunBpmn Root/Sequence/Flowchart/CompensationScope. After a real HTTP429/SIGKILL cut with two physical output effects, only the owned retained CSV lookup snapshot is temporarily renamed. The immutable source stays available; unchanged snapshot bytes are restored only after all hosts stop. No SQL row, clock, ETL classifier or production runtime writer was changed.

ETL and its original native RunEtl worker retain Faulted / etl.snapshot-read-failed. BPMN feeds an uncoded technical fault to released0.5.0 semantics; the etl.rows-rejected boundary does not catch it. Exact worker result, model consumption, native parent settlement and source ACK survive. Root/Sequence workflows fault, Flowchart also faults its composite, and default CompensationScope preserves Completed/Compensated with Resolved/AbsorbFault. No forward successor runs; #3242 remains undecided. A third standard host keeps state/effects unchanged past the original HTTP retry deadline plus two seconds.

[Portable evidence](https://github.com/elsa-workflows/elsa-foundation/tree/edeaca12e2cede1a68628a957deb3996fdff145b/specs/1017-direct-bpmn-hosting/evidence/pipeline/technical-fault-native-recovery): five cases/30 whole stores/117 qualifying raw assets, complete pins and original invocation/attempt/registration. Waiting/final interpreter states compare across direct/all parents, normalizing only the self work handle;12 captured first-party product versions/hashes match. Fifteen Workbench processes/five HTTP fixtures/all20 listed children stopped. Two diagnostic counterexamples retain28 assets/12 integrity-checked stores at original sources; all30 rejected listed children stopped. They preserve the observed HTTP400 BusinessError classification and completed-versus-waiting shard distinction, rather than changing either to force a technical fault. Physical lookup binding/preparation/key/hash and original CSV bytes are verified. The original format2 model material/content hash is retained before policy changes.

Next implement the approved pinned bounded HoldForRetry path before feeding semantic fault: retain active token/state and original failed-run evidence, inspect the exact current incident, and authorize one new physical attempt through the shared checkpoint/outbox. Model-held retry and a model retry command's final-state refusal remain unproved. Remaining timer/model-broadcast/race/provider/retention/rollback/final affected-source upgrade/Studio acceptance remains open. T036/T037/T039/T040 and #2898/#2907/program remain incomplete/open/Partial; goal active. Draft/full-PR rounds0 of6. Owner-deferred GitGuardian39189012 remains unresolved before merge; non-required CLA is not signed. Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6506796470).

## #2892 6507619810 elsa-workflows-codex[bot] 2026-10-29T20:30:25Z
[Codex] On behalf of @sfmskywalker.

Head `bd8a7d0fc78e26d243058de77d810d4df5062624`. [Actual held-service retry](https://github.com/elsa-workflows/elsa-foundation/tree/bd8a7d0fc78e26d243058de77d810d4df5062624/specs/1017-direct-bpmn-hosting/evidence/pipeline/held-service-retry), executing source `25bec5ade15d98fa4be0259acdb522e2bd07ff95`, now works directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. The pinned HoldForRetry/two-total-attempt policy captures real native/ETL Faulted / etl.snapshot-read-failed before feeding a terminal semantic fault. Revision2/WaitingIncident retains the exact active interpreter token/state, original failed worker/result and native parent registration. After a second real SIGKILL, externally repairing the unchanged lookup bytes does not revive that attempt. One authorized retry at revision3 admits one different physical worker and ETL run for the same semantic invocation. Identical retry content replays; conflicting content returns409.

The replacement accepts four records and completes the model and original native parent. Failed ETL/native truth, native fault incident, pre-failure state and exact original consumption remain immutable. Both worker result sources and native parent settlement/ACK are proved; actual parent successors run once. A fourth standard host retains identical API/checked views and wire effects. Five journeys/45 whole stores/166 qualifying raw assets;20 Workbench/five HTTP processes/all25 listed children stopped. All12 captured first-party product versions/hashes match, with direct/parent interpreter traces equal after only the self work-handle normalization. Six physical HTTP records include a repeat of the original two successful effects: at-least-once delivery remains explicit.

Versioned format3 policy and state7–10 refuse older drivers; old formats1/2 retain their wire. The actual pre-policy format2 material still produces its original content hash; all104 frozen baseline assets and manifest remain unchanged. Local validation at d2e62a1ab: BPMN411/411, human-host9/9, portable149/149 including21 new positive/corrupt-copy controls; maps/123 tiers pass, zero skips. Source-matched standard-host build0 errors. New exact-head CI is pending. No final affected-source upgraded-host, retention/rollback or Studio acceptance is inferred.

Next prove budget exhaustion and cancellation while held, then obsolete-result and authorization-before-replay controls and remaining timer/model-broadcast/race/provider/retention/rollback/final upgrade/Studio gates. T036/T037 and #2898/#2907/program remain incomplete/open/Partial; goal active. Existing claim6461197535/PR3410 retained. Full-PR review rounds0 of6; incomplete draft. Owner-deferred GitGuardian39189012 and the size-skipped security scan remain unresolved before merge; non-required CLA is not signed. #3242 remains undecided; Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6507618221).

## #2892 6507819239 elsa-workflows-codex[bot] 2026-10-29T20:40:34Z
[Codex] On behalf of @sfmskywalker.

Head `b97d357be248668308f6d689cac646ae12308599`. [Actual cancellation while held](https://github.com/elsa-workflows/elsa-foundation/tree/b97d357be248668308f6d689cac646ae12308599/specs/1017-direct-bpmn-hosting/evidence/pipeline/held-service-cancellation), executing source `a4098bd1a23a1e975c82ebefb7334ba7c9a2bfd4`, now works directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. After real HTTP429/process loss and authentic etl.snapshot-read-failed, revision2/WaitingIncident preserves the exact active semantic token and original Faulted ETL/native worker. A second SIGKILL retains that held failure. Restoring unchanged lookup bytes does not revive it. The public cancel command retires model work/incident at revision3 without changing the original failed invocation, fault incident, result receipt, pre-failure interpreter snapshot or two prior HTTP effects.

No new physical worker, ETL run or HTTP effect appears. No cancellation is sent to the already-faulted worker. Every original native RunBpmn registration consumes cancellation; parent workflows become Cancelled and forward successors do not run. Exact parent settlement reaches model revision4. The parent's normal CancelEmbedded source acknowledges existing terminal model responsibility without another model input. The parent-return source is acknowledged after its exact settlement receipt. Retrying the actual retired incident returns409 and retains Rejected/execution-terminal at unchanged terminal revision. A fourth standard host preserves identical checked/API views, retired incident and wire effects.

Five actual journeys/45 whole stores/166 raw assets,20 Workbench/five HTTP processes, ten actual SIGKILL exits; all25 listed children stopped. Full immutable model/worker/parent pins, protected headers, typed consumption, source ACK, old ETL invocation/lookup preparation and native fault incident are checked in physical stores. Direct/all-parent interpreter histories compare after only the self work-handle normalization; all12 captured first-party product versions/hashes match. No SQL state, clock, ETL classifier or production .NET writer changed. Source-matched standard host build0 errors, portable161/161 including12 new positive/corrupt-copy controls, maps/123 tiers and104 unchanged frozen baseline assets/manifest pass; zero skips. Earlier BPMN411/human-host9 retain source d2e62a1ab; they are not relabeled as this controller-only increment.

The previous one authorized held retry and explicit final-fault refusal remain retained at their original sources. This closes the held-cancellation arm only. Next budget exhaustion, then obsolete-result and authorization-before-replay controls, remaining timer/competing-input/model-broadcast/provider/retention/rollback/final affected-source upgrade/Studio evidence. T036/T037 and #2898/#2907/program remain incomplete/open/Partial; goal active. Existing claim6461197535/PR3410 retained. Full-PR review rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and size-skipped security scan remain unresolved before merge; non-required CLA is not signed. #3242 undecided; Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6507817664).

## #2892 6508121643 elsa-workflows-codex[bot] 2026-10-29T20:55:45Z
[Codex] On behalf of @sfmskywalker.

Head `5a6b5c476288fa3a018b78fb4c33a0859528c30d`. [Actual service budget exhaustion](https://github.com/elsa-workflows/elsa-foundation/tree/5a6b5c476288fa3a018b78fb4c33a0859528c30d/specs/1017-direct-bpmn-hosting/evidence/pipeline/service-budget-exhaustion), executing source `f781ae7750d1d21d55793e11a4a781fecf0c90a0`, now works directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. The pinned policy allows two total physical attempts. Real HTTP429/process loss and etl.snapshot-read-failed leave attempt1 held at revision2/WaitingIncident with its exact active semantic snapshot. A second SIGKILL retains that state. After restoring the unchanged snapshot, one authorized retry admits one different worker/run for the same semantic invocation. Its temporarily unavailable original bound lookup source produces a genuine preparation fault, etl.binding-read-failed, before runnable partitions or new HTTP effects exist.

Attempt1 remains Retried and attempt2 becomes Final. Both failed native/ETL invocations, complete pins, native incidents, original result receipts and source ACK remain immutable. The final uncoded fault reaches BPMN at revision4, or revision5 after exact native parent settlement. Further retry of the actual final incident returns409 and retains Rejected/execution-terminal at unchanged revision; no third worker/run appears. Restoring the unchanged bound input after the failed host stops and starting a fourth standard host does not revive either attempt. The original two HTTP effects remain/zero additional effects.

Native Root/Sequence/Flowchart workflows retain Faulted; Sequence's composite remains Running, Flowchart faults both activities. Default CompensationScope preserves Completed/Compensated with Resolved/AbsorbFault. No forward successor runs. Exact typed RunBpmn consumption, parent settlement and parent-return ACK persist. These preserve observed projections; #3242 remains undecided.

Five actual journeys/45 whole stores/176 raw assets,20 Workbench/five HTTP processes, ten actual SIGKILL exits; all25 listed children stopped. Full material/policy/native dependency closure, both physical fault roots, original ETL preparation and actual replacement preparation failure, complete native incident inventory and all consumed/ACKed sources are checked. Waiting/held/final interpreter histories compare directly/all parents after only self work-handle normalization; all12 first-party product versions/hashes match. Source-matched standard host build0 errors, portable176/176 including15 new positive/corrupt-copy controls, maps/123 tiers and104 unchanged frozen assets/manifest pass; zero skips. No production .NET writer, SQL state, clock, classifier or input bytes changed. Earlier BPMN411/human-host9 retain source d2e62a1ab; not relabeled here.

Previous successful held retry, held cancellation and explicit final refusal remain retained at their sources. Next obsolete-result and authorization-before-replay controls, then remaining timer/competing-input/model-broadcast/provider/retention/rollback/final affected-source upgrade/Studio evidence. T036/T037 and #2898/#2907/program remain incomplete/open/Partial; goal active. Existing claim6461197535/PR3410 retained. Full-PR review rounds0 of6; incomplete draft/new exact-head CI pending. Deferred GitGuardian39189012 and size-skipped security scan remain unresolved before merge; non-required CLA is not signed. Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6508120030).

## #2892 6508993668 elsa-workflows-codex[bot] 2026-10-29T21:42:02Z
[Codex] On behalf of @sfmskywalker.

Head `1ea988decda8154cb1b2a7bcbdffc2a8c37d3236`. [Actual retry authorization/recovery](https://github.com/elsa-workflows/elsa-foundation/tree/1ea988decda8154cb1b2a7bcbdffc2a8c37d3236/specs/1017-direct-bpmn-hosting/evidence/pipeline/retry-authorization), executing source `1a10565935b568e42c8431158bfafe77b571c775`, now passes directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. Each real held ETL/native fault survives two SIGKILLs; one authorized retry admits exactly one new physical worker/run, completes the same semantic invocation, retains its original failed attempt and exact source receipts/ACK, and remains stable in a fourth standard host. External HTTP effects remain at least once: six records include the previous two again.

Four normal password-backed Identity accounts per case use stored roles, exact bounded read/retry permissions and default/foreign tenant scopes. Across355 real HTTP probes and60 actual sign-ins, anonymous requests return401; read-only users inspect without retrying; retry-only users replay the exact accepted receipt without reading; no-permission/foreign users receive concealed denials without retained outcomes. Existing/unknown command denials match. The same boundaries hold before retry, after acceptance and after the fourth host. Accounts use the ordinary Identity user/role services, normal HTTP login and production authorization; no fake authentication handler or execution-state seeding.

Next obsolete-result refusal while the replacement attempt is live, then remaining timer/competing-input/model-broadcast/provider/retention/rollback and final affected-source upgrade/Studio evidence. Earlier successful retry/cancellation/budget/final-fault receipts keep their executing sources. Native composite fault decision#3242 remains undecided. T036/T037 and #2898/#2907/program remain open/Partial; existing claim6461197535/PR3410 retained. Full-PR rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and neutral size-skipped scan remain unresolved before merge; non-required CLA remains unsigned. Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6508992400).

## #2892 6509215988 elsa-workflows-codex[bot] 2026-10-29T21:54:47Z
[Codex] On behalf of @sfmskywalker.

Head `2aa0d612ed51b316c3db97c24f76a498a8357f8e`. [Actual obsolete-result controls](https://github.com/elsa-workflows/elsa-foundation/tree/2aa0d612ed51b316c3db97c24f76a498a8357f8e/specs/1017-direct-bpmn-hosting/evidence/pipeline/obsolete-service-results), executing source `9380009b86f3ceb383b7b58b6317b2a90f94b17d`, now pass directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. Each journey retains a real held ETL/native fault across two SIGKILLs, then one authorized retry admits a different physical worker/run for the same semantic invocation. The owned HTTP fixture gives that replacement its own real429/Retry-After20 wait after two output effects, so the probes execute while it is still active.

The normal production model mailbox accepts an exact replay of the original failed result without replacing its revision2 receipt or advancing the revision3 replacement. Conflicting old content and an unchanged old result sent to a new input address both refuse before durable admission. Across15 actual transports, the active model/work/attempt, original fault/receipt/source ACK and empty model queue remain unchanged. Complete coupled stores prove the old ETL run remains Faulted beside the live replacement. Standard hosts subsequently finish exactly that replacement and original native RunBpmn parent, retain exact typed consumption/settlement/ACK, and stay stable through a fourth host. Six physical HTTP records include the prior two again; effects remain at least once.

Next real timer interruption and competing retry/cancel commit orders, then remaining model-broadcast/provider/retention/rollback/final affected-source upgrade/Studio evidence. #3242 remains undecided. T036/T037 and #2898/#2907/program remain open/Partial; existing claim6461197535/PR3410 retained. Full-PR rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and neutral size-skipped scan remain unresolved before merge; non-required CLA remains unsigned. Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6509214672).

## #2892 6510130443 elsa-workflows-codex[bot] 2026-10-29T22:39:19Z
[Codex] On behalf of @sfmskywalker.

Head `99b7eca5b4d6bf25ac4550e543fb6132d23b49bb`. [Actual runtime-only human/duration recovery](https://github.com/elsa-workflows/elsa-foundation/tree/99b7eca5b4d6bf25ac4550e543fb6132d23b49bb/specs/1017-direct-bpmn-hosting/evidence/races/human-duration), executing source `a2c2e47751d595c9489f889593ed4d7427ef6076`, now proves both human-first and timer-first orders through production authenticated Workbench hosts. The original human wait and real30-second boundary timer survive SIGKILL/restart with their exact invocation, attempt, pin, deadline and committed source. The first winner reaches revision2 and survives another process loss. The third host rejects the original late timer/human input as execution-terminal at unchanged revision2; timer source ACK follows its exact receipt. A fourth host retains identical checked model/input/source/queue and API views. Two journeys/eight whole Runtime stores/28 raw assets/eight stopped Workbench children, all exit137. No native workflow/activity/bookmark carrier or Design storage exists.

Definition4 adds explicit timer bindings; state11/12 retains their exact deadline/source. Foundation uses the existing delayed outbox, with deadline equal to accepting checkpoint UTC plus duration and independent model eligibility validation. Human completion cannot fire a timer. The released0.5.0 library owns token/interruption semantics. Existing definition1-3 wire and older private frames remain supported;104 frozen baseline assets and the original manifest are unchanged. Direct date/cycle timers remain outside the profile. Real worker/timer and held-failure interruption are not inferred from these human journeys.

Source-matched BPMN431/431, actual duration-host2/2, existing human-host9/9 and native-service host1/1 pass. Portable tools27/27 include13 new positive/corrupt-copy controls; existing ETL208/208, maps and123 tiers pass, zero skips. Standard host build0 errors. Removing only the deadline guard makes the actual-source eligibility regression fail; exact restoration precedes the qualifying build. Initial native-only DI and timed-human admission findings were fixed before these actual captures. Binaries, observer, source identity, both winner diagnostics and physical receipts/deadlines/ACK/native-row absence are checked.

Next real worker/timer orders and held-failure interruption, then competing retry/cancel commits and remaining direct-model broadcast/provider/retention/rollback/final affected-source upgrade/Studio evidence. #3242 remains undecided. T020/T023/T024 and broader tasks, #2898/#2907/program remain open/Partial; claim6461197535/PR3410 retained. Full-PR rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and neutral size-skipped scan remain unresolved before merge; non-required CLA remains unsigned. Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6510128407).

## #2892 6510722806 elsa-workflows-codex[bot] 2026-10-29T23:13:24Z
[Codex] On behalf of @sfmskywalker.

Head `fd11a9831faa2613ca5742bf9f2306f107edd4f5`. [Actual ETL worker/duration recovery matrix](https://github.com/elsa-workflows/elsa-foundation/tree/fd11a9831faa2613ca5742bf9f2306f107edd4f5/specs/1017-direct-bpmn-hosting/evidence/races/service-duration), executing source `8dc088bae4463b8a9279a1f25036ac14b1715cd6`, now proves worker-first, timer-first and interruption of a held failure directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. Fifteen actual production Workbench journeys retain488 raw assets and135 coupled whole stores. All75 listed children are stopped (60 Workbench/15 HTTP fixtures);30 predecessor exits are actual SIGKILL. No execution state or clock was edited.

Each original ETL/native worker first receives actual HTTP429 after its sibling delivers two records. Worker-first Retry-After20 completes four records before the60-second boundary and later rejects the original timer without advancing. Timer-first uses10/60 seconds: the real boundary cancels the original native worker and ETL run, preserves their actual Cancelled result and settles the original cancellation; no delayed HTTP retry occurs. Held interruption uses90/20 seconds: the unchanged lookup snapshot is temporarily unavailable, producing genuine etl.snapshot-read-failed and held revision2. That semantic snapshot survives another SIGKILL and repair of the identical external file. The timer retires the exact incident and completes its boundary route while preserving the original native/ETL fault; a later retry is409 with no new attempt. Every native parent consumes its original typed Done result, runs its successor once where present and settles the model before source ACK. A fourth host retains identical model/worker/ETL/incident/API/receipt/source/queue and HTTP views.

Portable ETL224/224 including16 new positive/corrupt-copy controls, BPMN tools27/27, standard source-matched host build0 errors, maps/123 tiers and104 unchanged frozen baseline assets/original manifest pass, zero skips. Production duration code did not change; prior BPMN431 and actual human/timer2, human-host9/native-service1 results retain sourcea2c2e4775. These ordered worker/timer decisions do not establish simultaneous competing commits.

Next actual simultaneous retry/cancel commit orders, then remaining direct-model broadcast/provider/retention/rollback/final affected-source upgrade/Studio evidence. #3242 remains undecided. T020/T023/T024 and broader tasks, #2898/#2907/program remain open/Partial; claim6461197535/PR3410 retained. Full-PR rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and neutral size-skipped scan remain unresolved before merge; non-required CLA remains unsigned. Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6510721704).

## #2892 6510969119 elsa-workflows-codex[bot] 2026-10-29T23:29:42Z
[Codex] On behalf of @sfmskywalker.

Head `ddc1d02c62629ea88cc6ede78b1edf1baaafd36f`. [Actual concurrent held retry/cancel recovery](https://github.com/elsa-workflows/elsa-foundation/tree/ddc1d02c62629ea88cc6ede78b1edf1baaafd36f/specs/1017-direct-bpmn-hosting/evidence/races/held-command-race), executing source `7414d8a13ee6cd2f65923914065b075602437ca2`, now proves retry-first and cancel-first directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. Ten production journeys retain412 raw assets and120 coupled whole stores. All70 listed children stopped (40 Workbench/20 SDK/10 HTTP fixtures);20 predecessor exits are actual SIGKILL. This increment changes capture/verification only; no production semantics or execution state/clock edits.

Each original ETL/native worker receives real HTTP429 after its sibling delivers two records, loses its host, then genuinely faults on the temporarily unavailable unchanged lookup snapshot. Exact held interpreter/failure state at revision2 survives a second SIGKILL. After identical external-file repair, one production-SDK process pauses its unchanged real proposal at the existing commit hook. A separate SDK process queues the competitor and acquires successor ownership. The protected FIFO head prevents a second proposal; the first writer cannot commit with its stale fence. Both original inputs remain pending in their exact queue order with unchanged held state. Physical stores retain the greater successor fence and both real queue payloads before cold recovery.

Fresh standard hosts consume retry-first as exact retry revision3, cancellation revision4 and positive replacement non-admission retirement revision5. Original start/cancel ACKs follow the exact retirement receipt; no new native worker or ETL run is admitted. Cancel-first retires the failure at revision3 and rejects the queued retry as execution-terminal at unchanged revision. Both retain the original native/ETL fault and two prior HTTP effects, with no additional effects. All native parents consume their original typed Cancelled result, remain Cancelled, run no successor and settle the model before return ACK. A fourth host retains identical model/worker/ETL/incident/API/receipt/source/queue and wire views. This proves actual concurrent admission, stale ownership refusal and both protected FIFO decision orders, without bypassing the queue or manufacturing two simultaneous provider proposals.

Next direct-model broadcast delivery-time recipient snapshot/rearm/process-loss, provider/retention/rollback and final affected-source upgrade/Studio evidence. #3242 remains undecided. T023/T024/T025 and broader tasks, #2898/#2907/program remain open/Partial; claim6461197535/PR3410 retained. Full-PR rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and neutral size-skipped scan remain unresolved before merge; non-required CLA remains unsigned. Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6510967816).

## #2892 6511203854 elsa-workflows-codex[bot] 2026-10-29T23:44:54Z
[Codex] On behalf of @sfmskywalker.

Program dependency checkpoint: the refreshed main at4c79e3688 has a new failed required Build & test gate, tracked by [#3452](https://github.com/elsa-workflows/elsa-foundation/issues/3452), run40968443946. PR shardpr-2 fails the Activities Design complete-public-surface guard on both attempts after #3427 adds PaletteHints to the positional DTO constructor/deconstructor. The isolated main checkout reproduces the guard failure; a new causal regression additionally fails because the existing17-parameter constructor is missing.

A narrow [base repair PR3453](https://github.com/elsa-workflows/elsa-foundation/pull/3453) at a0c1f1c6b3b924674b6e29888ebb69c8b4ea29a4 preserves PaletteHints as an additive init/JSON property, restores the previous constructor/deconstructor and records the reviewed additive API shape. Whole Activities Design692/692 passes, zero skips; all669 listed definitions reconcile to692 TRX cases (two dynamic-data theories account for23 additional cases). Map and122-tier checks pass. Independent correctness/standards/acceptance review round1 and required CI/architecture qualification are in progress; no clean-review/merge claim yet. The failing base gate remains open until actual verification.

The retained #2898 claim6461197535, branchagent/codex/2898-direct-bpmn-hosting and draft PR3410 remain at ddc1d02c62629ea88cc6ede78b1edf1baaafd36f. The published25 real timer/concurrent-command journeys retain their existing sources and scope. PR3453 is a base-CI dependency, not another execution-model implementation leaf or competing program PR. Broadcast implementation resumes after the required base gate is corrected; no production broadcast writer has been edited. #2898/#2907/program remain open/Partial, full-PR3410 rounds0, standing safeguards/deferrals unchanged.

## #2892 6511254070 elsa-workflows-codex[bot] 2026-10-29T23:48:04Z
[Codex] On behalf of @sfmskywalker.

Base-CI dependency update: [PR3453](https://github.com/elsa-workflows/elsa-foundation/pull/3453) at `a0c1f1c6b3b924674b6e29888ebb69c8b4ea29a4` has a clean independent review round1. Whole Activities Design692/692 and Architecture592/592 pass with zero skips, all listed tests reconciled; maps/122 tier registrations pass. The exact-head required CI/full tier is now running. The required main failure #3452 remains open until actual resulting-main verification. No merge/bypass/CLA signature.

The existing execution-model leaf #2898/PR3410 and claim6461197535 remain retained at ddc1d02c6, open/Partial; full PR3410 rounds stay0. Broadcast production writers remain unedited pending base correction. [Local gate evidence](https://github.com/elsa-workflows/elsa-foundation/pull/3453#issuecomment-6511251127).

## #2892 6511882924 elsa-workflows-codex[bot] 2026-10-30T00:31:06Z
[Codex] On behalf of @sfmskywalker.

Head `51605da8389712dc2d1e5f65e73110d03b72ec4e` adopts current main and the catalog compatibility repair. The owner merged [PR3453](https://github.com/elsa-workflows/elsa-foundation/pull/3453) as `b9cf52c181b79e3e79eef233f7d61cb0843f4da7` after the reviewed-head required Build & test / Generated maps fresh / Full tier succeeded. It is not recorded as a Codex self-merge. The existing configured #3261 compensation-sample quarantine did fail; it remains open and is not relabelled as a passing test. The other PR/full-tier outcome summaries have no failed-twice, retry-pass or aborted results. Owner-closed #3452 is retained as closed; [resulting-main CI40978933651](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40978933651) is still pending, so resulting-main health is not yet claimed.

Next concrete journey: actual bound Event waits behind model-owned signal catches, using the existing native-work result/address bridge and durable first-delivery cohort. Code inspection confirms that the native bridge already captures generic typed root results and that Event/PublishEvent owns the existing named-event wait/send path. This is a candidate to qualify, not a direct-signal acceptance claim. The current direct profile still refuses signal constructs before runnable publication. Implement the explicit pin-backed event binding, then prove two catches, a listener created after publication/before first delivery, listener rearm and original source retry/pre-ACK process loss. Add delivery contracts only if that actual journey exposes a missing guarantee. T021 and broader acceptance remain open.

Retained #2898 claim6461197535, branchagent/codex/2898-direct-bpmn-hosting and PR3410; no competing execution-model PR. #2898/#2907/program remain open/Partial; PR3410 full-review rounds0 of6, incomplete draft. Provider/retention/rollback/final affected-source upgrade/Studio, #3242 decision, owner-deferred GitGuardian39189012 and program scan gate remain unresolved. Non-required CLA stays unsigned. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6511881570).

## #2892 6512226447 elsa-workflows-codex[bot] 2026-10-30T00:55:55Z
[Codex] On behalf of @sfmskywalker.

Head `71975cdff12b39748a7dbebe3442f88990335320`; actual signal-host source `8a1aa37942393923b4f55330d6da75a1d5eb5b12`. [Five real signal journeys](https://github.com/elsa-workflows/elsa-foundation/tree/71975cdff12b39748a7dbebe3442f88990335320/specs/1017-direct-bpmn-hosting/evidence/events/signal-recovery) now prove direct BPMN/native Root/Sequence/Flowchart/CompensationScope start → two signal catches → SIGKILL → restart → actual PublishEvent delivery → typed EventResult consumption → complete, followed by another stable cold host. The model owns progression; its two real published Event workers retain original full pins and exact model invocation/attempt origins. The original durable native Event cohort contains exactly their captured registrations. Every native parent gets typed Done, consumes/settles before result-source ACK, and continues once where present. Thirty whole Runtime/Design stores,79 qualification assets and15 owned SIGKILLed Workbench processes are retained.

Definition format5 adds only explicit pin-backed native Event bindings and reuses the existing native-work bridge/opaque frames2/5 and Event cohort. Formats1–4 and104 frozen baseline assets/original manifest remain unchanged. The real first run exposed two incorrect binding assumptions (stable published Elsa.Event key and absent correlation literal); they were fixed before successful qualification. Twenty-seven diagnostic assets, including18 failed stores and the incorrect-source-label interrupted run, remain explicitly excluded. Whole BPMN456/456, actual signal hosting5/5 and portable14/14 (including13 rehashed corrupt-copy controls) pass, zero skips. Core builds, maps and123 tier registrations pass. No new general recipient ledger or event bus.

Next: the real delivery-time later-listener, rearm/pre-ACK retry and installed-empty-cohort cuts. T021 remains unchecked; these positive signal journeys do not substitute for those gates. Further shared delivery contracts will be added only if actual journeys expose a missing guarantee. Prior timer/concurrent held-command/ETL/upgrade/Studio receipts keep their executing sources; no final upgraded-host or Studio compatibility is inferred.

Retained #2898 claim6461197535, branchagent/codex/2898-direct-bpmn-hosting and draft PR3410. #2898/#2907/program remain open/Partial; formal full-PR review rounds0 of6, incomplete. Required new-head CI and resulting-main CI40978933651 are pending. Owner-merged PR3453/#3452 closure is retained; the earlier configured #3261 compensation quarantine is not relabelled as passing. Provider/retention/rollback/final affected-source upgrade/Studio, #3242 decision, owner-deferred GitGuardian39189012 and the program scan gate remain open. Non-required CLA stays unsigned. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6512225518).

## #2892 6513107458 elsa-workflows-codex[bot] 2026-10-30T02:01:14Z
[Codex] On behalf of @sfmskywalker.

Head `7dc385868391805726750f57774565b8dbf55c71`. [Three actual saved-source model signal cuts](https://github.com/elsa-workflows/elsa-foundation/tree/7dc385868391805726750f57774565b8dbf55c71/specs/1017-direct-bpmn-hosting/evidence/events/model-broadcast) now qualify the settled delivery-time matching rule through real Event workers and the existing native-work bridge. Executing source `6bde6e8ff3606244a8708d476cc662cacb04418b` proves partial callback → real model rearm before source ACK → process loss → higher-fence original-source retry. Source `791dc17016a6b6022a0413820fe61eb202c52afc` proves delayed first selection includes two registrations created after publisher commit, and a durably installed empty cohort excludes newly armed waits. Production files are identical between these sources. Each of the three cuts retains four owned SIGKILLed hosts, including a separate normal consumer while the original sender is deliberately held;55 qualification assets/18 complete Runtime-Design stores/12 hosts total. The later listener and original rearmed wait stay unchanged, the original saved cohort is never replaced, and another cold process retains the result. The two finite models in delayed selection complete with exact typed Event results.

No new common recipient ledger or duplicate signal semantics was needed for this profile. Model invocation/attempt/material origins address real published native Event work; its saved registration cohort supplies retry protection. Released BPMN0.5.0 products, full pins/registration generations, pre-ACK claim freshness, real lease expiry, consumption-before-ACK and actual stores are retained. Sixteen portable checks pass, including15 rehashed corrupt-copy controls. Forty-eight prototype diagnostic assets remain separate; successful cuts have no observer retries. Earlier attempts exposed live snapshot/Python SQLite observation limitations and the need for a separate normal consumer during the artificial pause; those failures are not relabelled as green. The actual finite two-catch/four-native-parent qualification retains source8a1aa3794,5 journeys/30 stores/15 hosts, BPMN456/456 and host5/5. Its14 portable checks include13 corrupt controls. Current maps/123 tiers/104 frozen baseline assets pass; original manifest unchanged. Native cohort wire/fingerprints remain unchanged.

Resulting-main [CI40978933651](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40978933651) succeeded at owner-mergeb9cf52c after PR3453; owner-closed #3452 remains closed. All9 downloaded outcome artifacts match that exact main SHA and have no failed-twice, retry-pass or aborted tests. The configured #3261 compensation-sample quarantine did fail; it remains a failure and is not called a pass. EF container shards were skipped, so this is not provider qualification. Program-head required checks remain pending and separate. No self-merge attribution or CLA signature.

Next actual work: bound Event-worker interruption and sibling settlement, then remaining retention/provider/activation and final affected-source upgrade/Studio gates. T021 remains unchecked; the new cuts qualify its exact-recipient arm, not broader delivery acceptance. #2898/#2907/program remain open/Partial with retained claim6461197535, branchagent/codex/2898-direct-bpmn-hosting and draft PR3410. Formal full-PR review rounds0 of6; no competing PR or program-complete claim. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain open. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6513106571).

## #2892 6513439586 elsa-workflows-codex[bot] 2026-10-30T02:26:19Z
[Codex] On behalf of @sfmskywalker.

Head `ba3efcccfe9e734f069d910912967b82ac5a5245`; actual fixed host source `c40881fd0209dd1f2e8765358c3afd3f007247ab`. [Real bound Event-worker sibling cancellation](https://github.com/elsa-workflows/elsa-foundation/tree/ba3efcccfe9e734f069d910912967b82ac5a5245/specs/1017-direct-bpmn-hosting/evidence/events/sibling-cancellation) reproduces and fixes an orphan before delivering the multi-catch profile. At red source `8d5ed3e03b228d866b26606a81e063839af183f6`, cancelling one Event worker settled the model at revision2 while its sibling remained Running; the four-store red capture is retained, not relabelled. The fixed journey restores both actual waiting stores captured at791dc1701, preserves original material/incarnation/worker pins across process loss, then uses the normal native CancelWorkflow API. Revision2 durably stages cancellation of the original sibling and stays TerminalPendingSettlement; its exact Cancelled result settles revision3. Both workers are Cancelled.

The real second SIGKILL occurs after both model result receipts are committed while the sibling-cancel source and both native-result sources remain FailedRetryable/unacknowledged. A third standard host acknowledges those original sources after their exact consumption receipts without changing the model. Six successful complete Runtime/Design stores, three owned SIGKILLed hosts and17 raw assets retain this bounded post-consumption/pre-ACK recovery plus the original red repro. A crash while model settlement itself remains pending is not claimed. The fix reuses existing cancellation ports and frames4/6 through one private staging helper; no new public contract, state format or common ledger. Whole BPMN456/456, actual host1/1 and portable10/10 (nine rehashed corrupt controls) pass, zero skips; maps/123 tiers/104 frozen baseline assets and original manifest remain unchanged.

Earlier finite5-parent signal recovery keeps source8a1aa3794; delivery-time/rearm/empty-cohort cuts keep6bde6e8ff/791dc1701 and their18 stores/12 hosts. All earlier native/ETL/timer/concurrency/upgrade/Studio receipts keep their sources. [The previous recipient checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6513106571) remains valid. No final upgraded-host or Studio acceptance is inferred.

Next: embedded/native-parent sibling interruption and pending-model-settlement crash, then remaining retention/provider/activation/rollback and final affected-source upgrade/Studio. T021 and broader #2898/#2907/program acceptance stay open/Partial; retained claim6461197535, branchagent/codex/2898-direct-bpmn-hosting and draft PR3410. Formal full-PR review rounds0 of6; new-head required CI pending. Owner-merged base PR3453/mainb9cf52c passed CI40978933651 with the recorded existing #3261 quarantine failure and skipped EF containers; those are not passing-test/provider claims. #3452 stays owner-closed. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain unresolved. Non-required CLA stays unsigned; Orleans/task-runner deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6513438663).

## #2892 6513876895 elsa-workflows-codex[bot] 2026-10-30T03:00:27Z
[Codex] On behalf of @sfmskywalker.

Head `336071d006f80be9f935510fdb6a74f8075bc560`. [Actual pending Event-sibling cancellation recovery](https://github.com/elsa-workflows/elsa-foundation/tree/336071d006f80be9f935510fdb6a74f8075bc560/specs/1017-direct-bpmn-hosting/evidence/events/pending-sibling-interruption) now passes directly and under RunBpmn Root, Sequence, Flowchart and CompensationScope, executing source `f4c923ed9bb01f764e648ee45d1c76b081f51098`. The normal native CancelWorkflow API cancels one real Event worker. Its result commits model revision 2 as TerminalPendingSettlement with the original sibling still Running and cancellation durably owed. A test-only pause holds the original fresh cancellation claim before dispatch; the owned host is SIGKILLed. A standard host recovers after natural lease expiry, reclaims that same source with a higher fence, cancels the original sibling and consumes its exact result. Direct BPMN settles revision 3; native parent consumption/settlement finishes revision 4 without running successors. Another SIGKILL and third standard host retain identical model, worker, parent and source observations. Pins, material incarnation, original source addresses and interpreter history survive; no state or clock is seeded or edited.

Five journeys retain 30 complete Runtime/Design stores, 107 qualifying assets and 15 owned SIGKILLed hosts; all are stopped. Successful runs needed zero collector retries. The first Direct attempt at `0dc96a38f` recovered cancellation but its final retained backup was refused: its 19 assets/six whole diagnostic stores remain excluded from acceptance. The collector now records refused reads and retries a complete coupled capture after resuming the real transaction. Standard/probe/reader builds have zero errors and committed raw logs. Portable checks pass 13/13, including 12 rehashed corrupt controls; maps, all 123 tier registrations and the original 104 frozen baseline assets/manifest pass. Every one of the 130 manifest assets is tracked and pushed, including the initially ignored build logs. Production files are unchanged from the real orphan fix at `c40881fd0`; the earlier BPMN 456/456 and actual cancellation host 1/1 receipts retain that executing source.

The [earlier post-consumption/pre-ACK checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6513438663), delivery-time recipient snapshots/rearm/empty-cohort cuts, finite signal, ETL, timer, concurrency and upgrade/Studio receipts keep their own sources and limits. This adds the actual pending-model crash/native-parent sibling witness; it does not claim final upgraded-host or Studio acceptance.

Next: remaining retention/provider/activation/rollback checks, final affected-source upgrade/Studio and consolidated acceptance mapping, then complete-PR review. #2898, #2907 and program #2892 stay open/Partial. Existing claim 6461197535, branch `agent/codex/2898-direct-bpmn-hosting` and draft PR #3410 continue; full-PR review remains 0 of 6 rounds and new-head required CI is pending. The confirmed goal statement remains current on #2892 and Project #62. #3242, owner-deferred GitGuardian incident 39189012 and the program scan gate remain unresolved; CLA is non-required and unsigned. Orleans/task-runner remain deferred. Base main `b9cf52c` keeps its successful CI 40978933651 with the recorded #3261 quarantine failure and skipped EF container shards; neither is relabelled as passing/provider coverage. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6513875880).

## #2892 6514567884 elsa-workflows-codex[bot] 2026-10-30T03:55:23Z
[Codex] On behalf of @sfmskywalker.

Head `7ff5367ae3d245136c2e0085594d04e0f17cf5e2`. [Actual publication retention and admission-off/runtime-only recovery](https://github.com/elsa-workflows/elsa-foundation/tree/7ff5367ae3d245136c2e0085594d04e0f17cf5e2/specs/1017-direct-bpmn-hosting/evidence/retention/runtime-only-rollback) passes directly and under RunBpmn Root, Sequence, Flowchart and CompensationScope at executing source `2e142e51055aa2d84c0839dffb49b3621489d9ce`. Revision 1 commits both original native Event-worker obligations before dispatch. The SDK calls the existing publication-retirement and reference-collector ports over these private actual stores: the unreferenced control artifact/source is collected, while every owed model/worker/parent pin, incarnation and retired provenance survives. Both workers remain unadmitted at the captured cut and the original native-start claim is fresh. No execution, queue, claim, receipt or clock is edited.

Next: physical provider/migration and remaining compatibility checks, final affected-source legacy/Studio qualification, consolidated acceptance mapping and full-PR review. Existing actual native/ETL, timer/race, finite signal/broadcast, cancellation and older upgrade/Studio receipts keep their sources and limits; [previous checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6513875880). #2898, #2907 and program #2892 stay open/Partial. Retained claim6461197535, existing branch/draft PR #3410; formal complete-PR rounds0 of6. New-head required CI and resulting-main CI40996404025 at927f91e51 remain pending, not green. No new human reviews/holds were found. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain unresolved; non-required CLA stays unsigned. Orleans/task-runner stay deferred. The confirmed goal remains unchanged. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6514567054).

## #2892 6515060293 elsa-workflows-codex[bot] 2026-10-30T04:34:39Z
[Codex] On behalf of @sfmskywalker.

Head `de0e800384b91268827af674e195b1097455dd45`. [Model storage and additive migration qualification](https://github.com/elsa-workflows/elsa-foundation/tree/de0e800384b91268827af674e195b1097455dd45/specs/1017-direct-bpmn-hosting/evidence/providers/model-storage) passes71/71 with zero skips at executing source `26aef90429532f26c41907d8b8d8a743b9837b8f`:18 cases on private PostgreSQL/SQL Server/MySQL containers and53 focused SQLite cases. T011 is now checked for the declared common-provider storage gate, with explicit fixture/host limits. No production code or public contract changed.

The physical final-marker observer sees model state, input receipt and outbox rows already saved inside the transaction, with consumed queue absent and marker absent. An injected marker-insert failure rolls every participant and the execution-fence touch back; a fresh context retains the original protected claim. Normal commit/replay consumes once. Other cases refuse stale fences/revisions, reused input IDs and conflicting replay without partial state; exact old replay does not overwrite later progress. Running and TerminalSettled receipt-only cases preserve model JSON/revision. Strict native-provider mode and removed external connection-string overrides ensure all three engines actually run in test-owned containers, with no skipped-provider pass.

Main advanced legitimately: owner-merged PR #3461's compact activity-definition header is adopted as base `07f3e4f2a0835a325b1a8280f731940645a80032` in merge `de0e800384b91268827af674e195b1097455dd45`. Earlier main PR #3460's resource cleanup remains included. The actual standard Workbench legacy-host qualification is now running on this combined head against the original complete captures, with fresh source-bound evidence output. It is not yet a pass. T041's final legacy/Studio qualification, remaining compatibility/public-profile reconciliation, consolidated acceptance mapping, complete-PR review and required CI remain open.

All earlier actual direct/native/ETL, race/broadcast, pending cancellation and admission-off/runtime-only retention receipts keep their executing sources and limits; [previous checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6514567054). #2898/#2907/program #2892 remain open/Partial under existing claim6461197535 and draft PR #3410. Formal review rounds0 of6; new-head required CI and resulting-main CI41002383046 remain pending. No human holds/reviews were found. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain unresolved. Non-required CLA stays unsigned; Orleans/task-runner stay deferred. Broader provider/Studio/program acceptance is not inferred from these technical tests. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6515059404).

## #2892 6515276027 elsa-workflows-codex[bot] 2026-10-30T04:52:24Z
[Codex] On behalf of @sfmskywalker.

Head `d46c8d080274d1d47adfbbbe0b8f94cb757d9180`. [Final affected-runtime legacy and existing Studio compatibility](https://github.com/elsa-workflows/elsa-foundation/tree/d46c8d080274d1d47adfbbbe0b8f94cb757d9180/specs/1017-direct-bpmn-hosting/evidence/final-compatibility) is committed and T041 is checked. The actual standard Workbench legacy suite passes 7/7 with zero skips at `de0e800384b91268827af674e195b1097455dd45`; six separately verified families retain 33 resulting whole stores. Both actual saved Studio families execute at `905b6a491d4372fda5c1b71607d1edbc37020c06`, retaining twelve stores and four new complete executions. All 22 original whole-store inputs are bound to their unchanged capture hashes, and all 104 frozen assets remain unchanged.

The final actual Studio browser journey opens each saved definition, exports JSON/XML, changes only the gateway label, saves, reviews and publishes versions 3.0.0/4.0.0, runs the exact published artifact and a separate Test Run through the real native Delay, inspects old and new executions, restarts the isolated Workbench and reopens the same run. Initial exports match exactly. New runs have two completed activities, no incidents/waits; full stored pins, old/new API views, retained original 84/92 native executable payloads/incarnations and published five-node layout survive. Twelve screenshots were visually inspected. The controller now uses the existing .NET SQLite reader for coupled backups while only its owned Workbench is paused, with full process identity and read-only snapshot receipts. No execution, queue, claim, receipt or clock is seeded. All 47 listed legacy/Studio host processes stopped; user hosts and existing browser tabs were preserved.

This completes T041's affected SQLite legacy-host/existing embedded-BPMN Studio repeat for the current runtime. Non-SQLite actual-host upgrades and first-class direct-model Studio #2907 are not inferred. Draft Test Runs retain existing empty layout-sidecar behavior; saved/published layout is checked separately. Development sign-in still required explicitly reopening the owned Studio URL after return to Workbench root; automatic return-URL support is not claimed. The earlier [71/71 physical storage/migration gate](https://github.com/elsa-workflows/elsa-foundation/tree/d46c8d080274d1d47adfbbbe0b8f94cb757d9180/specs/1017-direct-bpmn-hosting/evidence/providers/model-storage), real model/native/ETL recovery, broadcast, sibling-cancellation and runtime-only rollback receipts retain their own executing sources and limits; [previous checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6515059404).

Next: T042 public API/profile/XML/provider/rollback/composition reconciliation and T043 concise FR/SC/#2898 mapping, then task/spec closeout and the full independent complete-PR review loop. Draft PR #3410 remains open under the retained Codex claim; formal complete-PR rounds remain 0 of6. New-head required CI is pending, no human holds/reviews were found in the refreshed discussion, and no merge has occurred. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain unresolved; non-required CLA remains unsigned. #2898/#2907/#2892 and Project62 remain open/In Progress/Partial. Orleans/task-runner remain deferred; the program goal remains active. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6515275158).

## #2892 6515474956 elsa-workflows-codex[bot] 2026-10-30T05:08:24Z
[Codex] On behalf of @sfmskywalker.

Head `4d77feefdd55132f167c072f2163f10201cad886`. [T042 API/version and compatibility reconciliation](https://github.com/elsa-workflows/elsa-foundation/tree/4d77feefdd55132f167c072f2163f10201cad886/specs/1017-direct-bpmn-hosting/evidence/compatibility-reconciliation) is committed. The actual publish-state snapshot `f49ff392871e217896efdbfe8c208f10cece7365` and read-only calculator output at `fae8dce0d5177e987ca50affde428eec03303219` are retained with six hashed assets. Runtime Core adds177 tracked entries and Runtime adds4, with zero removals against both released previews and the current PR base. Existing provider extensions default to false/refusal. Existing BPMN public source files are unchanged; the adapter adds its hosting feature, RunBpmn, replacement port and typed activity records. No binary ApiCompat or automatic magnitude gate is claimed.

One genuine owner choice has been presented in a card: framework §4.2 classifies compatible Core additions as MINOR, while the configured pre-GA line computes Runtime.Core4.0.55-preview→4.0.56-preview. Every recorded package is still a preview; §E5 retains the magnitude rule while ADR0080 D4 keeps one pre-GA line. Recommendation: an explicit scoped preview-magnitude exception for PR3410's compatible additions, preserving the current4.0 line. Alternative: advance the repository shared line to4.1. No exception is assumed. T042 remains unchecked and PR3410/#2898 receive needs:decision; independent qualification and acceptance mapping continue. This is a version-policy decision, not a renewed claim/self-review/self-merge authorization question.

The API README now lists all9 routes/6 permissions including cancellation, incident inspection and exact retry. Core docs index declared formats1–5; catalogs describe actual protocol input kinds, native/model/ETL composition, timer/signal/settlement, provider tuple refusals and admission-off recovery. Root extension index no longer advertises retired Foundation element-behavior contributors. XML stays in the existing authored native envelope; no general XML-to-direct conversion is claimed. Quickstart/tool docs point to actual producers and final receipts instead of a nonexistent generic qualify phase or already-completed open gates. All276 changed-document relative paths and the160-file catalog link check pass. No production implementation or test code changed in this reconciliation.

Next independent work is T043 whole affected-project checks and the concise FR001–022/SC001–006/#2898 evidence mapping. Complete-PR rounds remain0 of6; latest-head required CI is pending. No merge occurred. #2898/#2907/#2892 and Project62 remain open/In Progress/Partial under the retained Codex claim/draft PR3410; the whole program goal remains active. Non-SQLite actual-host upgrades, distributed placement and first-class direct-model Studio acceptance are not inferred. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain unresolved; non-required CLA stays unsigned. Orleans/task-runner remain deferred. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6515474060).

## #2892 6516145320 elsa-workflows-codex[bot] 2026-10-30T06:01:40Z
[Codex] On behalf of @sfmskywalker.

Head `78faee3b7c50bf6722209f939196db37b1425ff4`. [The actual paired partial-fork journey](https://github.com/elsa-workflows/elsa-foundation/tree/78faee3b7c50bf6722209f939196db37b1425ff4/specs/1017-direct-bpmn-hosting/evidence/embedding/parallel-native-recovery) closes a specific SC001/T019/T029 evidence gap: one immutable human parallel model runs directly and through Root/Sequence/Flowchart/CompensationScope; left completes before SIGKILL, the original right wait survives, the join and after-join work run once, both models complete, native continuation settles once, and another cold process preserves exact observations. Executing source `c34c1f4e1f279c66598a5ab83a8c2cc05e9b4a72`: four pairs/eight completed models,24 whole stores/52 qualifying assets/twelve killed owned hosts, plus13 passing portable controls. Observed model-local producer handles are the sole normalized state field, bound to physical invocation/attempt receipts; all semantic IDs/order/diagnostics/outcomes remain exact. The two earlier four-case observer failures and the negative-copy control failure remain separately diagnostic. No runtime change was required. All104 frozen authoring assets remain unchanged.

[Whole affected-project gates](https://github.com/elsa-workflows/elsa-foundation/tree/78faee3b7c50bf6722209f939196db37b1425ff4/specs/1017-direct-bpmn-hosting/evidence/delivery-gates/4d77feefd) retain12 complete projects/8061 passed/zero skipped at `4d77feefdd55132f167c072f2163f10201cad886`, including strict owned PostgreSQL/SQL Server/MySQL execution. All discoveries are accounted for, including five runtime-expanded theories. Locked graph restore, maps and123-project tiers pass. Portable ETL240/240 passes; portable BPMN173 passes with three explicitly unconfigured optional historical live-fixture probes, not176 passes. The expanded32-case hosting suite atc34 is still running; no result is assumed. Subsequent main changes are not covered by relabelling these source-bound receipts.

Fresh remote read shows no new human hold/review and retains the original Codex claim6461197535. Main now includes legitimate PR3462/3469/3448/3474 progress through `c986f9ddfdec2c641b2f1c1f5d8f82f8dd19e529`, including Workbench/Studio composition and editor changes. Adoption and affected verification follow; earlier T041 legacy/Studio passes retain their own exact sources. T043 acceptance mapping and task reconciliation are in progress, not yet checked.

The existing owner version-policy card remains unanswered: framework §4.2/§E5 magnitude versus the configured4.0 preview line. No scoped exception is assumed; T042 remains unchecked and needs:decision remains on PR3410/#2898. Complete-PR review remains0 of6, latest-head required CI is pending, no merge occurred. #2898/#2907/#2892 and Project62 remain open/In Progress/Partial under the existing draft PR. First-class direct-model Studio, non-SQLite actual-host upgrades and distributed placement are not inferred. Owner-deferred GitGuardian39189012 and the scan gate remain unresolved before merge; CLA stays unsigned. #3242, Orleans/task-runner and other existing deferrals remain unchanged. Program goal active. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6516144460).

Source-label correction:4d77feefd executed the8061-test run;78faee3b7 pushed its receipts. The committed receipts and their hashes already identified4d77feefd correctly.

## #2892 6516275617 elsa-workflows-codex[bot] 2026-10-30T06:11:28Z
[Codex] On behalf of @sfmskywalker.

Head `d7ee22b164bc04098bedde19e5b4722ed6f2b871` adopts legitimate main `c986f9ddfdec2c641b2f1c1f5d8f82f8dd19e529` (PR3462/3469/3448/3474) without conflicts. The existing Runtime README and [FR001–022/SC001–006/#2898 mapping](https://github.com/elsa-workflows/elsa-foundation/tree/d7ee22b164bc04098bedde19e5b4722ed6f2b871/specs/1017-direct-bpmn-hosting/evidence/qualification.md) now describe actual consumers, exact receipts, planned-path deviations and remaining limits. T041 is reopened for affected Workbench/Studio repetition after those main changes; its earlier exact-source legacy/Studio receipts remain valid historical evidence.

The expanded32-case hosting run atc34c1f4e1 finished31 passed/one failed/zero skipped, so it is not green. [Retained full-suite refusal](https://github.com/elsa-workflows/elsa-foundation/tree/d7ee22b164bc04098bedde19e5b4722ed6f2b871/specs/1017-direct-bpmn-hosting/evidence/delivery-gates/c34c1f4e1) and [focused physical diagnosis](https://github.com/elsa-workflows/elsa-foundation/tree/d7ee22b164bc04098bedde19e5b4722ed6f2b871/specs/1017-direct-bpmn-hosting/evidence/delivery-gates/called-ack-observer) preserve the failure. Focused reproduction first passed twice, then failed; repetition stopped on that failure. The original compiled checked reader over the retained whole closed database identifies its unchanged guard: the caller is Completed but the actual later terminal source is still Delivering with no deliveredAt. The fixture had stopped the sender before its durable ACK. The correction waits for real source acknowledgements before stopping the host; no receipt guard or runtime implementation is changed. Fixed-source actual qualification is in progress, not assumed green. The closed diagnostic database hash remained unchanged throughout read-only diagnosis.

The separately passed paired partial fork atc34 retains four direct/native parent pairs/eight completed models/24 whole stores/13 portable controls. The broad4d77feefd receipt retains12 projects/8061 passes/zero skips, strict owned native providers, locked graph/maps/discovery/tiers; portable ETL240 passes and BPMN173 passes plus three explicitly unconfigured optional live probes. Those results retain their sources and do not override the new refusal or qualify later main changes. All104 frozen assets/authoring fingerprint remain unchanged.

The version-policy owner card remains pending; no4.0 preview-magnitude exception or4.1 advance is assumed. T042 and T043 remain unchecked; needs:decision stays on PR3410/#2898. Complete-PR rounds0 of6, latest reviewed-head required CI and post-merge main verification are still open; no merge occurred. Original Codex claim6461197535/existing draft PR remain the only active leaf. #2898/#2907/#2892 and Project62 stay open/In Progress/Partial. First-class direct-model Studio, non-SQLite actual-host recovery and distributed placement are not inferred. GitGuardian39189012 remains owner-deferred and the scan gate unresolved before merge; CLA stays unsigned. #3242, Orleans/task-runner and existing program deferrals remain unchanged. Goal active. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6516274647).

## #2892 6516804187 elsa-workflows-codex[bot] 2026-10-30T06:50:25Z
[Codex] On behalf of @sfmskywalker.

Head `7cfbf739f0d4c3c220097918b04c2b33b5cb3bb3` commits the [affected-main qualification](https://github.com/elsa-workflows/elsa-foundation/tree/7cfbf739f0d4c3c220097918b04c2b33b5cb3bb3/specs/1017-direct-bpmn-hosting/evidence/main-adoption/d7ee22b16) with240 hashed receipt/diagnostic files; every asset was checked from its committed Git blob. Actual executing products remain `d7ee22b164bc04098bedde19e5b4722ed6f2b871`. This commit changes evidence/spec/task/review-index documentation, not the qualified production implementation. Mainc986f9ddf (PR3462/3469/3448/3474) is adopted.

At that exact executing source: whole hosting32/32 and Architecture594/594 pass, zero skips; discovery, maps and123-project tier/shard checks pass. All six actual legacy families/seven included host tests again recover the22 original whole-store inputs, retaining33 resulting whole stores. Four direct/native partial-fork pairs complete eight models after partial-progress SIGKILL/restart, retain24 stores and one logical join each. Both actual saved Studio families preserve exact opening JSON/XML and the five-node saved layout, change only gateway labels, publish versions3.0.0/4.0.0 and complete two Published Runs plus two Test Runs. Twelve coupled stores preserve all original views,84/92 native material payloads/incarnations and identical new full views/pins after restart. The two new bundles each pass13 portable positive/corrupt controls, zero skips. All63 listed owned hosts stopped:41 legacy,12 paired-fork, six primary Studio and four additional read-only Details inspection hosts. All104 frozen baseline assets and the authoring fingerprint remain unchanged. Initial authentication return to the Workbench root and existing Test Run draft layout-sidecar behavior remain declared limits; first-class direct-model Studio is not inferred.

[The consolidated FR001–022/SC001–006/#2898 index](https://github.com/elsa-workflows/elsa-foundation/tree/7cfbf739f0d4c3c220097918b04c2b33b5cb3bb3/specs/1017-direct-bpmn-hosting/evidence/qualification.md) and actual implementation paths are reconciled. T001–T041/T043/T044 are evidenced. The spec's Implemented status and checklist retirement are prepared in this implementation PR as required by lifecycle; shipped status becomes true only at merge. Broader #2907/#2908/program criteria are not closed. The older12-project8061/8061/zero-skip gate remains executing source4d77feefd, not its later78faee3b7 receipt-push head; the old checkpoint source label is corrected to match its already-correct committed receipts. Portable ETL240 and historical BPMN173 passes plus three unconfigured optional live probes retain their sources; they are not current-head CI.

T042 remains open for the pending owner version-policy card; no4.0 preview magnitude exception or shared4.1 advance is assumed. needs:decision remains on PR3410/#2898. Complete-PR rounds0 of6; independent full-PR review is next. Required exact reviewed-head checks, the scan gate/owner-deferred GitGuardian39189012, normal protected merge and resulting-main verification remain open; CLA stays unsigned. No merge occurred. Retained Codex claim6461197535/existing draft PR3410 remain the only active leaf. #2898/#2907/#2892 and Project62 stay open/In Progress/Partial; #3242 and Orleans/task-runner deferrals remain unchanged. Program goal active. [Checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6516803129).

## #2892 6516924312 elsa-workflows-codex[bot] 2026-10-30T06:58:25Z
[Codex] On behalf of @sfmskywalker.

Complete-PR round1/6 is in progress at `7cfbf739f0d4c3c220097918b04c2b33b5cb3bb3` with independent correctness/standards/acceptance lenses; zero rounds completed. Runtime qualification atd7ee22b16 and the five evidenced runtime criteria retain their source; pending version decision/scan/CI hold merge. New main4df0c5e9d (PR3475) is fetched outside this head and will be adopted/qualified before final delivery. Existing claim/PR, open/In Progress/Partial preserved. [Round record](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6516922901).

## #2892 6522037380 elsa-workflows-codex[bot] 2026-10-30T11:54:03Z
[Codex] On behalf of @sfmskywalker.

Full-PR round1/6 is complete with five surviving findings. Two reproduced recovery gaps reopen service cancellation and human/incident acceptance: native result can settle before pending ETL cancel, and invalid service retry can block a human model FIFO. Three standards corrections cover Core event ownership, contextual JSON errors and Source naming. Fixes and actual recovery requalification are next; prior passing journeys retain their source/limits. Draft/open/In Progress/Partial, not clean or merge eligible. Version decision/scan/CI holds persist. [Completed round](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6516922901).

## #2892 6522223571 elsa-workflows-codex[bot] 2026-10-30T12:01:32Z
[Codex] On behalf of @sfmskywalker.

Head `7fc0217a4520216834125c9b94b3a851fb02841c` contains the five round1 repairs in1e07e90b7 and adopts legitimate main `5fa0840be9208c78a63a3e2d9cf4c8e710c2069f` (Studio secondary root slots PR3475 and workspace appearance PR3449) without conflicts. Invalid service retry now checks eligibility before resolving service policy; all Cancelled native results require their exact downstream cancellation inventory to be delivered. The existing initialization event/payload is public Runtime Core, the returning port is named IRuntimeExecutionProtocolSource, and owned BPMN definition/input/state JSON failures retain a contextual BpmnModelValidationException with original cause.

[Round1 reports and actual red diagnostics](https://github.com/elsa-workflows/elsa-foundation/tree/7fc0217a4520216834125c9b94b3a851fb02841c/specs/1017-direct-bpmn-hosting/evidence/reviews/round-1) retain five surviving findings. Five new behavioral cases failed before production fixes; preliminary local green6/6 also includes an external public Core-event subscriber. These precommit checks are diagnostics, not exact-head whole-project/host acceptance. Source7fc0217a4 whole BPMN and standard-host build are running. The existing actual ETL controller/owned SDK now support result-first cancellation delivery, require retryable refusal with no model/receipt/queue change, and leave original sources for cold-host recovery. Actual direct/all-four-parent repetition, invalid-retry HTTP proof, affected legacy/Studio, API audit, whole affected gates and round2 are still due. All104 frozen baseline hashes were checked unchanged before the repair commit.

Two issue acceptance rows and the directly affected task/gate statuses are reopened; spec is In progress. Existing claim/PR preserved, one full-PR round of6 complete with findings, no clean round or merge eligibility. Earlier source-bound passes retain their own scope. T042 owner magnitude card remains unanswered and needs:decision stays; owner-deferred GitGuardian39189012/scan and exact reviewed-head required checks remain holds. #2898/#2907/program remain open/In Progress/Partial. Orleans/task-runner remain deferred.

## #2892 6522532164 elsa-workflows-codex[bot] 2026-10-30T12:12:55Z
[Codex] On behalf of @sfmskywalker.

Head `0ce9a41dba03c4f362c4d386f14737823f33238a`, adopted main5fa0840be (PR3475/3449). Round1's five production/standards repairs remain pushed; later changes correct only the new inverse-order observer. The first observer incorrectly expected no queued input; the second failed to retain the expected dependency-unavailable signal. Both failed diagnostics/whole stores remain committed, separately labelled. The correct invariant is one original queued result, no accepted receipt or model advance until exact downstream cancellation settles.

Fresh publish-state8832507151eaa2a308a69cf2cd23ac41bab52b5b/API audit: Runtime Core180 additions/0 removals and Runtime4/0 against their actual published baselines. New Source replaces only an unpublished PR addition; the three public Core event entries are additive. Computed Core remains4.0.56 versus published4.0.55-preview. This is not binary ApiCompat or magnitude clearance; T042's owner card remains unanswered.

Existing claim/draft PR retained. Two issue acceptance rows and directly affected task/gate statuses remain reopened; spec In progress. One full-PR round of6 completed with findings; round2 is not yet started. Version-policy needs:decision, owner-deferred GitGuardian39189012/scan, exact final reviewed-head required checks and post-merge verification remain holds. No settled authorization is asked again. #2898/#2907/program and Project62 remain open/In Progress/Partial; #3242, Orleans/task-runner deferrals unchanged.

## #2892 6522934492 elsa-workflows-codex[bot] 2026-10-30T12:32:51Z
[Codex] On behalf of @sfmskywalker.

Head `cb0354a5b507271b67c5923a700d88f950975e25` commits the round1 repairs and **335 manifested evidence assets, all checked from committed Git blobs**. Six intentionally retained log files were initially ignored by Git; the follow-up adds them and the full Git-blob verification now passes. Production fixes are in1e07e90b7; later source changes correct the new observer, and this receipt commit changes evidence/test tooling/docs. Executing sources retain their original labels.

[Repair/legacy/API qualification](https://github.com/elsa-workflows/elsa-foundation/tree/cb0354a5b507271b67c5923a700d88f950975e25/specs/1017-direct-bpmn-hosting/evidence/reviews/round-1/repair-qualification): actual authenticated invalid-human-retry followed by completion or cancellation passes at7fc0217a4, retaining durable rejection, two terminal revision2 executions, zero queued inputs and a closed whole Runtime store. Whole BPMN462/462 at7fc0217a4, Runtime3078/3078 and Architecture594/594 atfe8e77ce9, and hosting32/32 at0ce9a41db pass with zero skips and discovery reconciliation. Maps/123-project tiers pass at clean0ce9a41db; the earlier wrong tier command remains a command diagnostic. All six actual legacy families/seven included host tests recover22 original whole-store inputs and retain33 resulting stores. Four paired partial forks again complete eight models and retain24 stores; their13 current-bundle controls pass. All53 listed legacy/partial hosts are stopped, independently of the30 ETL children and one HTTP retry host. All104 frozen baseline assets remain unchanged.

The Core initialization event, returning Source port and contextual owned-JSON domain errors are corrected with passing regressions; current tracked API audit is Core180 additions/0 removals, Runtime4/0 against actual published baselines. Publish-state8832507151eaa2a308a69cf2cd23ac41bab52b5b still computes Core4.0.56 from4.0.55-preview. Binary ApiCompat and magnitude clearance are not claimed; T042's existing owner card remains unanswered and needs:decision stays.

T001–T040 implementation/repair evidence is recorded. T041/T043/T044 remain open for final affected Studio/gate reconciliation; spec In progress. Fresh cb0354a5b frontend, Studio host and standard Workbench/reader/SDK builds now pass; the two actual saved Studio families are next after adopted main5fa (3475/3449). This does not relabel the older d7 UI receipts. Full-PR round1/6 completed with findings; round2 remains due after qualification. Draft/open/In Progress/Partial, no clean round or merge eligibility. Owner-deferred GitGuardian39189012/scan, exact final reviewed-head required checks, protected merge and resulting-main verification remain holds. #2898/#2907/program and wider ETL acceptance remain open; #3242 and Orleans/task-runner deferrals unchanged. No settled authorization is asked again.

## #2892 6524215496 elsa-workflows-codex[bot] 2026-10-30T13:40:19Z
[Codex] On behalf of @sfmskywalker.

Current head `4eedd052ef9314ae4d2e0f94316996103c968d5e`; existing draft PR3410 and retained Codex claim6461197535. The program goal remains active: deliver working, recoverable user journeys across BPMN, native workflows, ETL and Studio, preserve authoring/persisted-state compatibility, let demonstrated needs drive architecture, and keep issues/PRs/Project62 current. Direct BPMN remains first; wider program acceptance and existing Orleans/task-runner deferrals remain unchanged.

[Newly adopted main931123c7e compatibility regression](https://github.com/elsa-workflows/elsa-foundation/tree/4eedd052ef9314ae4d2e0f94316996103c968d5e/specs/1017-direct-bpmn-hosting/evidence/main-adoption/931123c7e): legitimate template progress #3472 was adopted. The real old partial-fork recovery test now fails at standard host startup, before authentication/resumption: SQLite reports `table "__ElsaDatabaseIdentity_ElsaWorkflowsDesign" already exists`. All four Design Initial migration IDs were regenerated. Before editing the writer, a real current-source1ae57d214 standard Workbench saved a template and published/suspended a real native Event workflow through normal authenticated APIs. Two closed whole-store backups retain its new Initial history, template identity/revision and held full executable pins. One owned writer host stopped. Raw red TRX/log and that actual current-writer input are portable: all18 manifested asset hashes verify from committed Git blobs. No state/queue/receipt/clock was seeded or edited. The repair must preserve both original September stores and this newly written October store; no changed-host success is claimed yet.

T041/T043/T044 reopen for this concrete Design upgrade regression; spec In progress. Previous round1 repairs and source-bound BPMN462/Runtime3078/Architecture594/hosting32, inverse-order cancellation5/5 and earlier recovery receipts retain their declared sources. All104 frozen baseline assets remain unchanged. One full-PR round of six completed with findings subsequently repaired; round2 has not begun. T042's unanswered owner preview-magnitude card and needs:decision, deferred GitGuardian39189012/scan, exact reviewed-head required checks, protected merge and resulting-main verification remain open. No clean round, merge eligibility or #2898/#2907/program completion is claimed. Current work: narrow migration compatibility repair and affected real-host verification; no new implementation issue or competing PR.

## #2892 6524413811 elsa-workflows-codex[bot] 2026-10-30T13:49:56Z
[Codex] On behalf of @sfmskywalker.

Implementation head `38c402d3143cafc135a1b900d1a5902dcf16c517` repairs the concrete Design migration regression exposed by the direct BPMN recovery journey. The original eight September migration sources are retained byte-exact, and all four providers add only the template table/index. An internal Design history decorator recognizes the known cumulative October Initial without rewriting physical history; offline idempotent guards retain provider quoting and configured schemas. The existing generator now protects both Runtime and Design histories and has a selected Design incremental mode. No public abstraction or execution semantics were added.

Validation so far: six offline provider/schema cases pass, and four isolated destructive-boundary generator tests pass, zero skips. The latter found and fixed the Bash empty-target case when every selected history is retained. The full standard-host suite is running at this committed source, including real original legacy recovery and the captured October template/native wait. No changed-host or final repair acceptance is claimed until terminal results. Subsequent affected migration/Design tests, provider checks and Studio repetition remain due.

[Actual failing old-store run and current-writer input](https://github.com/elsa-workflows/elsa-foundation/tree/38c402d3143cafc135a1b900d1a5902dcf16c517/specs/1017-direct-bpmn-hosting/evidence/main-adoption/931123c7e) retain source1ae57d214: normal APIs saved a real template and published/suspended native wait; two closed stores,18 committed manifested assets, all104 frozen assets unchanged. Prior Studio2 families/4 new completed runs/12 stores/13 controls retain cb0354a5b5; existing execution/ETL evidence keeps its original sources. One full-PR round of6 completed; round2 has not begun. Spec In progress; T041/T043/T044 open. Unanswered owner magnitude card, needs:decision, owner-deferred GitGuardian39189012/scan, exact required checks and protected/post-merge delivery remain open. #2898/#2907/program and Project62 remain open/In Progress/Partial. Orleans/task-runner and #3242 deferrals unchanged.

## #2892 6525466338 elsa-workflows-codex[bot] 2026-10-30T14:41:03Z
[Codex] On behalf of @sfmskywalker.

Head `4f46ac55c482b3b68932ca74f147439bfdacda49`, existing draft PR3410 and retained Codex claim6461197535. [Actual migration-repair qualification](https://github.com/elsa-workflows/elsa-foundation/tree/4f46ac55c482b3b68932ca74f147439bfdacda49/specs/1017-direct-bpmn-hosting/evidence/main-adoption/931123c7e/repair) now passes at executing source `3ac1c675729c14b1c2ad7249f43c47d33d13e37e`: authenticated direct BPMN start→wait→graceful restart→resume→complete1/1, both actual Design-history upgrade tests2/2, full migration507/507 and Design128/128, zero skips. All eight original legacy partial-fork models recover with original pins. The real October writer's saved template/native wait, [captured before changing that writer](https://github.com/elsa-workflows/elsa-foundation/tree/4f46ac55c482b3b68932ca74f147439bfdacda49/specs/1017-direct-bpmn-hosting/evidence/main-adoption/931123c7e), retains its original history row and template identity/revision, saves a second template normally, survives two further processes and completes the original published execution once. Six final whole-store archives, exact API observations and matching hashes for affected Design/shared-EF products are portable. All39 manifested repair assets verify from committed Git blobs. All104 frozen baseline assets remain unchanged; eight original September migration sources remain byte-exact.

The fix retains the September Design migrations, adds only templates for four providers and recognizes the known cumulative October Initial without rewriting physical history. The shared EF binding installs compatibility before options freeze for pooling; only four Design migrations declare an included baseline. Four generator controls and six Python3.14 workflow guards pass; the generator guard is now in CI. The cache warning remains an error. Source38's whole hosting33/33 is a separate earlier pass; its failed11/507 migration gate,5/501 existing-only control,1/2 pooled test and the intermediate2/507 cache failures remain explicit negative diagnostics.148 historical observations/backup receipts are portable;143 interim store payloads are not duplicated. No older pass is relabelled final-source or clean-review evidence. All81 listed receipt PIDs are absent, including six final-journey processes; the separate current Studio qualification hosts are owned and still running.

Frontend, Studio host and standard Workbench/reader/SDK builds pass at current head4f46ac55c. Actual adopted-template Studio repetition is now underway on private copies of the saved stores; the old cb0354a5b5 Studio receipts retain their source. T041/T043/T044 remain open; spec In progress. One full-PR round of6 completed with repaired findings; round2 has not begun. Updated API/magnitude assessment includes the new shared EF migration metadata; T042's owner card is unanswered and needs:decision stays. Deferred GitGuardian39189012/scan, exact final reviewed-head required CI and protected/post-merge delivery remain open. No clean round, merge eligibility, upgraded-host ETL, first-class direct-model Studio or wider program completion is claimed. #2898/#2907/program and Project62 remain open/In Progress/Partial. #3242 and Orleans/task-runner deferrals unchanged.

## #2892 6526296816 elsa-workflows-codex[bot] 2026-10-30T15:19:23Z
[Codex] On behalf of @sfmskywalker.

Head `bbb21b25b1a2fa40c900d4374c2a979ff21377f4`, existing draft PR3410 and retained Codex claim6461197535. [Actual adopted-template Studio qualification](https://github.com/elsa-workflows/elsa-foundation/tree/bbb21b25b1a2fa40c900d4374c2a979ff21377f4/specs/1017-direct-bpmn-hosting/evidence/main-adoption/931123c7e/studio-qualification) now passes at executing source4f46ac55c: both saved families, exact frozen JSON/XML/five-node layout, normal save/publish dialogs, four completed Published/Test workflow runs, retained original Test Runs and unchanged complete execution views after restart. Twelve coupled whole stores, twelve visually inspected screenshots and thirteen unchanged-verifier controls are retained. All six owned hosts and both qualification tabs are stopped/closed; user hosts/tabs untouched. The early Details/loading observation remains an unconfirmed diagnostic. Existing Studio compatibility is proved for these journeys; direct-model Studio acceptance is explicitly false.

[Migration repair](https://github.com/elsa-workflows/elsa-foundation/tree/bbb21b25b1a2fa40c900d4374c2a979ff21377f4/specs/1017-direct-bpmn-hosting/evidence/main-adoption/931123c7e/repair) at source3ac1c6757 passes the primary authenticated direct BPMN start→wait→restart→resume→complete1/1, both actual old/current Design-history upgrades2/2, full migration507/507 and Design128/128, zero skips. It retains both physical histories, the actual October writer's template/native wait captured before editing that writer, and all eight legacy partial-fork models' original pins. All104 frozen baseline assets remain unchanged. The newest Studio/API bundles verify99 manifested assets from committed Git blobs; raw observations/diffs remain byte-exact compressed where repository whitespace requires presentation copies. Normal Codex App Git push succeeds at this head.

CI at4f46 found two new shared EF files absent from the architecture inventory. Adding their exact entries alone passes594/594 architecture tests, maps and123-project tiers locally; no guard relaxation or production edit. This correction is committed here. Prior green PR/Core-only/three EF-container shards and all raw failures retain their sources; fresh exact-head required CI is pending. Spec Implemented is prepared in this implementation PR under the lifecycle transition rule and becomes shipped only at merge. T041/T043/T044 are evidenced; final CI remains T046.

[Updated API/version audit](https://github.com/elsa-workflows/elsa-foundation/tree/bbb21b25b1a2fa40c900d4374c2a979ff21377f4/specs/1017-direct-bpmn-hosting/evidence/main-adoption/931123c7e/api-reconciliation) refreshes publish-state23a8d3c4c: Runtime Core180 additions/0 removals, Runtime4/0, shared EF four manually reviewed public declarations/0 removals. The calculator proposes Core4.0.56/Runtime4.0.70/EF4.0.33. No binary ApiCompat or magnitude clearance is claimed. T042's existing owner card remains unanswered; needs:decision stays. Deferred GitGuardian39189012/scan, full-PR round2 of6, exact reviewed-head checks and protected/post-merge delivery remain open. One full round is completed; this evidence checkpoint is not another review round. No upgraded-host ETL, first-class direct-model Studio or program completion is inferred. #2898/#2907/#2908/program stay open/In Progress/Partial. #3242 and Orleans/task-runner deferrals unchanged. Project62 maintenance/readback already works with the App's existing organization Projects grant; no new access is currently needed.

Full-PR round2/6 has now started at exact head `bbb21b25b1a2fa40c900d4374c2a979ff21377f4`, merge base `931123c7ed45aa896539d857c6227a267d08b28f`, using independent correctness, standards and acceptance reviewers under the org protocol. One round is completed; round2 is running, with no result or clean-loop claim yet. Required exact-head CI has started.

## #2892 6526584453 elsa-workflows-codex[bot] 2026-10-30T15:30:43Z
[Codex] On behalf of @sfmskywalker.

Complete-PR author review round2/6 — completed with six surviving findings; no clean review or merge clearance.

Reviewed exact head `bbb21b25b1a2fa40c900d4374c2a979ff21377f4`; main merge base `931123c7ed45aa896539d857c6227a267d08b28f`. Three independent correctness, standards and acceptance lenses inspected the complete PR and all supplied issue/PR discussion, without seeing each other's outputs. The author checked the concrete failures and ratified rules. [Reports, original diagnostics and provenance](https://github.com/elsa-workflows/elsa-foundation/tree/0d9ba38563abaf8af3e838f6b15e622e40adb281/specs/1017-direct-bpmn-hosting/evidence/reviews/round-2) are committed at `0d9ba38563abaf8af3e838f6b15e622e40adb281`; all41 manifested assets verify from Git blobs.

1. **P2 — Immediate-completion RunBpmn admission stalls.** Supported start→end completes directly at revision1, but the first embedded terminal decision cannot pass the Running-only parent-admission shape. Native RunBpmn waits indefinitely. Permit the valid first terminal decision/result while retaining the exact live-parent cancellation compare.
2. **P2 — Publication retirement blocks accepted start replay.** After normal retirement, an identical same-caller start returns404 even though its exact Accepted receipt remains. Replay exact retained caller/source/payload/pin identity before requiring a live publication for fresh admission; preserve conflicts/foreign-scope refusal and authorization.
3. **P2 — Model EF reader leaks provider errors.** All three query methods expose raw SQLite errors instead of contextual domain errors with the original cause. Preserve requested cancellation.
4. **P2 — Human-work inspection leaks owned JSON failure.** ListWork bypasses the repaired Document reader; malformed persisted work is reported as a malformed-request JSON error. Reuse the contextual owned-state boundary.
5. **P2 — Profile refusals lose process/element context.** The closed-profile check correctly refuses unsupported constructs, but the422 response cannot locate the offending element as FR019 requires. Retain process/element/type context.
6. **P3 — Three new CLR names exceed the E6 cap.** Shorten redundant components of the unpublished extension container and two internal types, preserving Checkpoint and every wire/persisted identifier.

Dropped: no normal-route model/native identity collision survived; destructive schema downgrade is outside the declared forward/admission-off rollback contract. No runtime failure is alleged for naming. Correctness probes execute source4f46 products plus unchanged older test helpers; exact relevant source equivalence to reviewedbbb is retained. Standards probes compile the exact reviewed classes with declared dependencies; the stateless refusal probe uses the byte-identical earlier driver. No probe is relabelled current-head HTTP-host/CI proof, and original temporary paths remain historical provenance.

Acceptance independently passes397 portable controls, zero skips; verifies104 frozen assets,22 actual baseline stores,16 writer hashes,39 repair assets/six final stores and92 current Studio assets. These positives do not cover the new failures. Spec returns to In progress; T041/T043/T044 reopen for affected correction/qualification. Next: narrow fixes, red-to-green regressions, actual affected journey proof and full-PR round3. Two of six full rounds are completed; spec/plan/task reviews remain separate.

Existing Codex claim6461197535/PR3410 retained, draft/open/In Progress/Partial. Unanswered T042 magnitude card/needs:decision, owner-deferred GitGuardian39189012/scan, exact reviewed-head required CI and protected/post-merge delivery remain open. #2898/#2907/#2908/program stay open; #3242 and Orleans/task-runner deferrals unchanged.

## #2892 6526887158 elsa-workflows-codex[bot] 2026-10-30T15:44:18Z
[Codex] On behalf of @sfmskywalker.

Published head `e3ec219fcc3a93c949d2669fc585bd1e79152abe`, existing draft PR3410 and Codex claim6461197535. The six findings from [complete-PR round2](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6526582380) have narrow implementations: permit a first terminal child decision with the exact live native-parent condition; resolve an exact retained/queued start before fresh-publication admission; normalize all three model EF read failures through the existing Core store-unavailable exception with context/cause/cancellation; reuse the owned Document reader for human inspection; identify the refused process/element/type; shorten only the three new CLR names, retaining all wire/family/checkpoint identifiers.

Two full PR rounds of6 are completed. Round3 has not begun; no clean review/merge clearance. Spec In progress, affected T041/T043/T044 still open. Prior actual legacy/ETL/Studio and migration receipts retain their executing sources;104 frozen baseline assets unchanged. T042 magnitude owner card/needs:decision, deferred GitGuardian39189012/scan, exact final required CI and protected/post-merge delivery remain open. #2898/#2907/#2908/program In Progress/Partial; #3242 and Orleans/task-runner deferrals unchanged.

## #2892 6527696416 elsa-workflows-codex[bot] 2026-10-30T16:21:25Z
[Codex] On behalf of @sfmskywalker.

Published head `fcf551c789c37c722b3b07d0c1cf4aecb56a16ad`, existing draft PR3410 and retained Codex claim6461197535. [Round2 correction qualification](https://github.com/elsa-workflows/elsa-foundation/tree/fcf551c789c37c722b3b07d0c1cf4aecb56a16ad/specs/1017-direct-bpmn-hosting/evidence/reviews/round-2/qualification) now verifies all six findings at executing sourcee3ec219fc. Six focused regression cases fail before correction then pass; the actual standard-host Root stall also retains its red diagnostic. Four actual authenticated first-completion journeys now return through Root, Sequence, Flowchart and CompensationScope after process loss/restart, then retain the exact result after a third process. First input is revision1/TerminalPendingSettlement with the native return owed; the exact parent consumes it and source ACK settles revision2.16 actual whole stores/8 coupled Runtime–Design pairs,12 stopped owned hosts/recorded137 exits, complete pins/API/physical views and product hashes are portable. Four actual cases and24 copied observation controls verify; those controls are evidence checks, not runtime acceptance substitutes.

Six whole projects pass6165/6165, zero skips: BPMN465, Runtime3078, actual hosting37, RuntimeEF1782, Architecture594 and native-provider209. Raw discovery reconciles every method and the existing deferred theory expansions; maps/123-project tiers pass. Native-provider counts include PostgreSQL135, SQL Server36, MySQL35 plus three support/SQLite-plan cases, with test-owned engines and all three connection overrides cleared. The whole37-host suite also repeats actual legacy/Design histories; only the16 new immediate-completion stores are duplicated in this bundle. All104 frozen assets remain unchanged. Existing actual Studio source4f46 stays qualified for the unchanged legacy adapter/authored/persistence paths; no current-source browser run or direct-model Studio acceptance is claimed.

Refreshed main184759ce5 / #3480 is [adopted normally](https://github.com/elsa-workflows/elsa-foundation/tree/fcf551c789c37c722b3b07d0c1cf4aecb56a16ad/specs/1017-direct-bpmn-hosting/evidence/main-adoption/184759ce5) at merge833e586e7. All BPMN/Runtime/sharedEF/Design production trees remain byte-identical to qualifiede3. Main changes connection validation/dialogs plus one error-response fallback in the shared Studio SDK; successful requests and persisted workflow/layout data are unchanged. Whole Connections157/157 and the affected SDK registry34/34 pass at833, zero skips.81 qualification and7 adoption assets verify from committed Git blobs. No old result is relabelled final-head CI.

Two full-PR rounds of6 completed; round3 is starting on this combined exact head, with no clean-loop claim. T041/T043/T044 are evidenced and spec Implemented is prepared for this implementation merge, becoming shipped only at merge. The fresh API audit retains Core180 additions/0 removals, Runtime4/0 and sharedEF4 manual declarations/0 removals; no binary ApiCompat or magnitude clearance. T042's existing owner card/needs:decision, deferred GitGuardian39189012/scan, final exact reviewed-head required checks, protected merge and resulting-main verification remain open. #2898/#2907/#2908/program stay open/In Progress/Partial. Upgraded-host/wider ETL and first-class direct-model Studio remain due; #3242 and Orleans/task-runner deferrals unchanged.

## #2892 6531839570 elsa-workflows-codex[bot] 2026-10-30T19:34:01Z
[Codex] On behalf of @sfmskywalker.

Complete-PR author review round3/6 is complete, **not clean**. Reviewed exact head `fcf551c789c37c722b3b07d0c1cf4aecb56a16ad`, base `184759ce53bc251ccc81b07ec3980d804ad8fd76`. Three independent correctness/standards/acceptance reviewers examined the complete diff and all issue/PR discussion without seeing current peer reports. [Reports, raw diagnostics, provenance and actual pre-fix checkpoint](https://github.com/elsa-workflows/elsa-foundation/tree/6618636002026ecb19a34b245d242203b87ad133/specs/1017-direct-bpmn-hosting/evidence/reviews/round-3) are committed at `6618636002026ecb19a34b245d242203b87ad133`.

Five retained P2 findings:
1. Format2 concurrent service work can fault/settle while an accepted second native start remains owed forever. Preserve supported topology and durably settle/retire remaining work, including actual old-checkpoint recovery, without reviving semantics or changing native composite fault policy.
2. Valid legacy worker material with nullable omitted InputContract crashes new binding publication; deliberate contextual profile refusal is required.
3. Pending-command owned JSON leaks JsonException through start replay/command inspection; preserve execution/request context and cause.
4. Timed binding refusal omits process/task/binding context.
5. FR013/SC003 lack actual embedded ETL-originated cancellation. Existing direct-only and native-origin receipts do not prove that arm. RunBpmn→RunEtl must be cancelled through the actual ETL API and prove typed settlement/ACK/effects after process loss across declared native parents.

No retained finding is dropped; fixes and red-to-green/source-bound qualification are pending. The normal-produced faulted store, original owed source and failed cold retry were preserved before any writer change through the existing .NET SQLite backup/integrity path; no state/queue/clock/receipt seeding. Reviewer probes retain their exact executing/source-equivalence limits. Independent397 portable controls and prior6165 whole-project passes remain valid for their original scopes, not these failures.

Spec returns to In progress and affected T041/T043/T044 reopen. Three of six full-PR rounds completed; round4 is due after corrections, not started. Existing owner magnitude/needs:decision and deferred GitGuardian39189012 holds remain; neutral/skipped scan is not green. Exact final required checks, normal protected merge and resulting-main verification remain due. #2898/#2907/#2908/#2892 stay open/In Progress/Partial. First-class direct-model Studio and broader/upgraded-host ETL retain their own obligations; #3242 and Orleans/task-runner deferrals unchanged. Fresh remote main3386a1abc includes scheduler/JSON progress; affected integration will be adopted before final qualification.

## #2892 6531932943 elsa-workflows-codex[bot] 2026-10-30T19:39:08Z
[Codex] On behalf of @sfmskywalker.

Round3 correction checkpoint at `eef92c613853f80cb192a5fe462a1f929c3836a8`: C2, S1 and A1 are fixed with four focused cases failing before and passing after, zero skips. [Raw/source-bound correction evidence](https://github.com/elsa-workflows/elsa-foundation/tree/eef92c613853f80cb192a5fe462a1f929c3836a8/specs/1017-direct-bpmn-hosting/evidence/reviews/round-3/context-corrections). Legacy nullable-contract native work still runs; the new closed binding now refuses deliberately with binding/pin context. Owned queued JSON preserves its cause and execution/request/work context. Timed missing-binding refusal identifies process/element/binding. No added dependency or abstraction.

Main3386a1abc (durable-delay/JSON-binding work) adopted at5e7642e5e; the sole conflict was additive public API declarations, both retained. C1 owed-start fault recovery and A2 actual embedded ETL-originated cancellation remain open; actual old C1 store is already captured. Affected whole-project/host/Studio qualification remains due after these changes. This is correction progress within completed round3/6, not a new round or clean-loop claim. Spec/tasks stay In progress; owner magnitude, deferred scan, exact final CI/protected/post-main gates and wider program scope remain open.

## #2892 6532115926 elsa-workflows-codex[bot] 2026-10-30T19:49:05Z
[Codex] On behalf of @sfmskywalker.

At `ab76430fadf67ad531bff3f1d5107ba22399ab4f`, four of round3's five findings have corrections. C1 [final-fault physical settlement](https://github.com/elsa-workflows/elsa-foundation/tree/ab76430fadf67ad531bff3f1d5107ba22399ab4f/specs/1017-direct-bpmn-hosting/evidence/reviews/round-3/fault-correction) preserves admitted concurrent format2 topology and the exact interpreter snapshot/Faulted result. Every remaining committed native start owes actual cancellation or positive retirement. Original start retries and actual results can recover old prematurely settled frames through existing model/native queues and checkpoint authority; no new public abstraction/store is introduced. Two normal old-writer whole stores cover never-admitted and already-admitted second workers, with .NET backup receipts and source/product provenance; no state or clock seeding. Both recover without an extra native worker or semantic revival.

Four BPMN recovery cases plus the terminal-header provider case qualify. Removing the admitted-result recovery path fails its actual-store test while the never-admitted control passes; restoring passes. The provider still refuses terminal-result replacement and Running progression, and unchanged-revision mutation controls pass. Whole BPMN473 and RuntimeEF1788 pass, zero skips, on the committed correction tree's listed production blobs. Main3386 scheduler/JSON progress is included. All104 frozen baseline assets verify unchanged. These are worktree-built whole-project/persisted-port gates; the clean-commit standard Release host now builds successfully, but fresh HTTP/Studio/strict-provider qualification and final CI are not yet claimed. C2/S1/A1 retain their four focused red-to-green cases in eef92c613.

A2 actual **embedded ETL-originated cancellation** remains open; its real RunBpmn→RunEtl journey is now running. T041/T043/T044 stay open/In progress. Three completed full-PR rounds of6; round4 not started, no clean-loop claim. Owner magnitude/needs:decision, deferred GitGuardian39189012, exact final required checks, normal protected merge and resulting-main verification remain due. #2898/#2907/#2908/#2892 stay open/In Progress/Partial; wider/upgraded-host ETL and first-class direct-model Studio retain their own acceptance. #3242/Orleans/task-runner deferrals unchanged.

## #2892 6532360930 elsa-workflows-codex[bot] 2026-10-30T20:03:01Z
[Codex] On behalf of @sfmskywalker.

Head `d3b103df0c5a96d5b9c4ae4bc679b360c8ff3337` adds [actual standard runtime-only Workbench recovery](https://github.com/elsa-workflows/elsa-foundation/tree/d3b103df0c5a96d5b9c4ae4bc679b360c8ff3337/specs/1017-direct-bpmn-hosting/evidence/reviews/round-3/fault-correction/host-qualification) for both normally produced old C1 fault cuts: never-admitted and already-admitted second work. Executing production sourceab76430fa;2/2 real-host cases pass, four upgraded Workbench processes/four whole Runtime snapshots, then exact recovery survives another process loss/restart. Original pins/incarnation/authority/semantic snapshot/Faulted result remain; exact result or positive retirement settles every original source. No Design storage, SQL/clock/authority rewriting, extra worker or synthetic native carrier. All owned hosts stopped. The fixture's original probe-user differs from the logged-in account: HTTP404 correctly remains, with authorized backend recovery observed through the existing checked .NET reader. This is scoped old-store host proof, not an owner UI/Studio/other-provider acceptance claim.

[A2 initial actual Root RunBpmn→RunEtl journey](https://github.com/elsa-workflows/elsa-foundation/tree/d3b103df0c5a96d5b9c4ae4bc679b360c8ff3337/specs/1017-direct-bpmn-hosting/evidence/reviews/round-3/etl-cancellation-tooling) also executes standard sourceab76430fa. After HTTP429/process loss, the **ETL cancel API** accepts cancellation while Running; typed ETL/native/model/original-parent consumption and ACKs settle. A third Workbench retains exact truth beyond the saved retry deadline, with only the two already delivered records and no resumed shard-B request.22 raw assets/six whole coupled stores, all four journey processes stopped. The verifier now handles this actual embedded origin explicitly; its positive case fails before correction, six focused and all259 ETL evidence controls pass afterward. No ETL production semantics or architectural abstraction is added.

Four of five round3 findings are corrected. A2 remains open until fresh actual ETL-origin cancellation through Root, Sequence, Flowchart and CompensationScope all verifies; that matrix is now running from clean committed sourced3b103df0. This is progress inside completed round3/6, not round4 or clean-loop clearance. Spec/T041/T043/T044 remain In progress/open. Owner magnitude/needs:decision, deferred GitGuardian39189012, affected broader host/provider/Studio qualification, exact final required CI, protected merge and resulting-main verification remain due. #2898/#2907/#2908/#2892 stay open/Partial; #3242 and Orleans/task-runner deferrals unchanged.

## #2892 6532509625 elsa-workflows-codex[bot] 2026-10-30T20:11:45Z
[Codex] On behalf of @sfmskywalker.

All five findings from complete-PR round3 now have corrections and scoped evidence. Current published head `e86f5521a50a2757ca61080dd36565ce84022442`; the actual four-parent matrix executes clean sourced3b103df0c5a96d5b9c4ae4bc679b360c8ff3337. [Four actual embedded ETL-origin cancellations](https://github.com/elsa-workflows/elsa-foundation/tree/e86f5521a50a2757ca61080dd36565ce84022442/specs/1017-direct-bpmn-hosting/evidence/pipeline/embedded-pipeline-cancellation): Root, Sequence, Flowchart and CompensationScope each run RunBpmn→RunEtl, lose the owned Workbench after real HTTP429, recover, then accept the ordinary ETL cancel API while the original run is Running. Exact typed ETL/native/model/original-parent consumption, parent settlement and source ACKs verify. A third process stays beyond the original saved retry deadline with exactly two already delivered records, no revived shard-B HTTP request and zero owed records/bytes.24 whole coupled stores/12 Workbench/four HTTP processes; all16 owned processes stopped. No state, clock, authority, source or receipt seeding. These are actual executions, separate from259 portable evidence controls.

C1 final-fault work correction is ab76430fa: concurrent admitted format2 semantics stay supported; every residual committed native start owes real cancellation/result consumption or positive retirement. Both actual normal old-writer cuts recover on standard runtime-only Workbench and retain exact fault/pins/authority/semantic snapshot after another process loss;2/2 actual host cases/four stores/four hosts. Different-caller HTTP404 remains correctly enforced, with backend recovery inspected through the existing checked .NET reader. C2/S1/A1 are eef92c613 with four focused red-to-green cases. BPMN473 and RuntimeEF1788 whole-project passes0skip retain their exact source/blob ledger; the result-trigger removal fails as expected. All104 frozen assets remain unchanged.

Spec and T041/T043/T044 stay In progress/open while final affected qualification completes: strict native providers, changed whole projects/actual host gates and saved Studio compatibility after adopted main's scheduler/JSON work. Only then prepare exact-head round4 with three independent reviewers. Three of six full-PR rounds completed; none clean. The existing owner magnitude/needs:decision and deferred GitGuardian39189012 holds remain; no neutral/skipped scan is green. Final exact required CI, normal protected merge and resulting-main verification remain due. #2898/#2907/#2908/#2892 stay open/Partial; broader/upgraded-host ETL and first-class direct-model Studio retain their own acceptance. #3242/Orleans/task-runner deferrals unchanged.

## #2892 6532986734 elsa-workflows-codex[bot] 2026-10-30T20:38:44Z
[Codex] On behalf of @sfmskywalker.

Affected qualification at df053ce214c794e16685b0cfd15a890cabf7a0c5: whole BPMN473 and Runtime3083 pass, zero skips. The complete39-case standard-host suite is **31 passed/8 failed**, zero skips; it is not green. All eight startup failures are the same activity catalog content-authority conflict after the adopted WriteHttpResponse contract update requires a new catalog version. An isolated signal-cancellation case reproduces at low load. The restored catalog's logical CLR SourceId is its original captured deployment identity; the relocated qualification host used its new assembly folder as a different default identity.

The existing ClrReconciliationOptions contract already separates SourceId from FolderPath. The qualification controllers now carry the sole captured global CLR source identity as configuration while scanning the current build directory. They refuse ambiguous sources/conflicting explicit bindings. The product authority guard and stored authority/versions/pins are unchanged. The actual isolated signal-cancellation journey passes with this binding; closed-store comparison confirms all34 original authority rows and34 immutable version rows remain byte/value unchanged, with one normal new version appended. The full39-case suite is rerunning with the preserved binding. These controller changes and fresh full-run evidence are not yet committed/claimed complete; no old path is dereferenced as a resource.

The strict native-provider project also passes212/2120skip, including three new actual PostgreSQL/SQL Server/MySQL terminal cleanup/fence/result tests; its source-bound receipt is committed in df053ce21. All five round3 findings retain their corrections and scoped actual evidence, including the four-parent ETL-origin cancellation matrix. Current saved Studio qualification and remaining affected gates are still due, followed by exact-head round4 (three of6 full-PR rounds completed, none clean). Existing owner magnitude/needs:decision, deferred scan and final CI/protected/post-main holds remain. Program/coordinating acceptance stays open/Partial.

## #2892 6533173868 elsa-workflows-codex[bot] 2026-10-30T20:49:34Z
[Codex] On behalf of @sfmskywalker.

Published head76e8139dc7744781fba864f8247c180134eaaaed. The [relocated-source qualification](https://github.com/elsa-workflows/elsa-foundation/tree/76e8139dc7744781fba864f8247c180134eaaaed/specs/1017-direct-bpmn-hosting/evidence/reviews/round-3/relocated-source-qualification) now retains the original31/39 red run and the complete **39/39 standard-host pass, zero skips**, after carrying the original logical CLR source ID through the existing deployment option. The scanner still loads current assemblies. Product runtime/publication authority code is unchanged; original34 authorities/34 immutable versions remain untouched, with one normal new catalog version appended. The actual signal cancel/restart/settlement views and six whole stores are portable. Both saved Studio families have one captured CLR identity, and their controller preserves it for the upcoming current UI qualification.

All five round3 findings retain corrections/evidence: four actual embedded ETL-origin cancellations/24 whole coupled stores/16 stopped processes, two actual old-fault standard-host recoveries/four stores/four stopped hosts, four contextual-boundary red-to-green cases. Whole BPMN473, Runtime3083 and strict native-provider212 pass0skip at their declared sources; the native suite includes three new real SQL-engine terminal cleanup/fence/result tests. All104 frozen authoring/baseline assets remain unchanged. Fresh remaining RuntimeEF/architecture/maps/discovery gates are running from the committed helper head; current saved Studio qualification and exact-head round4 are next. No direct-model Studio, upgraded-host/wider ETL or program production acceptance is inferred.

Spec/T041/T043/T044 stay open/In progress pending final affected qualification. Three completed full-PR rounds of6, none clean; round4 not started. Existing owner magnitude/needs:decision and deferred GitGuardian39189012, final exact required CI, normal protected merge and resulting-main verification remain open. #2898/#2907/#2908/#2892 remain open/Partial; native fault-policy and Orleans/task-runner deferrals unchanged.

## #2892 6533485584 elsa-workflows-codex[bot] 2026-10-30T21:07:53Z
[Codex] On behalf of @sfmskywalker.

Head `cdc02819f852684dc855ecb111bfa261171f40b6`; [round3 correction qualification](https://github.com/elsa-workflows/elsa-foundation/tree/cdc02819f852684dc855ecb111bfa261171f40b6/specs/1017-direct-bpmn-hosting/evidence/reviews/round-3/qualification). All five retained findings have corrections and affected proof. Six changed whole projects pass **6189/6189, zero skips**: BPMN473/Runtime3083/standard host39/RuntimeEF1788/Architecture594/native providers212. Source/discovery reconciliation retains the distinct executing trees; this is not final reviewed-head CI. The original31/39 source-authority setup failure stays diagnostic; normal captured CLR SourceId configuration yields39/39 without changing the product authority guard. The whole host pass includes all six actual legacy families, both Design histories and both actual old-fault recoveries.

T041/T043/T044 are evidenced again. Implemented status is prepared in this implementation PR under the lifecycle rule and becomes shipped only at merge. Three completed full-PR rounds of6, none clean; exact-head round4 remains next. Existing unanswered API/version-magnitude/needs:decision, owner-deferred GitGuardian39189012 and scan gate, final exact required checks, normal protected merge and resulting-main verification remain open. #2898/#2907/#2908/#2892 stay open/Partial. Existing embedded Studio compatibility does not establish first-class direct-model Studio or upgraded-host/wider ETL/program production acceptance. #3242 and Orleans/task-runner deferrals are unchanged.

## #2892 6533522190 elsa-workflows-codex[bot] 2026-10-30T21:09:57Z
[Codex] On behalf of @sfmskywalker.

Complete-PR author-review **round4 of6 is in progress** on exact head `cdc02819f852684dc855ecb111bfa261171f40b6`, merge base `3386a1abcc01b5ff07f127e4bc0cc07ecbe0bc37`. Three independent correctness/standards/acceptance reviewers cover the entire PR and all issue/PR discussion; they do not share current reports. Three prior rounds completed, none clean. This is a started-round checkpoint, not a completed verdict, approval or merge clearance. No head changes while this round runs.

[Affected correction qualification](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6533484429) passes6189 changed-project cases0skip and both actual saved Studio families (four completed new runs/12 whole stores/13 controls); all104 frozen assets unchanged. The actual source boundaries, original failed diagnostics and limits remain explicit. Fresh origin/main advanced to `8b5f2b3d8662a7f31fd8b2b39d2d19e588b1cbbf`; it is not integrated into this reviewed head. Its relevance/protection requirements and affected requalification will be assessed before delivery. Existing owner magnitude/needs:decision, deferred GitGuardian39189012/scan, final exact required CI, protected merge and resulting-main verification remain open. #2898/#2907/#2908/#2892 remain open/Partial; existing deferrals unchanged.

## #2892 6533876794 elsa-workflows-codex[bot] 2026-10-30T21:30:53Z
[Codex] On behalf of @sfmskywalker.

Complete-PR author-review **round4 of6 completed, not clean**, on exact `cdc02819f852684dc855ecb111bfa261171f40b6`, merge base3386a1abcc01b5ff07f127e4bc0cc07ecbe0bc37. Three independent correctness/standards/acceptance lenses reviewed the full diff and every issue/PR comment/review without sharing current reports. The author retains all three P2 findings; none dropped:

1. C1: concurrent model admissions share a retention lease. Cancelling one can let normal publication retirement/GC delete material before another durable queue write. Actual compiled router/EF proof and a unique-lease-only control retain separate coherent whole stores.
2. S1: malformed owned timer payload escapes the public dispatcher as raw JsonException, losing execution/outbox context. Matching source/current-claim proof and a missing-payload domain control are retained; analogous owned delivery boundaries need auditing.
3. A1: actual old Faulted/TerminalSettled state can leave an admitted native worker waiting, with all19 sources Delivered and no automatic cleanup trigger. The old normal producer store, fresh standard runtime-only host failure, nine old writer products and separate supported-cancel control are preserved. The control reaches rev4/Work0/worker Cancelled/zero owed without changing the exact original semantic fault/interpreter state. Existing unadmitted/already-terminal recovery cases did not cover this cut.

All reports,102 assets and original raw/provider provenance are now committed at9414095a491ec0b82436b2beda84840e90ff0c5f in [round4 evidence](https://github.com/elsa-workflows/elsa-foundation/tree/9414095a491ec0b82436b2beda84840e90ff0c5f/specs/1017-direct-bpmn-hosting/evidence/reviews/round-4), before affected writer changes. Four full rounds completed, none clean; two remain within the original bound. This receipt fixes no finding yet. Spec In progress; T041/T043/T044 reopened pending corrections and affected actual qualification.

Review verification includes66 focused Runtime cases,259 ETL evidence controls,13 current Studio controls and independent four-case embedded ETL-origin verification. The earlier6189 whole-project positives retain their executing sources and do not prove these new cases. All104 frozen baseline assets remain unchanged, and owned reviewer processes are stopped.

A separate author binary API-shape audit passes five unsuppressed/resolved-reference comparisons against actual published Core4.0.55/56-preview, Runtime4.0.69/70-preview and shared EF4.0.32-preview binaries; embedded source commits and the fresh publish-state are retained. Three reverse-contract controls fail as expected. The initial incomplete-reference attempt remains diagnostic. This is not package/version-magnitude clearance, and T042/its unanswered card stays open.

Next: fix the three concrete findings using existing retention/cancellation/diagnostic boundaries, adopt relevant new main8b5f2b3d8 and repeat affected qualification before exact-head round5. Existing owner magnitude/needs:decision, owner-deferred GitGuardian39189012/scan, final required CI, protected merge and resulting-main verification remain open. #2898/#2907/#2908/#2892 stay open/Partial; #3242 and Orleans/task-runner deferrals unchanged.

## #2892 6534157565 elsa-workflows-codex[bot] 2026-10-30T21:46:15Z
[Codex] On behalf of @sfmskywalker.

Head ee345b6022570145220f3c90bdb0665e9b9f2168 adopts main8b5f2b3d8 through mergec2504c399 and corrects round4 C1/S1. Each physical model admission now owns a unique retention lease while queue/replay identity stays stable. The actual-router/EF cancellation→publication-retirement→GC case fails before the fix while its unique-lease control passes; both cases now pass0skip. Owned JSON interpretation is contextualized at all seven timer/native-work/native-parent start/cancel/result kinds, preserving the original JsonException and execution/source/scope/kind. All seven public-dispatcher cases fail before and pass after0skip, including two formerly wrapped errors that still lacked context. [Source-bound red/green evidence](https://github.com/elsa-workflows/elsa-foundation/tree/ee345b6022570145220f3c90bdb0665e9b9f2168/specs/1017-direct-bpmn-hosting/evidence/reviews/round-4/boundary-corrections).

A1 remains open. The actual old waiting-worker store is now wired into the permanent standard-host upgrade test. Its first formal run failed only because the harness expected the other producer's START log marker; that setup diagnostic is retained, the actual FINAL MODEL identity parser is corrected, and a verified pre-fix run is in progress. The independent round4 actual cold-host failure remains valid. The implementation will reuse existing scoped background partitions, the durable queue and ordinary fenced cancellation to settle physical work without changing the original fault/interpreter state.

Four full rounds completed, none clean; two remain. T041/T043/T044, whole affected/current-host/Studio qualification, exact-head round5 and owner magnitude/scan/required-CI/protected/post-main gates remain open. All104 frozen assets remain unchanged. #2898/#2907/#2908/#2892 stay open/Partial and existing deferrals unchanged.

## #2892 6534582253 elsa-workflows-codex[bot] 2026-10-30T22:11:33Z
checkpoint: all three retained round 4 findings have corrections on the existing branch; no competing PR. Current head `f6d3c370e5c3295bb9ea0499b0ea6adbc533b8a1`; last production correction `178154c1334a85ec3b06f0acf40360849c1f44c0`.

C1/S1: unique physical admission leases and contextual owned delivery JSON are corrected, with the existing two admission and seven public-dispatcher red/green cases. A1: automatic startup discovery now queues the existing cancellation command over the host's finite persistence scopes and paged model reader. No public protocol/input kind, state writer or native composite policy is added.

[Actual committed-source recovery receipt](https://github.com/elsa-workflows/elsa-foundation/tree/f6d3c370e5c3295bb9ea0499b0ea6adbc533b8a1/specs/1017-direct-bpmn-hosting/evidence/reviews/round-4/fault-recovery/README.md): all three old checkpoints pass, zero skips, including the admitted native Flowchart worker still waiting after its sibling faults. Six stopped Runtime stores, distinct killed/restarted processes, unchanged exact semantic fault/interpreter state/pins/incarnation/authority, and zero queued/owed work are retained. The corrected native host profile's registration-disabled control gives two passes and the one expected waiting-worker failure. Earlier incomplete native profiles and the temporary diagnostic trace are retained honestly; the trace line is absent from the executing commit.

Whole affected qualification, current standard-host/Studio evidence and full-PR round5 remain due. Four full-PR rounds completed, none clean; two left. T041/T043/T044 stay open. Existing owner API/version-magnitude/needs:decision, deferred GitGuardian39189012/scan, final required CI, protected merge and resulting-main gates remain open. #2898/#2907/#2908/#2892 stay open/Partial; #3242 and Orleans/task-runner deferrals remain unchanged.

## #2892 6534697541 elsa-workflows-codex[bot] 2026-10-30T22:19:10Z
checkpoint: legitimate main4ab657f72 is adopted without conflict in `30dfb0a9b7ee46b59ef90e18b548162fa5a96c3f` and pushed to the existing draft PR3410. This includes the Usage startup initialization and execution-toolbar polling fixes. The preliminary f6d3c370e Studio pairs are stopped and their owned tab closed; no completed browser journey is claimed for those preliminary pairs. The final saved Studio journeys will use the integrated source.

At sourcef6d3c370e, whole BPMN481, Runtime3083 and RuntimeEF1790 pass with zero skips; the corrected architecture run passes594/594, zero skips. The40-case standard host run on that same source is still executing and its products will not be overwritten. The five binary API-shape comparisons pass again against the actual recorded previews with resolved references and no suppressions; fresh publish-statef4482d87 retains those same Core/Runtime/EF versions. Compared production assembly sources are unchanged by this main integration. This does not clear the owner's version-magnitude card.

All three round4 corrections and the actual three-cut recovery receipt remain retained. Final current-main affected qualification/Studio, full-PR round5, existing owner magnitude/needs:decision, deferred scan, required CI and protected/post-main delivery remain open. Four full-PR rounds completed, none clean; two left. T041/T043/T044 and #2898/#2907/#2908/#2892 remain open/Partial; existing deferrals unchanged.

## #2892 6535636146 elsa-workflows-codex[bot] 2026-10-30T23:24:45Z
checkpoint: committed correction qualification in `7a05e2097`, executing current-main source `30dfb0a9b`: all six affected suites pass **6200/6200, zero skips**, including the complete **40-case standard-host matrix**. Actual old-fault recovery passes all three cuts. Both actual saved Studio families pass with four new completed Published/Test Runs, 12 whole coupled stores, 12 inspected screenshots, 13 passing controls and unchanged original JSON/XML/layout/state. All 104 frozen baseline assets remain unchanged. Ten directional binary API comparisons cover all seven changed published assemblies and pass without suppressions or unresolved references. [Portable source-bound evidence](https://github.com/elsa-workflows/elsa-foundation/tree/7a05e2097/specs/1017-direct-bpmn-hosting/evidence/reviews/round-4/qualification).

Subsequent legitimate main `7b4951365` is integrated and pushed as `78554070a07b5a71481abf106bf33e12acc6fa19`. Its four files only adjust Inspector spacing and Sequence-card presentation. A targeted affected editor test/build/smoke check is underway. Backend source/persistence writers are unchanged; full recovery receipts retain their executing sources, without relabelling them as new runs.

All three round4 findings are corrected. Four complete PR rounds have finished, none clean; round5 has not started and two remain. T041/T043/T044 stay open until this final affected UI check/consolidation. Existing owner version-magnitude/needs:decision, deferred GitGuardian39189012, exact-head clean review/required checks, protected merge and resulting-main verification remain open. Existing Studio compatibility is proved; first-class direct-model Studio and wider/upgraded-host ETL are not. #2898/#2907/#2908/#2892 remain open/Partial; native-fault policy #3242 and Orleans/task-runner deferrals are unchanged.

## #2892 6535745221 elsa-workflows-codex[bot] 2026-10-30T23:33:04Z
Full-PR self-review round 5 starting on exact head `1e707d58fc2148be3715d50616dfdb69dc82ae65`, base `7b49513650665606e5f52fdc08c5831f60802dac`. Four full rounds completed, none clean; this is the fifth of the six-round bound. Three independent read-only lenses will inspect the full diff and every issue/PR comment/review: correctness, repository standards and acceptance. No clean result is assumed.

[Correction qualification](https://github.com/elsa-workflows/elsa-foundation/tree/1e707d58fc2148be3715d50616dfdb69dc82ae65/specs/1017-direct-bpmn-hosting/evidence/reviews/round-4/qualification/README.md): six affected suites6200/6200, zero skips, including40 standard-host cases and three actual old-fault recovery cuts. Both actual saved Studio families retain four completed new runs,12 whole stores,13 controls and unchanged original authoring/state. Ten binary comparisons cover every changed published assembly. After main7b's four frontend-only files,12 Sequence tests, both exact saved exports and the attached Run data Inspector after a completed Test Run pass at78554070a. Three screenshots and eight additional coherent stores are retained. All104 frozen baseline assets are unchanged; all owned hosts/tabs are closed. Each receipt retains its actual executing source.

The preceding78554070a CI integration build failed MSB3030 because an original fixture log was excluded by the Git ignore rule. This head restores that hash-exact log and12 other manifest-listed original logs; no runtime/test/verifier/history changed. All explicit Hosting fixture files are tracked, and the affected Hosting project builds with0 errors. Two raw historical logs retain their original trailing blank lines; their existing hashes were preserved. Old failed CI is not called green; final exact-head CI is required.

T041/T043 are evidenced, T044 prepares Implemented in this implementation PR under the lifecycle transition rule, effective only on merge. T042 owner API/version magnitude/needs:decision, deferred GitGuardian39189012, clean review, required checks, normal protected merge and resulting-main verification stay open. #2898/#2907/#2908/#2892 remain open/Partial. First-class direct-model Studio, wider/upgraded-host ETL and existing native-policy/Orleans/task-runner deferrals are unchanged.

## #2892 6535926604 elsa-workflows-codex[bot] 2026-10-30T23:46:28Z
Complete-PR self-review round 5 — **not clean**

Reviewed exact head `1e707d58fc2148be3715d50616dfdb69dc82ae65`, base `7b49513650665606e5f52fdc08c5831f60802dac`. Three independent correctness/standards/acceptance lenses completed the whole PR and all discussion. **Four P2 findings adopted, none dropped.**

- C1, RuntimeExecutionProtocolRouter.cs:57 / WorkflowSchedulerDrainer.cs:220: fully settled model executions never trigger the built-in terminal mailbox eviction. Eight actual completions retain eight mailboxes; explicit passivation releases them and exact retained replay still works.
- S1, RuntimeExecutionProtocolSelector.cs:42, plus the analogous direct router decode: malformed owned model envelopes escape as raw JSON errors without execution/input/work context. Actual EF queue claim remains unchanged.
- S2, EfRuntimeCheckpointCommitStore.cs:150: a model-only checkpoint misses provider-error normalization. The valid physical SQLite transaction rolls back completely on final-marker failure, but exposes the raw EF exception without model execution/input/scope/commit context. The identical no-fault commit succeeds.
- A1, BpmnLegacyFaultWorkRecovery.cs:30–31: startup skips an actual old embedded fault still awaiting its native parent. One upgraded standard host consumes the parent result and leaves another Event worker Running, despite delivered sources and empty queues. A second normal startup clears the same worker, proving the missing trigger.

[Committed reports, controls and actual old whole-store input](https://github.com/elsa-workflows/elsa-foundation/tree/f450993c30747ee07110f8f531c77c895deceabb/specs/1017-direct-bpmn-hosting/evidence/reviews/round-5/README.md) in `f450993c30747ee07110f8f531c77c895deceabb`, before any affected correction. The actual e3ec old writer creates the pending-parent input through ordinary production ports; its decoded SHA256 is `0a5ea64058dcdb950fdda9e5b792264ceec2f6ca19fa9398a7733f6c62ea097e`. Exact1e cold-host failure and same-store second-start control preserve original semantic fault/interpreter state, pins/incarnation/authority; all owned hosts are stopped. No SQL state/queue/receipt/authority edits. Five complete rounds finished, none clean; **one remains under max6**.

Independent tests: correctness481 BPMN plus50 focused EF pass0skip at the declared byte-equivalent product source; acceptance259 ETL and13 current Studio controls pass; standards migration generator4/4. These are distinct from retained6200/0 and actual full Studio receipts and do not substitute for affected correction qualification or exact-head CI.

T041/T043/T044 and In progress reopen. Fix the four findings with meaningful red/green controls and actual one-cold-host old-input recovery, then affected qualification and final full-PR round6. Existing owner API/version-magnitude/needs:decision, deferred GitGuardian39189012/scan, exact required checks, protected merge and resulting-main verification remain open. #2898/#2907/#2908/#2892 stay open/Partial; direct-model Studio, wider/upgraded-host ETL and existing deferrals unchanged.

## #2892 6536225213 elsa-workflows-codex[bot] 2026-10-31T00:06:49Z
checkpoint: all four round5 findings have corrections in `a50a31e3ec45993c304b068638bf52fefd3aa2b5`. [Red/green controls](https://github.com/elsa-workflows/elsa-foundation/tree/a50a31e3ec45993c304b068638bf52fefd3aa2b5/specs/1017-direct-bpmn-hosting/evidence/reviews/round-5/corrections/README.md) retain every attempted repair and its status.

- C1: use the committed model's TerminalSettled result for existing mailbox eviction after the permitted drain, while retaining the native stop/purge distinction. Eight completed models release mailboxes; late reactivation/replay and an active human wait remain correct.
- S1: contextual shared envelope failures before fresh admission or durable claim, retaining the original JSON/owned-constructor cause and exact identities. Four cases pass; actual physical queue claims remain unchanged.
- S2: model-only provider errors retain scope/execution/input/commit context and the original cause. All47 model checkpoint tests pass, including complete rollback, replay, cancellation, fencing/CAS and original retention-domain outcomes.
- A1: the actual parent-ACK model decision introduces existing cleanup after consuming the ACK. This avoids the demonstrated FIFO cycle from the initial startup-both-lifecycles attempt. All four actual old-fault standard-host cases pass, including the original pending-parent input: one cold host cancels the original Event worker, settles its native result and parent ACK, preserves original fault/interpreter state/pins/authority, then remains unchanged after another real process loss.

Those are explicitly precommit worktree controls, not final committed-head CI or a clean review. The original old input was committed before writer correction. The initial too-broad error wrapper, startup FIFO cycle and omitted observer argument remain distinct failed diagnostics; none is relabelled green.

Remote refresh found legitimate main `d2f99623d` (#3492 BPMN Decision authoring/publication), now integrated in `04c2b53adf7b8eeda6cdf2c879f697b867fc5ad2`. Both independent README contributions are retained and the combined dependency lock passes normal **locked restore**. Since main changes authoring and publication, final qualification includes fresh actual saved Studio journeys as well as affected native/model/host/provider/compiler tests. No old machine path or temporary database is required by the new permanent legacy test.

T041/T043/T044 and spec In progress stay open until affected qualification. Five complete full-PR rounds finished, none clean; final round6 has not begun. Existing owner magnitude/needs:decision, deferred GitGuardian39189012, exact required CI, protected merge and resulting-main verification remain open. #2898/#2907/#2908/#2892 remain open/Partial; broader Studio/ETL/native-policy/Orleans/task-runner deferrals unchanged.

## #2892 6536652324 elsa-workflows-codex[bot] 2026-10-31T00:41:01Z
checkpoint: round5 corrections are qualified and retained in e950fb9d5. Actual executing source04c2b53ad passes **6928/6928 across eight whole backend suites, zero skips**: BPMN492, Runtime3083, RuntimeEF1790, Architecture594, strict native-provider212, standard-host41, Publishing61 and Design655. Discovery method sets reconcile, including deferred theories. Locked restore, maps/123-project tiers,52 frontend tests and builds pass.

All four actual old-fault cases pass through normal cold-host recovery and another SIGKILL; eight closed Runtime stores retain physical truth, original state/pins and actual product hashes. The original pending-parent ACK now cancels the remaining Event worker in that consuming decision. Original pre-fix input and failed repair diagnostics remain separate.

Remote main advanced with frontend-only Switch authoring #3495. It is adopted without conflict and pushed in `9c7681c56c529c8a1a4ab4d9fc91934ec07d0448`. Backend sources remain unchanged from04c; affected editor/build smoke is running before final round6. Five complete-PR rounds have finished, none clean; one remains and has not started. Existing owner magnitude/needs:decision, deferred GitGuardian39189012, exact required CI, protected merge and resulting-main gates remain open. #2898/#2907/#2908/#2892 stay open/Partial; all existing deferrals remain. Current Project access works; no additional App permission is needed. The goal is active and normal engineering tools work; no safeguard setting was changed.

## #2898 6234213665 elsa-workflows-codex[bot] 2026-10-17T13:04:14Z
Isolated operational host evidence is committed and pushed at `0613e988ca263ce31d514f71857b067629bb4572`. Root independently ran the pinned real-interpreter witness successfully: fresh-process fork/join, timer/human race orders, fault dispositions/incidents, definition pinning, foreign/stale handles, and persisted Sequence-style parent progression. Direct and composed child traces match.

[Review and evidence boundaries](https://github.com/elsa-workflows/elsa-foundation/blob/0613e988ca263ce31d514f71857b067629bb4572/docs/reports/unified-execution/witness-review-2026-10-17.md). This is a custom experimental host adapter, not current Elsa native integration or a takeover of #2735. Validated modeled message delivery is not arbitrary token alteration. Upstream dependency NU1902 remains recorded. The evidence is available for program review; no production migration acceptance claimed.

## #2898 6234455384 elsa-workflows-codex[bot] 2026-10-17T13:29:42Z
Research checkpoint: root independently rebuilt and ran the full real-interpreter host witness, including the ETL service-task bridge. Evidence and source hashes are committed at `2176219c8` on `agent/codex/2896-shared-work-proof`.

The bridge now survives hard exits after partial pipeline provisioning, after ETL completion before BPMN receipt creation, and after the BPMN callback/receipt transaction commits. Fresh-process replay preserves two partitions/four source rows/two initial work rows and one callback. Success, caught business error, propagated worker fault and interrupting cancellation paths passed.

Limits remain explicit: separate stores have no shared transaction; work cancellation does not terminalize the experimental ETL model; arbitrary token alteration is rejected, not implemented. These are inputs to the reviewed architecture decision and production follow-ups. Build passed with the pinned upstream Microsoft.Build.Tasks.Git advisory warnings. Production BPMN migration ownership is unchanged.

Evidence: https://github.com/elsa-workflows/elsa-foundation/tree/2176219c8/tools/experiments/UnifiedExecution.BpmnProof/evidence


## #2898 6234528166 elsa-workflows-codex[bot] 2026-10-17T13:36:47Z
The bounded BPMN investigation is delivered: actual pinned interpreter, restart/races, direct/child traces and recoverable ETL service bridge passed. Two original acceptance items remain deliberately unchecked: released parity clearance (source-pin research used the owner exception) and arbitrary validated alteration (unsupported; modeled event delivery is not alteration). These are explicit negative/deferred findings, assigned to existing #2735 and product #2907. This issue stays open for disposition; it is not a request to pause the delivered research or take over production migration.

Evidence and recommendation: https://github.com/elsa-workflows/elsa-foundation/tree/4b464e163/docs/reports/unified-execution/acceptance-audit.md

## #2898 6461197535 elsa-workflows-codex[bot] 2026-10-28T05:09:59Z
claim: codex starting

## #2898 6461459146 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6461657762 elsa-workflows-codex[bot] 2026-10-28T05:43:29Z
pr: https://github.com/elsa-workflows/elsa-foundation/pull/3410

Specification committed and pushed at `ad683917c41d46f079bd3d7af7fafc2104a456c3`, branch `agent/codex/2898-direct-bpmn-hosting`, base `d3ebb980e2dbebeed680808e58c1edd694fae0f7`. [Spec1017](https://github.com/elsa-workflows/elsa-foundation/blob/ad683917c41d46f079bd3d7af7fafc2104a456c3/specs/1017-direct-bpmn-hosting/spec.md) defines five journeys, 22 functional requirements and six observable success criteria. Initial author checklist and structural/link checks pass. Independent correctness, standards and acceptance specification reviews are running; no plan or implementation approval is claimed.

The current draft contains specification only. Next: resolve specification findings, then reviewed plan and tasks. Capture actual current-host checkpoints before changing any affected writer. No runtime acceptance or #2898/#2907 closure is claimed; the full program goal remains active. Delivery-time broadcast matching with a durable first-recipient snapshot is retained.


## #2898 6462170896 elsa-workflows-codex[bot] 2026-10-28T06:17:12Z
Specification and implementation plan are independently reviewed; [planning receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6462168774). Task list is committed/pushed at `62c33169a19c71fb57a352709a0ab36e27334f6b` in draft3410, with task review and cross-artifact consistency pending. No production writer/schema has changed. Actual capture precedes writer edits; all production acceptance remains open.

## #2898 6462603876 elsa-workflows-codex[bot] 2026-10-28T06:47:11Z
T001 capture tooling verified at `8e5d4686ac51e7b2d528f298d09862fa690253b4`; [full review/capture checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6462601743). Eight actual old-writer runs and whole stores are committed with source identities and frozen authoring proof;12capture tests/controls pass. T002 remains open before writer changes. No direct-host or upgraded-host recovery acceptance is claimed; all issue production criteria remain unchecked.

## #2898 6463521105 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6463958632 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6464794182 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6480185309 elsa-workflows-codex[bot] 2026-10-28T20:41:00Z
[Codex] On behalf of @sfmskywalker.

Immediate delivery priority: genuine direct BPMN start → wait → host restart → resume → complete. Introduce only the mechanisms that this real journey needs; retain the existing claim, compatibility gates and full issue/program scope. [Current objective and ETL follow-up recommendation](https://github.com/elsa-workflows/elsa-foundation/issues/2892#issuecomment-6480176858). Project #62 overview now follows this lane; no acceptance or review round is marked complete by this sequencing checkpoint.

## #2898 6482493343 elsa-workflows-codex[bot] 2026-10-28T22:38:17Z
Continuation at `33e3c140fd3307e2d2d98af05e027a0f9880fe43`: protected model queue/pre-claim refusal and unchanged native EF budgets are qualified; T009 remains partial. [Current implementation and evidence checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6482464958). Verified protocol selection and the real BPMN driver are next. No model admission/direct recovery/actual changed-host/Studio acceptance; draft and existing claim retained. Project62 remains In Progress / Partial and its overview is current.

## #2898 6483930276 elsa-workflows-codex[bot] 2026-10-28T23:59:20Z
Initial real direct human recovery milestone pushed at `9c6eaa314f4b986b382d934eabcf197b8d7f79c6`. Initial direct BPMN authenticated start → human wait → owned process exit/restart → exact completion passes on production Workbench, built-in single-node mailbox/EF SQLite. Full pin/incarnation/attempt and revision survive; stale attempts are rejected, exact replay adds no revision and native workflow/activity/bookmark rows are zero. Actual protocol selection and released-library driver are wired; accepted first-input rooting and admission-off recovery pass. 1,320 local checks, maps/tier checks and final locked restore pass. Source `48bf343b51f9db4c682bacb737758d0c6dbdcfbc`; evidence head `9c6eaa314f4b986b382d934eabcf197b8d7f79c6`. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/9c6eaa314f4b986b382d934eabcf197b8d7f79c6/specs/1017-direct-bpmn-hosting/evidence/direct-recovery); [checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6483911994). This is an initial same-source combined-host human profile; runtime-only, actual changed-host/legacy/Studio/clustered placement, full fork/race/settlement/source-admission and native/ETL integration gates remain open. Full-PR rounds0; PR stays draft, new-head CI and external GitGuardian owner action pending. #2898/#2907/program remain open.

## #2898 6484000255 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6484640574 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6485121309 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6489729696 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6490569817 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6490932492 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6491352014 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6492051835 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6492384215 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6493202988 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6494290554 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6496012928 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6496609027 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6497740401 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6498120556 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6498578845 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6499016240 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6499523138 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6500191297 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6500835550 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6501663981 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6502221963 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6502456142 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6503046658 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6503984416 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6504213538 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6505025082 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6505468498 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6506144293 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6506797160 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6507618960 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6507818474 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6508120818 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6508993060 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6509215261 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6510129373 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6510722288 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6510968408 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6511203129 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6511253485 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6511882212 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6512226006 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6513107015 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6513439141 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6513876413 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6514567458 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6515059830 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6515275619 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6515474515 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6516144909 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6516275074 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6516803672 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6516923644 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6522036478 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6522222483 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6522530930 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6522933761 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6524214512 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6524413127 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6525465552 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6526295570 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6526583448 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6526886336 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6527695598 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6531838734 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6531932266 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6532115264 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6532360139 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6532508914 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6532985877 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6533173257 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6533485012 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6533521554 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6533876219 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6534156887 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6534581733 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6534697041 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6535635705 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6535744757 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6535925938 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6536224579 elsa-workflows-codex[bot] duplicate body already reviewed

## #2898 6536651814 elsa-workflows-codex[bot] duplicate body already reviewed

## #2907 6281858047 elsa-workflows-codex[bot] 2026-10-20T02:23:26Z
Clarified owner-approved BPMN operational foundations, explicit deferrals and #2735 ownership; all production acceptance remains unchecked and not ready.

Program metadata reconciliation only. #3056 / PR #3087 remains the sole implementation leaf; no source, claim, review gate or external-release change.

<!-- program-coverage-reconciliation-20261020-2907 -->

## #2907 6391986221 elsa-workflows-codex[bot] 2026-10-25T01:32:37Z
Upstream prerequisite #34 / PR #52 is delivered: Code Review approved exact head `3cbb2c0` and merged it as `f0fc3ac143e242d959fe799abc64fe3af7a1bbdf`. Exact-merge build/test/pack, configured Feedz preview (`0.4.0-preview.53`) and wiki jobs pass; 969 tests pass with no failures/skips. [Final receipt](https://github.com/valence-works/bpmn/pull/52#issuecomment-6391983505).

This supplies refused collection reads with exact host faults and null BPMN ErrorCode. It is not stable-release adoption or proof of the six Foundation acceptance/operational criteria above. Those checkboxes remain open; #2735 retains adoption/parity ownership. Remaining upstream library leaves are being refreshed through the shared queue.

<!-- bpmn2907-pr52-f0fc3ac -->


## #2907 6392195564 elsa-workflows-codex[bot] 2026-10-25T01:57:17Z
Upstream BPMN prerequisites #34/PR52, #35/PR55 and #36/PR56 are now merged and resulting-main verified. Latest merge `a33c10e9abfecbe681ff1cd63e600fd8cfcb0de3` passes 984 tests with no failures/skips; configured Feedz preview and wiki jobs succeeded, NuGet.org skipped. [Latest receipt](https://github.com/valence-works/bpmn/pull/56#issuecomment-6392194091). The ordering contract, refused-read fault isolation and optional scheduling provenance are qualified within their upstream scope.

The next parity leaf #38 is being refreshed through the single shared implementation queue. All six Foundation acceptance/operational checkboxes above remain open; #2735 retains released-library adoption/parity ownership. No Foundation adoption or stable-release claim follows from these upstream previews.

<!-- bpmn2907-three-prerequisites-a33c10e -->

## #2907 6392529968 elsa-workflows-codex[bot] 2026-10-25T02:36:43Z
BPMN source-scenario port #38 / PR93 is merged and exact-merge verified: https://github.com/valence-works/bpmn/pull/93#issuecomment-6392528898. 1,207 tests pass on reviewed head and resulting main; all242 pinned methods accounted (197 ported,23 main,19 host obligations,3 intentional differences). Feedz preview56 exists; NuGet.org skipped and current stable does not contain it. The six Foundation production/adoption acceptance items stay open and #2735 keeps its owner. Active program implementation now resumes #40/PR58; no whole-feature completion claim.

<!-- bpmn38-parent-checkpoint-a8e3105 -->

## #2907 6392671680 elsa-workflows-codex[bot] 2026-10-25T02:53:43Z
Upstream #40/PR58 safe canceled-token pruning is merged and exactmerge verified: https://github.com/valence-works/bpmn/pull/58#issuecomment-6392670507. Current-head and resulting-main gates each pass1,214tests, samples/guard verified, Feedzpreview57 and wiki succeeded; NuGet.org skipped. No unconditional bound or Foundation adoption claim. Foundation #2735 owner and six production acceptance gates remain; approved issue7 is the sole implementation leaf.

<!-- bpmn40-parent-9c023d2 -->

## #2907 6392871154 elsa-workflows-codex[bot] 2026-10-25T03:17:59Z
Upstream #7/PR94 is complete at3db18aa: https://github.com/valence-works/bpmn/pull/94#issuecomment-6392869873. Exacthead and resultingmain each pass1,227tests; Feedzpreview58/wiki succeed, NuGet.org skipped. Default imports preserved, explicit host availability and real Call Activity escalation/ordinary-task compensation witnesses verified. Add both new capabilities to stable-release notes. The reviewer’s optional late Cancelled completion after Call Activity teardown is retained for later host lifecycle qualification, not claimed as new conformance proof. All six Foundation acceptance items remain open; #2735 retains its owner. Active implementation is queued diagnostic follow-up92.

<!-- bpmn7-parent-3db18aa -->

## #2907 6392888982 elsa-workflows-codex[bot] 2026-10-25T03:20:10Z
[Codex] On behalf of @sfmskywalker.

The next stable-library boundary is now durably tracked in https://github.com/valence-works/bpmn/issues/95. Targetv0.5.0 from qualifiedmain, with explicit77wire/76QName investigation,92completion, milestone dispositions, migration/schema/package-backed evidence and actual four-package NuGetverification. Existing release authority applies; no release is claimed yet. This is queued/unclaimed and does not replace #2735 ownership or #2898 selected-release parity. #92 remains the sole implementation leaf.

<!-- bpmn-stable-release-gate-20261025 -->

## #2907 6393057581 elsa-workflows-codex[bot] 2026-10-25T03:40:53Z
BPMN #92 / [PR #96](https://github.com/valence-works/bpmn/pull/96) is delivered: merge `61e0589a494a0817494a690b464d09c5658e5010`, protected cycle 2 clean, resulting-main 1,245 tests green. Structured IDs now identify all nine known-element family refusals; rejection messages and conditions are unchanged. [Final evidence](https://github.com/valence-works/bpmn/pull/96#issuecomment-6393056253). Preview .59 is not stable adoption. #77 is the sole current implementation; release-readiness #95, owner-held #2735, selected-release parity #2898 and all six production acceptance items remain open.

## #2907 6393160092 elsa-workflows-codex[bot] 2026-10-25T03:53:56Z
BPMN #77 / [PR #97](https://github.com/valence-works/bpmn/pull/97) delivered, merge `37a402b8d1dbbfbcc25bb1d1b56367988823a437`; protected cycle2 approved and exact resulting-main 1,251 tests green, preview .60 and wiki push verified. [Receipt](https://github.com/valence-works/bpmn/pull/97#issuecomment-6393158577). Computed HasValue is omitted from host-value JSON while legacy strict reads/C# API remain; published payload roots are unchanged. #76 QName fidelity is the sole current implementation; release #95, owner-held #2735, selected-release #2898 and the six #2907 production acceptance items remain open.

## #2907 6393410858 elsa-workflows-codex[bot] 2026-10-25T04:24:55Z
BPMN #76 / [PR98](https://github.com/valence-works/bpmn/pull/98) delivered: merge `48663f298bb75225b6045446a53ad9282115c83a`, protected cycle3 approved and exact-main1,268 tests/preview61/wiki verified. [Receipt](https://github.com/valence-works/bpmn/pull/98#issuecomment-6393409262). Payload1.10 QName-value context is durable through JSON with documented lexical/refusal limits. Release95 is the sole active leaf and includes one newly reproduced serialization-shadowing repair before publication; no stable-release or Foundation-adoption completion. #2735 ownership/#2898 parity and all six production criteria remain open.

## #2907 6393861316 elsa-workflows-codex[bot] 2026-10-25T05:20:57Z
[Codex] On behalf of @sfmskywalker.

Stable prerequisite delivered: BPMN v0.5.0 at `021d2c5bba494f17d346144d97763cd3b2a13a4b`. PR99 merged with exact-head approval; main and release CI passed 1,271 tests. All four publicly downloaded packages, signatures, both framework executions and all eight public symbols are verified. [Permanent receipt](https://github.com/valence-works/bpmn/releases/download/v0.5.0/bpmn-0.5.0-qualification.json); [final evidence](https://github.com/valence-works/bpmn/pull/99#issuecomment-6393844989).

[Handoff to #2735](https://github.com/elsa-workflows/elsa-foundation/issues/2735#issuecomment-6393837314) preserves its owner. All six production criteria remain open, and #2898 remains blocked on selected-release parity/adoption and scheduling. No Foundation adoption or complete-program claim.

<!-- bpmn95-parent2907-complete -->

## #2907 6461459702 elsa-workflows-codex[bot] duplicate body already reviewed

## #2907 6526358785 elsa-workflows-codex[bot] 2026-10-30T15:22:14Z
[Codex] On behalf of @sfmskywalker.

Existing #2898 / draft PR3410 is at `bbb21b25b1a2fa40c900d4374c2a979ff21377f4` with full-PR round2 running after round1 repairs. Actual direct BPMN recovery and service/human/timer/cancellation/incident API journeys are source-qualified in the [current checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6526294297). Both saved Studio families now survive adopted-template upgrade, normal save/publish/run and restart, retaining exact authoring/layout/pins (4 new runs/12 stores/13 controls at4f46ac55c). This is existing embedded Studio compatibility, not first-class direct-model Studio acceptance. The implementation is unmerged; coordinating acceptance remains unchecked until its own delivery/verification. Version-magnitude choice, deferred GitGuardian39189012/scan, exact reviewed-head required checks and protected/post-merge delivery remain open. Existing #3242 fault-policy disposition and Orleans/task-runner deferrals are unchanged. No second implementation claim or competing PR is created.

## #2908 6279805321 elsa-workflows-codex[bot] 2026-10-19T23:42:34Z
ETL readiness audit — production scope preserved, implementation not activated

Audited source: Foundation `b656e3a8ed8bc59d02291da4af3912fd16b7139b`. Independent read-only audit plus root source/issue review; no code, builds, claims or new leaf. #3056 remains the sole active implementation leaf.

The [owner-approved continuation](https://github.com/elsa-workflows/elsa-foundation/issues/2892#issuecomment-6249319967) already approves finite batches and continuous integration; CSV/JSON Lines; paginated JSON HTTP ingestion/JSON delivery; PostgreSQL and SQL Server snapshot/watermark reads and transactional keyed writes; RabbitMQ JSON ingestion/delivery with manual acknowledgements and publisher confirms. It also requires partition-owned positions, bounded local mapping/filter/validation/routing/lookups, record and byte admission, destination idempotency and stale-progress rejection. Workflow/BPMN invocation, parent outcomes and Studio remain delivery requirements. These are the full end state, not optional follow-ups to a files-only prototype. Log CDC, stage shuffle, windows/stream joins and general analytics remain deferred; physical effects remain at least once unless a connector proves stronger behavior.

| Surface | Current evidence and limit |
|---|---|
| Existing `Pipelines.Core` | [PipelineBuilder](https://github.com/elsa-workflows/elsa-foundation/blob/b656e3a8ed8bc59d02291da4af3912fd16b7139b/Essentials/src/Pipelines/Core/PipelineBuilder.cs) composes per-message middleware delegates. This is real production infrastructure, but supplies no ETL run/partition/cursor/checkpoint model. |
| Native durable background work | [BackgroundActivityWork](https://github.com/elsa-workflows/elsa-foundation/blob/b656e3a8ed8bc59d02291da4af3912fd16b7139b/Essentials/src/Workflows/Runtime/Core/Models/BackgroundActivityWork.cs) pins a workflow activity invocation, attempt, executable and correlated terminal receipt. Reusable mechanisms need evidence-led extraction; these workflow-specific types do not already implement ETL semantics or byte budgets. |
| Partition and outcome witnesses | The [historical acceptance audit](https://github.com/elsa-workflows/elsa-foundation/blob/b656e3a8ed8bc59d02291da4af3912fd16b7139b/docs/reports/unified-execution/acceptance-audit.md) describes experimental WorkProof/BpmnProof, not production Elsa integration. It explicitly retains separate non-atomic stores and experimental fault/cancel runs left Running with cancelled work. Do not adopt that limitation as production behavior or count the witness as completed ETL delivery. |
| Connectors and continuous lifecycle | Bounded inspection of current `Essentials/` and `Extensions/` found no production ETL connector/run implementation meeting this matrix. A workflow HTTP activity and SQL persistence-provider support are not those connectors. Real replay, acknowledgement and checkpoint evidence is still required per connector and per SQL engine. |
| Studio | Bounded inspection of `Studio/src` and `Studio/tests` found no ETL run/partition authoring or inspection surface. Connection-selection UI is not pipeline execution. |

Dependency correction: #2904 is already CLOSED/status:done with all its bounded architecture-packet criteria checked. Its completion should not be requested again. That does not qualify production ETL or make #2908 independently pickable: the ordered program/shared queue and actual ETL design gates still apply. The older deferred/readiness wording must be interpreted through the later approved continuation.

<!-- etl-production-readiness-b656e3a8 -->

## #2908 6281858471 elsa-workflows-codex[bot] 2026-10-20T02:23:28Z
Consolidated approved connector/partition/transform/budget/replay/Studio acceptance on the owning feature; all production criteria remain unchecked, with no new ready leaf.

Program metadata reconciliation only. #3056 / PR #3087 remains the sole implementation leaf; no source, claim, review gate or external-release change.

<!-- program-coverage-reconciliation-20261020-2908 -->

## #2908 6288126715 elsa-workflows-codex[bot] 2026-10-20T09:44:30Z
First production child #3109 is now claimed for specification/implementation: [claim](https://github.com/elsa-workflows/elsa-foundation/issues/3109#issuecomment-6288097403). It uses the qualified built-in host and does not depend on deferred Orleans. Finite file/native/Studio evidence will not check off the full continuous/connector/BPMN feature.

<!-- 20261020-finite-etl-child-start -->

## #2908 6291968816 elsa-workflows-codex[bot] 2026-10-20T13:27:34Z
#3109 / draft PR #3111 now includes the bounded durable runtime at `8a74c3c0e2b75b706dbddafc8eb0a43bf866700e`: pinned admission/preparation, independently leased/reserved partitions, fenced accepted output and terminal outbox. Integrated local gate: 180 ETL + 579 architecture cases passed, no failures/skips; real host/shell lifecycle and exact safeguard-removal/restoration evidence are recorded. Fresh CI is pending. This is 14/36 tasks, not native/Studio or two-process recovery acceptance; the parent connector, continuous-processing and BPMN obligations remain open. [Evidence](https://github.com/elsa-workflows/elsa-foundation/blob/8a74c3c0e2b75b706dbddafc8eb0a43bf866700e/specs/255-finite-file-etl/evidence/finite-file-foundations.md).

<!-- 2908-runtime-checkpoint-8a74c3c0e2b7 -->

## #2908 6293147078 elsa-workflows-codex[bot] 2026-10-20T14:24:43Z
#3109 / draft #3111 now includes native ETL component checkpoint `73f79539a4b52f451c0af12b3d791b63923c8bc7`: ordinary typed native wait, actual-bookmark admission, cancellation, scoped result delivery and hash-bound publication pin. Root's included-boundary self-review ended clean; 235 ETL + 579 architecture cases passed, zero failures/skips, with locked restores and map/filter checks. [Evidence](https://github.com/elsa-workflows/elsa-foundation/blob/73f79539a4b52f451c0af12b3d791b63923c8bc7/specs/255-finite-file-etl/evidence/native-boundary-checkpoint.md).

Fresh exact-head CI is running. The complete finite ETL/native/Studio leaf remains In Progress / Verification Partial (14/36 tasks); real composite continuation, two-process recovery, materialization and API/Studio/browser are not yet accepted. This is not parent/program completion. Existing claim continues; no actor-provider work is resumed.

<!-- 2908-native-component-73f79539a4b5 -->

## #2908 6293849118 elsa-workflows-codex[bot] 2026-10-20T14:56:42Z
#3109 / draft #3111 at `bca4c08cc02f75f7d5d67256f832ba501ba950b4` now proves actual durable Sequence, Flowchart and CompensationScope ETL continuation, including a later scope fault with output retained and outer continuation. Generic callback provenance loss was reproduced/fixed; landed compensation retry/uncertainty behavior is preserved.

Final local evidence: 239 ETL + 66 compensation + 569 Activity Runtime + 579 architecture cases passed, zero failures/skips; locked restores/maps/filters and source-regression controls passed. [Integrated receipt](https://github.com/elsa-workflows/elsa-foundation/blob/bca4c08cc02f75f7d5d67256f832ba501ba950b4/specs/255-finite-file-etl/evidence/native-composite-integration.md). Fresh CI is pending/queued/running as recorded on the PR. The finite ETL/native/Studio leaf remains In Progress / Verification Partial, 16/36 tasks; terminal-outcome/cancellation, materialization, two-process recovery and API/Studio/browser gates remain open. This is not parent/program completion; existing claim continues and actor-provider work remains deferred.

<!-- 2908-composite-integrated-bca4c08cc02f -->

## #2908 6294183522 elsa-workflows-codex[bot] 2026-10-20T15:12:08Z
#3109 / draft #3111 at `5f5633dd17c8eadbacc25245856112788375339a` completes T020's actual native terminal-outcome matrix: BusinessError/Faulted/Cancelled in Sequence, Flowchart and CompensationScope, with typed result/receipt/outbox assertions and ordinary composite semantics. **248 ETL tests passed**, zero failures/skips; maps/filter/diff checks and a source-removal regression control passed. [Evidence](https://github.com/elsa-workflows/elsa-foundation/blob/5f5633dd17c8eadbacc25245856112788375339a/specs/255-finite-file-etl/evidence/native-terminal-outcomes.md).

The leaf stays In Progress / Verification Partial at 17/36 tasks. Native-initiated cancellation/pre-admission ordering is next; final materialization, two-process recovery, workflow compiler publication and API/Studio/browser remain open. Fresh CI is pending as recorded on the PR. This is not the feature/program completion and does not resume deferred actor work.

<!-- 2908-native-outcomes-5f5633dd17c8 -->

## #2908 6294542257 elsa-workflows-codex[bot] 2026-10-20T15:29:00Z
#3109 / draft #3111 at `50681f79d7cee86c912e9210ac69279eee133544` now proves native whole-workflow cancellation into ETL and a cancellation tombstone preceding delayed admission, across Sequence/Flowchart/CompensationScope. Fixed an actual generic scheduler cleanup omission; cancelled waits are removed in the native checkpoint. **254 ETL / 2,431 workflow-runtime / 579 architecture tests passed**, zero failures/skips; real-server replay/restart, maps/filters/diff and removal/restoration controls passed. [Evidence](https://github.com/elsa-workflows/elsa-foundation/blob/50681f79d7cee86c912e9210ac69279eee133544/specs/255-finite-file-etl/evidence/native-parent-cancellation.md).

T022 stays open for genuine activity-boundary subtree cancellation/reversed ordering. 17/36 tasks; leaf In Progress / Assigned / Verification Partial. Fresh exact-head CI is pending. Materialization, two-process recovery and API/Studio product acceptance remain owed. Parent/program stay open, existing claim continues, deferred actor work does not resume.

<!-- 2908-native-parent-cancellation-50681f79d7ce -->

## #2908 6295465966 elsa-workflows-codex[bot] 2026-10-20T16:11:44Z
#3109 / draft #3111 at `ddb3f5a3652c7bc3c2dcc15d52a13a84f12d1fd2` completes T022: 12 actual native whole-workflow/placed-subtree cancellation cases across all three composites and both admission orderings, plus 3 placed normal-completion controls. Fixed the missing ETL published resume declaration and preserved actual placement-generated target identities in frozen state. **273 ETL / 2,436 workflow-runtime / 579 architecture passed**, zero failures/skips; final native subset28 passed; locked restore/maps/filter/diff and removal/restoration passed. [Evidence](https://github.com/elsa-workflows/elsa-foundation/blob/ddb3f5a3652c7bc3c2dcc15d52a13a84f12d1fd2/specs/255-finite-file-etl/evidence/native-subtree-cancellation.md).

18/36 tasks; leaf In Progress / Assigned / Verification Partial. Fresh exact-head CI remains separate. Materialization, live permits, two-process recovery and persisted authoring/API/Studio product gates remain owed. Parent/program stay open; existing claim continues; optional actor work stays deferred.

<!-- 2908-native-subtree-cancellation-ddb3f5a3652c -->

## #2908 6295899974 elsa-workflows-codex[bot] 2026-10-20T16:32:56Z
#3109 / draft #3111 at `1aacfc90977d8c579ff33f0ce8ef7406db13e24b` completes T016: deterministic terminal JSONL materialization from verified manifest-accepted chunks, retained output pins, replay/conflict refusal and explicit cancelled/faulted partials. **285 ETL / 579 architecture passed**, zero failures/skips; focused filter13, digest removal/restoration and maps/filter/diff passed. [Evidence](https://github.com/elsa-workflows/elsa-foundation/blob/1aacfc90977d8c579ff33f0ce8ef7406db13e24b/specs/255-finite-file-etl/evidence/terminal-materialization.md). 19/36 tasks; In Progress / Assigned / Verification Partial. Fresh CI pending. Previous Studio head failed known #3081 readiness race (seed11), not an ETL source change; supporting repair is being handled in the same lane. API/Studio exposure, live permits, two-process recovery and full publication remain owed; parent/program stay open, claim6288815023 continues.

<!-- 2908-terminal-materialization-1aacfc90977d -->

## #2908 6296268588 elsa-workflows-codex[bot] 2026-10-20T16:51:23Z
Supporting CI repair for active #3109 / draft #3111 is pushed at `ee18ca9de7ada3ab105125771d81a2cc055d753c`. Deterministic delayed-waits red proof reproduced #3081; actual editor/form/feedback waits preserve all request/UUID assertions. Integrated shuffled seeds1/11/29 each passed2124 tests; typecheck/ESLint/maps/filter/diff passed, three root self-review passes ended clean. [Evidence](https://github.com/elsa-workflows/elsa-foundation/blob/ee18ca9de7ada3ab105125771d81a2cc055d753c/specs/255-finite-file-etl/evidence/studio-readiness-repair.md). Fresh CI pending (Studio CI 39460945666: in_progress / no conclusion; CI 39460945997: in_progress / no conclusion); 19/36 tasks, program/product incomplete, one lane unchanged. Backend source unchanged from T016. Standing self-review/normal self-merge authority needs no independent reviewer; draft remains until product acceptance.

<!-- 2908-readiness-ee18ca9de7ad -->

## #2908 6296566127 elsa-workflows-codex[bot] 2026-10-20T17:06:50Z
Active #3109 / draft #3111 at `9dfa6993f899b916ff5bd1950a07943d392da946` completes T021 (20/36 tasks). Actual file execution/SQLite takeover preserves owed reservations and four independent local allowances until cancellation/cleanup unwind; stale acceptance refuses, successor owns its own permit and commits one matching effect. **287 ETL / 579 architecture passed**, zero failures/skips; final original-source removal2fail/byte-exact restore287pass, maps/filter/diff passed. Three root self-review passes ended clean. [Evidence](https://github.com/elsa-workflows/elsa-foundation/blob/9dfa6993f899b916ff5bd1950a07943d392da946/specs/255-finite-file-etl/evidence/live-attempt-replacement.md). Fresh exact-head CI pending; prior-head checks retain separate provenance. Separate-process interruption, full publication/API/Studio acceptance remain owed. One claim/lane continues; program incomplete, Orleans deferred.

<!-- 2908-live-attempt-9dfa6993f899 -->

## #2908 6296811255 elsa-workflows-codex[bot] 2026-10-20T17:19:18Z
#3109 / draft #3111 at `b6cd2f27a7e38288b52d6dd460582972a6d5d127` completes T023 (21/36): two real fixture workers over shared SQLite/files, owned predecessor exit after publication and survivor higher-fence same-effect replay/one acceptance. **288 ETL / 579 architecture passed**, zero failures/skips; focused3/locked restore/maps/filter/diff passed, three root self-review passes clean. [Evidence](https://github.com/elsa-workflows/elsa-foundation/blob/b6cd2f27a7e38288b52d6dd460582972a6d5d127/specs/255-finite-file-etl/evidence/two-process-recovery.md). Fresh exact-head CI pending; no independent approval gate. Full interruption/recovery matrix, persisted publication/API/Studio acceptance remain owed; one claim/lane and draft/product gate continue. Program incomplete; Orleans deferred.

<!-- 2908-process-b6cd2f27a7e3 -->

## #2908 6297309289 elsa-workflows-codex[bot] 2026-10-20T17:44:38Z
#3109 / draft #3111 `51302776b4040f68477094cc832a3fdc9fd3ac15` adds actual source/JSONL staging interruption and full replacement publication before acceptance, plus SQLite stale-delivery fencing. **291 ETL/579 architecture passed**, zero failures/skips; locked restore/maps/filters/diff passed. Bypassing composed services explicitly fails both midpoint cases; exact restoration passes. [Evidence](https://github.com/elsa-workflows/elsa-foundation/blob/51302776b4040f68477094cc832a3fdc9fd3ac15/specs/255-finite-file-etl/evidence/staged-write-recovery.md). T024 partial, 21/36 unchanged; full persisted publication/API/Studio and remaining recovery acceptance owed. Sole claim/lane continues; Orleans deferred; program incomplete.

<!-- 2908-staging-51302776b404 -->

## #2908 6297854256 elsa-workflows-codex[bot] 2026-10-20T18:12:50Z
#3109 / draft #3111 `3164c1721f587548c0b499d7c44083de1848ad06` completes T024 (**22/36**): actual process read/reservation/staging/publication/committed-cursor/result-claim interruption, conflicting output refusal and separate SQLite/native replay proofs. **297 ETL/604 activity-runtime/202 compensation/579 architecture passed**, zero failures/skips; CI restore graphs/maps/filters/diff and three rebuilt native REST journeys passed. [Matrix](https://github.com/elsa-workflows/elsa-foundation/blob/3164c1721f587548c0b499d7c44083de1848ad06/specs/255-finite-file-etl/evidence/interruption-matrix.md); [new-main lock/provenance integration](https://github.com/elsa-workflows/elsa-foundation/blob/3164c1721f587548c0b499d7c44083de1848ad06/specs/255-finite-file-etl/evidence/ci-merge-lock-integration.md). Fresh CI pending; PR stays draft. Next T018 real persisted compiler fan-in/runtime-only proof; picker/API/Studio and wider T025 acceptance remain owed. Overall claim/one lane continues; program incomplete; Orleans deferred.

<!-- 2908-recovery-3164c1721f58 -->

## #2908 6298505632 elsa-workflows-codex[bot] 2026-10-20T18:44:52Z
#3109 / draft #3111 `e558abc37204e6eb930c5df3729d7f61061f7a59` adds the genuine persisted parent publication/compiler proof for Sequence and Flowchart, then executes retained ETL v1 after v2 publication in a runtime-only provider with the ETL design database offline. **299 ETL/579 architecture passed**, zero failures/skips; both cases fail under omitted production pin contribution and byte-exact restoration passes299. CI restore graphs/maps/filters/diff passed. [Evidence and limits](https://github.com/elsa-workflows/elsa-foundation/blob/e558abc37204e6eb930c5df3729d7f61061f7a59/specs/255-finite-file-etl/evidence/persisted-parent-publication.md). **22/36; T018 partial** until picker/catalog. Next scoped authoring/published-version APIs; product/program incomplete, PR draft, overall claim active. Fresh exact-head CI pending; prior native/process evidence keeps its own provenance. No independent approval gate or actor-provider prerequisite.

<!-- 2908-persisted-parent-e558abc37204 -->

## #2908 6299407521 elsa-workflows-codex[bot] 2026-10-20T19:26:12Z
Finite-file leaf #3109 / draft #3111 checkpoint `7fdca1f94b3d398f649e442dd245d06c624157c3` completes T011: nine scoped authoring/binding/published-version operations over actual SQLite/HTTP, with exact tuple replay including a deterministic concurrent-read race. **338 ETL / 581 architecture passed**, zero failures/skips. Removing the production replay recheck fails the expected status assertion; exact restoration passes338. Locked CI restore graphs/maps/filters/diff and three rebuilt native REST smokes passed. [Evidence and limits](https://github.com/elsa-workflows/elsa-foundation/blob/7fdca1f94b3d398f649e442dd245d06c624157c3/specs/255-finite-file-etl/evidence/authoring-api.md). **23/36; T018 picker/runtime API/Studio/ETL host-browser/provider and wider terminal acceptance remain owed.** Parent connector/BPMN/continuous obligations remain open. PR draft, overall claim active, fresh exact-head CI pending. Task-runner intent is a separate owner-recorded follow-up, not scope expansion.

<!-- 2908-authoring-api-7fdca1f94b3d -->

## #2908 6300713314 elsa-workflows-codex[bot] 2026-10-20T20:25:43Z
T028 complete at `b47e59b332ea4823e7cf86e5b52029ddc43fa226` in draft #3111: **24/36 finite-ETL tasks checked**.

Four runtime-only NativeEndpoints operations now expose scoped run/partition lists, safe retained run detail and idempotent cancellation. They compose independently of design services and compute workers. Signed cursors bind scope, kind, page limit and run; bounded store reads honor provider limits without changing provider keyset order. Cancellation resolves the retained invocation and returns the actual terminal outcome, including a previously settled result. Safe detail includes source/lookup binding revision, expected digest and last verified preparation identity, with no storage path, object key, worker identity or native result address. Inspection is not a fresh input-integrity check; cancellation does not reverse external effects or prove workers stopped.

Final rebuilt suite: **346 ETL tests / 583 architecture checks passed, zero failures or skips**. Removing only the cursor resource comparison causes the actual HTTP test to return OK instead of BadRequest for another run; exact restoration and subsequent final tests passed. CI Release/isolated-Debug locked restores, map regeneration/freshness, solution filters, local links and diff review passed. The earlier architecture attempt correctly refused an assembly older than the final input-identity edit; the final Release rebuild resolves that provenance issue. Root self-review checked dependency closure, provider paging, retained identities, cancellation races and the final diff; no remaining actionable finding in T028.

[Executed evidence and limits](https://github.com/elsa-workflows/elsa-foundation/blob/b47e59b332ea4823e7cf86e5b52029ddc43fa226/specs/255-finite-file-etl/evidence/runtime-api.md). T028 scope6299493547 is complete/pushed. Overall claim6288815023 and Studio scope6300345739 remain active in the same branch. T018 picker, T029/T030 Studio, T025 terminal/address/corrupt-format matrix, T027 provider and T031/T032 integrated ETL Workbench/browser acceptance remain owed. Studio preparation is deliberately not included in this commit. Prior persisted-parent publication and two-process T024 recovery are already proved with their recorded provenance. This checkpoint does not complete the leaf, parent connectors/BPMN or program. Future task-runner/pause discussion remains outside this implementation.

<!-- 2908-runtime-api-b47e59b332ea -->

## #2908 6306600605 elsa-workflows-codex[bot] 2026-10-21T02:36:38Z
Next production slice #3151 is claimed for specification and delivery: paginated HTTP input, durable JSON delivery, mixed file/HTTP pipelines, native continuation and Studio. The issue records the supported protocol, connection policy, compatibility and failure/recovery proof. Existing file v1 is preserved. No claim of completed HTTP behavior; #3109 post-merge verification remains running.

<!-- 2908-http-start-3151 -->

## #2908 6307906760 elsa-workflows-codex[bot] 2026-10-21T04:16:40Z
#3109 is verified on resulting-main `da9a4927d98fb29eda017b4e1a74a28ee4316439`; the child row is checked and its exact-SHA evidence is in the [PR #3111 receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3111#issuecomment-6307901682). Parent #2908 acceptance remains open, and #3151 retains its full HTTP/native/Studio scope.

<!-- etl-2908-3109-closeout-da9a4927-20261021 -->

## #2908 6323106536 elsa-workflows-codex[bot] 2026-10-21T18:09:47Z
Finite HTTP/native/Studio child #3151 merged in PR #3156 as `9462cb743c08a515e9b8973c57110e3f44df0f7f`. [Evidence](https://github.com/elsa-workflows/elsa-foundation/pull/3156#issuecomment-6323105067). Exact reviewed-head checks passed; resulting-main verification is pending and the child is not yet verification-complete. This does not close continuous processing, SQL, RabbitMQ, JSONL input or BPMN invocation obligations. Existing finite CSV-to-JSONL completion remains separately recorded.

<!-- 2908-http-merged-pending-9462cb743 -->

## #2908 6323246976 elsa-workflows-codex[bot] 2026-10-21T18:16:38Z
Remaining provider qualification made explicit during successor preparation: [ADR0073 D1](https://github.com/elsa-workflows/elsa-foundation/blob/9462cb743c08a515e9b8973c57110e3f44df0f7f/docs/adr/0073-ef-core-is-the-only-first-party-persistence-family.md#d1--ef-core-is-the-only-first-party-persistence-implementation-family) names SQLite, SQL Server, PostgreSQL and MySQL for first-party durable contracts. Current [ETL runtime binding](https://github.com/elsa-workflows/elsa-foundation/blob/9462cb743c08a515e9b8973c57110e3f44df0f7f/Extensions/Etl/src/Persistence/EntityFrameworkCore/DependencyInjection/EtlRuntimeEntityFrameworkCoreRegistration.cs#L36) explicitly supports only SQLite; the design binding is likewise SQLite-only.

The delivered finite file and newly merged HTTP leaves qualify their named SQLite profile. They do not establish the remaining runtime/design persistence providers. This is distinct from PostgreSQL/SQL Server source and destination connectors: a pipeline reading a SQL database does not prove that its authoritative run store supports that database engine.

Keep all four runtime/design provider implementations, migration/scope/claim/receipt/cancellation/outbox contract tests and actual provider evidence in the parent completion audit. A local shared-file multi-process test is not cross-machine storage qualification. The next bounded provider/connector specification must make this dependency explicit rather than inheriting qualification from EF composition alone. No new leaf is activated, no current leaf is expanded, and no provider-policy exception is claimed. #3151 post-merge checks remain the sole active delivery gate.

<!-- 2908-runtime-provider-gap-9462cb743 -->

## #2908 6324180849 elsa-workflows-codex[bot] 2026-10-21T19:03:59Z
Finite HTTP child #3151 is verified and its delivery claim released. [Exact merge CI/Studio/CodeQL/maps and explicit skips](https://github.com/elsa-workflows/elsa-foundation/pull/3156#issuecomment-6324159475). The finite HTTP criterion is checked; finite file evidence remains recorded. Continuous processing, remaining file directions, both SQL connectors, RabbitMQ, BPMN invocation and four-provider design/runtime persistence qualification remain open. Source-record closeout #3182 is still in the program integration lane.

<!-- 2908-http3151-verified-9462cb743 -->

## #2908 6393884289 elsa-workflows-codex[bot] 2026-10-25T05:23:50Z
[Codex] On behalf of @sfmskywalker.

**Prepared next-spec candidate, not an activated implementation:** finite JSON Lines file input into the existing JSONL/HTTP destinations. This is a recommendation inferred from the current reuse surface, not a new product-ordering decision or claim. Keep the full #2908 acceptance open.

Source snapshot `6e677745bb828dcb1117379859068f8e735dac47`:
- [V2 declarations](https://github.com/elsa-workflows/elsa-foundation/blob/6e677745bb828dcb1117379859068f8e735dac47/Extensions/Etl/src/Core/EtlPipelineV2.cs#L26-L93) expose only CSV/HTTP JSON sources and JSONL/HTTP destinations. Typed JSON Pointer fields already exist, so JSONL input can potentially reuse extraction/transform/output rather than introduce another output format.
- [Prepared state and positions](https://github.com/elsa-workflows/elsa-foundation/blob/6e677745bb828dcb1117379859068f8e735dac47/Extensions/Etl/src/Core/Runtime/IEtlConnectorRuntimeStore.cs#L71-L100) use `EtlPreparedCsvInput` and durable file ordinal ranges. A generic prepared-file record or new persisted case needs an explicit compatibility decision; do not silently rename stored DTOs.
- [Current input builder](https://github.com/elsa-workflows/elsa-foundation/blob/6e677745bb828dcb1117379859068f8e735dac47/Extensions/Etl/src/Runtime/Elsa.Etl.Runtime/Execution/EtlConnectorInputBatchBuilder.cs#L50-L133) supports CSV snapshots and retained HTTP pages. New framing/indexing is not already delivered by that code or prior CSV/HTTP proofs.
- [ETL runtime EF registration](https://github.com/elsa-workflows/elsa-foundation/blob/6e677745bb828dcb1117379859068f8e735dac47/Extensions/Etl/src/Persistence/EntityFrameworkCore/DependencyInjection/EtlRuntimeEntityFrameworkCoreRegistration.cs#L24-L55) still rejects non-SQLite providers. Adding a SQL data connector and qualifying the ETL persistence stores on SQL Server/PostgreSQL/MySQL are separate obligations.

Before a leaf is ready, settle and specify: UTF-8/BOM and LF/CRLF/final-line/blank-line framing; accepted top-level JSON shape; malformed/overlong records versus field errors and their terminal/error-route policy; compatibility of prepared inputs; deterministic disjoint partition indexes and restart positions; accounting against existing logical record/batch/snapshot/index/output limits. Retain host-only paths/credentials, immutable source/binding revisions and digests.

The eventual vertical slice must prove a real native/Studio publication-run-inspection-continuation journey plus persisted worker replacement at reservation/output/route/acceptance boundaries, cancellation and duplicate/late work. Reuse retained output/effect identity; physical delivery remains at least once absent an independently proved stronger destination guarantee. Existing recovery tests are scaffolding, not JSONL-source evidence.

<!-- etl-next-spec-research-20261025 -->

## #2908 6526361036 elsa-workflows-codex[bot] 2026-10-30T15:22:20Z
[Codex] On behalf of @sfmskywalker.

Existing draft PR3410 / #2898, head `bbb21b25b1a2fa40c900d4374c2a979ff21377f4`, now source-qualifies real BPMN→native RunEtl success, business error, technical fault and cancellation, including inverse cancellation ordering/recovery directly and through all four native parent shapes. It uses actual finite HTTP429/retry/output paths and durable work, not one workflow per record. [Current checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6526294297) indexes exact sources/whole stores and limits; full-PR round2 is running. This unmerged finite integration proof does not complete upgraded-host ETL, continuous processing, SQL/RabbitMQ connectors, four-engine ETL-store qualification or integrated ETL Studio obligations. Existing delivered file/HTTP child receipts remain valid; every unchecked feature criterion stays open. After #2898 delivery, prioritize a real ETL saved-checkpoint/failure/restart/replay journey and its Studio observation, then continue the approved connector/continuous scope. No new implementation leaf or competing claim is activated here.

## #3410 6461648531 coderabbitai[bot] 2026-10-28T05:42:55Z
<!-- coderabbit-ai-generated:v1 -->

<!-- This is an auto-generated comment: summarize by coderabbit.ai -->
<!-- This is an auto-generated comment: skip review by coderabbit.ai -->

<!-- autopilot:start -->
- [ ] <!-- {"checkboxId":"2708ad07-9f24-4260-9c11-7dc76a49f2e3"} --> <strong title="Keep fixing CodeRabbit findings and required CI, and resolving merge conflicts">Autofix</strong> · Keep fixing CodeRabbit findings and required CI, and resolving merge conflicts
<!-- autopilot:end -->
<!-- tips_start -->

<!-- tips_end -->

## #3410 6461747498 elsa-workflows-codex[bot] 2026-10-28T05:48:29Z
Specification review complete — spec1017

Reviewed specification head: `10af302d89ba10d3c91d8064d6c3c14b1123cf9c`, base `d3ebb980e2dbebeed680808e58c1edd694fae0f7`.

Two bounded specification-review iterations, with independent correctness, standards and acceptance reviewers. Iteration 1 (`ad683917c41d46f079bd3d7af7fafc2104a456c3`) found two actionable gaps: stale-owner wording promised more than fenced decisions plus at-least-once physical delivery; pipeline cancellation could leave the real ETL model Running. Both are fixed in `10af302d8`. Iteration 2 is clean across all three lenses.

The reviewed spec requires actual pipeline cancellation/remaining-work disposition across admission/result races, truthful already-terminal results, actual pre-writer native/BPMN captures and upgraded-host/Studio proof. The user-selected first-delivery recipient snapshot remains required. Author structural/link checks pass; documentation-only changes need no behavioral test run.

Next: Spec Kit implementation plan and concrete contracts/qualification sequence, independent plan review, then reviewed tasks. These are specification reviews only, **zero complete-PR implementation review rounds** have run. No runtime behavior or #2898/#2907 acceptance is claimed, and this draft must not merge on documentation-only green checks.


## #3410 6462168774 elsa-workflows-codex[bot] 2026-10-28T06:17:04Z
Ordered planning checkpoint

Specification review is clean across all three independent lenses at `10af302d89ba10d3c91d8064d6c3c14b1123cf9c` ([receipt](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6461747498)). Plan review is clean across all three lenses at `66e69122411e1aeb3ff78ba20dbbe8c9c94abf03` after two bounded iterations. Fixed plan findings: authoritative native/model lifecycle and terminal-settlement recovery; retryable incident held before semantic fault with real retry proof. The plan also preserves baseline databases through a narrow incremental Runtime migration path instead of destructive Initial regeneration.

Draft tasks are pushed at `62c33169a19c71fb57a352709a0ab36e27334f6b`: 47 tasks covering all five journeys, exact paths, hard actual-capture-before-writer gate, API/provider/compatibility checks and complete-PR/main delivery gates. Independent task reviews are running; any dependency findings will be corrected before implementation.

No production writer/schema has changed. First implementation action after task review/cross-artifact analysis: the portable actual-host baseline capture runner, then actual parked checkpoints. First observable production milestone: genuine direct start/wait/resume and partial fork/join restart through the shared authority. Real ETL/parent settlement and existing Studio upgrade evidence remain required before #2898 closes. Complete-PR implementation review rounds: zero; no runtime or full-program acceptance claimed.


## #3410 6462563853 gitguardian[bot] 2026-10-28T06:44:29Z
#### ⚠️ GitGuardian has uncovered 1 secret following the scan of your pull request.

Please consider investigating the findings and remediating the incidents. Failure to do so may lead to compromising the associated services or software components.

| GitGuardian id | GitGuardian status | Secret                         | Commit           | Filename        |                      |
| -------------- | ------------------ | ------------------------------ | ---------------- | --------------- | -------------------- |
| [39189012](https://dashboard.gitguardian.com/workspace/571996/incidents/39189012?occurrence=307758917) | Triggered | Generic High Entropy Secret | 72b13f46ded5f6e23bdad0c2765ba5e92e76d421 | specs/1017-direct-bpmn-hosting/evidence/baseline/manifest.json | [View secret](https://github.com/elsa-workflows/elsa-foundation/commit/72b13f46ded5f6e23bdad0c2765ba5e92e76d421#diff-7a34306f1dab890839b23b8ea37a7c0a7f662e3c63bc64ebd394a8c28a39390dR5) |

-   following these [best practices](https://blog.gitguardian.com/secrets-api-management/?utm_source=product&amp;utm_medium=GitHub_checks&amp;utm_campaign=check_run_comment) for managing and storing secrets including API keys and other credentials
-   install [secret detection on pre-commit](https://docs.gitguardian.com/ggshield-docs/integrations/git-hooks/pre-commit?utm_source=product&amp;utm_medium=GitHub_checks&amp;utm_campaign=check_run_comment) to catch secret before it leaves your machine and ease remediation.

<sup>🦉 [GitGuardian](https://dashboard.gitguardian.com/auth/login/?utm_medium=checkruns&amp;utm_source=github&amp;utm_campaign=cr1) detects secrets in your source code to help developers and security teams secure the modern development process. You are seeing this because you or someone else with access to this repository has authorized GitGuardian to scan your pull request.<br/></sup>

## #3410 6462601743 elsa-workflows-codex[bot] 2026-10-28T06:47:02Z
T001 verified; actual pre-writer capture underway

Current head `8e5d4686ac51e7b2d528f298d09862fa690253b4`, branch `agent/codex/2898-direct-bpmn-hosting`. Specification is clean at10af302d8, plan at66e691224, tasks at647f7f54f across independent correctness/standards/acceptance reviews. Read-only cross-artifact analysis maps all22FRs/sixSCs to47tasks with no unresolved findings. These component gates do not count as complete-PR implementation review rounds; that count remains zero.

T001 is complete: the portable capture runner parks real normally published/executed legacy partial forks and uses exact owned-process identity plus consistent whole-store snapshots. [Committed actual receipt](https://github.com/elsa-workflows/elsa-foundation/blob/8e5d4686ac51e7b2d528f298d09862fa690253b4/specs/1017-direct-bpmn-hosting/evidence/baseline/partial-forks/capture.md) and [manifest](https://github.com/elsa-workflows/elsa-foundation/blob/8e5d4686ac51e7b2d528f298d09862fa690253b4/specs/1017-direct-bpmn-hosting/evidence/baseline/partial-forks/manifest.json) retain eight actual held executions, Balanced/Durable × legacy root/Sequence/Flowchart/CompensationScope. BranchA is durably completed by the normal Event command and branchB remains held. Executing source is438001406d980051584234e5d656eb8e6a67f47f, not relabeled as a later docs/tooling head. Nine inspected writer/host binaries share that source; three released library binaries are recorded separately.

T002 remains open: capture affected pending callback, recipient/cohort/rearm, called-control/MI/compensation and actual Studio boundaries before editing their writers. No production source under Essentials/src or ETL/src and no schema has changed from verified main. This bundle is actual old-writer capture, not new direct hosting or upgraded-host recovery proof. #2898/#2907 and the full program remain open; next implementation action is the remaining T002 capture matrix, then T003–T013 shared foundations. No new issue, competing claim or merge of this incomplete draft.


## #3410 6463514178 elsa-workflows-codex[bot] 2026-10-28T07:42:57Z
#2898 / PR3410 continuation: actual pre-writer capture is progressing; Gate A remains open.

- #2735 remains delivered; no production semantics writer/schema has changed in this increment.
- New thin BPMN Core/API consumer projects and locked dependency graphs compile successfully (T003). They register no new direct-host API yet.
- Retained actual called-control, compensation, broadcast selection/empty/populated/rearm/pre-ACK, and called-result pre-ACK inputs. Four real sequential/parallel multi-instance cases across Balanced/Durable also pass API and independent physical-state correlation checks. Actual saved Studio layout/export/publication and fresh completed test runs are captured.
- Independent Gate A review identified that consumed-inbox/pre-ACK results do not prove native-composite callbacks before parent consumption. Capturing that separate physical transaction boundary is the remaining gate; test-only probe observation is being qualified. Initial diagnostic-scope misses are excluded from positive evidence.

The portable matrix is being assembled, not yet accepted. T002 remains unchecked. Upgraded-host recovery, genuine direct hosting, RunBpmn and real ETL bridge/retry acceptance remain unproved. Full-PR review rounds remain zero. Project62 stays In Progress / Partial; no production acceptance is closed.


## #3410 6463947799 elsa-workflows-codex[bot] 2026-10-28T08:08:28Z
Gate A / T002 is captured and verified at `6af6df2c230e92f16f38ca23f886c8af62f03725`. T001–T003 are complete; T004 and the shared runtime implementation are next.

- 104 portable assets,22 coherent whole stores and 15 checked-provider observations pass; source-bound writer map retains 16 unchanged existing writer/reader source hashes.
- Actual inputs cover eight partial forks/native parents, real called-control/compensation, four genuine MI cases across sequential/parallel and Balanced/Durable, twelve native fault/cancel outcomes, four broadcast selection/cohort/rearm/pre-ACK cuts, two accepted-inbox/pre-ACK call cuts, and six pending native-parent fault outcomes. Authentication/secrets were isolated before fixture creation; raw execution rows were never manufactured or edited.
- Independent coverage review found missing MI and pre-consumption parent state; both are now actual retained inputs. Successful completion can fold even Durable, so its held precursor is labeled truthfully. Full callback pins are checked.
- Actual Studio exports, publication, saved five-node layout and completed transient test runs are retained; frozen fingerprint remains `41aa0bb979ea46fc2533b057e3677f408ab54c3411fecfafaa238a2adae38c92`.
- Capture suites 12+5 pass; legacy/ACK reader checks 20+18 pass; six invalid native reader controls, a separate bad callback pin and four bundle mutations are refused without changing original inputs. Targeted reader/probe/Core/API builds pass. The weaker reader also refused the bad-pin control; no guard-removal proof is claimed for it.

The specific pre-writer barrier is satisfied for this map. No affected production runtime/ETL writer or schema changed. Direct hosting, RunBpmn, real ETL/retry/settlement, changed-host recovery and final Studio/runtime acceptance remain unproved. Full-PR review rounds 0; draft3410 is not merge-ready. Keep #2898/#2907/#2892 open; #3242 native fault projection and Orleans/task-runner deferrals remain unchanged. Project62 remains In Progress / Partial.


## #3410 6464768721 elsa-workflows-codex[bot] 2026-10-28T08:55:00Z
T004 is complete; T005 model-material contracts are started at `d8932737d83ad785bb81e177860a573f72414a8b`.

The new integration-tier project launches the real built Workbench in an owned temporary content root, publishes and runs a native workflow through normal authenticated APIs, kills only its own process, restarts against the same isolated stores and verifies the persisted execution/pin. Its build metadata supports `--artifacts-path`; no production host composition is copied into the test process. One native host restart test passes.

The first shared Core contracts add a versioned semantic protocol, opaque model material, complete dependency pins, declared input/output contracts and a physical material-incarnation snapshot. No native root is fabricated. Existing artifact providers/decorators default-refuse the additive model operations and preserve cancellation; none advertises model material yet. Native constructors/serialization remain unchanged, with 42 tracked public API additions.

T005 remains unchecked: model-state/input/lifecycle/checkpoint and dispatch contracts still follow, then the actual provider/driver implementation. No schema or persisted execution writer changed, no model storage/admission is enabled, and this native restart is not direct-model or upgraded-version recovery acceptance. The verified Gate A inputs remain unchanged. Full-PR review rounds 0; draft3410 and #2898/#2907/program acceptance remain open. Project62 stays In Progress / Partial.


## #3410 6464893719 elsa-workflows-codex[bot] 2026-10-28T09:01:57Z
Follow-up at `401267e9a7c8f59076d276c00a425382b93647a5`: the owned-host restart witness now compares all five executable-pin fields (artifact ID/hash/version and definition ID/version), and passes again (1 test,0 skipped). This strengthens T004; model storage/driver and changed-version recovery remain unproved.


## #3410 6480184523 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6481009290 elsa-workflows-codex[bot] 2026-10-28T21:22:40Z
Model checkpoint foundation — exact head `151de7d669f6a9d74eecd3b13e90a56c24fd787d`

The first direct BPMN journey now has a physical state/input checkpoint participant in the existing runtime authority. This is an implementation checkpoint, not direct-host acceptance or an author-review round.

- Model state and retained accepted-input receipt commit with the existing execution fence, consumed scheduler claim, outbox and final marker. Complete material pin/incarnation, immutable authority and semantic revision are checked. Terminal progression and unsupported/deferred/coalesced writes refuse.
- Added two model tables through additive Runtime migrations for all four providers. All eight original migration source files and IDs remain unchanged. The default generator preserves Runtime history; the explicit Runtime incremental mode appends migrations.
- Removed the uncommitted native-caller/admission-predicate and registration ports; those arrive with their real consumers. Model material storage/retention and verified dispatch remain the next work.

Verification: **182 runtime/native/model/coalescing checks +64 SQLite checkpoint/actual-store-schema-upgrade checks +47 migration/schema checks passed**, zero skips; maps and the123-project tier/shard check passed. The captured actual legacy store migrates with every legacy row unchanged and its original history retained. Removing the new immutable-authority guard makes the authority-replacement test fail; restoring it passes. An initial schema-scan failure came from out-of-repository artifacts/root discovery; the unchanged scan passed from ignored in-repository artifacts.

Portable [receipt](https://github.com/elsa-workflows/elsa-foundation/blob/151de7d669f6a9d74eecd3b13e90a56c24fd787d/specs/1017-direct-bpmn-hosting/evidence/model-checkpoint-foundation.json). Non-SQLite physical checkpoint behavior, model material/GC qualification, actual changed-host legacy recovery, direct BPMN start/wait/restart/resume/complete and Studio acceptance remain unproved. No model admission is enabled. T005/T007/T008 retain unchecked work, full-PR rounds remain0, and PR3410 remains draft. #2898/#2907/Program2892 stay open. Project62 mirrors this state.

## #3410 6481998201 elsa-workflows-codex[bot] 2026-10-28T22:12:54Z
T006 material/retention checkpoint — exact head `ff5266e67dd50dc69e5981d0b6517bfb16e1118d`

Implemented native/model material in the existing artifact authority: separate model hash/document, persisted creation time and incarnation, additive model-kind column, actual closure grants and complete dependency pins, fenced source publication, retained model roots and orphan GC. Known cache/invalidating decorators forward these operations explicitly; unknown paths default-refuse. Native material never becomes a fabricated model root or vice versa.

**701 local checks passed, zero skips:** 228 runtime/hash/cache/native/model; 308 actual EF material/checkpoint/native/retention and captured-store schema upgrade; 84 architecture/build/catalog/composition/permission scan; 18 cluster readability; 63 four-provider migration/payload/finalization/schema checks. Maps and the123-project tier/shard check pass. All16 pre-existing migration source files/IDs remain unchanged. The actual legacy database keeps its original column values and history; new kind defaults to native. Removing full child-pin validation makes the real-provider/root-grant test fail; restoration passes.

Fixed the previous head's CI build/catalog/solution-folder and new schema-family/payload expectation omissions without relaxing assertions. New-head CI still has to run. GitGuardian incident39189012 is the public frozen authoring SHA-256 (verified equal to the owner's supplied value); its false-positive dashboard action is pending. CLA remains pending separately. No gate is bypassed.

[Portable receipt](https://github.com/elsa-workflows/elsa-foundation/blob/ff5266e67dd50dc69e5981d0b6517bfb16e1118d/specs/1017-direct-bpmn-hosting/evidence/model-material-retention.json). T006 is checked; T005/T007/T008 retain their remaining integration/qualification work. Next: verified model dispatch and the actual released BPMN driver, then start → wait → restart → resume → complete. Before model queue admission, older/unknown readers must demonstrably refuse it rather than acknowledge through native/Noop handling.

No direct model admission, direct-process restart, changed-host legacy recovery, Studio acceptance or non-SQLite physical model behavior is claimed. Full-PR rounds0; PR remains draft and #2898/#2907/Program2892 remain open. New main6432ed240 contains Studio build-path fixes; it will be incorporated before final qualification.

## #3410 6482464958 elsa-workflows-codex[bot] 2026-10-28T22:36:49Z
Continuation checkpoint — protected model queue; direct BPMN driver remains next

Head `33e3c140fd3307e2d2d98af05e027a0f9880fe43` on the existing `agent/codex/2898-direct-bpmn-hosting` branch. Implementation commit `130037598`; imported current main `6432ed240` in qualified runtime/tool source `7be89f8eea17d2d35514ffde1f0d15421d48ca96`. This remains the sole #2898 PR and retained claim6461197535.

The existing scheduler table now has its own RuntimeSchedulerWork v1/v2 content family. Actual held-v1 gate tests preserve native writes and refuse model input; v1 reads retain native bytes and reject forged model content. An actual predecessor provider/Core binary from `bf83b23b4b3987d6ac3b7c31df98ee9133156763` accepts the native v1 control and refuses the real current writer's v2 model row with schema skew. The committed fixture and product hashes make that reader witness portable. It is not a full old-host placement/recovery witness.

The drainer validates model/unknown work before claiming it. EF uses its existing checked head read; coalescing forwards validation. A missing protocol leaves the model row unchanged, unclaimed and owed. Removing EF's validation callback reproduced silent native-fallback acknowledgement (expected test failure); the guard was restored and the affected provider checks passed.

Fixed the previous head's integration-other failure: model-only incarnation/grant revalidation had added unnecessary reads to native-only closures. Native closures retain their existing path, model closures retain the stronger checks, and all ten existing EF command-budget checks now pass without changing budgets. [Failing prior CI job](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40778085585/job/123132579194).

Validation: **1,026 unique passing checks, zero skipped** across runtime/coalescing/leases (517), EF queue/material/checkpoint/retention/schema and seven gate cases (334 unique), architecture/catalog/composition/permission (84), readability (18), four-provider migration/payload/finalization/schema checks (63), and native EF budgets (10). Maps and tier checks pass (123 projects each in one tier/shard). [Source-bound receipt and reproduction commands](https://github.com/elsa-workflows/elsa-foundation/blob/33e3c140fd3307e2d2d98af05e027a0f9880fe43/specs/1017-direct-bpmn-hosting/evidence/model-queue-compatibility.json). Local behavior suites ran against byte-identical runtime source before commit; the separate predecessor probe was rebuilt and run on committed source `7be89f8eea17d2d35514ffde1f0d15421d48ca96`.

T001–T004/T006 remain complete. T009 is partial: protocol selection/registration, actual model dispatch and the released BPMN driver still need implementation. No model admission is enabled. Direct recovery, actual changed-host legacy recovery, Studio compatibility and capability-aware worker placement remain unproved. Complete-PR review rounds remain **zero**; this draft is not ready to merge. New-head CI is pending; the external GitGuardian false-positive owner card remains outstanding. Pending non-required CLA is recorded separately.

Next: wire verified protocol selection and the actual released interpreter into the existing fenced mailbox/queue/checkpoint/lifecycle path, then publish/start/inspect/complete through supported HTTP commands and prove the owned-host start → wait → restart → resume → complete journey. Keep #2907 and Program #2892 open.

## #3410 6483911994 elsa-workflows-codex[bot] 2026-10-28T23:58:10Z
Initial direct BPMN process recovery is now demonstrated on the real production Workbench: authenticated publish → start → model-owned human wait → owned process exit → same-store restart → exact completion. The full pin, physical incarnation, protocol, waiting revision and human invocation/attempt survive. Completion replay adds no revision; stale attempts are retained as rejected; conflicting content cannot advance state; body fields cannot replace route identities. Native workflow/activity/bookmark row counts are zero.

Pushed head: `9c6eaa314f4b986b382d934eabcf197b8d7f79c6`. Production/test source: `48bf343b51f9db4c682bacb737758d0c6dbdcfbc`; the later commit adds only evidence. [Portable observations, exact binary versions/hashes and consistent stopped-host Runtime snapshots](https://github.com/elsa-workflows/elsa-foundation/tree/9c6eaa314f4b986b382d934eabcf197b8d7f79c6/specs/1017-direct-bpmn-hosting/evidence/direct-recovery). Released Bpmn.Model/Bpmn.Semantics remain 0.5.0. This is the explicit built-in single-node mailbox / EF SQLite / combined-host profile; new admission defaults off. Clustered model placement is refused before admission rather than credited from the ordinary distributed provider.

The actual scoped protocol contributor/registry, material/state/authority selector and real BPMN driver now consume the shared queue/claim/fence/checkpoint path. Native and model drains share ownership/heartbeat/release mechanics; native error/lifecycle policy stays native. An accepted first model input roots material before its first header. Recovery with new admission disabled consumes accepted work and completes; a new start is refused.

Validation: 1,320 positive local checks, zero skips: whole BPMN suite 378/378 discovered; whole production host suite 2/2 discovered (rebuilt/rerun on exact source); runtime scheduler/ownership/model/coalescing selection 512; EF model/material/queue/migration selection 334; architecture/catalog/composition/permission selection 84; unchanged native EF budgets 10. Release/Debug graph restoration, final locked solution restore, maps and 123-project tier checks pass. Other behavior suites ran before the source commit over identical production source; the exact-source host suite and binary hashes are separately identified in the receipt.

Removed-guard control: deleting the human AttemptId equality made the real HTTP test fail because an obsolete attempt was accepted and completed the execution (HTTP 200 instead of 409). Restored driver SHA-256 `981d499af1f91958bf556f2813a15d1e5d491a64d85bdddaa467ea8830bcb672`; the complete host suite then passed and was repeated after commit.

Compatibility limits remain explicit: all 104 retained baseline assets are unchanged, all 22 whole stores pass integrity checks and the frozen authoring fingerprint is unchanged. A diagnostic current-reader attempt against an unmigrated old baseline refused with RuntimeArtifactEntityFrameworkPersistenceException; that store lacks the new MaterialKind column. This is not changed-host recovery evidence. Actual migrated/changed-host legacy continuation and Studio remain open, as do runtime-only deployment, partial fork/join and full crash/race matrix, source-admission serialization, authoritative lifecycle/settlement, real native/ETL bindings and clustered model placement. The initial human milestone does not close T019, #2898, #2907 or the program.

The PR stays draft. Full-PR review rounds: zero of six; independent full-scope review and required exact-head checks are still required. New-head CI is pending. External GitGuardian incident 39189012 remains owner-action pending; the frozen public fingerprint must not be changed or broadly ignored. Non-required CLA status remains separate. Next work builds on this real journey toward recoverable bound work/ETL and the remaining #2898 gates, with one implementation leaf and the approved deferrals retained.


## #3410 6483996147 elsa-workflows-codex[bot] 2026-10-29T00:03:18Z
CI follow-up at `1b95de8708614d22ee2693ed4a5a5a859bfa9ff4`: the initial evidence head `9c6eaa314f4b986b382d934eabcf197b8d7f79c6` failed restore with NU1004 because several transitive Runtime consumer lock snapshots were stale. My attempt to trim generated lock changes left those consumers inconsistent; a cached local restore did not revalidate them. [Failed CI](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40790816735).

Regenerated the full graph with `--force-evaluate` and kept its generated dependency updates/pruning. Forced locked restores pass for the whole solution, Core filter and Workbench filter; the Workbench validation uses a fresh intermediate path. [Repair receipt](https://github.com/elsa-workflows/elsa-foundation/blob/1b95de8708614d22ee2693ed4a5a5a859bfa9ff4/specs/1017-direct-bpmn-hosting/evidence/direct-recovery/ci-lock-repair.json). This follow-up changes dependency locks and its receipt; production/host-test source stays at the demonstrated `48bf343b51f9db4c682bacb737758d0c6dbdcfbc` implementation. New-head CI is pending; the previous failures are not green evidence.

The direct human process-restart milestone and its exact-source snapshots remain valid within their recorded single-node/combined-host limits. PR3410 stays draft, review rounds0 and all remaining acceptance/required-check gates remain open. Project62 stays In Progress / Partial; full-program and ETL sequencing remain unchanged.

## #3410 6484436282 elsa-workflows-codex[bot] 2026-10-29T00:29:35Z
Owner decision: GitGuardian incident 39189012 will be handled later. Keep the finding open and continue implementation/qualification. This does not waive the failed check, authorize changing the frozen fingerprint, or permit a merge/protection bypass. The next merge audit must require its resolution along with all other exact-head gates; no repeated owner card is needed while this decision stands.

## #3410 6484636710 elsa-workflows-codex[bot] 2026-10-29T00:42:10Z
Continuation at `d61bd5d828cf9c54c2b93628e0d36673183c3853`; production/test source `1dd83ad436bffcef45377e462e580ea41a5924b9`. Two real result-handling gaps are fixed: obsolete inputs no longer advance semantic revision, and late completions after TerminalSettled retain rejected receipts instead of remaining pending. The existing checkpoint retains exact state bytes/timestamps/revision, while state/receipt/claim/marker still share the fenced transaction and physical revision compare. No new table, checkpoint field or public type is introduced.

[Exact-source host observations, binary hashes and whole Runtime snapshots](https://github.com/elsa-workflows/elsa-foundation/tree/d61bd5d828cf9c54c2b93628e0d36673183c3853/specs/1017-direct-bpmn-hosting/evidence/direct-recovery/retained-input) show wait/restart/obsolete rejection at revision1, completion at revision2 and late rejection at revision2 with pending=false. Whole execution views remain unchanged across rejections. Native workflow/activity/bookmark rows remain zero.

Validation: 1,054 positive checks/zero skips: BPMN379, whole architecture594, EF model25, runtime model/ownership/drain51, production host2 rebuilt after commit, and required actual PostgreSQL/SQL Server/MySQL3 (both Running and TerminalSettled per provider). The EF scope includes mutation, rollback and concurrency controls. Removing the physical compare made its race test fail (expected DbUpdateConcurrencyException was absent); restored staging SHA `61d9f81771494b1b93e674713546c8be79f59a957b5525689cf95dec5d6105e6`, and all25 EF checks pass. Final forced locked restore/maps/123-project tiers pass. The evidence separates exact-source host proof from component verification.

Prior head `1b95de8708614d22ee2693ed4a5a5a859bfa9ff4` passed backend Windows/Ubuntu and Core checks but failed the full architecture job: missing physical-reader composition and the new API owner's schema-refusal coverage. Both are fixed without weakening guards; default native-only composition runs while model operations explicitly refuse unavailable readers. Whole architecture594 now passes locally. [Failed prior job](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40791428087/job/123177429092); new-head CI is pending.

This is still the single-node combined-host human profile. Partial fork/join/runtime-only recovery, source-admission serialization, actual changed-host/legacy/Studio, generic settlement, real native/ETL bindings and clustered placement remain open. Next qualify runtime-only partial-fork recovery, then continue real work/ETL integration through the existing leaf. Full-PR rounds0; PR stays draft; #2898/#2907/program stay open. The owner chose Handle it later for GitGuardian39189012: keep the failed check open, continue implementation and require resolution before merge; no repeated card or bypass.

## #3410 6485117612 elsa-workflows-codex[bot] 2026-10-29T01:13:48Z
Runtime-only partial fork/join recovery is now demonstrated on actual production Workbench HTTP. Head `bee416574b9d6c3da25a58491e4a02828e382fac`; production/host-test source `58309bd997494bbe7e3f31fd7025c53d004c2a7c`; later commits add only evidence/spec progress.

The real model forks to two human waits. Complete left → revision2 with right still active → owned process exit/restart → identical execution/pin/incarnation/right invocation and attempt. Replay left changes nothing. Complete right → exactly one modeled post-join human wait at revision3; replay right adds no wait. Complete that wait → one TerminalSettled/Completed result at revision4. Four input receipts/checkpoint markers and zero native workflow/activity/bookmark rows are verified.

[Portable observations, 17-feature profile, all owned SQLite table catalogs, exact binary versions/hashes and consistent Runtime snapshots](https://github.com/elsa-workflows/elsa-foundation/tree/bee416574b9d6c3da25a58491e4a02828e382fac/specs/1017-direct-bpmn-hosting/evidence/direct-recovery/runtime-only-parallel). No Design/publication feature or Design/definition table exists in the owned runtime/authentication profile; design.db is absent. Only Runtime contents are exported, with Identity excluded. Workbench explicitly discovers the BPMN implementation and API assemblies, and the profile includes the existing file-system lock provider required by Tasks. Failed activation is an authoritative fixture failure with diagnostics, rather than a hidden timeout.

Latest qualification: rebuilt exact-source whole host suite3/3 discovered, plus10 composition/discovery/catalog checks, zero skips. This extends the prior [unchanged-state rejected/terminal-input proof](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6484636710), whose 1,054 component checks include three required native database providers. The prior head d61bd5d828cf9c54c2b93628e0d36673183c3853 has green Build & test, Full tier and Windows/Ubuntu backend checks; GitGuardian remains failed and non-required CLA queued. These prior-head results are not new-head CI evidence; new-head checks are pending.

This advances the direct recovery outcome and T019/T031, without checking their remaining crash/provider/upgrade criteria. Actual changed-binary/legacy resume, timer/broadcast/cancellation/settlement, real native/ETL work bindings, clustered placement and Studio still require evidence. The next implementation priority is the real native/ETL work path through this same model lifecycle, with required compatibility qualification retained. #2898 remains the sole implementation leaf; no competing issue/PR or program closure.

Full-PR review rounds0 of six; PR stays draft. The owner deferred GitGuardian resolution, which remains required before merge; do not change the frozen fingerprint, repeat the decision card or bypass any check/hold. Orleans/task-runner and the other approved deferrals remain unchanged.

## #3410 6489414037 elsa-workflows-codex[bot] 2026-10-29T06:12:32Z
Goal alignment checkpoint at `38be070a2e17d3e933e0290964b49669aa0e24f2`: the owner-confirmed [program goal](https://github.com/elsa-workflows/elsa-foundation/issues/2892#issuecomment-6489393346) is committed in [docs/program-goals/unified-execution.md](https://github.com/elsa-workflows/elsa-foundation/blob/38be070a2e17d3e933e0290964b49669aa0e24f2/docs/program-goals/unified-execution.md), and Program2892 / leaf2898 / this PR / Project62 have been updated and read back. This commit changes only the program document; no runtime or evidence source changes. `git diff --check` and local documentation links pass; behavior tests were not rerun for this documentation-only change.

Remote audit confirmed implementation head `bee416574b9d6c3da25a58491e4a02828e382fac` passed Build & test, Generated maps fresh, Full tier and both backend platforms. The current documentation head needs its own required checks. GitGuardian remains failed and owner-deferred, still merge-gating; CLA queued separately. Draft/full-PR rounds0 and all remaining acceptance limits are unchanged. Continue real ETL failure/recovery and BPMN-to-ETL integration through this same leaf and claim, preserving the pending operational, upgraded-host and Studio gates.

## #3410 6489704967 elsa-workflows-codex[bot] 2026-10-29T06:31:53Z
Actual saved-state upgrade checkpoint at `7948d768065a4cf0ef54bc76cfc097d2fda59c00`; executing host/runner source `f3b56e516d4e6bd05bfa82995f512f27f4520fe8`.

The changed production Workbench copies the actual pre-writer Runtime/Design stores from `438001406d980051584234e5d656eb8e6a67f47f`, recovers all eight retained partial forks, and finishes them through normal authenticated Event commands. Legacy BPMN roots and Sequence/Flowchart/CompensationScope each pass in Balanced and Durable modes. Complete native pins, exact wait identities, the prior completed branch and one successor are preserved. Both additive model migrations apply while retaining the original migration and all59 native executable payloads/incarnations. Original baseline files remain byte-identical and closed.

Failure controls: changing the new native-material discriminator default to model=true causes the real remaining Event stimulus to fail; the migration is restored and the exact-source positive suite passes. Five rehashed copies of the actual upgraded evidence are refused for changed physical terminal state, original executable bytes, wait identity, baseline binding or frozen-store binding. Qualification records the runner corrections for immutable source reads and physical EF key encoding; earlier refused runner attempts are not passed evidence.

T030 is partial for this one family. Pending parent delivery/callbacks, broadcast cohorts, MI/compensation/called-control and actual Studio still require changed-host qualification before the native/ETL bridge modifies these boundaries; real bindings, remaining races/settlement/admission and clustered placement stay open. No production abstraction or writer changed in this slice. Draft/full-PR rounds0; #2898/#2907/program remain open/partial. Current-head CI is running (Generated maps fresh is already green); GitGuardian remains owner-deferred and merge-gating. Continue the same claim and PR, then real ETL/BPMN integration after the remaining compatibility gate.

GitHub read-back completed: #2898 Readiness, this PR body, #2892 control surface and Project62 README now point to this checkpoint. Project62 also has a Latest evidence text field populated on the program, active task and PR items; Status remains In Progress and Verification remains Partial.

## #3410 6490538109 elsa-workflows-codex[bot] 2026-10-29T07:19:30Z
Actual native-parent upgrade checkpoint at `779427881ac18e2eca0609745a7882e10978814f`; executing host/runner source `02602bad34602496314b5cbf7a84a6b2f549124a`.

Six actual pending fault-notification stores now recover on the standard production Workbench, without the test-only recovery probe. Normal resumption delivers the original committed work; a second process preserves the resulting execution and exact source ContentJson/revision. Four native parent outcomes apply. The two Sequence cases retain the existing Faulted-workflow/Running-parent disposition; an empty queue/Delivered enqueue is not claimed as parent consumption. Flowchart retains its native parent incident, while CompensationScope completes Compensated and resolves its child incident. This preserves the captured behavior and does not resolve #3242.

Twelve already-terminal native Fault/Cancel cases also preserve their pins, invocation IDs, outcomes and incident projection across another process. All84 original executable payloads/incarnations remain unchanged in that Runtime store. Restore topology is preserved: combined Runtime/Design for pending captures, coupled separate captures for terminal history. The upgraded Design store matches both frozen published BPMN authoring contracts. [Portable source-bound observations, original/delivered sources, eight upgraded whole stores and qualification](https://github.com/elsa-workflows/elsa-foundation/tree/779427881ac18e2eca0609745a7882e10978814f/specs/1017-direct-bpmn-hosting/evidence/upgrade/native-parents).

Validation: exact-source whole hosting6/6; verifier23/23 with the actual baseline supplied, zero skips. Normal copied native fixtures also pass2/2. Six native evidence controls reject false parent-consumption claims, a physically undelivered source, changed original intent, foreign full pin, relabeled Compensated and revived terminal history after rehashing. All104 original assets/22 stores still pass hash/integrity checks; this does not upgrade the remaining families. The qualification records the initial fixture topology/incident-expectation corrections; no production writer or new backend abstraction changed in this slice.

T030 stays partial. Called-workflow acknowledgments, broadcast cohorts, active MI/compensation/control and actual Studio remain open before the native/ETL bridge. These existing native/BpmnProcess tests do not establish direct-model settlement or real service bindings. #2898/#2907/program stay open/partial; draft/full-PR rounds0. Previous head7948 passed Build & test/Full tier/maps; new-head CI pending. GitGuardian remains owner-deferred and still merge-gating; no repeated owner card or waiver is implied.

## #3410 6490922188 elsa-workflows-codex[bot] 2026-10-29T07:41:21Z
Head `f390e46bf08fef48d8049d154b4aa267a2207387`; executing production host/checked-reader source `4bba8f266327369608733fb4ee484e07a33bbf6a`.

Both actual legacy called-workflow cuts now recover: caller acceptance was committed before the original notice or terminal sender acknowledgment. The standard resumption pump reclaims the unchanged source with fencing token 2 and records Delivered without repeating caller work. The existing checked EF reader independently verifies the original transport/full address, complete executable pins, committed inbox ordinal and terminal receipt. Original finish/warning Events complete both pairs. Second and third actual processes preserve recovered/final views. Four upgraded combined-store snapshots, six process identities, actual HTTP observations and checked proofs are [retained with hashes and binary versions](https://github.com/elsa-workflows/elsa-foundation/tree/f390e46bf08fef48d8049d154b4aa267a2207387/specs/1017-direct-bpmn-hosting/evidence/upgrade/called-ack). Each store retains both original executable payloads/incarnations and migration history; both published BPMN descriptors still match the frozen authoring fingerprint. Original captures remain unchanged.

Validation: exact-source whole hosting **7/7**, capture/upgrade verifier **29/29**, zero skips with the actual baseline supplied; maps and test tiers pass. Six new copied-evidence controls refuse physically undelivered sources, lost physical caller acceptance, repeated successors, foreign full pins, unchecked acceptance and altered original transport after rehashing. Timestamp comparison preserves exact instants while permitting the native UTC offset rendering.

This advances T030 only for legacy native/BpmnProcess acknowledgment cuts. Earlier partial-fork and native-parent evidence retains its own source identities; no new direct-model/RunBpmn settlement or native/ETL bridge is inferred. Broadcast, active MI/compensation/control recovery and actual Studio remain before the pipeline addition; remaining operational/clustered acceptance stays open. Draft/full-PR rounds **0 of 6**; new-head CI pending. GitGuardian39189012 remains owner-deferred and merge-gating. #2898/#2907/Program#2892 remain open/partial; goal active.

## #3410 6491351179 elsa-workflows-codex[bot] 2026-10-29T08:05:23Z
Head `a365a8628b0948f74a34bd8a7ad28eb6cbf4bc71`; executing production host/checked-reader source `facffc859ce01a2d4e3fe85be52bcb5b5b285998`.

All four actual saved broadcast cuts recover through the standard Workbench pump with no recovery probe or edited row/clock. Each original source is acknowledged under fencing token2. Before first selection, delivery includes the listeners and binding created after publisher commit (2 keyed starts /4 callbacks), while excluding waits created by those starts. Installed cohorts remain fixed (1 start /2 callbacks), partial retry preserves the accepted callback/attempt, its re-armed wait and parked keyed start, and the installed empty decision remains nonnull/empty despite later matches. Checked EF observations, actual HTTP views, twelve process identities, eight upgraded snapshots, binary/source hashes and [portable verification are retained](https://github.com/elsa-workflows/elsa-foundation/tree/a365a8628b0948f74a34bd8a7ad28eb6cbf4bc71/specs/1017-direct-bpmn-hosting/evidence/upgrade/broadcast). Every store retains all5 original executable payloads/incarnations and migration history; both actual published BPMN descriptors preserve the frozen authoring fingerprint.

A second process preserves the complete acknowledged source and recipient boundary. Selected finite work completes through normal Events. The generic HTTP endpoint's existing `Ambiguous` result for an excluded workflow with two matching waits is preserved and recorded; those excluded listeners and the authored infinite loops retire through existing native `CancelWorkflow`. Across the independent cuts, 11 executions finish Completed and5 retire Cancelled; all16 have no remaining waits/incidents. A third process preserves every final API view. No new generic HTTP broadcast operation is claimed.

Validation: exact-source whole hosting **8/8**; capture/upgrade verifier **37/37**, zero skips with the original baseline supplied; maps and tiers pass. Eight new rehashed copied-evidence controls refuse missing/expanded recipient decisions, missed delivery-time listeners, repeated callbacks, changed re-arm generations, undelivered physical sources, noncompleted physical callbacks and physically nonterminal final workflows. The portable verifier was corrected against actual text activity status and raw bookmark identities/Revision; qualification records its own script/control hashes separately from the host/reader source.

This advances T030 for legacy native/BpmnProcess broadcasts. Earlier partial-fork/native-parent/called-ACK receipts retain their own source limits. Legacy controls, active MI and actual Studio still precede real native/ETL integration. Direct-model broadcast/settlement and remaining operational/clustered acceptance stay open. Draft/full-PR rounds **0 of6**; new-head CI pending. GitGuardian39189012 remains owner-deferred and merge-gating. #2898/#2907/program stay open/partial; goal active.

## #3410 6492051091 elsa-workflows-codex[bot] 2026-10-29T08:42:06Z
Head `c9e963906963432c2b11abeaeedea7134aabe4f8`; executing production host/checked-reader source `0595851685e3c0ce3321d1a884ad18dbd8f00215`.

The original coupled Runtime/Design control stores now recover all six escalation policies, both policies for two simultaneous non-iteration tokens at one call binding, and one ordinary-task compensation replay. Actual checked EF reads match the original capture before continuation. Normal correlated Events finish the six escalation paths, handle the second live semantic call token while leaving its sibling held, restart and finish the remaining sibling. Compensation continues original handlerB → restart with handlerA held → handlerA → settled replay → original hold completion. A further process preserves all final API views. [Source-bound observations and six upgraded snapshots](https://github.com/elsa-workflows/elsa-foundation/tree/c9e963906963432c2b11abeaeedea7134aabe4f8/specs/1017-direct-bpmn-hosting/evidence/upgrade/controls) retain full pins, all72 original executable payloads/incarnations, applied migration history, original committed inbox/source addresses and the frozen published-authoring fingerprint (2/2 descriptors).

Nineteen observed workflows end as13 Completed,3 Cancelled and3 Faulted, with the required3 authored-failure incidents preserved and no remaining waits in those nineteen executions. Those native fault/cancellation projections are intentional. The store's eight other active runs are the partial-fork IDs already qualified separately. The legacy receipt does not imply new direct-model parent/worker settlement or native/ETL delivery.

Validation: exact-source whole hosting **9/9**, capture/upgrade verifier **46/46**, zero skips with the actual baseline supplied; maps/tiers pass. Nine new copied-evidence controls reject wrong sibling retirement, reversed compensation order, changed physical semantic state, missing committed inbox acceptance, altered immutable intent, relabeled authored failure, unchecked consumption, changed held-wait generation and mismatched decoded receipt bytes. Fifteen full checked observations are retained in lossless gzip with both compressed and decoded hashes; no positive state/clock was edited. The explicit native appliedAt comparison preserves the exact timestamp instant across offset rendering.

T030 remains partial for active multi-instance and actual Studio before real native/ETL integration. Earlier partial-fork/native-parent/called-ACK/broadcast receipts retain their own source limits. Direct-model/RunBpmn settlement and remaining operational/clustered acceptance stay open. Draft/full-PR rounds **0 of6**; new-head CI pending. GitGuardian39189012 remains owner-deferred/merge-gating. #2898/#2907/program stay open/partial; goal active.

## #3410 6492383536 elsa-workflows-codex[bot] 2026-10-29T08:59:13Z
Head `7878c307f75f89551f7b8cc3dccfe7eecf238ee6`; executing production host/checked-reader source `645d59aa6990df001d218af055154092c841cc41`.

All four actual partial multi-instance cases now recover on the changed standard Workbench: sequential/parallel cardinality3 in Balanced/Durable modes, initially with one child completed. Normal correlated Events advance each saved loop1 → 2 → restart → 3 completed children. Exact loop/iteration/token identity, original and newly created child full pins, immutable keyed-start/terminal sources, committed terminal inboxes and surviving wait generations are checked against actual EF state. The original completed child stays unchanged, and another process preserves all sixteen final parent/child views. All twelve native iterations complete without incidents or waits. Both coupled input stores and original capture bytes remain intact; all92 original executable payloads/incarnations, migration history and both actual frozen-authoring descriptors are preserved. [Four checked observations, four host processes and five upgraded snapshots are retained](https://github.com/elsa-workflows/elsa-foundation/tree/7878c307f75f89551f7b8cc3dccfe7eecf238ee6/specs/1017-direct-bpmn-hosting/evidence/upgrade/multi-instance) with compressed/decoded hashes and binary/source versions.

This is legacy native/BpmnProcess MI qualification, not new direct-model MI or native/ETL delivery. Actual Studio open/edit/export/publish/run/inspect is now the remaining saved-state gate before native/ETL integration; earlier compatibility receipts keep their own source limits. Direct/RunBpmn settlement and remaining operational/clustered acceptance stay open. Draft/full-PR rounds **0 of6**; new-head CI pending. The prior `c9e963906` GitGuardian result is **neutral: PR too large to scan**; it is not a completed scan or resolution of owner-deferred incident39189012, and neither is treated as merge clearance. #2898/#2907/program stay open/partial; goal active.

## #3410 6493202199 elsa-workflows-codex[bot] 2026-10-29T09:37:55Z
[Codex] On behalf of @sfmskywalker.

Head `a06b3b90bcd36577c987b62b606c93e860317b2c`; executing Workbench/Studio/checked-reader source `801042981812d52b327fa0d008a09f12d6160a94`. **T030/T032/T033 are complete for the current saved-state and existing-Studio phase**, with final T041 repetition still required after bridge/retry changes.

The existing Test Run boundary is explicit: inspection identifies the draft source while identical material may reuse its immutable published pin; draft Test Runs keep the existing empty layout sidecar. Authoring layout and the Published Run layout are verified separately. This is **existing embedded BPMN Studio compatibility**, not #2907 first-class direct-model Studio acceptance.

Next: real ETL failure/recovery using delivered RunEtl, then the actual RunBpmn/model-to-native bindings and typed result/cancellation/retry settlement needed for BPMN-to-ETL. T031, final T041, new direct-model Studio and remaining operational/clustered acceptance stay open. Earlier raw upgrade receipts retain their own source identities. Draft/full-PR review rounds remain **0 of6**; new-head required checks pending. Source801042981 GitGuardian is neutral because the PR was too large to scan, not scan success; that scan gate and owner-deferred incident39189012 remain unresolved before merge. #2898/#2907/program remain open/partial; goal active. Orleans/task-runner remain deferred.

## #3410 6494289708 elsa-workflows-codex[bot] 2026-10-29T10:32:14Z
[Codex] On behalf of @sfmskywalker.

Head `fdda380cc14f08db5b50dd54b81e480a0e0a1fdc`; executing Workbench/ETL/observer/controller source `9a3b397382e0a7dde27f830a9b236851d41c28fe`. The delivered native ETL path now has an actual process-loss recovery reference for the forthcoming BPMN binding. No ETL production semantics changed.

Three real published journeys use normal owned Workbench hosts and the actual HTTP source/receiver: Sequence and Flowchart each complete RunEtl then their native successor; a real RunEtl root completes with native outcome `BusinessError`. Every case receives HTTP429 with Retry-After20, preserves the original waiting invocation and completed sibling partition, loses its owned Workbench through SIGKILL (exit -9), recovers in a fresh process on the same unedited stores, and retains exact terminal API/partition/native views and physical HTTP outputs after a third process. The two success cases accept/deliver four records. The worker-root case accepts/delivers three, rejects one, and retains the safe `etl.invalid-value` error and `etl.rows-rejected` diagnostic. Its native workflow/activity are `Completed` with outcome `BusinessError`, while ETL is `businessError`; the adapter must not infer ETL success from native workflow status alone.

[Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/fdda380cc14f08db5b50dd54b81e480a0e0a1fdc/specs/1017-direct-bpmn-hosting/evidence/pipeline/native-http-reference) contains nine actual Workbench processes, three owned HTTP fixture processes, eighteen closed whole-store snapshots, API/wire views and provider backup receipts. All original invocation identities, full five-part executable pins, published format2 ETL pins, native bookmark/result addresses and immutable ETL invocation payloads survive process loss. The persisted terminal ETL outbox is acknowledged, owed record bytes are zero, the native successor runs once where present, and actual second HTTP attempts respect the first response's twenty-second delay. User hosts remain untouched; all owned journey processes are stopped. Captured temporary paths and ports are comparison evidence; reproduction creates fresh private bindings.

This is **same-source native ETL recovery after a transient HTTP retry**, not upgraded-host ETL recovery, direct/RunBpmn integration or model-held terminal-fault retry. T027/T034–T040 remain unchecked, including T039. Next: actual RunBpmn/model-to-native admission and typed result/cancellation/retry settlement, building on this real worker boundary. Prior saved-state/existing-Studio T030/T032/T033 qualification keeps source801042981; T031 and final T041 repetition, direct-model Studio and remaining operational/clustered acceptance stay open.

Draft; full-PR review rounds **0 of6**. Current-head CI is pending. GitGuardian is neutral because this PR was too large to scan; that is not scan success. The scan gate and owner-deferred incident39189012 remain unresolved before merge. #2898/#2907/program remain open/partial; goal active. Orleans/task-runner remain deferred.

## #3410 6496012185 elsa-workflows-codex[bot] 2026-10-29T11:57:44Z
[Codex] On behalf of @sfmskywalker.

Head `47ca9cb707ed4ffae25760537870d20d3a5f9842` adopts current main (`c379a6e01`) and adds the first opt-in closed direct BPMN/native worker binding. Plain start/service/end retains the exact native worker dependency, model invocation/attempt and frozen return address. Native admission physically compares the live model decision in the same checkpoint as the native header/root work; native terminal acceptance retains the typed root result and owed delivery. Shared queue/outbox/resumption consumes results before acknowledgement, with no fabricated native parent. Protected queue/header families refuse older readers. Validation: BPMN379/379, persistence1765/1765, focused contract81/81 and new persistence guards37/37; zero skips. A removed physical-compare control failed as required and source was restored; maps/tiers pass; all104 original asset hashes remain unchanged. The first actual BPMN-to-HTTP-ETL process-loss journey is now running; no bridge recovery acceptance is claimed yet. [Last verified native ETL reference](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6494289708) retains source9a3b39738; prior Studio qualification retains source801042981. T027/T031/T034–T041, embedding, broader event/service shapes, cancellation/settlement, held retry, direct-model Studio and remaining program acceptance stay open. Draft/full-PR review rounds0 of6; new-head CI pending. GitGuardian scan-size limitation and deferred incident39189012 remain unresolved before merge. #2898/#2907/program remain open/partial; goal active.

## #3410 6496608242 elsa-workflows-codex[bot] 2026-10-29T12:25:06Z
[Codex] On behalf of @sfmskywalker.

Head `9559a659b63644ded96c8ad03e174adaf3c809c2`; executing Workbench/BPMN/runtime/ETL/controller source `18ac139e055b7e9af4573b720086c989884a9f48`. Two actual direct BPMN → published native RunEtl root → BPMN journeys recover after SIGKILL during a real HTTP429/Retry-After20 wait with the sibling partition already complete. Success delivers four mapped HTTP records and BPMN Completed. The rejected-record case delivers three records plus one safe JSONL error, preserves native Completed / typed BusinessError with etl.rows-rejected, and maps the unmatched modeled error to BPMN Faulted. The original native invocation, complete model/worker pins, incarnation and model invocation/attempt/frozen return input survive. The native terminal and typed result outbox commit together; a physically retained exact model receipt precedes source acknowledgment. A third host preserves terminal API/checked-provider/wire observations. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/9559a659b63644ded96c8ad03e174adaf3c809c2/specs/1017-direct-bpmn-hosting/evidence/pipeline/direct-http-recovery) retains six Workbench processes, two HTTP fixtures, twelve whole-store snapshots and36 raw assets; all eight owned children are stopped. Real recovery exposed an overly narrow native-terminal guard after Balanced outbox folding; fixed in18ac139e0, with materialized-outbox acceptance and intent-only/foreign-scope refusal regressions. Current source passes BPMN379/379, full Runtime EF1770/1770 and direct hosting2/2; portable native/direct comparisons plus eight corrupt controls pass10/10, zero skips. Maps/tiers pass; all104 original baseline asset hashes remain unchanged. This proves the first closed direct start/service/end worker cut on the built-in single-node actor/SQLite, not RunBpmn embedding, matched errors, cancellation/settlement, held terminal-fault retry, upgraded-host ETL or final affected-source/direct-model Studio. T027/T031/T034–T041 and remaining program acceptance stay open. Earlier native ETL/Studio receipts retain their own sources. Draft/full-PR rounds0 of6; exact-head CI pending, Full tier not yet requested. GitGuardian neutral scan-size limitation and deferred incident39189012 remain unresolved before merge. #2898/#2907/program remain open/partial; goal active. Orleans/task-runner remain deferred.

## #3410 6497739402 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6497752668 CLA unique notification

@elsa-workflows-codex[bot] please read the following Contributor License Agreement(CLA). If you agree with the CLA, please reply with the following information.

```
@dotnet-policy-service agree [company="{your company}"]
```

> Options:
> - (default - no company specified) I have sole ownership of intellectual property rights to my Submissions and I am not making Submissions in the course of work for my employer.
>```
>@dotnet-policy-service agree
>```
> - (when company given) I am making Submissions in the course of work for my employer (or my employer has intellectual property rights in my Submissions by contract or applicable law). I have permission from my employer to make Submissions and enter into this Agreement on behalf of my employer. By signing below, the defined term “You” includes me and my employer.
>```
>@dotnet-policy-service agree company="Microsoft"
>```

<details>
    <summary>Contributor License Agreement</summary>
    
### Contribution License Agreement

This Contribution License Agreement ( **“Agreement”** ) is agreed to by the party signing below ( **“You”** ),
and conveys certain license rights to the .NET Foundation ( **“.NET Foundation”** ) for Your contributions to
.NET Foundation open source projects. This Agreement is effective as of the latest signature date below.

**1. Definitions.**

**“Code”** means the computer software code, whether in human-readable or machine-executable form,
that is delivered by You to .NET Foundation under this Agreement.

**“Project”** means any of the projects owned or managed by .NET Foundation and offered under a license
approved by the Open Source Initiative (www.opensource.org).

**“Submit”** is the act of uploading, submitting, transmitting, or distributing code or other content to any
Project, including but not limited to communication on electronic mailing lists, source code control
systems, and issue tracking systems that are managed by, or on behalf of, the Project for the purpose of
discussing and improving that Project, but excluding communication that is conspicuously marked or
otherwise designated in writing by You as “Not a Submission.”

**“Submission”** means the Code and any other copyrightable material Submitted by You, including any
associated comments and documentation.

**2. Your Submission.** You must agree to the terms of this Agreement before making a Submission to any
Project. This Agreement covers any and all Submissions that You, now or in the future (except as
described in Section 4 below), Submit to any Project.

**3. Originality of Work.**  You represent that each of Your Submissions is entirely Your 
original work. Should You wish to Submit materials that are not Your original work, 
You may Submit them separately to the Project if You (a) retain all copyright and 
license information that was in the materials as you received them, (b) in the 
description accompanying your Submission, include the phrase &quot;Submission 
containing materials of a third party:&quot; followed by the names of the third party and any 
licenses or other restrictions of which You are aware, and (c) follow any other 
instructions in the Project&#39;s written guidelines concerning Submissions.

**4. Your Employer.** References to “employer” in this Agreement include Your employer or anyone else
for whom You are acting in making Your Submission, e.g. as a contractor, vendor, or agent. If Your
Submission is made in the course of Your work for an employer or Your employer has intellectual
property rights in Your Submission by contract or applicable law, You must secure permission from Your
employer to make the Submission before signing this Agreement. In that case, the term “You” in this
Agreement will refer to You and the employer collectively. If You change employers in the future and
desire to Submit additional Submissions for the new employer, then You agree to sign a new Agreement
and secure permission from the new employer before Submitting those Submissions.

**5. Licenses.**

**a. Copyright License.** You grant .NET Foundation, and those who receive the Submission directly
or indirectly from .NET Foundation, a perpetual, worldwide, non-exclusive, royalty-free, irrevocable
license in the Submission to reproduce, prepare derivative works of, publicly display, publicly perform,
and distribute the Submission and such derivative works, and to sublicense any or all of the foregoing
rights to third parties.

**b. Patent License.** You grant .NET Foundation, and those who receive the Submission directly or
indirectly from .NET Foundation, a perpetual, worldwide, non-exclusive, royalty-free, irrevocable license
under Your patent claims that are necessarily infringed by the Submission or the combination of the
Submission with the Project to which it was Submitted to make, have made, use, offer to sell, sell and
import or otherwise dispose of the Submission alone or with the Project.

**c. Other Rights Reserved.** Each party reserves all rights not expressly granted in this Agreement.
No additional licenses or rights whatsoever (including, without limitation, any implied licenses) are
granted by implication, exhaustion, estoppel or otherwise.

**6. Representations and Warranties.** You represent that You are legally entitled to grant the above
licenses. You represent that each of Your Submissions is entirely Your original work (except as You may
have disclosed under Section 3 ). You represent that You have secured permission from Your employer to
make the Submission in cases where Your Submission is made in the course of Your work for Your
employer or Your employer has intellectual property rights in Your Submission by contract or applicable
law. If You are signing this Agreement on behalf of Your employer, You represent and warrant that You
have the necessary authority to bind the listed employer to the obligations contained in this Agreement.
You are not expected to provide support for Your Submission, unless You choose to do so. UNLESS
REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING, AND EXCEPT FOR THE WARRANTIES
EXPRESSLY STATED IN SECTIONS 3, 4, AND 6 , THE SUBMISSION PROVIDED UNDER THIS AGREEMENT IS
PROVIDED WITHOUT WARRANTY OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, ANY WARRANTY OF
NONINFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.

**7. Notice to .NET Foundation.** You agree to notify .NET Foundation in writing of any facts or
circumstances of which You later become aware that would make Your representations in this
Agreement inaccurate in any respect.

**8. Information about Submissions.** You agree that contributions to Projects and information about
contributions may be maintained indefinitely and disclosed publicly, including Your name and other
information that You submit with Your Submission.

**9. Governing Law/Jurisdiction.** This Agreement is governed by the laws of the State of Washington, and
the parties consent to exclusive jurisdiction and venue in the federal courts sitting in King County,
Washington, unless no federal subject matter jurisdiction exists, in which case the parties consent to
exclusive jurisdiction and venue in the Superior Court of King County, Washington. The parties waive all
defenses of lack of personal jurisdiction and forum non-conveniens.

**10. Entire Agreement/Assignment.** This Agreement is the entire agreement between the parties, and
supersedes any and all prior agreements, understandings or communications, written or oral, between
the parties relating to the subject matter hereof. This Agreement may be assigned by .NET Foundation.


*.NET Foundation dedicates this Contribution License Agreement to the public domain according to the Creative Commons CC0 1.*

</details>
<!-- Policy app identification https://img.shields.io/static/v1?label=ContributorLicenseAgreement. -->

## #3410 6498119714 elsa-workflows-codex[bot] 2026-10-29T13:34:01Z
[Codex] On behalf of @sfmskywalker.

Head `3e919eb57cf7c7814951def0f5c35f035ab22818`; executing Workbench/runtime/BPMN/publishing source `0c419ca5f5fe494c802d062eff2512a2b7ab9f38`. Eight actual human-work RunBpmn journeys (Root, Sequence, Flowchart, CompensationScope × completion/whole-parent cancellation) survive SIGKILL at the real native/model wait, then complete or cancel the original invocation on the same stores. Four actual direct counterparts have equal released-interpreter waiting/terminal states after only the declared producingWorkHandle identity normalization. The exact model/native pins, material incarnation, original typed wait and dependency are retained. Native consumption precedes the durable model settlement receipt; only that receipt permits result-source acknowledgment. Late human completion cannot advance a cancelled model. A third host preserves exact checked terminal observations. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/3e919eb57cf7c7814951def0f5c35f035ab22818/specs/1017-direct-bpmn-hosting/evidence/embedding/human-native-recovery) retains24 owned Workbench processes,32 closed whole-store snapshots and64 raw assets; all owned children stopped. At executing0c419: actual host8/8 and complete Runtime EF1777/1777 pass. Pre-merge implementation-content tests381/381 BPMN and61/61 Publishing are separately scoped. Portable verification plus seven rehashed corrupt controls pass8/8, zero skips. All104 frozen baseline assets remain unchanged. This proves human-work embedding on the built-in single-node actor/SQLite, not ETL embedding, cancellation-before-admission, pending-parent-result crash, final affected-source upgrade/Studio or remaining operational/provider/held-retry acceptance. T027/T028/T029/T031/T034–T041 remain incomplete. Exact-source CI is red: architecture delivery-service composition, missing behavioral RunBpmn drive/contract baseline, and readability-version expectations. Next fix these integration gaps, then continue real ETL cancellation/embedding/held retry. Full-PR rounds0 of6, incomplete draft; no merge authorized by these partial receipts. GitGuardian neutral scan-size skip and owner-deferred incident39189012 remain unresolved before merge. #2898/#2907/program remain open/partial; goal active. Orleans/task-runner deferred.

## #3410 6498130755 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6498133434 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6498282876 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6498405585 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6498577929 elsa-workflows-codex[bot] 2026-10-29T13:54:17Z
[Codex] On behalf of @sfmskywalker.

Head `888c6c3867c1a09fc4f2788b4bb071c807d814ae`; executing source `d22a35f0e6e33305734cdfdb9e98d2dc604e71f8`. Actual native RunBpmn root cancellation before first model admission is now proved: normal public alteration processing commits parent cancellation while the original start/cancel sources remain owed; stopped physical stores contain no model execution, receipt or model command. After SIGKILL (exit137), fresh standard resumption creates a Cancelled model without starting interpreter semantics (sequence0/no tokens/work/diagnostics), retains exact original model/native pins and wait address, and commits the exact parent settlement receipt before result-source ACK. A third process is stable. [New evidence](https://github.com/elsa-workflows/elsa-foundation/tree/888c6c3867c1a09fc4f2788b4bb071c807d814ae/specs/1017-direct-bpmn-hosting/evidence/embedding/cancel-before-admission) binds3 owned Workbench processes,4 closed whole stores and9 raw assets; all children stopped. The earlier [eight-parent human-work matrix](https://github.com/elsa-workflows/elsa-foundation/tree/3e919eb57cf7c7814951def0f5c35f035ab22818/specs/1017-direct-bpmn-hosting/evidence/embedding/human-native-recovery) retains executing source0c419,32 stores and four actual direct/embedded trace comparisons; all eight host cases pass again against d22a35f0e built products. Current host9/9 and both evidence suites14/14 pass, zero skips; all104 frozen baseline assets are unchanged. f925baa8c fixes the CI-discovered optional-reader composition, RunBpmn behavioral drive/contract snapshot and readability/finalization integration. Its local content checks pass BPMN381/381, behavioral220/220, composition2/2, readability117/117, contract3/3 and tooling15/15; maps/tiers pass. EF1777/1777 remains the earlier exact0c419 receipt. No earlier evidence is relabeled as final-source qualification. Remaining: real ETL cancellation/RunBpmn service embedding and held terminal-fault retry, pending-parent-result crash, simultaneous admission race, provider/rollback/race criteria and final affected-source upgrade/Studio. T027/T028/T029/T031/T034–T041 remain incomplete. Exact-head CI is pending; historical0c419 failures are not green and Full-PR rounds remain0 of6. GitGuardian neutral size skip, owner-deferred incident39189012 and queued CLA remain unresolved before merge. Draft #3410, #2898/#2907 and program remain open/partial; active goal unchanged. Orleans/task-runner remain deferred.

## #3410 6498579012 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6498593194 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6498675754 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6498750499 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6498985820 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6499015379 elsa-workflows-codex[bot] 2026-10-29T14:12:29Z
[Codex] On behalf of @sfmskywalker.

Head `86d18d7209a4a074917d10fd848cac285af4b6e0`; executing source `b5c612276334d1d39aec827b85d12cb1021e5c38`. Actual pipeline-originated cancellation now survives the full ETL → native RunEtl worker → direct BPMN path after process loss. A real HTTP429/Retry-After60 holds shard B after shard A delivers two mapped records; the owned Workbench is killed with SIGKILL. On fresh recovery the ordinary ETL cancel API accepts cancellation. The pipeline, original native activity/workflow and BPMN all retain Cancelled. Physical verification requires the exact Consumed ETL/native typed registration and the exact model input receipt before native result-source ACK; a cancelled header alone is insufficient. A third standard Workbench remains stable past the original saved retry deadline, with no second shard-B request. Two delivered records remain intact; outstanding records/bytes are zero. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/86d18d7209a4a074917d10fd848cac285af4b6e0/specs/1017-direct-bpmn-hosting/evidence/pipeline/direct-cancellation) retains3 Workbench processes,1 HTTP fixture,6 closed whole-store snapshots and19 raw assets; all four journey children stopped. Focused ETL checkpoint/result/cancellation/API checks72/72 and portable native/direct/cancel comparisons plus corrupt controls17/17 pass, zero skips. All104 frozen baseline assets remain unchanged. No ETL production semantics changed for this increment. Earlier human RunBpmn eight-case recovery, four direct trace comparisons and root cancellation-before-first-model-admission retain their executing0c419/d22 sources and own receipts; current-source qualification is not inferred from them. Next: reverse native/model cancellation into a running ETL worker and its admission/result cuts, RunBpmn service embedding, held fault retry, pending parent-result recovery, remaining provider/race/rollback criteria, final affected-source upgrade/Studio. T027/T029/T031/T034–T041 remain incomplete; #2898/#2907/program remain open/partial and the goal active. Draft PR3410/full-PR rounds0 of6. Exact-head CI is pending; earlier red/cancelled runs are not green. GitGuardian neutral size skip, deferred incident39189012 and CLA remain unresolved before merge. Orleans/task-runner remain deferred.

## #3410 6499031227 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6499168366 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6499510376 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6499522214 elsa-workflows-codex[bot] 2026-10-29T14:32:48Z
[Codex] On behalf of @sfmskywalker.

Head `d0b27796ec4a9c504fc3ad83c8df5dc242afbe8b`; executing source `78b1e582793d6e76410bc357aa55c687bc3e8e1d`. The actual native-worker → ETL cancellation hop now has its own process-loss witness. A real HTTP429/Retry-After60 holds shard B after shard A delivers two mapped records; the owned host is killed with SIGKILL. On fresh recovery the normal public CancelWorkflow alteration plan targets the original native RunEtl worker. Its cancellation checkpoint owns both the exact Elsa.Etl.Cancel.v1 source and the native/model result source. Physical verification requires their same checkpoint identity and the original frozen ETL invocation/result address. The actual ETL run becomes cancelled with two accepted records and zero outstanding records/bytes; the original native activity/workflow and direct BPMN retain Cancelled. ETL acknowledges its return as ProvenParentTerminal, distinct from typed ETL consumption in the earlier pipeline-originated case. The exact model input receipt precedes native result-source ACK. A third standard Workbench remains stable after the original retry deadline with no second shard-B request. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/d0b27796ec4a9c504fc3ad83c8df5dc242afbe8b/specs/1017-direct-bpmn-hosting/evidence/pipeline/native-cancellation) binds3 Workbench processes,1 HTTP fixture,6 whole-store snapshots and19 raw assets; all four journey children stopped. Actual journey1/1 and portable comparisons/corrupt controls21/21 pass, zero skips; all104 frozen baseline assets remain unchanged. No production semantics changed; the existing native cancellation producer works for this real hop. Legitimate test-only main6ad81f7c7 was adopted first. Earlier human embedding, pre-admission and pipeline-originated cancellation receipts retain their own sources and limits. The model-to-worker cancellation producer remains the next required implementation, followed by native admission/result/cancel crash cuts, RunBpmn service embedding, held fault retry, remaining provider/race/rollback and final affected-source upgrade/Studio acceptance. T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending, historical red/cancelled runs not green. GitGuardian size-skip/neutral and deferred incident39189012 remain unresolved before merge. CLA remains queued; current org protocol treats a non-required pending CLA as nonblocking, with actual required checks audited at merge. Orleans/task-runner remain deferred.

## #3410 6499537695 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6500177170 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6500186372 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6500190314 elsa-workflows-codex[bot] 2026-10-29T14:59:05Z
[Codex] On behalf of @sfmskywalker.

Head `35bcc66f1bd95eaeeb5647a16f5b071517214ee9`; executing source `6f6bf1786cb6fbf290caac500c4737f4721b2a96`. The public BPMN cancel command now reaches the original already-admitted native RunEtl worker and actual ETL run after HTTP429/SIGKILL/restart. Revision2 retains the exact cancellation command as TerminalPendingSettlement, its reason and durable CancelNativeWork source. The ordinary native Cancel queue command closes that original worker; its terminal checkpoint owns both the actual ETL cancel delivery and typed model result. The result retains every other terminal-checkpoint delivery, including ETL's existing intent handler. Qualified physical reads require actual downstream acknowledgment before the native-result input settles model revision3; the model cancellation source acknowledges only after that exact consumption receipt. The original revision2 command receipt remains an acceptance decision. ETL/native/model retain Cancelled, two delivered HTTP records remain and zero records/bytes are owed. A third standard Workbench stays stable beyond the saved retry deadline with no second shard-B request. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/35bcc66f1bd95eaeeb5647a16f5b071517214ee9/specs/1017-direct-bpmn-hosting/evidence/pipeline/model-cancellation) binds3 Workbench/1 HTTP processes,6 closed whole stores and20 raw assets; all journey children stopped. The first real capture exposed an omitted ETL delivery in the new inventory; 6f6bf1786 fixes it, and the verifier rejects both that unqualified capture and a fully rehashed empty-inventory control. BPMN382/382, focused ETL72/72, actual HTTP authorization/not-found/recovery1/1 and portable26/26 pass, zero skips; all104 baseline assets and the authoring fingerprint remain unchanged. The additive default-refusing public cancellation contract and package API build cleanly. This is the admitted-worker cancellation arm, not cancellation before admission: in that cut semantic progression closes and the existing atomic admission condition prevents a late child, but start/cancel responsibility remains owed until positive durable start retirement is implemented. Next deliver that retirement, admission/result/cancel crash/race cuts, then service embedding, held fault retry and final affected-source upgrade/Studio acceptance. Earlier receipts retain their sources and limits. T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR review rounds0 of6; exact-head CI pending. GitGuardian size-skip/neutral and owner-deferred incident39189012 remain unresolved before merge. CLA remains queued/non-required under current org policy; actual required checks must be audited at merge. Orleans/task-runner remain deferred.

## #3410 6500207776 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6500805360 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6500834568 elsa-workflows-codex[bot] 2026-10-29T15:24:44Z
[Codex] On behalf of @sfmskywalker.

Head `a50a9a641d685a651ddbe3caba5c952ac08eb4b1`; executing source `3e14b7ef7f90c8103e812eeeb21e20aeab9de56e`. Cancellation before first native worker admission now has an actual process-loss witness. Normal authenticated APIs publish the real ETL pipeline, closed RunEtl worker and direct BPMN service model. With the normal recovery sweep set to300 seconds, model start retains the original native-start source while no native workflow/activity/bookmark or ETL run exists. Public BPMN cancellation records revision2/TerminalPendingSettlement and its exact original invocation/attempt/cancel source. SIGKILL loses the owned host at that pending cut. Fresh standard Workbench hosts using normal0.2-second recovery consume one exact native-start-retired input, retain NotAdmitted at model revision3 and acknowledge start then cancel only after that positive consumption receipt. No native carrier, invented worker result, ETL run or HTTP effect appears across a third host. Full model/native/ETL pins and the interpreter snapshot remain unchanged. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/a50a9a641d685a651ddbe3caba5c952ac08eb4b1/specs/1017-direct-bpmn-hosting/evidence/pipeline/native-start-retirement) binds3 Workbench/1 HTTP processes,9 closed coupled stores and22 raw assets; all children stopped. A saved-state test additionally sends a late start through the production dispatcher: it retires without native state/root work, replay converges, and missing physical cancellation proof leaves the queued work owed. That provider/dispatcher test does not replace the actual already-queued-start process cut. BPMN384/384 and portable33/33 pass, zero skips; six new rehashed controls reject missing receipt, early acknowledgment, invented admitted-child result, hidden physical carrier, graceful-exit substitution and acceptance mislabeled as settlement. All104 baseline assets and the frozen authoring fingerprint remain unchanged. The implementation uses irreversible model cancellation plus the existing qualified atomic admission condition; no new execution authority or fake native carrier is introduced. Earlier admitted-worker cancellation/ETL and embedding receipts retain their own sources and limits. Next qualify actual queued native start/checkpoint recovery and the simultaneous admission/cancellation race, then pending native result/cancel cuts, RunBpmn service embedding, held retry, provider/rollback and final affected-source upgrade/Studio acceptance. T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR review rounds0 of6; exact-head CI pending. GitGuardian size-skip/neutral and owner-deferred incident39189012 remain unresolved before merge. CLA is queued/non-required under current org policy; actual required checks must be audited at merge. Orleans/task-runner remain deferred.

## #3410 6500851249 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6501628566 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6501663205 elsa-workflows-codex[bot] 2026-10-29T15:57:32Z
[Codex] On behalf of @sfmskywalker.

Head `49cd5f4d31a9443ff298fc93b256397c4afc7fa4`; executing source `fc03c3b96b99ae309a3763ecbae07562a237ade5`. Both actual native queue cuts now recover across cancellation/SIGKILL: the original Start item and the generated WorkflowStarted checkpoint. Authenticated Workbench APIs publish the real ETL pipeline/closed RunEtl worker/direct BPMN model. An owned production-SDK client uses the existing drain-policy seam to enqueue only or drain one item, retaining the actual live model authority, full pins and original invocation/attempt/source. Public model cancellation records revision2/TerminalPendingSettlement while the same protected-family3 native envelope remains queued. Fresh standard Workbench hosts retire it without native header/activity/bookmark, invented worker result, ETL run or HTTP effect. The original native retirement commit ID is physically retained with no pending root-work outbox; the exact model retirement receipt at revision3 then precedes start/cancel acknowledgment. A third host stays unchanged for each cut. The first real queued captures exposed a missing flush boundary: an anonymous coalesced-flush marker replaced the logical retirement receipt. The existing checkpoint catalog now names NativeModelWorkStartRetired and its existing policy flushes it immediately; no new execution authority or participant is added. Both pre-fix actual captures are rejected, along with a fully rehashed anonymous-marker control. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/49cd5f4d31a9443ff298fc93b256397c4afc7fa4/specs/1017-direct-bpmn-hosting/evidence/pipeline/queued-native-retirement) binds two journeys,6 Workbench/2 SDK/2 HTTP processes,18 whole coupled stores and46 raw assets; all ten qualified children stopped. BPMN384/384, policy23/23, portable40/40, maps and test tiers123 pass, zero skips; the tracked Core constant builds with zero errors and all104 baseline assets/authoring fingerprint remain unchanged. Earlier undelivered-start, admitted-worker cancellation/ETL and embedding receipts retain their own sources/limits. Next qualify simultaneous native admission/cancellation, then pending native result/cancel cuts, RunBpmn service embedding, held retry, provider/rollback and final affected-source upgrade/Studio acceptance. T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. GitGuardian size-skip/neutral and owner-deferred incident39189012 remain unresolved before merge. CLA remains queued/non-required under current org policy; actual required checks must be audited at merge. Orleans/task-runner remain deferred.

## #3410 6501677260 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6502218085 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6502221084 elsa-workflows-codex[bot] 2026-10-29T16:21:29Z
[Codex] On behalf of @sfmskywalker.

Head `2182c310ae6a60abb7633e52e6c328fdc637d757`; executing source `54d8532b0a00c39626185a7d617790004b9f9448`. Both actual native-admission/BPMN-cancellation commit orders now survive SIGKILL and fresh standard Workbench recovery. The owned SDK queues the genuine WorkflowStarted checkpoint; a pass-through existing validation hook records and gates the first unchanged real proposal before its provider transaction. Cancellation-first commits model revision2, then the real EF SQLite writer defers the stale revision1 native proposal; cold recovery retains the original rootless retirement marker and exact NotAdmitted receipt before start/cancel ACK. Admission-first commits the real native header/root scheduling while cancellation still observes revision1, then releases unchanged cancellation; cold recovery cancels that actual worker and retains its exact native result/model consumption receipt at revision3. A third host is unchanged in each case. The existing SDK two-cycle budget stops before root invocation: no ETL run/HTTP effect in these races; earlier admitted-worker/ETL cancellation keeps its own source. No production semantic change or abstraction was needed. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/2182c310ae6a60abb7633e52e6c328fdc637d757/specs/1017-direct-bpmn-hosting/evidence/pipeline/native-admission-race) binds2 cases,6 Workbench/6 SDK/2 HTTP processes,18 whole stores/56 raw assets; all14 qualified children and rejected/superseded attempts stopped. BPMN384/384, focused EF model checkpoint43/43, portable51/51 with10 new rehashed negative controls, maps and test tiers123 pass, zero skips. All104 frozen baseline assets/authoring fingerprint remain unchanged. Next actual pending result/cancel process cuts, then RunBpmn service embedding, held retry, provider/rollback and final affected-source upgrade/Studio. T027/T029/T031/T034–T041 and #2898/#2907/program stay incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. GitGuardian size-skip/neutral and owner-deferred incident39189012 remain unresolved before merge; non-required CLA does not block under current org policy. Orleans/task-runner remain deferred.

## #3410 6502234470 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6502452125 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6502455236 elsa-workflows-codex[bot] 2026-10-29T16:31:42Z
[Codex] On behalf of @sfmskywalker.

Head `5611d0dccf75a0c561f0bbb051f908167fc256f3`; executing source `b2251d591944fd89663748edac064b07cea89aa4`. Two actual admitted-ETL cancellation/result cuts now survive a second SIGKILL and fresh standard-host recovery. Both begin with the published direct BPMN/native RunEtl/HTTP429 journey, two completed sibling effects and the original frozen retry. In the model-command cut, public BPMN cancel commits revision2/TerminalPendingSettlement and its original native-cancel source while native/ETL remain active; the second host is killed before worker delivery. In the native-terminal cut, public native CancelWorkflow has committed actual native Cancelled plus the same-checkpoint ETL-cancel/BPMN-result sources, both owed; the model is still Running at revision1 without native-result consumption. After the second process loss, the third standard host settles the original worker/ETL/model and exact receipts before acknowledgment; a fourth host stays unchanged through the original HTTP retry deadline plus2 seconds. The two earlier HTTP effects remain; no late retry/owed output occurs. The actual ETL result uses ProvenParentTerminal for the already-cancelled native parent, not fabricated typed consumption. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/5611d0dccf75a0c561f0bbb051f908167fc256f3/specs/1017-direct-bpmn-hosting/evidence/pipeline/pending-cancellation) binds2 cases,8 Workbench/2 HTTP processes,4 actual SIGKILL exits,18 whole stores/51 raw assets; all10 children stopped. Source-matched standard host build has zero errors; portable61/61 with9 new rehashed negative controls pass, zero skips; all104 frozen baseline assets/authoring fingerprint remain unchanged. No production semantic change or new abstraction was needed. Earlier BPMN384/EF model43/race receipts retain executing source54d8532b0; these counts are not relabelled as new-source test runs. Next actual post-consumption/pre-ACK process loss, then RunBpmn service embedding, held retry, provider/rollback and final affected-source upgrade/Studio. T027/T029/T031/T034–T041 and #2898/#2907/program stay incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block under org policy. Orleans/task-runner remain deferred.

## #3410 6502469043 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6503017790 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6503045272 elsa-workflows-codex[bot] 2026-10-29T16:57:04Z
[Codex] On behalf of @sfmskywalker.

Head `efb0ac3c09aca350d09bef05a76a58ee8162d67c`; executing source `d1bd08c33f436764eaca5a5c69017f14a3ea85d5`. Both actual admitted-ETL cancellation origins now survive model consumption followed by source-ACK loss. The standard first host runs published direct BPMN/native RunEtl to a real HTTP429 wait with two completed sibling effects, then loses its process. After public model/native cancellation, an owned production-SDK client uses the original bindings/stores, actual outbox processors and protocol-aware recovery mailboxes: it delivers the original ETL cancellation, queues the original native result without ACK, and commits its exact model input receipt. The consumed-phase whole stores prove ETL/native already Cancelled and model TerminalSettled at revision3/2, while the original fenced native-result source remains FailedRetryable/unacknowledged; model-originated cancellation also retains its original cancel ACK as owed. The second standard host then loses its process through SIGKILL. Fresh third/fourth standard hosts acknowledge those exact sources without a new model revision or input receipt, clear the ordinary native recovery wake, and stay unchanged past the saved HTTP retry deadline plus2 seconds. Two earlier HTTP effects remain, zero late retries; actual ETL terminal delivery uses ProvenParentTerminal. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/efb0ac3c09aca350d09bef05a76a58ee8162d67c/specs/1017-direct-bpmn-hosting/evidence/pipeline/consumed-before-ack) binds2 cases,8 Workbench/2 SDK/2 HTTP processes,4 actual SIGKILL exits,24 whole stores/65 raw assets; all12 qualified and all rejected/superseded children stopped. Source-matched standard host build0 errors, portable71/71 with9 new rehashed controls, maps/test tiers123 and all104 frozen baseline assets/authoring fingerprint pass. First SDK native-coalescing misuse was correctly refused; the fixed client uses normal protocol-aware mailboxes. A read-only completed-work observer was also fixed. No production semantic change or new architecture was needed. Earlier BPMN384/EF model43 receipts retain source54d8532b0. Next RunBpmn service embedding/native-parent mappings, then held retry, provider/rollback and final affected-source upgrade/Studio. T027/T029/T031/T034–T041 and #2898/#2907/program stay incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block. Orleans/task-runner remain deferred.

## #3410 6503061760 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6503983531 elsa-workflows-codex[bot] 2026-10-29T17:39:45Z
[Codex] On behalf of @sfmskywalker.

Head `14a6fb5a3041517cd8662373dfe4aee544c17ad1`; executing source `b6e7e1f0de7367f81d35aebc5016d4b91e2d7927`. Real native RunBpmn → native RunEtl → HTTP journeys now complete and whole-parent cancel under Root, Sequence, Flowchart and CompensationScope after HTTP429/SIGKILL/restart. The existing pin/dependency and delivery boundaries admit the native-service profile; explicit runtime model formats5/6 retain service parent/cancellation responsibility and refuse parent settlement while worker cancellation is owed. Actual success consumes typed RunEtl and RunBpmn results, then commits exact native-parent settlement before source ACK; cancellation waits for actual downstream ETL cancellation and exact native result before parent settlement. Four HTTP records remain per success; cancellation retains two prior effects and no late retry past the original deadline on another host. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/14a6fb5a3041517cd8662373dfe4aee544c17ad1/specs/1017-direct-bpmn-hosting/evidence/pipeline/embedded-native-recovery) binds8 embedded cases plus1 actual same-source direct success counterpart:54 whole stores/190 raw assets,27 Workbench/9 HTTP children, all36 stopped. Actual waiting/final interpreter states match direct success for all4 parents, normalizing only the self-referential work handle; process/binding contracts and12 captured first-party product hashes match. Each publication retains its own exact checked pins. Source-matched host build0 errors, BPMN391/391, all8 actual human embedding host regressions, portable84/84 with12 new rehashed controls, maps/test tiers123 and104 unchanged frozen baseline assets pass. Two rejected Sequence attempts exposed an expected asynchronous-admission HTTP404 observer issue; the controller was fixed and original failed stores retained. Pending parent-result/source-ACK crash recovery, business/technical-fault mappings, held retry, races, other providers/rollback and final affected-source upgrade/Studio remain open. T025/T027/T029/T031/T034–T041 and #2898/#2907/program stay incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block. Orleans/task-runner remain deferred.

## #3410 6503995220 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6503999797 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6504212828 elsa-workflows-codex[bot] 2026-10-29T17:50:06Z
[Codex] On behalf of @sfmskywalker.

Head `aef0d539b80f1147761f18b773be5678f2dd1d82`; executing source `ef833d12dc288202bf6e538884837b6e2526dc7e`. Cancelled native RunBpmn parents now recover their original model return across a second actual SIGKILL under Root, Sequence, Flowchart and CompensationScope. After the real HTTP429/first SIGKILL and public outer-parent CancelWorkflow, an owned source-matched production-SDK client uses the original outbox processors and recovery mailboxes to consume embedded cancellation, actual worker/ETL cancellation and its exact native result. Complete parent-pending stores retain ETL/native/outer parent Cancelled, model revision3/TerminalPendingSettlement with downstream cancellation settled, original ResumeNativeParent source Pending, no parent-settlement receipt, and native-result/embedded-cancel/worker-cancel source ACKs still FailedRetryable/fenced/owed. No state/result/receipt/ACK is fabricated. Second SIGKILL then fresh third/fourth standard hosts settle revision4 and ACK original sources without changing interpreter payload or previous receipts;2 earlier HTTP effects remain/0 late retries past the original deadline plus2 seconds. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/aef0d539b80f1147761f18b773be5678f2dd1d82/specs/1017-direct-bpmn-hosting/evidence/pipeline/pending-native-parent-return) binds4 cases/36 whole coupled stores/120 raw assets,16 Workbench/4 SDK/4 HTTP children, all24 stopped. Source-matched host/SDK builds0 errors and portable94/94 with9 new rehashed controls pass;104 frozen baseline assets/authoring fingerprint unchanged. No production semantic change was needed. Earlier service success/cancel and same-source direct comparison retain sourceb6e7e1f0d:8 embedded+1 direct/54 stores/190 assets/all36 children stopped, BPMN391/human-host8/maps/tiers123 passed there, not rerun for capture-tool changes. Next successful parent-result consumption/pre-ACK crash, business/technical-fault mappings, held retry, races, other providers/rollback and final affected-source upgrade/Studio. T025/T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; exact-head CI pending. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block. Orleans/task-runner remain deferred.

## #3410 6504219215 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6504231779 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6505024228 elsa-workflows-codex[bot] 2026-10-29T18:27:46Z
[Codex] On behalf of @sfmskywalker.

Head `6cd8483e6888d95864ee270c62c9f0bf43cced0e`; executing source `cdef9b87e136ac082fbf1ef332ca3abb115a0018`. Successful native RunBpmn→RunEtl→HTTP return now survives second actual SIGKILL at all3 boundaries under Root/Sequence/Flowchart/CompensationScope: pending original parent wait at model r2/PendingSettlement; typed RunBpmn consumption with exact settlement queued at r2; and accepted model settlement r3/TerminalSettled with original parent source ACK still fenced/owed. Original native-result ACK also remains owed, with its unchanged accepted r2 receipt. Native workflow headers are still Running at all12 cuts: child consumption/model settlement are distinct from native workflow completion. Fresh third/fourth standard hosts finish original native continuations/successors, settle/ACK exact original sources, clear queues and retain4 physical HTTP records with0 additional effects or model/previous-receipt changes. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/6cd8483e6888d95864ee270c62c9f0bf43cced0e/specs/1017-direct-bpmn-hosting/evidence/pipeline/successful-native-parent-return) binds12 cases/108 whole coupled stores/348 raw assets,48 Workbench/12 SDK/12 HTTP children, all72 stopped;37 rejected/superseded children also stopped. The SDK composes existing native activity/CLR/parent modules and serialization/type registry;14 source-matched product identities, no background worker or synthetic state/result/receipt/ACK. No production semantic change was needed. Source-matched standard host/SDK build0 errors, portable106/106 with11 new rehashed controls, maps/test tiers123 and104 unchanged frozen baseline assets pass. Earlier service/cancellation/direct comparisons and BPMN391/human-host8 receipts retain their original sources. Compatibility gap found while refreshing remote CI: prior pushed aef0d539b failed LegacyBroadcastUpgradeTests.Actual_saved_broadcast_cuts_recover_their_exact_recipients_and_retire_normally twice in integration-other, propagating Full tier failure, waiting on saved recipient14iZz9Wu7V8. A focused local run reproduces it on unchanged production source; it is not a retry/quarantine pass or resolved by this new matrix. Next diagnose/fix that saved legacy-broadcast recovery, then business/technical-fault mappings, held retry, races, other providers/rollback and final affected-source upgrade/Studio. T025/T027/T029/T031/T034–T041, #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR rounds0 of6; new exact-head CI pending and previous compatibility CI red. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block or authorize signing. Orleans/task-runner remain deferred.

## #3410 6505030021 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6505043605 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6505467589 elsa-workflows-codex[bot] 2026-10-29T18:47:35Z
[Codex] On behalf of @sfmskywalker.

Head `208bcab970e9864ddff987332f5657f066cd1f44`; executing source `4716b51ec75284efa2b85fdf3b36a5125571335b`. Fixed and requalified the saved legacy-broadcast upgrade failure that failed twice in aef0d539b integration-other CI and reproduced locally. Actual failed API/whole-store evidence showed both original native waits still Suspended with blocking EfSchemaWriteRefusedException: revision-only exact-resume owner-header touches retained storage1 while the admitted host writer required2. Exact bookmark resume and model-parent wait metadata touches now use the existing family version selector, preserving the write guard, version floor, native ContentJson, live-owner/CAS checks and conditional atomicity. No schema hold/finalization override, timeout extension, retry/quarantine pass or new protocol. Held-v1/current-v2 provider controls prove unchanged native JSON and exact revision advance; the active-v2 control failed before the fix. Focused EF resume/model/schema106/106, all8 actual RunBpmn human-model host regressions and all4 original saved-broadcast cuts pass, zero skips. [Evidence](https://github.com/elsa-workflows/elsa-foundation/tree/208bcab970e9864ddff987332f5657f066cd1f44/specs/1017-direct-bpmn-hosting/evidence/upgrade/broadcast-header-schema) retains the original failed counterexample plus12 fresh standard Workbench processes/8 whole upgraded stores; all12 stopped. Actual delivery-time recipient/source snapshots, empty/rearm decisions, keyed starts, immutable pins/artifacts and migration history remain correct through recovery/retirement and another process. Both actual published BPMN descriptors match the frozen authoring fingerprint; all104 baseline assets/manifest unchanged. The earlier12 successful parent return cuts/108 stores/348 assets/portable106 and service/cancellation/direct comparisons retain their executing sources, especially cdef9b87e, rather than being relabelled as final-source qualification. Next business/technical-fault mappings, pinned held retry, remaining timer/broadcast/race arms, provider/retention/rollback and final affected-source upgrade/Studio. T025/T027/T029/T031/T034–T041 and #2898/#2907/program remain incomplete/open/partial; goal active. Draft/full-PR rounds0 of6. New exact-head remote CI pending; old CI failure is not called green from local results. Owner-deferred GitGuardian incident39189012 remains unresolved before merge; non-required CLA does not block and is not signed. Orleans/task-runner remain deferred.

## #3410 6505469023 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6505488399 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6506143350 elsa-workflows-codex[bot] 2026-10-29T19:18:40Z
[Codex] On behalf of @sfmskywalker.

Head `552ef47398194f6b7b6c8c0759bbf4c06102203a`; executing source `d55964a76139349eeff722501df473401cce204d`. Delivered coded service-error boundaries through released BPMN0.5.0 semantics, with exact terminal-worker proof required before any cancellation command can be retired. No binding DTO/state format/native authoring descriptor or persisted writer changed for this increment.

Ten actual HTTP429/SIGKILL/restart journeys qualify matching/nonmatching codes directly and under native RunBpmn Root/Sequence/Flowchart/CompensationScope, plus another standard process retaining identical state and effects. ETL always retains3 accepted/1 rejected, safe-error output and typed native BusinessError. Matching code takes the modeled error path and completes; a different code retains BPMN Faulted/errorCode etl.rows-rejected. Native dispositions remain distinct: Root/Sequence fault with a blocking child incident; Flowchart also faults its composite and retains both incidents; default CompensationScope absorbs the fault and completes Compensated with Resolved/AbsorbFault. No unmatched forward successor runs. Sequence composite Running is observed, not ratified; #3242 remains undecided.

[Portable evidence](https://github.com/elsa-workflows/elsa-foundation/tree/552ef47398194f6b7b6c8c0759bbf4c06102203a/specs/1017-direct-bpmn-hosting/evidence/pipeline/business-error-native-recovery):60 whole stores/204 qualifying raw assets, complete pins, original invocation/attempt/registration and exact worker consumption/native parent settlement/source-ACK proofs. Waiting/final interpreter states and12 captured first-party product versions/hashes compare across direct/all parents; only the model self work handle is normalized. Thirty standard Workbench processes/ten HTTP fixtures/all40 listed children stopped. Three rejected controller expectations retain46 additional assets/18 integrity-checked stores at their original sources; all41 rejected/superseded listed children stopped. Those corrected observer assumptions did not change native fault/compensation policy or extend timeouts.

Next real technical final-fault mapping and pinned bounded held retry, then remaining timer/model-broadcast/race/provider/retention/rollback and final affected-source upgrade/Studio. T039/T040 and other open acceptance, #2898/#2907/program remain incomplete/open/Partial; goal active. Draft/full-PR rounds0 of6. New exact-head CI pending; no skipped/neutral check is called green. Owner-deferred GitGuardian39189012 remains unresolved before merge; non-required CLA is not signed. Orleans/task-runner remain deferred.

## #3410 6506148973 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6506163322 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6506796470 elsa-workflows-codex[bot] 2026-10-29T19:51:00Z
[Codex] On behalf of @sfmskywalker.

Head `edeaca12e2cede1a68628a957deb3996fdff145b`; executing source `5533b8367c7fe78850677fcebf5c7fcb0f2e7e27`. Five actual default technical-fault journeys now recover through direct BPMN and native RunBpmn Root/Sequence/Flowchart/CompensationScope. After a real HTTP429/SIGKILL cut with two physical output effects, only the owned retained CSV lookup snapshot is temporarily renamed. The immutable source stays available; unchanged snapshot bytes are restored only after all hosts stop. No SQL row, clock, ETL classifier or production runtime writer was changed.

ETL and its original native RunEtl worker retain Faulted / etl.snapshot-read-failed. BPMN feeds an uncoded technical fault to released0.5.0 semantics; the etl.rows-rejected boundary does not catch it. Exact worker result, model consumption, native parent settlement and source ACK survive. Root/Sequence workflows fault, Flowchart also faults its composite, and default CompensationScope preserves Completed/Compensated with Resolved/AbsorbFault. No forward successor runs; #3242 remains undecided. A third standard host keeps state/effects unchanged past the original HTTP retry deadline plus two seconds.

[Portable evidence](https://github.com/elsa-workflows/elsa-foundation/tree/edeaca12e2cede1a68628a957deb3996fdff145b/specs/1017-direct-bpmn-hosting/evidence/pipeline/technical-fault-native-recovery): five cases/30 whole stores/117 qualifying raw assets, complete pins and original invocation/attempt/registration. Waiting/final interpreter states compare across direct/all parents, normalizing only the self work handle;12 captured first-party product versions/hashes match. Fifteen Workbench processes/five HTTP fixtures/all20 listed children stopped. Two diagnostic counterexamples retain28 assets/12 integrity-checked stores at original sources; all30 rejected listed children stopped. They preserve the observed HTTP400 BusinessError classification and completed-versus-waiting shard distinction, rather than changing either to force a technical fault. Physical lookup binding/preparation/key/hash and original CSV bytes are verified. The original format2 model material/content hash is retained before policy changes.

Next implement the approved pinned bounded HoldForRetry path before feeding semantic fault: retain active token/state and original failed-run evidence, inspect the exact current incident, and authorize one new physical attempt through the shared checkpoint/outbox. Model-held retry and a model retry command's final-state refusal remain unproved. Remaining timer/model-broadcast/race/provider/retention/rollback/final affected-source upgrade/Studio acceptance remains open. T036/T037/T039/T040 and #2898/#2907/program remain incomplete/open/Partial; goal active. Draft/full-PR rounds0 of6. Owner-deferred GitGuardian39189012 remains unresolved before merge; non-required CLA is not signed. Orleans/task-runner deferred.

## #3410 6506806260 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6506819808 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6507618221 elsa-workflows-codex[bot] 2026-10-29T20:30:20Z
[Codex] On behalf of @sfmskywalker.

Head `bd8a7d0fc78e26d243058de77d810d4df5062624`. [Actual held-service retry](https://github.com/elsa-workflows/elsa-foundation/tree/bd8a7d0fc78e26d243058de77d810d4df5062624/specs/1017-direct-bpmn-hosting/evidence/pipeline/held-service-retry), executing source `25bec5ade15d98fa4be0259acdb522e2bd07ff95`, now works directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. The pinned HoldForRetry/two-total-attempt policy captures real native/ETL Faulted / etl.snapshot-read-failed before feeding a terminal semantic fault. Revision2/WaitingIncident retains the exact active interpreter token/state, original failed worker/result and native parent registration. After a second real SIGKILL, externally repairing the unchanged lookup bytes does not revive that attempt. One authorized retry at revision3 admits one different physical worker and ETL run for the same semantic invocation. Identical retry content replays; conflicting content returns409.

The replacement accepts four records and completes the model and original native parent. Failed ETL/native truth, native fault incident, pre-failure state and exact original consumption remain immutable. Both worker result sources and native parent settlement/ACK are proved; actual parent successors run once. A fourth standard host retains identical API/checked views and wire effects. Five journeys/45 whole stores/166 qualifying raw assets;20 Workbench/five HTTP processes/all25 listed children stopped. All12 captured first-party product versions/hashes match, with direct/parent interpreter traces equal after only the self work-handle normalization. Six physical HTTP records include a repeat of the original two successful effects: at-least-once delivery remains explicit.

Versioned format3 policy and state7–10 refuse older drivers; old formats1/2 retain their wire. The actual pre-policy format2 material still produces its original content hash; all104 frozen baseline assets and manifest remain unchanged. Local validation at d2e62a1ab: BPMN411/411, human-host9/9, portable149/149 including21 new positive/corrupt-copy controls; maps/123 tiers pass, zero skips. Source-matched standard-host build0 errors. New exact-head CI is pending. No final affected-source upgraded-host, retention/rollback or Studio acceptance is inferred.

Next prove budget exhaustion and cancellation while held, then obsolete-result and authorization-before-replay controls and remaining timer/model-broadcast/race/provider/retention/rollback/final upgrade/Studio gates. T036/T037 and #2898/#2907/program remain incomplete/open/Partial; goal active. Existing claim6461197535/PR3410 retained. Full-PR review rounds0 of6; incomplete draft. Owner-deferred GitGuardian39189012 and the size-skipped security scan remain unresolved before merge; non-required CLA is not signed. #3242 remains undecided; Orleans/task-runner deferred.

## #3410 6507637180 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6507638757 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6507817664 elsa-workflows-codex[bot] 2026-10-29T20:40:30Z
[Codex] On behalf of @sfmskywalker.

Head `b97d357be248668308f6d689cac646ae12308599`. [Actual cancellation while held](https://github.com/elsa-workflows/elsa-foundation/tree/b97d357be248668308f6d689cac646ae12308599/specs/1017-direct-bpmn-hosting/evidence/pipeline/held-service-cancellation), executing source `a4098bd1a23a1e975c82ebefb7334ba7c9a2bfd4`, now works directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. After real HTTP429/process loss and authentic etl.snapshot-read-failed, revision2/WaitingIncident preserves the exact active semantic token and original Faulted ETL/native worker. A second SIGKILL retains that held failure. Restoring unchanged lookup bytes does not revive it. The public cancel command retires model work/incident at revision3 without changing the original failed invocation, fault incident, result receipt, pre-failure interpreter snapshot or two prior HTTP effects.

No new physical worker, ETL run or HTTP effect appears. No cancellation is sent to the already-faulted worker. Every original native RunBpmn registration consumes cancellation; parent workflows become Cancelled and forward successors do not run. Exact parent settlement reaches model revision4. The parent's normal CancelEmbedded source acknowledges existing terminal model responsibility without another model input. The parent-return source is acknowledged after its exact settlement receipt. Retrying the actual retired incident returns409 and retains Rejected/execution-terminal at unchanged terminal revision. A fourth standard host preserves identical checked/API views, retired incident and wire effects.

Five actual journeys/45 whole stores/166 raw assets,20 Workbench/five HTTP processes, ten actual SIGKILL exits; all25 listed children stopped. Full immutable model/worker/parent pins, protected headers, typed consumption, source ACK, old ETL invocation/lookup preparation and native fault incident are checked in physical stores. Direct/all-parent interpreter histories compare after only the self work-handle normalization; all12 captured first-party product versions/hashes match. No SQL state, clock, ETL classifier or production .NET writer changed. Source-matched standard host build0 errors, portable161/161 including12 new positive/corrupt-copy controls, maps/123 tiers and104 unchanged frozen baseline assets/manifest pass; zero skips. Earlier BPMN411/human-host9 retain source d2e62a1ab; they are not relabeled as this controller-only increment.

The previous one authorized held retry and explicit final-fault refusal remain retained at their original sources. This closes the held-cancellation arm only. Next budget exhaustion, then obsolete-result and authorization-before-replay controls, remaining timer/competing-input/model-broadcast/provider/retention/rollback/final affected-source upgrade/Studio evidence. T036/T037 and #2898/#2907/program remain incomplete/open/Partial; goal active. Existing claim6461197535/PR3410 retained. Full-PR review rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and size-skipped security scan remain unresolved before merge; non-required CLA is not signed. #3242 undecided; Orleans/task-runner deferred.

## #3410 6507827609 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6507843961 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6508120030 elsa-workflows-codex[bot] 2026-10-29T20:55:40Z
[Codex] On behalf of @sfmskywalker.

Head `5a6b5c476288fa3a018b78fb4c33a0859528c30d`. [Actual service budget exhaustion](https://github.com/elsa-workflows/elsa-foundation/tree/5a6b5c476288fa3a018b78fb4c33a0859528c30d/specs/1017-direct-bpmn-hosting/evidence/pipeline/service-budget-exhaustion), executing source `f781ae7750d1d21d55793e11a4a781fecf0c90a0`, now works directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. The pinned policy allows two total physical attempts. Real HTTP429/process loss and etl.snapshot-read-failed leave attempt1 held at revision2/WaitingIncident with its exact active semantic snapshot. A second SIGKILL retains that state. After restoring the unchanged snapshot, one authorized retry admits one different worker/run for the same semantic invocation. Its temporarily unavailable original bound lookup source produces a genuine preparation fault, etl.binding-read-failed, before runnable partitions or new HTTP effects exist.

Attempt1 remains Retried and attempt2 becomes Final. Both failed native/ETL invocations, complete pins, native incidents, original result receipts and source ACK remain immutable. The final uncoded fault reaches BPMN at revision4, or revision5 after exact native parent settlement. Further retry of the actual final incident returns409 and retains Rejected/execution-terminal at unchanged revision; no third worker/run appears. Restoring the unchanged bound input after the failed host stops and starting a fourth standard host does not revive either attempt. The original two HTTP effects remain/zero additional effects.

Native Root/Sequence/Flowchart workflows retain Faulted; Sequence's composite remains Running, Flowchart faults both activities. Default CompensationScope preserves Completed/Compensated with Resolved/AbsorbFault. No forward successor runs. Exact typed RunBpmn consumption, parent settlement and parent-return ACK persist. These preserve observed projections; #3242 remains undecided.

Five actual journeys/45 whole stores/176 raw assets,20 Workbench/five HTTP processes, ten actual SIGKILL exits; all25 listed children stopped. Full material/policy/native dependency closure, both physical fault roots, original ETL preparation and actual replacement preparation failure, complete native incident inventory and all consumed/ACKed sources are checked. Waiting/held/final interpreter histories compare directly/all parents after only self work-handle normalization; all12 first-party product versions/hashes match. Source-matched standard host build0 errors, portable176/176 including15 new positive/corrupt-copy controls, maps/123 tiers and104 unchanged frozen assets/manifest pass; zero skips. No production .NET writer, SQL state, clock, classifier or input bytes changed. Earlier BPMN411/human-host9 retain source d2e62a1ab; not relabeled here.

Previous successful held retry, held cancellation and explicit final refusal remain retained at their sources. Next obsolete-result and authorization-before-replay controls, then remaining timer/competing-input/model-broadcast/provider/retention/rollback/final affected-source upgrade/Studio evidence. T036/T037 and #2898/#2907/program remain incomplete/open/Partial; goal active. Existing claim6461197535/PR3410 retained. Full-PR review rounds0 of6; incomplete draft/new exact-head CI pending. Deferred GitGuardian39189012 and size-skipped security scan remain unresolved before merge; non-required CLA is not signed. Orleans/task-runner deferred.

## #3410 6508138414 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6508155174 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6508992400 elsa-workflows-codex[bot] 2026-10-29T21:41:58Z
[Codex] On behalf of @sfmskywalker.

Head `1ea988decda8154cb1b2a7bcbdffc2a8c37d3236`. [Actual retry authorization/recovery](https://github.com/elsa-workflows/elsa-foundation/tree/1ea988decda8154cb1b2a7bcbdffc2a8c37d3236/specs/1017-direct-bpmn-hosting/evidence/pipeline/retry-authorization), executing source `1a10565935b568e42c8431158bfafe77b571c775`, now passes directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. Each real held ETL/native fault survives two SIGKILLs; one authorized retry admits exactly one new physical worker/run, completes the same semantic invocation, retains its original failed attempt and exact source receipts/ACK, and remains stable in a fourth standard host. External HTTP effects remain at least once: six records include the previous two again.

Four normal password-backed Identity accounts per case use stored roles, exact bounded read/retry permissions and default/foreign tenant scopes. Across355 real HTTP probes and60 actual sign-ins, anonymous requests return401; read-only users inspect without retrying; retry-only users replay the exact accepted receipt without reading; no-permission/foreign users receive concealed denials without retained outcomes. Existing/unknown command denials match. The same boundaries hold before retry, after acceptance and after the fourth host. Accounts use the ordinary Identity user/role services, normal HTTP login and production authorization; no fake authentication handler or execution-state seeding.

Next obsolete-result refusal while the replacement attempt is live, then remaining timer/competing-input/model-broadcast/provider/retention/rollback and final affected-source upgrade/Studio evidence. Earlier successful retry/cancellation/budget/final-fault receipts keep their executing sources. Native composite fault decision#3242 remains undecided. T036/T037 and #2898/#2907/program remain open/Partial; existing claim6461197535/PR3410 retained. Full-PR rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and neutral size-skipped scan remain unresolved before merge; non-required CLA remains unsigned. Orleans/task-runner deferred.

## #3410 6509012710 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6509016715 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6509214672 elsa-workflows-codex[bot] 2026-10-29T21:54:43Z
[Codex] On behalf of @sfmskywalker.

Head `2aa0d612ed51b316c3db97c24f76a498a8357f8e`. [Actual obsolete-result controls](https://github.com/elsa-workflows/elsa-foundation/tree/2aa0d612ed51b316c3db97c24f76a498a8357f8e/specs/1017-direct-bpmn-hosting/evidence/pipeline/obsolete-service-results), executing source `9380009b86f3ceb383b7b58b6317b2a90f94b17d`, now pass directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. Each journey retains a real held ETL/native fault across two SIGKILLs, then one authorized retry admits a different physical worker/run for the same semantic invocation. The owned HTTP fixture gives that replacement its own real429/Retry-After20 wait after two output effects, so the probes execute while it is still active.

The normal production model mailbox accepts an exact replay of the original failed result without replacing its revision2 receipt or advancing the revision3 replacement. Conflicting old content and an unchanged old result sent to a new input address both refuse before durable admission. Across15 actual transports, the active model/work/attempt, original fault/receipt/source ACK and empty model queue remain unchanged. Complete coupled stores prove the old ETL run remains Faulted beside the live replacement. Standard hosts subsequently finish exactly that replacement and original native RunBpmn parent, retain exact typed consumption/settlement/ACK, and stay stable through a fourth host. Six physical HTTP records include the prior two again; effects remain at least once.

Next real timer interruption and competing retry/cancel commit orders, then remaining model-broadcast/provider/retention/rollback/final affected-source upgrade/Studio evidence. #3242 remains undecided. T036/T037 and #2898/#2907/program remain open/Partial; existing claim6461197535/PR3410 retained. Full-PR rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and neutral size-skipped scan remain unresolved before merge; non-required CLA remains unsigned. Orleans/task-runner deferred.

## #3410 6509235292 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6509236005 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6510128407 elsa-workflows-codex[bot] 2026-10-29T22:39:14Z
[Codex] On behalf of @sfmskywalker.

Head `99b7eca5b4d6bf25ac4550e543fb6132d23b49bb`. [Actual runtime-only human/duration recovery](https://github.com/elsa-workflows/elsa-foundation/tree/99b7eca5b4d6bf25ac4550e543fb6132d23b49bb/specs/1017-direct-bpmn-hosting/evidence/races/human-duration), executing source `a2c2e47751d595c9489f889593ed4d7427ef6076`, now proves both human-first and timer-first orders through production authenticated Workbench hosts. The original human wait and real30-second boundary timer survive SIGKILL/restart with their exact invocation, attempt, pin, deadline and committed source. The first winner reaches revision2 and survives another process loss. The third host rejects the original late timer/human input as execution-terminal at unchanged revision2; timer source ACK follows its exact receipt. A fourth host retains identical checked model/input/source/queue and API views. Two journeys/eight whole Runtime stores/28 raw assets/eight stopped Workbench children, all exit137. No native workflow/activity/bookmark carrier or Design storage exists.

Definition4 adds explicit timer bindings; state11/12 retains their exact deadline/source. Foundation uses the existing delayed outbox, with deadline equal to accepting checkpoint UTC plus duration and independent model eligibility validation. Human completion cannot fire a timer. The released0.5.0 library owns token/interruption semantics. Existing definition1-3 wire and older private frames remain supported;104 frozen baseline assets and the original manifest are unchanged. Direct date/cycle timers remain outside the profile. Real worker/timer and held-failure interruption are not inferred from these human journeys.

Source-matched BPMN431/431, actual duration-host2/2, existing human-host9/9 and native-service host1/1 pass. Portable tools27/27 include13 new positive/corrupt-copy controls; existing ETL208/208, maps and123 tiers pass, zero skips. Standard host build0 errors. Removing only the deadline guard makes the actual-source eligibility regression fail; exact restoration precedes the qualifying build. Initial native-only DI and timed-human admission findings were fixed before these actual captures. Binaries, observer, source identity, both winner diagnostics and physical receipts/deadlines/ACK/native-row absence are checked.

Next real worker/timer orders and held-failure interruption, then competing retry/cancel commits and remaining direct-model broadcast/provider/retention/rollback/final affected-source upgrade/Studio evidence. #3242 remains undecided. T020/T023/T024 and broader tasks, #2898/#2907/program remain open/Partial; claim6461197535/PR3410 retained. Full-PR rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and neutral size-skipped scan remain unresolved before merge; non-required CLA remains unsigned. Orleans/task-runner deferred.

## #3410 6510159676 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6510172092 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6510721704 elsa-workflows-codex[bot] 2026-10-29T23:13:20Z
[Codex] On behalf of @sfmskywalker.

Head `fd11a9831faa2613ca5742bf9f2306f107edd4f5`. [Actual ETL worker/duration recovery matrix](https://github.com/elsa-workflows/elsa-foundation/tree/fd11a9831faa2613ca5742bf9f2306f107edd4f5/specs/1017-direct-bpmn-hosting/evidence/races/service-duration), executing source `8dc088bae4463b8a9279a1f25036ac14b1715cd6`, now proves worker-first, timer-first and interruption of a held failure directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. Fifteen actual production Workbench journeys retain488 raw assets and135 coupled whole stores. All75 listed children are stopped (60 Workbench/15 HTTP fixtures);30 predecessor exits are actual SIGKILL. No execution state or clock was edited.

Each original ETL/native worker first receives actual HTTP429 after its sibling delivers two records. Worker-first Retry-After20 completes four records before the60-second boundary and later rejects the original timer without advancing. Timer-first uses10/60 seconds: the real boundary cancels the original native worker and ETL run, preserves their actual Cancelled result and settles the original cancellation; no delayed HTTP retry occurs. Held interruption uses90/20 seconds: the unchanged lookup snapshot is temporarily unavailable, producing genuine etl.snapshot-read-failed and held revision2. That semantic snapshot survives another SIGKILL and repair of the identical external file. The timer retires the exact incident and completes its boundary route while preserving the original native/ETL fault; a later retry is409 with no new attempt. Every native parent consumes its original typed Done result, runs its successor once where present and settles the model before source ACK. A fourth host retains identical model/worker/ETL/incident/API/receipt/source/queue and HTTP views.

Portable ETL224/224 including16 new positive/corrupt-copy controls, BPMN tools27/27, standard source-matched host build0 errors, maps/123 tiers and104 unchanged frozen baseline assets/original manifest pass, zero skips. Production duration code did not change; prior BPMN431 and actual human/timer2, human-host9/native-service1 results retain sourcea2c2e4775. These ordered worker/timer decisions do not establish simultaneous competing commits.

Next actual simultaneous retry/cancel commit orders, then remaining direct-model broadcast/provider/retention/rollback/final affected-source upgrade/Studio evidence. #3242 remains undecided. T020/T023/T024 and broader tasks, #2898/#2907/program remain open/Partial; claim6461197535/PR3410 retained. Full-PR rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and neutral size-skipped scan remain unresolved before merge; non-required CLA remains unsigned. Orleans/task-runner deferred.

## #3410 6510739525 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6510743475 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6510967816 elsa-workflows-codex[bot] 2026-10-29T23:29:37Z
[Codex] On behalf of @sfmskywalker.

Head `ddc1d02c62629ea88cc6ede78b1edf1baaafd36f`. [Actual concurrent held retry/cancel recovery](https://github.com/elsa-workflows/elsa-foundation/tree/ddc1d02c62629ea88cc6ede78b1edf1baaafd36f/specs/1017-direct-bpmn-hosting/evidence/races/held-command-race), executing source `7414d8a13ee6cd2f65923914065b075602437ca2`, now proves retry-first and cancel-first directly and through native RunBpmn Root/Sequence/Flowchart/CompensationScope. Ten production journeys retain412 raw assets and120 coupled whole stores. All70 listed children stopped (40 Workbench/20 SDK/10 HTTP fixtures);20 predecessor exits are actual SIGKILL. This increment changes capture/verification only; no production semantics or execution state/clock edits.

Each original ETL/native worker receives real HTTP429 after its sibling delivers two records, loses its host, then genuinely faults on the temporarily unavailable unchanged lookup snapshot. Exact held interpreter/failure state at revision2 survives a second SIGKILL. After identical external-file repair, one production-SDK process pauses its unchanged real proposal at the existing commit hook. A separate SDK process queues the competitor and acquires successor ownership. The protected FIFO head prevents a second proposal; the first writer cannot commit with its stale fence. Both original inputs remain pending in their exact queue order with unchanged held state. Physical stores retain the greater successor fence and both real queue payloads before cold recovery.

Fresh standard hosts consume retry-first as exact retry revision3, cancellation revision4 and positive replacement non-admission retirement revision5. Original start/cancel ACKs follow the exact retirement receipt; no new native worker or ETL run is admitted. Cancel-first retires the failure at revision3 and rejects the queued retry as execution-terminal at unchanged revision. Both retain the original native/ETL fault and two prior HTTP effects, with no additional effects. All native parents consume their original typed Cancelled result, remain Cancelled, run no successor and settle the model before return ACK. A fourth host retains identical model/worker/ETL/incident/API/receipt/source/queue and wire views. This proves actual concurrent admission, stale ownership refusal and both protected FIFO decision orders, without bypassing the queue or manufacturing two simultaneous provider proposals.

Next direct-model broadcast delivery-time recipient snapshot/rearm/process-loss, provider/retention/rollback and final affected-source upgrade/Studio evidence. #3242 remains undecided. T023/T024/T025 and broader tasks, #2898/#2907/program remain open/Partial; claim6461197535/PR3410 retained. Full-PR rounds0 of6; incomplete draft/new exact-head CI pending. Owner-deferred GitGuardian39189012 and neutral size-skipped scan remain unresolved before merge; non-required CLA remains unsigned. Orleans/task-runner deferred.

## #3410 6510982529 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6510988758 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6511202415 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6511225352 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6511252793 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6511274206 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6511842883 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6511881570 elsa-workflows-codex[bot] 2026-10-30T00:31:01Z
[Codex] On behalf of @sfmskywalker.

Head `51605da8389712dc2d1e5f65e73110d03b72ec4e` adopts current main and the catalog compatibility repair. The owner merged [PR3453](https://github.com/elsa-workflows/elsa-foundation/pull/3453) as `b9cf52c181b79e3e79eef233f7d61cb0843f4da7` after the reviewed-head required Build & test / Generated maps fresh / Full tier succeeded. It is not recorded as a Codex self-merge. The existing configured #3261 compensation-sample quarantine did fail; it remains open and is not relabelled as a passing test. The other PR/full-tier outcome summaries have no failed-twice, retry-pass or aborted results. Owner-closed #3452 is retained as closed; [resulting-main CI40978933651](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40978933651) is still pending, so resulting-main health is not yet claimed.

Next concrete journey: actual bound Event waits behind model-owned signal catches, using the existing native-work result/address bridge and durable first-delivery cohort. Code inspection confirms that the native bridge already captures generic typed root results and that Event/PublishEvent owns the existing named-event wait/send path. This is a candidate to qualify, not a direct-signal acceptance claim. The current direct profile still refuses signal constructs before runnable publication. Implement the explicit pin-backed event binding, then prove two catches, a listener created after publication/before first delivery, listener rearm and original source retry/pre-ACK process loss. Add delivery contracts only if that actual journey exposes a missing guarantee. T021 and broader acceptance remain open.

Retained #2898 claim6461197535, branchagent/codex/2898-direct-bpmn-hosting and PR3410; no competing execution-model PR. #2898/#2907/program remain open/Partial; PR3410 full-review rounds0 of6, incomplete draft. Provider/retention/rollback/final affected-source upgrade/Studio, #3242 decision, owner-deferred GitGuardian39189012 and program scan gate remain unresolved. Non-required CLA stays unsigned. Orleans/task-runner remain deferred.

## #3410 6511903872 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6512225518 elsa-workflows-codex[bot] 2026-10-30T00:55:51Z
[Codex] On behalf of @sfmskywalker.

Head `71975cdff12b39748a7dbebe3442f88990335320`; actual signal-host source `8a1aa37942393923b4f55330d6da75a1d5eb5b12`. [Five real signal journeys](https://github.com/elsa-workflows/elsa-foundation/tree/71975cdff12b39748a7dbebe3442f88990335320/specs/1017-direct-bpmn-hosting/evidence/events/signal-recovery) now prove direct BPMN/native Root/Sequence/Flowchart/CompensationScope start → two signal catches → SIGKILL → restart → actual PublishEvent delivery → typed EventResult consumption → complete, followed by another stable cold host. The model owns progression; its two real published Event workers retain original full pins and exact model invocation/attempt origins. The original durable native Event cohort contains exactly their captured registrations. Every native parent gets typed Done, consumes/settles before result-source ACK, and continues once where present. Thirty whole Runtime/Design stores,79 qualification assets and15 owned SIGKILLed Workbench processes are retained.

Definition format5 adds only explicit pin-backed native Event bindings and reuses the existing native-work bridge/opaque frames2/5 and Event cohort. Formats1–4 and104 frozen baseline assets/original manifest remain unchanged. The real first run exposed two incorrect binding assumptions (stable published Elsa.Event key and absent correlation literal); they were fixed before successful qualification. Twenty-seven diagnostic assets, including18 failed stores and the incorrect-source-label interrupted run, remain explicitly excluded. Whole BPMN456/456, actual signal hosting5/5 and portable14/14 (including13 rehashed corrupt-copy controls) pass, zero skips. Core builds, maps and123 tier registrations pass. No new general recipient ledger or event bus.

Next: the real delivery-time later-listener, rearm/pre-ACK retry and installed-empty-cohort cuts. T021 remains unchecked; these positive signal journeys do not substitute for those gates. Further shared delivery contracts will be added only if actual journeys expose a missing guarantee. Prior timer/concurrent held-command/ETL/upgrade/Studio receipts keep their executing sources; no final upgraded-host or Studio compatibility is inferred.

Retained #2898 claim6461197535, branchagent/codex/2898-direct-bpmn-hosting and draft PR3410. #2898/#2907/program remain open/Partial; formal full-PR review rounds0 of6, incomplete. Required new-head CI and resulting-main CI40978933651 are pending. Owner-merged PR3453/#3452 closure is retained; the earlier configured #3261 compensation quarantine is not relabelled as passing. Provider/retention/rollback/final affected-source upgrade/Studio, #3242 decision, owner-deferred GitGuardian39189012 and the program scan gate remain open. Non-required CLA stays unsigned. Orleans/task-runner remain deferred.

## #3410 6512227580 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6512242755 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6512369028 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6513106571 elsa-workflows-codex[bot] 2026-10-30T02:01:10Z
[Codex] On behalf of @sfmskywalker.

Head `7dc385868391805726750f57774565b8dbf55c71`. [Three actual saved-source model signal cuts](https://github.com/elsa-workflows/elsa-foundation/tree/7dc385868391805726750f57774565b8dbf55c71/specs/1017-direct-bpmn-hosting/evidence/events/model-broadcast) now qualify the settled delivery-time matching rule through real Event workers and the existing native-work bridge. Executing source `6bde6e8ff3606244a8708d476cc662cacb04418b` proves partial callback → real model rearm before source ACK → process loss → higher-fence original-source retry. Source `791dc17016a6b6022a0413820fe61eb202c52afc` proves delayed first selection includes two registrations created after publisher commit, and a durably installed empty cohort excludes newly armed waits. Production files are identical between these sources. Each of the three cuts retains four owned SIGKILLed hosts, including a separate normal consumer while the original sender is deliberately held;55 qualification assets/18 complete Runtime-Design stores/12 hosts total. The later listener and original rearmed wait stay unchanged, the original saved cohort is never replaced, and another cold process retains the result. The two finite models in delayed selection complete with exact typed Event results.

No new common recipient ledger or duplicate signal semantics was needed for this profile. Model invocation/attempt/material origins address real published native Event work; its saved registration cohort supplies retry protection. Released BPMN0.5.0 products, full pins/registration generations, pre-ACK claim freshness, real lease expiry, consumption-before-ACK and actual stores are retained. Sixteen portable checks pass, including15 rehashed corrupt-copy controls. Forty-eight prototype diagnostic assets remain separate; successful cuts have no observer retries. Earlier attempts exposed live snapshot/Python SQLite observation limitations and the need for a separate normal consumer during the artificial pause; those failures are not relabelled as green. The actual finite two-catch/four-native-parent qualification retains source8a1aa3794,5 journeys/30 stores/15 hosts, BPMN456/456 and host5/5. Its14 portable checks include13 corrupt controls. Current maps/123 tiers/104 frozen baseline assets pass; original manifest unchanged. Native cohort wire/fingerprints remain unchanged.

Resulting-main [CI40978933651](https://github.com/elsa-workflows/elsa-foundation/actions/runs/40978933651) succeeded at owner-mergeb9cf52c after PR3453; owner-closed #3452 remains closed. All9 downloaded outcome artifacts match that exact main SHA and have no failed-twice, retry-pass or aborted tests. The configured #3261 compensation-sample quarantine did fail; it remains a failure and is not called a pass. EF container shards were skipped, so this is not provider qualification. Program-head required checks remain pending and separate. No self-merge attribution or CLA signature.

Next actual work: bound Event-worker interruption and sibling settlement, then remaining retention/provider/activation and final affected-source upgrade/Studio gates. T021 remains unchecked; the new cuts qualify its exact-recipient arm, not broader delivery acceptance. #2898/#2907/program remain open/Partial with retained claim6461197535, branchagent/codex/2898-direct-bpmn-hosting and draft PR3410. Formal full-PR review rounds0 of6; no competing PR or program-complete claim. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain open. Orleans/task-runner remain deferred.

## #3410 6513120278 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6513125890 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6513438663 elsa-workflows-codex[bot] 2026-10-30T02:26:15Z
[Codex] On behalf of @sfmskywalker.

Head `ba3efcccfe9e734f069d910912967b82ac5a5245`; actual fixed host source `c40881fd0209dd1f2e8765358c3afd3f007247ab`. [Real bound Event-worker sibling cancellation](https://github.com/elsa-workflows/elsa-foundation/tree/ba3efcccfe9e734f069d910912967b82ac5a5245/specs/1017-direct-bpmn-hosting/evidence/events/sibling-cancellation) reproduces and fixes an orphan before delivering the multi-catch profile. At red source `8d5ed3e03b228d866b26606a81e063839af183f6`, cancelling one Event worker settled the model at revision2 while its sibling remained Running; the four-store red capture is retained, not relabelled. The fixed journey restores both actual waiting stores captured at791dc1701, preserves original material/incarnation/worker pins across process loss, then uses the normal native CancelWorkflow API. Revision2 durably stages cancellation of the original sibling and stays TerminalPendingSettlement; its exact Cancelled result settles revision3. Both workers are Cancelled.

The real second SIGKILL occurs after both model result receipts are committed while the sibling-cancel source and both native-result sources remain FailedRetryable/unacknowledged. A third standard host acknowledges those original sources after their exact consumption receipts without changing the model. Six successful complete Runtime/Design stores, three owned SIGKILLed hosts and17 raw assets retain this bounded post-consumption/pre-ACK recovery plus the original red repro. A crash while model settlement itself remains pending is not claimed. The fix reuses existing cancellation ports and frames4/6 through one private staging helper; no new public contract, state format or common ledger. Whole BPMN456/456, actual host1/1 and portable10/10 (nine rehashed corrupt controls) pass, zero skips; maps/123 tiers/104 frozen baseline assets and original manifest remain unchanged.

Earlier finite5-parent signal recovery keeps source8a1aa3794; delivery-time/rearm/empty-cohort cuts keep6bde6e8ff/791dc1701 and their18 stores/12 hosts. All earlier native/ETL/timer/concurrency/upgrade/Studio receipts keep their sources. [The previous recipient checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6513106571) remains valid. No final upgraded-host or Studio acceptance is inferred.

Next: embedded/native-parent sibling interruption and pending-model-settlement crash, then remaining retention/provider/activation/rollback and final affected-source upgrade/Studio. T021 and broader #2898/#2907/program acceptance stay open/Partial; retained claim6461197535, branchagent/codex/2898-direct-bpmn-hosting and draft PR3410. Formal full-PR review rounds0 of6; new-head required CI pending. Owner-merged base PR3453/mainb9cf52c passed CI40978933651 with the recorded existing #3261 quarantine failure and skipped EF containers; those are not passing-test/provider claims. #3452 stays owner-closed. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain unresolved. Non-required CLA stays unsigned; Orleans/task-runner deferred.

## #3410 6513440997 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6513454574 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6513870125 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6513873036 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6513875880 elsa-workflows-codex[bot] 2026-10-30T03:00:22Z
[Codex] On behalf of @sfmskywalker.

Head `336071d006f80be9f935510fdb6a74f8075bc560`. [Actual pending Event-sibling cancellation recovery](https://github.com/elsa-workflows/elsa-foundation/tree/336071d006f80be9f935510fdb6a74f8075bc560/specs/1017-direct-bpmn-hosting/evidence/events/pending-sibling-interruption) now passes directly and under RunBpmn Root, Sequence, Flowchart and CompensationScope, executing source `f4c923ed9bb01f764e648ee45d1c76b081f51098`. The normal native CancelWorkflow API cancels one real Event worker. Its result commits model revision 2 as TerminalPendingSettlement with the original sibling still Running and cancellation durably owed. A test-only pause holds the original fresh cancellation claim before dispatch; the owned host is SIGKILLed. A standard host recovers after natural lease expiry, reclaims that same source with a higher fence, cancels the original sibling and consumes its exact result. Direct BPMN settles revision 3; native parent consumption/settlement finishes revision 4 without running successors. Another SIGKILL and third standard host retain identical model, worker, parent and source observations. Pins, material incarnation, original source addresses and interpreter history survive; no state or clock is seeded or edited.

Five journeys retain 30 complete Runtime/Design stores, 107 qualifying assets and 15 owned SIGKILLed hosts; all are stopped. Successful runs needed zero collector retries. The first Direct attempt at `0dc96a38f` recovered cancellation but its final retained backup was refused: its 19 assets/six whole diagnostic stores remain excluded from acceptance. The collector now records refused reads and retries a complete coupled capture after resuming the real transaction. Standard/probe/reader builds have zero errors and committed raw logs. Portable checks pass 13/13, including 12 rehashed corrupt controls; maps, all 123 tier registrations and the original 104 frozen baseline assets/manifest pass. Every one of the 130 manifest assets is tracked and pushed, including the initially ignored build logs. Production files are unchanged from the real orphan fix at `c40881fd0`; the earlier BPMN 456/456 and actual cancellation host 1/1 receipts retain that executing source.

The [earlier post-consumption/pre-ACK checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6513438663), delivery-time recipient snapshots/rearm/empty-cohort cuts, finite signal, ETL, timer, concurrency and upgrade/Studio receipts keep their own sources and limits. This adds the actual pending-model crash/native-parent sibling witness; it does not claim final upgraded-host or Studio acceptance.

Next: remaining retention/provider/activation/rollback checks, final affected-source upgrade/Studio and consolidated acceptance mapping, then complete-PR review. #2898, #2907 and program #2892 stay open/Partial. Existing claim 6461197535, branch `agent/codex/2898-direct-bpmn-hosting` and draft PR #3410 continue; full-PR review remains 0 of 6 rounds and new-head required CI is pending. The confirmed goal statement remains current on #2892 and Project #62. #3242, owner-deferred GitGuardian incident 39189012 and the program scan gate remain unresolved; CLA is non-required and unsigned. Orleans/task-runner remain deferred. Base main `b9cf52c` keeps its successful CI 40978933651 with the recorded #3261 quarantine failure and skipped EF container shards; neither is relabelled as passing/provider coverage.

## #3410 6513893266 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6514476707 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6514553467 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6514565144 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6514567054 elsa-workflows-codex[bot] 2026-10-30T03:55:19Z
[Codex] On behalf of @sfmskywalker.

Head `7ff5367ae3d245136c2e0085594d04e0f17cf5e2`. [Actual publication retention and admission-off/runtime-only recovery](https://github.com/elsa-workflows/elsa-foundation/tree/7ff5367ae3d245136c2e0085594d04e0f17cf5e2/specs/1017-direct-bpmn-hosting/evidence/retention/runtime-only-rollback) passes directly and under RunBpmn Root, Sequence, Flowchart and CompensationScope at executing source `2e142e51055aa2d84c0839dffb49b3621489d9ce`. Revision 1 commits both original native Event-worker obligations before dispatch. The SDK calls the existing publication-retirement and reference-collector ports over these private actual stores: the unreferenced control artifact/source is collected, while every owed model/worker/parent pin, incarnation and retired provenance survives. Both workers remain unadmitted at the captured cut and the original native-start claim is fresh. No execution, queue, claim, receipt or clock is edited.

Next: physical provider/migration and remaining compatibility checks, final affected-source legacy/Studio qualification, consolidated acceptance mapping and full-PR review. Existing actual native/ETL, timer/race, finite signal/broadcast, cancellation and older upgrade/Studio receipts keep their sources and limits; [previous checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6513875880). #2898, #2907 and program #2892 stay open/Partial. Retained claim6461197535, existing branch/draft PR #3410; formal complete-PR rounds0 of6. New-head required CI and resulting-main CI40996404025 at927f91e51 remain pending, not green. No new human reviews/holds were found. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain unresolved; non-required CLA stays unsigned. Orleans/task-runner stay deferred. The confirmed goal remains unchanged.

## #3410 6514585147 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6515058536 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6515059404 elsa-workflows-codex[bot] 2026-10-30T04:34:35Z
[Codex] On behalf of @sfmskywalker.

Head `de0e800384b91268827af674e195b1097455dd45`. [Model storage and additive migration qualification](https://github.com/elsa-workflows/elsa-foundation/tree/de0e800384b91268827af674e195b1097455dd45/specs/1017-direct-bpmn-hosting/evidence/providers/model-storage) passes71/71 with zero skips at executing source `26aef90429532f26c41907d8b8d8a743b9837b8f`:18 cases on private PostgreSQL/SQL Server/MySQL containers and53 focused SQLite cases. T011 is now checked for the declared common-provider storage gate, with explicit fixture/host limits. No production code or public contract changed.

The physical final-marker observer sees model state, input receipt and outbox rows already saved inside the transaction, with consumed queue absent and marker absent. An injected marker-insert failure rolls every participant and the execution-fence touch back; a fresh context retains the original protected claim. Normal commit/replay consumes once. Other cases refuse stale fences/revisions, reused input IDs and conflicting replay without partial state; exact old replay does not overwrite later progress. Running and TerminalSettled receipt-only cases preserve model JSON/revision. Strict native-provider mode and removed external connection-string overrides ensure all three engines actually run in test-owned containers, with no skipped-provider pass.

Main advanced legitimately: owner-merged PR #3461's compact activity-definition header is adopted as base `07f3e4f2a0835a325b1a8280f731940645a80032` in merge `de0e800384b91268827af674e195b1097455dd45`. Earlier main PR #3460's resource cleanup remains included. The actual standard Workbench legacy-host qualification is now running on this combined head against the original complete captures, with fresh source-bound evidence output. It is not yet a pass. T041's final legacy/Studio qualification, remaining compatibility/public-profile reconciliation, consolidated acceptance mapping, complete-PR review and required CI remain open.

All earlier actual direct/native/ETL, race/broadcast, pending cancellation and admission-off/runtime-only retention receipts keep their executing sources and limits; [previous checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6514567054). #2898/#2907/program #2892 remain open/Partial under existing claim6461197535 and draft PR #3410. Formal review rounds0 of6; new-head required CI and resulting-main CI41002383046 remain pending. No human holds/reviews were found. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain unresolved. Non-required CLA stays unsigned; Orleans/task-runner stay deferred. Broader provider/Studio/program acceptance is not inferred from these technical tests.

## #3410 6515076384 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6515275158 elsa-workflows-codex[bot] 2026-10-30T04:52:19Z
[Codex] On behalf of @sfmskywalker.

Head `d46c8d080274d1d47adfbbbe0b8f94cb757d9180`. [Final affected-runtime legacy and existing Studio compatibility](https://github.com/elsa-workflows/elsa-foundation/tree/d46c8d080274d1d47adfbbbe0b8f94cb757d9180/specs/1017-direct-bpmn-hosting/evidence/final-compatibility) is committed and T041 is checked. The actual standard Workbench legacy suite passes 7/7 with zero skips at `de0e800384b91268827af674e195b1097455dd45`; six separately verified families retain 33 resulting whole stores. Both actual saved Studio families execute at `905b6a491d4372fda5c1b71607d1edbc37020c06`, retaining twelve stores and four new complete executions. All 22 original whole-store inputs are bound to their unchanged capture hashes, and all 104 frozen assets remain unchanged.

The final actual Studio browser journey opens each saved definition, exports JSON/XML, changes only the gateway label, saves, reviews and publishes versions 3.0.0/4.0.0, runs the exact published artifact and a separate Test Run through the real native Delay, inspects old and new executions, restarts the isolated Workbench and reopens the same run. Initial exports match exactly. New runs have two completed activities, no incidents/waits; full stored pins, old/new API views, retained original 84/92 native executable payloads/incarnations and published five-node layout survive. Twelve screenshots were visually inspected. The controller now uses the existing .NET SQLite reader for coupled backups while only its owned Workbench is paused, with full process identity and read-only snapshot receipts. No execution, queue, claim, receipt or clock is seeded. All 47 listed legacy/Studio host processes stopped; user hosts and existing browser tabs were preserved.

This completes T041's affected SQLite legacy-host/existing embedded-BPMN Studio repeat for the current runtime. Non-SQLite actual-host upgrades and first-class direct-model Studio #2907 are not inferred. Draft Test Runs retain existing empty layout-sidecar behavior; saved/published layout is checked separately. Development sign-in still required explicitly reopening the owned Studio URL after return to Workbench root; automatic return-URL support is not claimed. The earlier [71/71 physical storage/migration gate](https://github.com/elsa-workflows/elsa-foundation/tree/d46c8d080274d1d47adfbbbe0b8f94cb757d9180/specs/1017-direct-bpmn-hosting/evidence/providers/model-storage), real model/native/ETL recovery, broadcast, sibling-cancellation and runtime-only rollback receipts retain their own executing sources and limits; [previous checkpoint](https://github.com/elsa-workflows/elsa-foundation/pull/3410#issuecomment-6515059404).

Next: T042 public API/profile/XML/provider/rollback/composition reconciliation and T043 concise FR/SC/#2898 mapping, then task/spec closeout and the full independent complete-PR review loop. Draft PR #3410 remains open under the retained Codex claim; formal complete-PR rounds remain 0 of6. New-head required CI is pending, no human holds/reviews were found in the refreshed discussion, and no merge has occurred. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain unresolved; non-required CLA remains unsigned. #2898/#2907/#2892 and Project62 remain open/In Progress/Partial. Orleans/task-runner remain deferred; the program goal remains active.

## #3410 6515284230 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6515294719 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6515300199 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6515458298 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6515474060 elsa-workflows-codex[bot] 2026-10-30T05:08:20Z
[Codex] On behalf of @sfmskywalker.

Head `4d77feefdd55132f167c072f2163f10201cad886`. [T042 API/version and compatibility reconciliation](https://github.com/elsa-workflows/elsa-foundation/tree/4d77feefdd55132f167c072f2163f10201cad886/specs/1017-direct-bpmn-hosting/evidence/compatibility-reconciliation) is committed. The actual publish-state snapshot `f49ff392871e217896efdbfe8c208f10cece7365` and read-only calculator output at `fae8dce0d5177e987ca50affde428eec03303219` are retained with six hashed assets. Runtime Core adds177 tracked entries and Runtime adds4, with zero removals against both released previews and the current PR base. Existing provider extensions default to false/refusal. Existing BPMN public source files are unchanged; the adapter adds its hosting feature, RunBpmn, replacement port and typed activity records. No binary ApiCompat or automatic magnitude gate is claimed.

One genuine owner choice has been presented in a card: framework §4.2 classifies compatible Core additions as MINOR, while the configured pre-GA line computes Runtime.Core4.0.55-preview→4.0.56-preview. Every recorded package is still a preview; §E5 retains the magnitude rule while ADR0080 D4 keeps one pre-GA line. Recommendation: an explicit scoped preview-magnitude exception for PR3410's compatible additions, preserving the current4.0 line. Alternative: advance the repository shared line to4.1. No exception is assumed. T042 remains unchecked and PR3410/#2898 receive needs:decision; independent qualification and acceptance mapping continue. This is a version-policy decision, not a renewed claim/self-review/self-merge authorization question.

The API README now lists all9 routes/6 permissions including cancellation, incident inspection and exact retry. Core docs index declared formats1–5; catalogs describe actual protocol input kinds, native/model/ETL composition, timer/signal/settlement, provider tuple refusals and admission-off recovery. Root extension index no longer advertises retired Foundation element-behavior contributors. XML stays in the existing authored native envelope; no general XML-to-direct conversion is claimed. Quickstart/tool docs point to actual producers and final receipts instead of a nonexistent generic qualify phase or already-completed open gates. All276 changed-document relative paths and the160-file catalog link check pass. No production implementation or test code changed in this reconciliation.

Next independent work is T043 whole affected-project checks and the concise FR001–022/SC001–006/#2898 evidence mapping. Complete-PR rounds remain0 of6; latest-head required CI is pending. No merge occurred. #2898/#2907/#2892 and Project62 remain open/In Progress/Partial under the retained Codex claim/draft PR3410; the whole program goal remains active. Non-SQLite actual-host upgrades, distributed placement and first-class direct-model Studio acceptance are not inferred. #3242, owner-deferred GitGuardian39189012 and the program scan gate remain unresolved; non-required CLA stays unsigned. Orleans/task-runner remain deferred.

## #3410 6515485532 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6515490208 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6516144460 elsa-workflows-codex[bot] 2026-10-30T06:01:36Z
[Codex] On behalf of @sfmskywalker.

Head `78faee3b7c50bf6722209f939196db37b1425ff4`. [The actual paired partial-fork journey](https://github.com/elsa-workflows/elsa-foundation/tree/78faee3b7c50bf6722209f939196db37b1425ff4/specs/1017-direct-bpmn-hosting/evidence/embedding/parallel-native-recovery) closes a specific SC001/T019/T029 evidence gap: one immutable human parallel model runs directly and through Root/Sequence/Flowchart/CompensationScope; left completes before SIGKILL, the original right wait survives, the join and after-join work run once, both models complete, native continuation settles once, and another cold process preserves exact observations. Executing source `c34c1f4e1f279c66598a5ab83a8c2cc05e9b4a72`: four pairs/eight completed models,24 whole stores/52 qualifying assets/twelve killed owned hosts, plus13 passing portable controls. Observed model-local producer handles are the sole normalized state field, bound to physical invocation/attempt receipts; all semantic IDs/order/diagnostics/outcomes remain exact. The two earlier four-case observer failures and the negative-copy control failure remain separately diagnostic. No runtime change was required. All104 frozen authoring assets remain unchanged.

[Whole affected-project gates](https://github.com/elsa-workflows/elsa-foundation/tree/78faee3b7c50bf6722209f939196db37b1425ff4/specs/1017-direct-bpmn-hosting/evidence/delivery-gates/4d77feefd) retain12 complete projects/8061 passed/zero skipped at `4d77feefdd55132f167c072f2163f10201cad886`, including strict owned PostgreSQL/SQL Server/MySQL execution. All discoveries are accounted for, including five runtime-expanded theories. Locked graph restore, maps and123-project tiers pass. Portable ETL240/240 passes; portable BPMN173 passes with three explicitly unconfigured optional historical live-fixture probes, not176 passes. The expanded32-case hosting suite atc34 is still running; no result is assumed. Subsequent main changes are not covered by relabelling these source-bound receipts.

Fresh remote read shows no new human hold/review and retains the original Codex claim6461197535. Main now includes legitimate PR3462/3469/3448/3474 progress through `c986f9ddfdec2c641b2f1c1f5d8f82f8dd19e529`, including Workbench/Studio composition and editor changes. Adoption and affected verification follow; earlier T041 legacy/Studio passes retain their own exact sources. T043 acceptance mapping and task reconciliation are in progress, not yet checked.

The existing owner version-policy card remains unanswered: framework §4.2/§E5 magnitude versus the configured4.0 preview line. No scoped exception is assumed; T042 remains unchecked and needs:decision remains on PR3410/#2898. Complete-PR review remains0 of6, latest-head required CI is pending, no merge occurred. #2898/#2907/#2892 and Project62 remain open/In Progress/Partial under the existing draft PR. First-class direct-model Studio, non-SQLite actual-host upgrades and distributed placement are not inferred. Owner-deferred GitGuardian39189012 and the scan gate remain unresolved before merge; CLA stays unsigned. #3242, Orleans/task-runner and other existing deferrals remain unchanged. Program goal active.

Source-label correction:4d77feefd executed the8061-test run;78faee3b7 pushed its receipts. The committed receipts and their hashes already identified4d77feefd correctly.

## #3410 6516156022 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6516160872 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6516274647 elsa-workflows-codex[bot] 2026-10-30T06:11:24Z
[Codex] On behalf of @sfmskywalker.

Head `d7ee22b164bc04098bedde19e5b4722ed6f2b871` adopts legitimate main `c986f9ddfdec2c641b2f1c1f5d8f82f8dd19e529` (PR3462/3469/3448/3474) without conflicts. The existing Runtime README and [FR001–022/SC001–006/#2898 mapping](https://github.com/elsa-workflows/elsa-foundation/tree/d7ee22b164bc04098bedde19e5b4722ed6f2b871/specs/1017-direct-bpmn-hosting/evidence/qualification.md) now describe actual consumers, exact receipts, planned-path deviations and remaining limits. T041 is reopened for affected Workbench/Studio repetition after those main changes; its earlier exact-source legacy/Studio receipts remain valid historical evidence.

The expanded32-case hosting run atc34c1f4e1 finished31 passed/one failed/zero skipped, so it is not green. [Retained full-suite refusal](https://github.com/elsa-workflows/elsa-foundation/tree/d7ee22b164bc04098bedde19e5b4722ed6f2b871/specs/1017-direct-bpmn-hosting/evidence/delivery-gates/c34c1f4e1) and [focused physical diagnosis](https://github.com/elsa-workflows/elsa-foundation/tree/d7ee22b164bc04098bedde19e5b4722ed6f2b871/specs/1017-direct-bpmn-hosting/evidence/delivery-gates/called-ack-observer) preserve the failure. Focused reproduction first passed twice, then failed; repetition stopped on that failure. The original compiled checked reader over the retained whole closed database identifies its unchanged guard: the caller is Completed but the actual later terminal source is still Delivering with no deliveredAt. The fixture had stopped the sender before its durable ACK. The correction waits for real source acknowledgements before stopping the host; no receipt guard or runtime implementation is changed. Fixed-source actual qualification is in progress, not assumed green. The closed diagnostic database hash remained unchanged throughout read-only diagnosis.

The separately passed paired partial fork atc34 retains four direct/native parent pairs/eight completed models/24 whole stores/13 portable controls. The broad4d77feefd receipt retains12 projects/8061 passes/zero skips, strict owned native providers, locked graph/maps/discovery/tiers; portable ETL240 passes and BPMN173 passes plus three explicitly unconfigured optional live probes. Those results retain their sources and do not override the new refusal or qualify later main changes. All104 frozen assets/authoring fingerprint remain unchanged.

The version-policy owner card remains pending; no4.0 preview-magnitude exception or4.1 advance is assumed. T042 and T043 remain unchecked; needs:decision stays on PR3410/#2898. Complete-PR rounds0 of6, latest reviewed-head required CI and post-merge main verification are still open; no merge occurred. Original Codex claim6461197535/existing draft PR remain the only active leaf. #2898/#2907/#2892 and Project62 stay open/In Progress/Partial. First-class direct-model Studio, non-SQLite actual-host recovery and distributed placement are not inferred. GitGuardian39189012 remains owner-deferred and the scan gate unresolved before merge; CLA stays unsigned. #3242, Orleans/task-runner and existing program deferrals remain unchanged. Goal active.

## #3410 6516292185 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6516292555 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6516787387 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6516803129 elsa-workflows-codex[bot] 2026-10-30T06:50:20Z
[Codex] On behalf of @sfmskywalker.

Head `7cfbf739f0d4c3c220097918b04c2b33b5cb3bb3` commits the [affected-main qualification](https://github.com/elsa-workflows/elsa-foundation/tree/7cfbf739f0d4c3c220097918b04c2b33b5cb3bb3/specs/1017-direct-bpmn-hosting/evidence/main-adoption/d7ee22b16) with240 hashed receipt/diagnostic files; every asset was checked from its committed Git blob. Actual executing products remain `d7ee22b164bc04098bedde19e5b4722ed6f2b871`. This commit changes evidence/spec/task/review-index documentation, not the qualified production implementation. Mainc986f9ddf (PR3462/3469/3448/3474) is adopted.

At that exact executing source: whole hosting32/32 and Architecture594/594 pass, zero skips; discovery, maps and123-project tier/shard checks pass. All six actual legacy families/seven included host tests again recover the22 original whole-store inputs, retaining33 resulting whole stores. Four direct/native partial-fork pairs complete eight models after partial-progress SIGKILL/restart, retain24 stores and one logical join each. Both actual saved Studio families preserve exact opening JSON/XML and the five-node saved layout, change only gateway labels, publish versions3.0.0/4.0.0 and complete two Published Runs plus two Test Runs. Twelve coupled stores preserve all original views,84/92 native material payloads/incarnations and identical new full views/pins after restart. The two new bundles each pass13 portable positive/corrupt controls, zero skips. All63 listed owned hosts stopped:41 legacy,12 paired-fork, six primary Studio and four additional read-only Details inspection hosts. All104 frozen baseline assets and the authoring fingerprint remain unchanged. Initial authentication return to the Workbench root and existing Test Run draft layout-sidecar behavior remain declared limits; first-class direct-model Studio is not inferred.

[The consolidated FR001–022/SC001–006/#2898 index](https://github.com/elsa-workflows/elsa-foundation/tree/7cfbf739f0d4c3c220097918b04c2b33b5cb3bb3/specs/1017-direct-bpmn-hosting/evidence/qualification.md) and actual implementation paths are reconciled. T001–T041/T043/T044 are evidenced. The spec's Implemented status and checklist retirement are prepared in this implementation PR as required by lifecycle; shipped status becomes true only at merge. Broader #2907/#2908/program criteria are not closed. The older12-project8061/8061/zero-skip gate remains executing source4d77feefd, not its later78faee3b7 receipt-push head; the old checkpoint source label is corrected to match its already-correct committed receipts. Portable ETL240 and historical BPMN173 passes plus three unconfigured optional live probes retain their sources; they are not current-head CI.

T042 remains open for the pending owner version-policy card; no4.0 preview magnitude exception or shared4.1 advance is assumed. needs:decision remains on PR3410/#2898. Complete-PR rounds0 of6; independent full-PR review is next. Required exact reviewed-head checks, the scan gate/owner-deferred GitGuardian39189012, normal protected merge and resulting-main verification remain open; CLA stays unsigned. No merge occurred. Retained Codex claim6461197535/existing draft PR3410 remain the only active leaf. #2898/#2907/#2892 and Project62 stay open/In Progress/Partial; #3242 and Orleans/task-runner deferrals remain unchanged. Program goal active.

## #3410 6516830893 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6516922901 elsa-workflows-codex[bot] 2026-10-30T06:58:21Z
[Codex] On behalf of @sfmskywalker.

Complete-PR author review round1/6 — completed with five surviving findings; fixes and requalification are next. No clean review or merge clearance.

Reviewed head: `7cfbf739f0d4c3c220097918b04c2b33b5cb3bb3`; main merge base `c986f9ddfdec2c641b2f1c1f5d8f82f8dd19e529`. Independent correctness, standards and acceptance lenses inspected the complete PR and its issue/PR discussion, with no cross-lens output sharing. The author checked each finding against the code, ratified rule and reproduced evidence.

1. **P1 — Independent native-worker cancellation can settle BPMN before downstream ETL cancellation.** With no model-origin cancellation entry, an authentic Cancelled worker result skips the settlement guard. Normal production outbox/model drains over copies of actual captured stores accepted it at model revision2/TerminalSettled while its exact ETL cancel remained Pending and actual ETL remained Running. This is a transport-ordering gap, not loss of the durable transport. The earlier positive witness delivered ETL cancel first. Require exact downstream settlement for every Cancelled result, then qualify the reverse order and recovery.
2. **P2 — Invalid service retry can block a human model's FIFO.** A valid format4 timed-human model with explicit `serviceBindings: []` publishes and starts. An ordinary retry command naming its real human work throws at the premature `Single` service-policy lookup; following valid completion/cancel remain queued. The actual authenticated Workbench diagnostic retained revision1 and all three inputs. Reject ineligible retry durably before policy lookup and prove later commands progress.
3. **P2 — Protocol initialization event belongs in Runtime Core.** Contributions already work through the public port; the mandatory named event is internal in implementation. Move the existing event/payload to public Core, retaining one Sequential aggregator.
4. **P2 — Owned BPMN JSON failures need a contextual domain exception.** Malformed nested process JSON escapes the non-HTTP model-runtime/driver boundary as raw JsonException. HTTP already renders400, so no HTTP500 is alleged. Wrap at the owned boundary with BpmnModelValidationException, retaining inner cause and material/execution context.
5. **P3 — Rename the new returning registration port to Source.** Framework2.6.1 requires return-style sources to use that suffix. Rename the new unpublished interface and its registrations/API/catalog without changing historical evidence.

The two runtime counterexamples use the actual d7ee22b16 production implementation, unchanged at this reviewed head. No execution/queue/receipt/claim/clock was seeded or edited. The cancellation diagnostic used normal SDK/outbox paths over actual saved whole stores, not a new full HTTP-host qualification. The raw-JSON diagnostic used existing source-identical Release products at4d77feefd; it is not current-head CI. Reviewer reports and original red diagnostics will be retained with their source labels.

Reopening the service outcome/cancellation and human/incident command acceptance rows, plus affected completion/requalification tasks. Prior32 hosting/594 Architecture, six legacy families, eight partial models and four actual Studio runs remain valid source-scoped receipts; they do not cover these newly reproduced scenarios. Next: red-to-green regressions, fixes, actual ordering/recovery proof, adopt main3475 and repeat affected gates/Studio, then full-PR round2. One of six full rounds is now complete; spec/plan/task rounds are separate.

Existing Codex claim/PR retained, draft/open/In Progress/Partial. T042's unanswered version-policy card, needs:decision, owner-deferred GitGuardian39189012/scan gate and exact reviewed-head required checks remain holds. No settled authorization is asked again. #2907 and program2892 remain open; Orleans/task-runner remain deferred.

## #3410 6516946404 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6522065502 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6522221371 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6522237201 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6522266620 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6522328041 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6522411270 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6522529847 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6522561823 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6522862609 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6522891365 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6522933051 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6522960075 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6523625656 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6523806209 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6524212172 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6524213442 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6524243188 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6524412474 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6524424307 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6524444260 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6525411155 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6525464787 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6525491017 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6526294297 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6526295072 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6526324273 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6526582380 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6526601287 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6526616904 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6526885382 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6526888673 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6526919116 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6527502680 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6527685910 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6527694791 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6527722117 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6531837881 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6531853441 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6531861338 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6531928664 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6531931552 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6532114561 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6532120822 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6532140131 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6532336792 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6532359437 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6532508249 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6532510617 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6532537317 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6532585857 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6532985177 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6533167835 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6533172674 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6533484429 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6533493199 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6533508848 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6533520934 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6533875645 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6533878695 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6533899311 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6534095495 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6534156089 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6534511765 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6534581166 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6534597021 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6534603141 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6534682930 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6534696556 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6535635183 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6535644378 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6535646338 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6535726187 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6535744309 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6535753607 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6535761207 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6535925251 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6535938323 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6535950374 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6536190856 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6536223992 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6536246104 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6536651278 elsa-workflows-codex[bot] duplicate body already reviewed

## #3410 6536659390 dotnet-policy-service[bot] duplicate body already reviewed

## #3410 6536678691 dotnet-policy-service[bot] duplicate body already reviewed
